package com.moat.analytics.mobile.tjy;

import android.util.Log;
import com.moat.analytics.mobile.tjy.base.functional.a;

class C0023z implements ba {
    final /* synthetic */ ap f76a;
    final /* synthetic */ String f77b;
    final /* synthetic */ C0019v f78c;

    C0023z(C0019v c0019v, ap apVar, String str) {
        this.f78c = c0019v;
        this.f76a = apVar;
        this.f77b = str;
    }

    public a m86a() {
        if (this.f76a.b()) {
            Log.d("MoatFactory", "Creating NativeVideo tracker.");
        }
        return a.a(new ah(this.f77b, this.f78c.f65b, this.f76a));
    }
}
