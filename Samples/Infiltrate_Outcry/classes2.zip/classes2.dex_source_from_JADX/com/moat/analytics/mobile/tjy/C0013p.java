package com.moat.analytics.mobile.tjy;

import android.util.Log;
import android.webkit.ValueCallback;

class C0013p implements ValueCallback {
    final /* synthetic */ C0011n f55a;

    C0013p(C0011n c0011n) {
        this.f55a = c0011n;
    }

    public void m70a(String str) {
        if (str == null || str.equalsIgnoreCase("null") || str.equalsIgnoreCase("false")) {
            if (this.f55a.f48d.b()) {
                Log.d("MoatJavaScriptBridge", "Received value is:" + (str == null ? "null" : "(String)" + str));
            }
            if (this.f55a.f49e == -1 || this.f55a.f49e == 50) {
                this.f55a.m66g();
            }
            this.f55a.f49e = this.f55a.f49e + 1;
        } else if (str.equalsIgnoreCase("true")) {
            this.f55a.f49e = -1;
            this.f55a.m63e();
        } else if (this.f55a.f48d.b()) {
            Log.d("MoatJavaScriptBridge", "Received unusual value from Javascript:" + str);
        }
    }

    public /* synthetic */ void onReceiveValue(Object obj) {
        m70a((String) obj);
    }
}
