package com.moat.analytics.mobile.tjy;

import android.os.Build.VERSION;
import com.tapjoy.TJAdUnitConstants;
import org.json.JSONArray;
import org.json.JSONObject;

public class C0018u {
    private boolean f60a = false;
    private boolean f61b = false;
    private int f62c = 200;

    public C0018u(String str) {
        m72a(str);
    }

    private boolean m71a(JSONObject jSONObject) {
        try {
            if (jSONObject.has("ob")) {
                JSONArray jSONArray = jSONObject.getJSONArray("ob");
                int length = jSONArray.length();
                for (int i = 0; i < length; i++) {
                    if (jSONArray.getInt(i) == VERSION.SDK_INT) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    public void m72a(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            String string = jSONObject.getString("sa");
            boolean equals = string.equals("8ace5ca5da6b9adb3c0f055aad4a98c2aedf4bd7");
            if ((string.equals("on") || equals) && !m71a(jSONObject)) {
                this.f60a = true;
                this.f61b = equals;
            }
            if (jSONObject.has("in")) {
                int i = jSONObject.getInt("in");
                if (i >= 100 && i <= TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT) {
                    this.f62c = i;
                }
            }
        } catch (Exception e) {
            this.f60a = false;
            this.f61b = false;
            this.f62c = 200;
        }
    }

    public boolean m73a() {
        return this.f61b;
    }

    public boolean m74b() {
        return this.f60a;
    }

    public int m75c() {
        return this.f62c;
    }
}
