package com.moat.analytics.mobile.tjy;

import com.moat.analytics.mobile.tjy.base.exception.a;

class C0005g implements Runnable {
    final /* synthetic */ C0004f f31a;

    C0005g(C0004f c0004f) {
        this.f31a = c0004f;
    }

    public void run() {
        try {
            this.f31a.m39a("Shutting down.");
            this.f31a.f30l.b();
            this.f31a.f30l = null;
        } catch (Exception e) {
            a.a(e);
        }
    }
}
