package com.moat.analytics.mobile.tjy;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import com.moat.analytics.mobile.tjy.base.exception.a;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

abstract class C0004f {
    protected static final MoatAdEventType[] f19b = new MoatAdEventType[]{MoatAdEventType.AD_EVT_FIRST_QUARTILE, MoatAdEventType.AD_EVT_MID_POINT, MoatAdEventType.AD_EVT_THIRD_QUARTILE};
    protected boolean f20a;
    protected final Map f21c = new HashMap();
    protected final Handler f22d = new Handler();
    protected Map f23e;
    protected WeakReference f24f;
    protected WeakReference f25g;
    protected final a f26h;
    protected final ap f27i;
    private boolean f28j;
    private WeakReference f29k;
    private ad f30l;

    public C0004f(String str, a aVar, ap apVar) {
        this.f27i = apVar;
        this.f26h = aVar;
        m39a("Initializing.");
        this.f30l = new ad(str, apVar, aVar);
        this.f29k = new WeakReference(aVar.c());
        this.f28j = false;
        this.f20a = false;
    }

    private int m32a(AudioManager audioManager) {
        return audioManager.getStreamVolume(3);
    }

    private MoatAdEvent m33a(Map map) {
        return new MoatAdEvent(MoatAdEventType.fromString((String) map.get("type")), map.containsKey("playHead") ? (Integer) map.get("playHead") : MoatAdEvent.TIME_UNAVAILABLE, map.containsKey("adVolume") ? (Double) map.get("adVolume") : MoatAdEvent.VOLUME_UNAVAILABLE);
    }

    private void m36b(MoatAdEvent moatAdEvent) {
        m39a(String.format("Received event: %s", new Object[]{mo4a(moatAdEvent).toString()}));
        this.f30l.a(r0);
        MoatAdEventType moatAdEventType = moatAdEvent.eventType;
        if (moatAdEventType == MoatAdEventType.AD_EVT_COMPLETE || moatAdEventType == MoatAdEventType.AD_EVT_STOPPED || moatAdEventType == MoatAdEventType.AD_EVT_SKIPPED) {
            this.f21c.put(moatAdEventType, Integer.valueOf(1));
            m43c();
        }
    }

    protected abstract Map m37a();

    protected JSONObject mo4a(MoatAdEvent moatAdEvent) {
        if (Double.isNaN(moatAdEvent.adVolume.doubleValue())) {
            try {
                moatAdEvent.adVolume = Double.valueOf(m44d());
            } catch (Exception e) {
                moatAdEvent.adVolume = Double.valueOf(1.0d);
            }
        }
        return new JSONObject(moatAdEvent.toMap());
    }

    protected void m39a(String str) {
        if (this.f27i.b() || this.f20a) {
            Log.d("MoatVideoTracker", str);
        }
    }

    protected boolean m40a(Integer num, Integer num2) {
        return ((double) (num2.intValue() - num.intValue())) <= Math.min(750.0d, ((double) num2.intValue()) * 0.05d);
    }

    public boolean m41a(Map map, Object obj, View view) {
        boolean z = true;
        boolean z2 = false;
        if (map == null) {
            try {
                m39a("trackVideoAd received null adIds object. Not tracking.");
                z = false;
            } catch (Exception e) {
                a.a(e);
            }
        }
        if (view == null) {
            m39a("trackVideoAd received null video view instance");
        }
        if (obj == null) {
            m39a("trackVideoAd received null ad instance. Not tracking.");
            z = false;
        }
        if (z) {
            String str = "trackVideoAd tracking ids: %s | ad: %s | view: %s";
            Object[] objArr = new Object[3];
            objArr[0] = new JSONObject(map).toString();
            objArr[1] = obj.toString();
            objArr[2] = view != null ? view.getClass().getSimpleName() + "@" + view.hashCode() : "null";
            m39a(String.format(str, objArr));
            this.f23e = map;
            this.f24f = new WeakReference(obj);
            this.f25g = new WeakReference(view);
            mo5b();
        }
        z2 = z;
        m39a("Attempt to start tracking ad was " + (z2 ? "" : "un") + "successful.");
        return z2;
    }

    protected void mo5b() {
        Map a = m37a();
        Integer num = (Integer) a.get("height");
        m39a(String.format("Player metadata: height = %d, width = %d, duration = %d", new Object[]{num, (Integer) a.get("width"), (Integer) a.get("duration")}));
        this.f30l.a((View) this.f25g.get(), this.f23e, r3, num, r5);
    }

    protected void m43c() {
        if (!this.f28j) {
            this.f22d.postDelayed(new C0005g(this), 500);
            this.f28j = true;
        }
    }

    public void changeTargetView(View view) {
        if (this.f27i.b()) {
            Log.d("MoatVideoTracker", "changing view to " + (view != null ? view.getClass().getSimpleName() + "@" + view.hashCode() : "null"));
        }
        this.f25g = new WeakReference(view);
        this.f30l.a(view);
    }

    protected double m44d() {
        AudioManager audioManager = (AudioManager) ((Context) this.f29k.get()).getSystemService("audio");
        return ((double) m32a(audioManager)) / ((double) audioManager.getStreamMaxVolume(3));
    }

    public void dispatchEvent(MoatAdEvent moatAdEvent) {
        try {
            m36b(moatAdEvent);
        } catch (Exception e) {
            a.a(e);
        }
    }

    public void dispatchEvent(Map map) {
        try {
            m36b(m33a(map));
        } catch (Exception e) {
            a.a(e);
        }
    }

    protected boolean m45e() {
        return this.f21c.containsKey(MoatAdEventType.AD_EVT_COMPLETE) || this.f21c.containsKey(MoatAdEventType.AD_EVT_STOPPED) || this.f21c.containsKey(MoatAdEventType.AD_EVT_SKIPPED);
    }

    public void setDebug(boolean z) {
        this.f20a = z;
    }
}
