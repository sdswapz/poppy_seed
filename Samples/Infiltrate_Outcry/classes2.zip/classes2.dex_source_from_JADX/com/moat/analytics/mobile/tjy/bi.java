package com.moat.analytics.mobile.tjy;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import com.moat.analytics.mobile.tjy.base.functional.a;
import com.tapjoy.TJAdUnitConstants.String;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

class bi implements bh, C0000m {
    private View f0a;
    private final WebView f1b;
    private boolean f2c;
    private final C0010l f3d;
    private final a f4e;
    private final ap f5f;
    private a f6g;

    bi(View view, WebView webView, boolean z, a aVar, ap apVar) {
        this(view, webView, z, new C0011n(webView.getContext(), apVar), aVar, apVar);
    }

    bi(View view, WebView webView, boolean z, C0010l c0010l, a aVar, ap apVar) {
        com.moat.analytics.mobile.tjy.base.asserts.a.a(view);
        com.moat.analytics.mobile.tjy.base.asserts.a.a(webView);
        com.moat.analytics.mobile.tjy.base.asserts.a.a(aVar);
        com.moat.analytics.mobile.tjy.base.asserts.a.a(c0010l);
        if (apVar.b()) {
            Log.d("MoatViewTracker", "In initialization method.");
        }
        this.f4e = aVar;
        this.f0a = view;
        this.f1b = webView;
        this.f2c = z;
        this.f3d = c0010l;
        this.f5f = apVar;
        this.f6g = a.a();
    }

    private static String m2a(Rect rect) {
        int i = rect.left;
        return String.valueOf(new StringBuilder("{\"x\":").append(i).append(',').append('\"').append("y\":").append(rect.top).append(',').append('\"').append("w\":").append(rect.right - rect.left).append(',').append('\"').append("h\":").append(rect.bottom - rect.top).append('}'));
    }

    private static String m3a(Map map, boolean z) {
        StringBuilder stringBuilder = new StringBuilder("{");
        for (Entry entry : map.entrySet()) {
            String str = (String) entry.getKey();
            String str2 = (String) entry.getValue();
            if (stringBuilder.length() > 1) {
                stringBuilder.append(',');
            }
            stringBuilder.append('\"').append(str).append('\"').append(':');
            if (z) {
                stringBuilder.append('\"').append(str2).append('\"');
            } else {
                stringBuilder.append(str2);
            }
        }
        stringBuilder.append("}");
        return String.valueOf(stringBuilder);
    }

    private void m4a(Map map, String str, Rect rect) {
        map.put(str, m2a(m5b(rect)));
    }

    private Rect m5b(Rect rect) {
        float f = m10j().density;
        if (f == 0.0f) {
            return rect;
        }
        return new Rect(Math.round(((float) rect.left) / f), Math.round(((float) rect.top) / f), Math.round(((float) rect.right) / f), Math.round(((float) rect.bottom) / f));
    }

    private Rect m6c(Rect rect) {
        Rect k = m11k();
        if (!this.f0a.getGlobalVisibleRect(k)) {
            k = m11k();
        }
        k.left = Math.min(Math.max(0, k.left), rect.right);
        k.right = Math.min(Math.max(0, k.right), rect.right);
        k.top = Math.min(Math.max(0, k.top), rect.bottom);
        k.bottom = Math.min(Math.max(0, k.bottom), rect.bottom);
        return k;
    }

    private String m7g() {
        Exception e;
        if (this.f6g.c()) {
            return (String) this.f6g.b();
        }
        String str = "_unknown_";
        String charSequence;
        try {
            Context context = this.f1b.getContext();
            charSequence = context.getPackageManager().getApplicationLabel(context.getApplicationContext().getApplicationInfo()).toString();
            try {
                this.f6g = a.a(charSequence);
                return charSequence;
            } catch (Exception e2) {
                e = e2;
                com.moat.analytics.mobile.tjy.base.exception.a.a(e);
                return charSequence;
            }
        } catch (Exception e3) {
            Exception exception = e3;
            charSequence = str;
            e = exception;
            com.moat.analytics.mobile.tjy.base.exception.a.a(e);
            return charSequence;
        }
    }

    private boolean m8h() {
        return this.f0a.isShown() && !this.f4e.a();
    }

    private Rect m9i() {
        DisplayMetrics j = m10j();
        return new Rect(0, 0, j.widthPixels, j.heightPixels);
    }

    private DisplayMetrics m10j() {
        return this.f0a.getContext().getResources().getDisplayMetrics();
    }

    private Rect m11k() {
        return new Rect(Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE);
    }

    public String mo1a() {
        int i = 0;
        Map hashMap = new HashMap();
        try {
            Rect i2 = m9i();
            Rect c = m6c(i2);
            Rect e = m17e();
            m4a(hashMap, "screen", i2);
            m4a(hashMap, String.VISIBLE, c);
            m4a(hashMap, "maybe", c);
            m4a(hashMap, "view", e);
            if (m8h()) {
                i = 1;
            }
            hashMap.put("inFocus", String.valueOf(i));
            hashMap.put("dr", m10j().density);
            return m3a(hashMap, false);
        } catch (Exception e2) {
            return "{}";
        }
    }

    public void m13a(View view) {
        if (this.f5f.b()) {
            Log.d("MoatViewTracker", "changing view to " + (view != null ? view.getClass().getSimpleName() + "@" + view.hashCode() : "null"));
        }
        this.f0a = view;
    }

    public String mo2b() {
        try {
            return m3a(m18f(), true);
        } catch (Exception e) {
            return "{}";
        }
    }

    public boolean m15c() {
        if (this.f5f.b()) {
            Log.d("MoatViewTracker", "Attempting bridge installation.");
        }
        boolean a = this.f3d.mo7a(this.f1b, this);
        if (this.f5f.b()) {
            Log.d("MoatViewTracker", "Bridge " + (a ? "" : "not ") + "installed.");
        }
        return a;
    }

    public void m16d() {
        this.f3d.mo6a();
    }

    public Rect m17e() {
        int[] iArr = new int[]{Integer.MAX_VALUE, Integer.MAX_VALUE};
        this.f0a.getLocationInWindow(iArr);
        int i = iArr[0];
        int i2 = iArr[1];
        return new Rect(i, i2, this.f0a.getWidth() + i, this.f0a.getHeight() + i2);
    }

    public Map m18f() {
        Map hashMap = new HashMap();
        String g = m7g();
        String num = Integer.toString(VERSION.SDK_INT);
        Object obj = this.f2c ? "1" : "0";
        hashMap.put("versionHash", "8ace5ca5da6b9adb3c0f055aad4a98c2aedf4bd7");
        hashMap.put("appName", g);
        hashMap.put("namespace", "TJY");
        hashMap.put("version", "1.7.10");
        hashMap.put("deviceOS", num);
        hashMap.put("isNative", obj);
        return hashMap;
    }
}
