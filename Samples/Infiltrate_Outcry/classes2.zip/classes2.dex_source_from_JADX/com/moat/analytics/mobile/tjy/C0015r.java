package com.moat.analytics.mobile.tjy;

import com.moat.analytics.mobile.tjy.base.exception.a;

class C0015r implements Runnable {
    final /* synthetic */ C0014q f57a;

    C0015r(C0014q c0014q) {
        this.f57a = c0014q;
    }

    public void run() {
        try {
            this.f57a.f56a.m57b();
        } catch (Exception e) {
            a.a(e);
        }
    }
}
