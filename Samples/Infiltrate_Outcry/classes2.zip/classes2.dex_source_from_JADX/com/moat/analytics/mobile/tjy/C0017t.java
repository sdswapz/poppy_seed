package com.moat.analytics.mobile.tjy;

import com.moat.analytics.mobile.tjy.base.exception.a;
import com.moat.analytics.mobile.tjy.base.exception.b;

class C0017t implements Runnable {
    final /* synthetic */ C0016s f59a;

    C0017t(C0016s c0016s) {
        this.f59a = c0016s;
    }

    public void run() {
        try {
            this.f59a.f58a.m59c();
        } catch (b e) {
            a.a(e);
        }
    }
}
