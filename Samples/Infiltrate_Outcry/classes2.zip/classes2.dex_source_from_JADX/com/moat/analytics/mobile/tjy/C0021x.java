package com.moat.analytics.mobile.tjy;

import android.util.Log;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.moat.analytics.mobile.tjy.base.functional.a;
import java.lang.ref.WeakReference;

class C0021x implements ba {
    final /* synthetic */ WeakReference f69a;
    final /* synthetic */ ap f70b;
    final /* synthetic */ C0019v f71c;

    C0021x(C0019v c0019v, WeakReference weakReference, ap apVar) {
        this.f71c = c0019v;
        this.f69a = weakReference;
        this.f70b = apVar;
    }

    public a m84a() {
        ViewGroup viewGroup = (ViewGroup) this.f69a.get();
        boolean b = this.f70b.b();
        if (viewGroup == null) {
            if (b) {
                Log.e("MoatFactory", "Target ViewGroup is null. Not creating WebAdTracker.");
            }
            return a.a();
        }
        if (b) {
            Log.d("MoatFactory", "Creating WebAdTracker for " + viewGroup.getClass().getSimpleName() + "@" + viewGroup.hashCode());
        }
        a a = this.f71c.f64a.mo3a(viewGroup);
        boolean c = a.c();
        if (b) {
            Log.e("MoatFactory", "WebView " + (c ? "" : "not ") + "found inside of ad container.");
        }
        return a.a(new bj((WebView) a.c(null), this.f71c.f65b, this.f70b));
    }
}
