package com.moat.analytics.mobile.tjy;

public interface C0000m {
    String mo1a();

    String mo2b();
}
