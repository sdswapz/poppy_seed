package com.moat.analytics.mobile.tjy;

import android.webkit.WebView;

interface C0010l {
    void mo6a();

    boolean mo7a(WebView webView, C0000m c0000m);
}
