package com.moat.analytics.mobile.tjy;

import org.json.JSONObject;

abstract class C0007i extends C0004f {
    protected C0009k f32j = C0009k.UNINITIALIZED;
    protected int f33k = Integer.MIN_VALUE;
    protected double f34l = Double.NaN;
    protected int f35m = Integer.MIN_VALUE;
    protected int f36n = Integer.MIN_VALUE;
    private int f37o = 0;

    public C0007i(String str, a aVar, ap apVar) {
        super(str, aVar, apVar);
    }

    protected JSONObject mo4a(MoatAdEvent moatAdEvent) {
        Integer f;
        if (moatAdEvent.adPlayhead.equals(MoatAdEvent.TIME_UNAVAILABLE)) {
            try {
                f = m48f();
            } catch (Exception e) {
                f = Integer.valueOf(this.f33k);
            }
            moatAdEvent.adPlayhead = f;
        } else {
            f = moatAdEvent.adPlayhead;
        }
        if (moatAdEvent.adPlayhead.intValue() < 0) {
            f = Integer.valueOf(this.f33k);
            moatAdEvent.adPlayhead = f;
        }
        if (moatAdEvent.eventType == MoatAdEventType.AD_EVT_COMPLETE) {
            if (f.intValue() == Integer.MIN_VALUE || this.f36n == Integer.MIN_VALUE || !m40a(f, Integer.valueOf(this.f36n))) {
                this.f32j = C0009k.STOPPED;
                moatAdEvent.eventType = MoatAdEventType.AD_EVT_STOPPED;
            } else {
                this.f32j = C0009k.COMPLETED;
            }
        }
        return super.mo4a(moatAdEvent);
    }

    protected void mo5b() {
        super.mo5b();
        this.d.postDelayed(new C0008j(this), 200);
    }

    protected abstract Integer m48f();

    protected abstract boolean m49g();

    protected abstract Integer m50h();

    protected boolean m51i() {
        int intValue;
        if (this.f.get() == null || m45e()) {
            return false;
        }
        try {
            int intValue2 = m48f().intValue();
            if (this.f33k >= 0 && intValue2 < 0) {
                return false;
            }
            this.f33k = intValue2;
            if (intValue2 == 0) {
                return true;
            }
            intValue = m50h().intValue();
            boolean g = m49g();
            double d = ((double) intValue) / 4.0d;
            double d2 = m44d();
            MoatAdEventType moatAdEventType = null;
            if (intValue2 > this.f35m) {
                this.f35m = intValue2;
            }
            if (this.f36n == Integer.MIN_VALUE) {
                this.f36n = intValue;
            }
            if (g) {
                if (this.f32j == C0009k.UNINITIALIZED) {
                    moatAdEventType = MoatAdEventType.AD_EVT_START;
                    this.f32j = C0009k.PLAYING;
                } else if (this.f32j == C0009k.PAUSED) {
                    moatAdEventType = MoatAdEventType.AD_EVT_PLAYING;
                    this.f32j = C0009k.PLAYING;
                } else {
                    MoatAdEventType moatAdEventType2;
                    intValue = ((int) Math.floor(((double) intValue2) / d)) - 1;
                    if (intValue >= 0 && intValue < 3) {
                        moatAdEventType2 = b[intValue];
                        if (!this.c.containsKey(moatAdEventType2)) {
                            this.c.put(moatAdEventType2, Integer.valueOf(1));
                            moatAdEventType = moatAdEventType2;
                        }
                    }
                    moatAdEventType2 = null;
                    moatAdEventType = moatAdEventType2;
                }
            } else if (this.f32j != C0009k.PAUSED) {
                moatAdEventType = MoatAdEventType.AD_EVT_PAUSED;
                this.f32j = C0009k.PAUSED;
            }
            Object obj = moatAdEventType != null ? 1 : null;
            if (obj == null && !Double.isNaN(this.f34l) && Math.abs(this.f34l - d2) > 0.05d) {
                moatAdEventType = MoatAdEventType.AD_EVT_VOLUME_CHANGE;
                obj = 1;
            }
            if (obj != null) {
                dispatchEvent(new MoatAdEvent(moatAdEventType, Integer.valueOf(intValue2), Double.valueOf(d2)));
            }
            this.f34l = d2;
            this.f37o = 0;
            return true;
        } catch (Exception e) {
            intValue = this.f37o;
            this.f37o = intValue + 1;
            return intValue < 5;
        }
    }
}
