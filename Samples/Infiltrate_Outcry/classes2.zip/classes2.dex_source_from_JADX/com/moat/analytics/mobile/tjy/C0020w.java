package com.moat.analytics.mobile.tjy;

import android.util.Log;
import android.webkit.WebView;
import com.moat.analytics.mobile.tjy.base.functional.a;
import java.lang.ref.WeakReference;

class C0020w implements ba {
    final /* synthetic */ WeakReference f66a;
    final /* synthetic */ ap f67b;
    final /* synthetic */ C0019v f68c;

    C0020w(C0019v c0019v, WeakReference weakReference, ap apVar) {
        this.f68c = c0019v;
        this.f66a = weakReference;
        this.f67b = apVar;
    }

    public a m83a() {
        WebView webView = (WebView) this.f66a.get();
        boolean b = this.f67b.b();
        if (webView == null) {
            if (b) {
                Log.e("MoatFactory", "Target ViewGroup is null. Not creating WebAdTracker.");
            }
            return a.a();
        }
        if (b) {
            Log.d("MoatFactory", "Creating WebAdTracker for " + webView.getClass().getSimpleName() + "@" + webView.hashCode());
        }
        return a.a(new bj(webView, this.f68c.f65b, this.f67b));
    }
}
