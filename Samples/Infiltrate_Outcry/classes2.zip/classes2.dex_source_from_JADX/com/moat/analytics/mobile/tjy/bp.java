package com.moat.analytics.mobile.tjy;

import android.view.View;
import java.util.Iterator;

class bp implements Iterator {
    final /* synthetic */ bo f11a;
    private int f12b;

    private bp(bo boVar) {
        this.f11a = boVar;
        this.f12b = -1;
    }

    public View m23a() {
        this.f12b++;
        return this.f11a.f10a.getChildAt(this.f12b);
    }

    public boolean hasNext() {
        return this.f12b + 1 < this.f11a.f10a.getChildCount();
    }

    public /* synthetic */ Object next() {
        return m23a();
    }

    public void remove() {
        throw new UnsupportedOperationException("Not implemented. Under development.");
    }
}
