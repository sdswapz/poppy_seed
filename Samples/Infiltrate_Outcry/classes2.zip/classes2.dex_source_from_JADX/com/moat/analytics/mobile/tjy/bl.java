package com.moat.analytics.mobile.tjy;

import android.view.ViewGroup;
import com.moat.analytics.mobile.tjy.base.functional.a;

interface bl {
    a mo3a(ViewGroup viewGroup);
}
