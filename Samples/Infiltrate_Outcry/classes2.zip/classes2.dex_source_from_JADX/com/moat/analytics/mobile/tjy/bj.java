package com.moat.analytics.mobile.tjy;

import android.util.Log;
import android.webkit.WebView;
import com.moat.analytics.mobile.tjy.base.exception.b;
import com.moat.analytics.mobile.tjy.base.functional.a;

class bj implements WebAdTracker {
    private final a f7a;
    private final ap f8b;

    bj(WebView webView, a aVar, ap apVar) {
        this.f8b = apVar;
        if (apVar.b()) {
            Log.d("MoatWebAdTracker", "In initialization method.");
        }
        if (webView == null) {
            if (apVar.b()) {
                Log.e("MoatWebAdTracker", "WebView is null. Will not track.");
            }
            this.f7a = a.a();
            return;
        }
        this.f7a = a.a(new bi(webView, webView, false, aVar, apVar));
    }

    public boolean track() {
        boolean c;
        boolean b = this.f8b.b();
        boolean z = false;
        if (b) {
            try {
                Log.d("MoatWebAdTracker", "In track method.");
            } catch (b e) {
                com.moat.analytics.mobile.tjy.base.exception.a.a(e);
            }
        }
        if (this.f7a.c()) {
            c = ((bh) this.f7a.b()).c();
        } else if (b) {
            Log.e("MoatWebAdTracker", "Internal tracker not available. Not tracking.");
            if (b) {
                Log.d("MoatWebAdTracker", "Attempt to start tracking ad was " + (z ? "" : "un") + "successful.");
            }
            return z;
        } else {
            c = false;
        }
        z = c;
        if (b) {
            if (z) {
            }
            Log.d("MoatWebAdTracker", "Attempt to start tracking ad was " + (z ? "" : "un") + "successful.");
        }
        return z;
    }
}
