package com.moat.analytics.mobile.tjy;

import com.moat.analytics.mobile.tjy.base.exception.a;

class C0008j implements Runnable {
    final /* synthetic */ C0007i f38a;

    C0008j(C0007i c0007i) {
        this.f38a = c0007i;
    }

    public void run() {
        try {
            if (this.f38a.f.get() == null || this.f38a.m45e()) {
                this.f38a.m43c();
            } else if (Boolean.valueOf(this.f38a.m51i()).booleanValue()) {
                this.f38a.d.postDelayed(this, 200);
            } else {
                this.f38a.m43c();
            }
        } catch (Exception e) {
            this.f38a.m43c();
            a.a(e);
        }
    }
}
