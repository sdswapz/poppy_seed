package com.moat.analytics.mobile.tjy;

import android.util.Log;
import android.view.View;
import com.moat.analytics.mobile.tjy.base.functional.a;
import java.lang.ref.WeakReference;

class C0022y implements ba {
    final /* synthetic */ WeakReference f72a;
    final /* synthetic */ ap f73b;
    final /* synthetic */ String f74c;
    final /* synthetic */ C0019v f75d;

    C0022y(C0019v c0019v, WeakReference weakReference, ap apVar, String str) {
        this.f75d = c0019v;
        this.f72a = weakReference;
        this.f73b = apVar;
        this.f74c = str;
    }

    public a m85a() {
        View view = (View) this.f72a.get();
        if (view == null) {
            if (this.f73b.b()) {
                Log.e("MoatFactory", "Target view is null. Not creating NativeDisplayTracker.");
            }
            return a.a();
        }
        if (this.f73b.b()) {
            Log.d("MoatFactory", "Creating NativeDisplayTracker for " + view.getClass().getSimpleName() + "@" + view.hashCode());
        }
        return a.a(new af(view, this.f74c, this.f75d.f65b, this.f73b));
    }
}
