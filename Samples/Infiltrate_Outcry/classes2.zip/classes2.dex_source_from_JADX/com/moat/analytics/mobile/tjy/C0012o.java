package com.moat.analytics.mobile.tjy;

import com.moat.analytics.mobile.tjy.base.exception.a;

class C0012o implements Runnable {
    final /* synthetic */ C0011n f54a;

    C0012o(C0011n c0011n) {
        this.f54a = c0011n;
    }

    public void run() {
        try {
            this.f54a.m63e();
        } catch (Exception e) {
            a.a(e);
        }
    }
}
