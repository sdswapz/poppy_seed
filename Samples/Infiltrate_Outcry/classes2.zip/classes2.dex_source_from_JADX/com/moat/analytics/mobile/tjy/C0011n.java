package com.moat.analytics.mobile.tjy;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build.VERSION;
import android.util.Log;
import android.webkit.WebView;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class C0011n implements C0010l {
    private final ScheduledExecutorService f45a;
    private ScheduledFuture f46b;
    private ScheduledFuture f47c;
    private final ap f48d;
    private int f49e = 0;
    private boolean f50f = false;
    private boolean f51g = false;
    private WebView f52h;
    private C0000m f53i;

    C0011n(Context context, ap apVar) {
        this.f48d = apVar;
        this.f45a = Executors.newScheduledThreadPool(1);
    }

    private void m57b() {
        try {
            if (this.f48d.a() != ar.a) {
                if (this.f48d.b() && !this.f51g) {
                    Log.d("MoatJavaScriptBridge", "Ready for communication (setting environment variables).");
                    this.f51g = true;
                }
                this.f52h.loadUrl(String.format("javascript:(function(b,f){function g(){function b(a,e){for(k in a)if(a.hasOwnProperty(k)){var c=a[k].fn;if('function'===typeof c)try{e?c(e):c()}catch(d){}}}function d(a,b,c){'function'===typeof a&&(c[b]={ts:+new Date,fn:a})}bjmk={};uqaj={};yhgt={};ryup=dptk=!1;this.a=function(a){this.namespace=a.namespace;this.version=a.version;this.appName=a.appName;this.deviceOS=a.deviceOS;this.isNative=a.isNative;this.versionHash=a.versionHash};this.bpsy=function(a){dptk||ryup||d(a,+new Date,bjmk)};this.qmrv=function(a){ryup||d(a,+new Date,uqaj)};this.lgpr=function(a,b){d(a,b,yhgt)};this.xrnk=function(a){yhgt.hasOwnProperty(a)&&delete yhgt[a]};this.vgft=function(){return dptk};this.lkpu=function(){return ryup};this.mqjh=function(){dptk||ryup||(dptk=!0,b(bjmk))};this.egpw=function(){ryup||(ryup=!0,b(uqaj))};this.sglu=function(a){b(yhgt,a);return 0<Object.keys(yhgt).length}}'undefined'===typeof b.MoatMAK&&(b.MoatMAK=new g,b.MoatMAK.a(f),b.__zMoatInit__=!0)})(window,%s);", new Object[]{this.f53i.mo2b()}));
            }
        } catch (Throwable e) {
            if (this.f48d.b()) {
                Log.e("MoatJavaScriptBridge", "Failed to initialize communication (did not set environment variables).", e);
            }
        }
    }

    @TargetApi(19)
    private void m59c() {
        if (this.f48d.a() != ar.a) {
            if (this.f52h == null || (this.f50f && this.f52h.getUrl() == null)) {
                if (this.f48d.b()) {
                    Log.d("MoatJavaScriptBridge", "WebView became null" + (this.f52h == null ? "" : "based on null url") + ", stopping tracking loop");
                }
                m66g();
                return;
            }
            if (this.f52h.getUrl() != null) {
                this.f50f = true;
            }
            String format = String.format("MoatMAK.sglu(%s)", new Object[]{this.f53i.mo1a()});
            if (VERSION.SDK_INT >= 19) {
                this.f52h.evaluateJavascript(format, new C0013p(this));
            } else {
                this.f52h.loadUrl("javascript:" + format);
            }
        }
    }

    private void m60d() {
        if (this.f48d.b()) {
            Log.d("MoatJavaScriptBridge", "Starting metadata reporting loop");
        }
        this.f47c = this.f45a.scheduleWithFixedDelay(new C0014q(this), 0, 50, TimeUnit.MILLISECONDS);
    }

    private void m63e() {
        if (this.f47c != null) {
            if (!this.f47c.isCancelled() && this.f48d.b()) {
                Log.d("MoatJavaScriptBridge", "Stopping metadata reporting loop");
            }
            this.f47c.cancel(true);
        }
    }

    private void m64f() {
        if (this.f48d.b()) {
            Log.d("MoatJavaScriptBridge", "Starting view update loop");
        }
        this.f46b = this.f45a.scheduleWithFixedDelay(new C0016s(this), 0, (long) this.f48d.c(), TimeUnit.MILLISECONDS);
    }

    private void m66g() {
        if (this.f46b != null) {
            if (this.f46b.isCancelled() && this.f48d.b()) {
                Log.d("MoatJavaScriptBridge", "Stopping view update loop");
            }
            this.f46b.cancel(true);
        }
    }

    public void mo6a() {
        if (this.f48d.a() != ar.a) {
            m63e();
            m66g();
        }
    }

    public boolean mo7a(WebView webView, C0000m c0000m) {
        boolean b = this.f48d.b();
        if (webView.getSettings().getJavaScriptEnabled()) {
            this.f52h = webView;
            this.f53i = c0000m;
            m60d();
            m64f();
            this.f45a.schedule(new C0012o(this), 10, TimeUnit.SECONDS);
            return true;
        }
        if (b) {
            Log.e("MoatJavaScriptBridge", "JavaScript is not enabled in the given WebView. Can't track.");
        }
        return false;
    }
}
