package com.moat.analytics.mobile.tjy;

import android.os.Handler;
import android.os.Looper;
import com.moat.analytics.mobile.tjy.base.exception.a;

class C0014q implements Runnable {
    final /* synthetic */ C0011n f56a;

    C0014q(C0011n c0011n) {
        this.f56a = c0011n;
    }

    public void run() {
        try {
            new Handler(Looper.getMainLooper()).post(new C0015r(this));
        } catch (Exception e) {
            a.a(e);
        }
    }
}
