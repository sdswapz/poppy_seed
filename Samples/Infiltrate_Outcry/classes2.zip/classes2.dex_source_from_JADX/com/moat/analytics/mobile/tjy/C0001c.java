package com.moat.analytics.mobile.tjy;

import android.app.Activity;
import android.app.Application;
import android.util.Log;
import com.moat.analytics.mobile.tjy.base.asserts.a;
import java.lang.ref.WeakReference;

class C0001c implements a {
    private final WeakReference f13a;
    private final WeakReference f14b;
    private boolean f15c;
    private final ap f16d;
    private boolean f17e;

    C0001c(Activity activity, ap apVar) {
        a.a(activity);
        if (apVar.b()) {
            Log.d("MoatActivityState", "Listening to Activity: " + (activity != null ? activity.getClass() + "@" + activity.hashCode() : "null"));
        }
        this.f13a = new WeakReference(activity.getApplication());
        this.f14b = new WeakReference(activity);
        this.f16d = apVar;
        this.f15c = false;
    }

    public boolean m28a() {
        return this.f17e;
    }

    public void m29b() {
        if (!this.f15c) {
            ((Application) this.f13a.get()).registerActivityLifecycleCallbacks(new C0003e());
        }
    }

    public Activity m30c() {
        return (Activity) this.f14b.get();
    }
}
