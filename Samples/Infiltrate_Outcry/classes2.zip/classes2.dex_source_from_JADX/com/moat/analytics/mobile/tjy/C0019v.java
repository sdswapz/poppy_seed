package com.moat.analytics.mobile.tjy;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import com.moat.analytics.mobile.tjy.base.exception.a;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicReference;

class C0019v extends MoatFactory {
    private static final AtomicReference f63c = new AtomicReference();
    private final bl f64a = new bm();
    private final a f65b;

    C0019v(Activity activity) {
        if (f63c.get() == null) {
            Object asVar;
            an anVar = new an();
            try {
                asVar = new as(ab.a);
            } catch (Exception e) {
                a.a(e);
                an anVar2 = anVar;
            }
            f63c.compareAndSet(null, asVar);
        }
        this.f65b = new C0001c(activity, (ap) f63c.get());
        this.f65b.b();
    }

    private NativeDisplayTracker m76a(View view, String str) {
        com.moat.analytics.mobile.tjy.base.asserts.a.a(view);
        ap apVar = (ap) f63c.get();
        return (NativeDisplayTracker) ay.a(apVar, new C0022y(this, new WeakReference(view), apVar, str), new ag());
    }

    private NativeVideoTracker m77a(String str) {
        ap apVar = (ap) f63c.get();
        return (NativeVideoTracker) ay.a(apVar, new C0023z(this, apVar, str), new ai());
    }

    private WebAdTracker m78a(ViewGroup viewGroup) {
        com.moat.analytics.mobile.tjy.base.asserts.a.a(viewGroup);
        ap apVar = (ap) f63c.get();
        return (WebAdTracker) ay.a(apVar, new C0021x(this, new WeakReference(viewGroup), apVar), new bk());
    }

    private WebAdTracker m79a(WebView webView) {
        com.moat.analytics.mobile.tjy.base.asserts.a.a(webView);
        ap apVar = (ap) f63c.get();
        return (WebAdTracker) ay.a(apVar, new C0020w(this, new WeakReference(webView), apVar), new bk());
    }

    public Object m82a(ac acVar) {
        return acVar.a(this.f65b, (ap) f63c.get());
    }

    public Object createCustomTracker(ac acVar) {
        try {
            return m82a(acVar);
        } catch (Exception e) {
            a.a(e);
            return acVar.a();
        }
    }

    public NativeDisplayTracker createNativeDisplayTracker(View view, String str) {
        try {
            return m76a(view, str);
        } catch (Exception e) {
            a.a(e);
            return new al();
        }
    }

    public NativeVideoTracker createNativeVideoTracker(String str) {
        try {
            return m77a(str);
        } catch (Exception e) {
            a.a(e);
            return new am();
        }
    }

    public WebAdTracker createWebAdTracker(ViewGroup viewGroup) {
        try {
            return m78a(viewGroup);
        } catch (Exception e) {
            a.a(e);
            return new ao();
        }
    }

    public WebAdTracker createWebAdTracker(WebView webView) {
        try {
            return m79a(webView);
        } catch (Exception e) {
            a.a(e);
            return new ao();
        }
    }

    public WebAdTracker createWebDisplayTracker(ViewGroup viewGroup) {
        return createWebAdTracker(viewGroup);
    }

    public WebAdTracker createWebDisplayTracker(WebView webView) {
        return createWebAdTracker(webView);
    }
}
