package com.moat.analytics.mobile.tjy;

import android.os.Handler;
import android.os.Looper;
import com.moat.analytics.mobile.tjy.base.exception.a;

class C0016s implements Runnable {
    final /* synthetic */ C0011n f58a;

    C0016s(C0011n c0011n) {
        this.f58a = c0011n;
    }

    public void run() {
        try {
            new Handler(Looper.getMainLooper()).post(new C0017t(this));
        } catch (Exception e) {
            a.a(e);
        }
    }
}
