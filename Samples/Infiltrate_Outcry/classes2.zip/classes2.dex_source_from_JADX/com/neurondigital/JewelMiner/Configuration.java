package com.neurondigital.JewelMiner;

public class Configuration {
    static final String BannerAd_unit_id = "";
    static final boolean DEBUG_MODE = false;
    static final int GAME_OVER_DELAY = 20;
    static final float ICE_HEIGHT_IN_SCREEN = 0.82f;
    static final String InterstitialAd_unit_id = "";
    static final float JEWEL_GAP = 0.01f;
    static final float JEWEL_MARGIN = 0.18f;
    static final int NUMBER_OF_JEWEL_COLUMNS = 8;
    static final int NUMBER_OF_JEWEL_ROWS = 10;
    static final int SHOW_RATE_AFTER_X_GAMEPLAYS = 5;
    static final int STREAK_SIZE = 3;
    static final int ad_shows_every_X_gameovers = 3;
    static final String trackingId = "";
}
