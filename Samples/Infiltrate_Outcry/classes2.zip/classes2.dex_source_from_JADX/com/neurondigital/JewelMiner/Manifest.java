package com.neurondigital.JewelMiner;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "en.cold.jewel.th.lines.permission.C2D_MESSAGE";
    }
}
