package com.neurondigital.JewelMiner;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;
import com.chartboost.sdk.Chartboost;
import com.neurondigital.nudge.Animator.AnimationReadyListener;
import com.neurondigital.nudge.Audio;
import com.neurondigital.nudge.Instance;
import com.neurondigital.nudge.LoadingBar;
import com.neurondigital.nudge.Particles;
import com.neurondigital.nudge.Rate;
import com.neurondigital.nudge.Screen;
import com.neurondigital.nudge.Share;
import com.neurondigital.nudge.Sprite;
import com.neurondigital.nudge.Text;
import com.neurondigital.nudge.Timer;
import com.neurondigital.nudge.Timer.TimerListener;
import com.tapjoy.TJAdUnitConstants;
import com.tapjoy.TJConnectListener;
import com.tapjoy.Tapjoy;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.TapjoyConnectFlag;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class MainGame extends Screen {
    final int GAMEOVER = 3;
    final int GAMEPLAY = 2;
    Paint Instruction_Paint = new Paint();
    final int LEVELMENU = 5;
    final int MENU = 1;
    final int RESTART = 4;
    Paint Title_Paint = new Paint();
    Audio audio;
    int best_score = 0;
    Instance btn_achievments;
    Instance btn_exit;
    Instance btn_leaderboard;
    Instance btn_like;
    Instance btn_no;
    Instance btn_play;
    Instance btn_restart;
    Instance btn_share;
    Instance btn_sound;
    Instance btn_yes;
    Paint countdown_Paint = new Paint();
    int gameStartCountdown = 3;
    boolean game_over = false;
    Paint game_over_win_overlay_Paint = new Paint();
    Paint gameover_Paint = new Paint();
    int gameover_counter = 0;
    Path icePath = new Path();
    float icePathY = 0.0f;
    Paint ice_Paint = new Paint();
    Instance igloo;
    Sprite igloo_sprite;
    Jewel[][] jewelBoard = ((Jewel[][]) Array.newInstance(Jewel.class, new int[]{8, 10}));
    Jewel jewelSelected;
    Paint menu_background_Paint = new Paint();
    Text message;
    Instance mountain;
    Sprite mountain_sprite;
    Paint restart_Paint = new Paint();
    int score = 0;
    Paint score_Paint = new Paint();
    Screen screen;
    Particles snow;
    int sound_achievment;
    int sound_button;
    int sound_countdown;
    int[] sound_gem = new int[4];
    Sprite sound_off_sprite;
    Sprite sound_on_sprite;
    Paint subTitle_Paint = new Paint();
    LoadingBar timeBar;
    int timeLeft = 100;
    Timer timer = new Timer();
    Timer timer10 = new Timer();
    Timer timerLike = new Timer();
    Timer timerMessage = new Timer();
    Paint top_score_Paint = new Paint();
    int totalPlayingTime = 0;
    Paint your_score_Paint = new Paint();

    class C00271 implements TJConnectListener {
        C00271() {
        }

        public void onConnectSuccess() {
        }

        public void onConnectFailure() {
        }
    }

    class C00302 implements AnimationReadyListener {
        C00302() {
        }

        public void onReady() {
        }
    }

    class C00313 implements AnimationReadyListener {
        C00313() {
        }

        public void onReady() {
            if (MainGame.this.audio.toggleMasterMute()) {
                MainGame.this.btn_sound.sprite = MainGame.this.sound_off_sprite;
                return;
            }
            MainGame.this.btn_sound.sprite = MainGame.this.sound_on_sprite;
        }
    }

    class C00324 implements AnimationReadyListener {
        C00324() {
        }

        public void onReady() {
            MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
        }
    }

    class C00335 implements AnimationReadyListener {
        C00335() {
        }

        public void onReady() {
            MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
        }
    }

    class C00346 implements AnimationReadyListener {
        C00346() {
        }

        public void onReady() {
            MainGame.this.Exit();
        }
    }

    class C00357 implements AnimationReadyListener {
        C00357() {
        }

        public void onReady() {
            MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
            MainGame.this.share();
        }
    }

    class C00368 implements AnimationReadyListener {
        C00368() {
        }

        public void onReady() {
            MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
            MainGame.this.state = 2;
            MainGame.this.audio.PlayMusic();
        }
    }

    class C00379 implements AnimationReadyListener {
        C00379() {
        }

        public void onReady() {
            MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
            MainGame.this.MainMenu();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        Hashtable<String, Object> connectFlags = new Hashtable();
        connectFlags.put(TapjoyConnectFlag.ENABLE_LOGGING, "false");
        Tapjoy.connect(getApplicationContext(), "AyEyX6eARX6U_OSI4MejtAECc4GiV0IIvhx2pMlx3uI5vu4BKDIJOwCKVmia", connectFlags, new C00271());
        Chartboost.startWithAppId(this, "5a01bc3c40c57a0b9e795b51", "f28d7507927fd9c51eb79b0c4b0ad09eb5eb22a2");
        Chartboost.onCreate(this);
        setDebugMode(false);
        super.onCreate(savedInstanceState);
        this.screen = this;
        setRequestedOrientation(1);
        this.audio = new Audio(this.screen, C0038R.raw.music);
        this.sound_button = this.audio.sp.load(this.activity, C0038R.raw.button, 1);
        this.sound_achievment = this.audio.sp.load(this.activity, C0038R.raw.achievment, 1);
        this.sound_countdown = this.audio.sp.load(this.activity, C0038R.raw.countdown, 1);
        this.sound_gem[0] = this.audio.sp.load(this.activity, C0038R.raw.gem1, 1);
        this.sound_gem[1] = this.audio.sp.load(this.activity, C0038R.raw.gem2, 1);
        this.sound_gem[2] = this.audio.sp.load(this.activity, C0038R.raw.gem3, 1);
        this.sound_gem[3] = this.audio.sp.load(this.activity, C0038R.raw.gem4, 1);
        this.state = 1;
    }

    public void Start() {
        super.Start();
        Typeface mainFont = Typeface.createFromAsset(getAssets(), "JungleFeverNF.ttf");
        this.Title_Paint.setTextSize((float) ((int) getResources().getDimension(2131230739)));
        this.Title_Paint.setTextScaleX(1.2f);
        this.Title_Paint.setAntiAlias(true);
        this.Title_Paint.setColor(getColorRef(C0038R.color.color_title));
        this.Title_Paint.setTypeface(mainFont);
        this.subTitle_Paint.setTextSize((float) ((int) getResources().getDimension(2131230738)));
        this.subTitle_Paint.setAntiAlias(true);
        this.subTitle_Paint.setColor(getColorRef(C0038R.color.color_title));
        this.subTitle_Paint.setTypeface(mainFont);
        this.gameover_Paint.setTextSize((float) ((int) getResources().getDimension(2131230739)));
        this.gameover_Paint.setTextScaleX(1.2f);
        this.gameover_Paint.setAntiAlias(true);
        this.gameover_Paint.setColor(getColorRef(C0038R.color.color_game_over_title));
        this.gameover_Paint.setTypeface(mainFont);
        this.Instruction_Paint.setTextSize((float) ((int) getResources().getDimension(2131230734)));
        this.Instruction_Paint.setAntiAlias(true);
        this.Instruction_Paint.setColor(getColorRef(C0038R.color.color_instructions));
        this.Instruction_Paint.setTypeface(mainFont);
        this.score_Paint.setTextSize((float) ((int) getResources().getDimension(2131230735)));
        this.score_Paint.setTextScaleX(1.2f);
        this.score_Paint.setAntiAlias(true);
        this.score_Paint.setColor(getColorRef(C0038R.color.color_title));
        this.score_Paint.setTypeface(mainFont);
        this.top_score_Paint.setTextSize((float) ((int) getResources().getDimension(2131230740)));
        this.top_score_Paint.setTextScaleX(1.2f);
        this.top_score_Paint.setAntiAlias(true);
        this.top_score_Paint.setColor(getColorRef(C0038R.color.color_title));
        this.top_score_Paint.setTypeface(mainFont);
        this.your_score_Paint.setTextSize((float) ((int) getResources().getDimension(2131230742)));
        this.your_score_Paint.setTextScaleX(1.2f);
        this.your_score_Paint.setAntiAlias(true);
        this.your_score_Paint.setColor(getColorRef(C0038R.color.color_title));
        this.your_score_Paint.setTypeface(Typeface.DEFAULT);
        this.restart_Paint.setTextSize((float) ((int) getResources().getDimension(2131230741)));
        this.restart_Paint.setAntiAlias(true);
        this.restart_Paint.setColor(getColorRef(C0038R.color.color_restart_text));
        this.restart_Paint.setTypeface(mainFont);
        this.countdown_Paint.setTextSize((float) ((int) getResources().getDimension(2131230733)));
        this.countdown_Paint.setAntiAlias(true);
        this.countdown_Paint.setColor(getColorRef(C0038R.color.color_countdown));
        this.countdown_Paint.setTypeface(mainFont);
        this.menu_background_Paint.setColor(getColorRef(C0038R.color.color_trans_white_background));
        this.menu_background_Paint.setAntiAlias(true);
        this.game_over_win_overlay_Paint.setColor(getColorRef(C0038R.color.color_game_over_overlay));
        this.game_over_win_overlay_Paint.setAntiAlias(true);
        this.ice_Paint.setColor(getColorRef(C0038R.color.color_ice));
        this.ice_Paint.setAntiAlias(true);
        float averageHeight = ((float) ScreenHeight()) * 0.82f;
        this.icePath.reset();
        this.icePath.moveTo(0.0f, averageHeight);
        this.icePath.lineTo(((float) ScreenWidth()) * 0.2f, ((float) dpToPx(5)) + averageHeight);
        this.icePath.lineTo(((float) ScreenWidth()) * 0.7f, averageHeight - ((float) dpToPx(8)));
        this.icePath.lineTo((float) ScreenWidth(), averageHeight);
        this.icePath.lineTo((float) ScreenWidth(), (float) (ScreenHeight() * 3));
        this.icePath.lineTo(0.0f, (float) (ScreenHeight() * 3));
        this.icePathY = 0.0f;
        this.message = new Text(this.Instruction_Paint, "", (float) ScreenWidth(), Text.ALIGN_CENTER, 0);
        this.btn_play = new Instance(new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.play), ((float) ScreenWidth()) * 0.4f), (float) (ScreenWidth() / 2), (float) (ScreenHeight() / 2), this, false);
        this.btn_play.setAnchor(0.5f, 0.5f);
        if (this.state != 1) {
            this.btn_play.setScale(0.0f);
        }
        Sprite btn_leaderboard_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.highscore), ((float) ScreenWidth()) * 0.07f);
        btn_leaderboard_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 8, ScreenWidth() / 4);
        this.btn_leaderboard = new Instance(btn_leaderboard_sprite, 0.0f, 0.0f, this, false);
        this.btn_leaderboard.f80y = ((float) ScreenHeight()) - (((float) this.btn_leaderboard.getHeight()) * TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER);
        this.btn_leaderboard.f79x = ((float) (ScreenWidth() / 2)) - (((float) this.btn_leaderboard.getWidth()) * 1.1f);
        Sprite btn_achievments_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.achievments), ((float) ScreenWidth()) * 0.05f);
        btn_achievments_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 8, ScreenWidth() / 4);
        this.btn_achievments = new Instance(btn_achievments_sprite, 0.0f, 0.0f, this, false);
        this.btn_achievments.f80y = ((float) ScreenHeight()) - (((float) this.btn_achievments.getHeight()) * TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER);
        this.btn_achievments.f79x = ((float) (ScreenWidth() / 2)) + (((float) this.btn_achievments.getWidth()) * 0.1f);
        this.sound_off_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.sound_off), ((float) ScreenWidth()) * 0.1f);
        this.sound_off_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 5, ScreenWidth() / 5);
        this.sound_on_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.sound_on), ((float) ScreenWidth()) * 0.1f);
        this.sound_on_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 5, ScreenWidth() / 5);
        this.btn_sound = new Instance(this.sound_on_sprite, 0.0f, 0.0f, this, false);
        this.btn_sound.f80y = ((float) ScreenHeight()) - (((float) this.btn_sound.getHeight()) * 1.2f);
        this.btn_sound.f79x = ((float) ((ScreenWidth() / 2) - (this.btn_leaderboard.getWidth() / 2))) - (((float) this.btn_sound.getWidth()) * 1.5f);
        Sprite btn_exit_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.exit), ((float) ScreenWidth()) * 0.1f);
        btn_exit_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 5, ScreenWidth() / 5);
        this.btn_exit = new Instance(btn_exit_sprite, 0.0f, 0.0f, this, false);
        this.btn_exit.f80y = ((float) ScreenHeight()) - (((float) this.btn_exit.getHeight()) * 1.2f);
        this.btn_exit.f79x = ((float) ((ScreenWidth() / 2) + (this.btn_leaderboard.getWidth() / 2))) + (((float) this.btn_sound.getWidth()) * 0.5f);
        this.btn_yes = new Instance(new Sprite(getResources().getString(C0038R.string.Yes), (float) ((int) getResources().getDimension(2131230741)), mainFont, getResources().getColor(C0038R.color.color_restart_text)), 0.0f, 0.0f, this, false);
        this.btn_yes.f80y = ((float) ScreenHeight()) * 0.55f;
        this.btn_yes.f79x = (float) ((ScreenWidth() / 2) - (this.btn_yes.getWidth() * 2));
        this.btn_no = new Instance(new Sprite(getResources().getString(C0038R.string.No), (float) ((int) getResources().getDimension(2131230741)), mainFont, getResources().getColor(C0038R.color.color_restart_text)), 0.0f, 0.0f, this, false);
        this.btn_no.f80y = ((float) ScreenHeight()) * 0.55f;
        this.btn_no.f79x = (float) ((ScreenWidth() / 2) + this.btn_no.getWidth());
        Sprite btn_menu_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.replay), ((float) ScreenWidth()) * 0.1f);
        btn_menu_sprite.addBackground(1, getColorRef(C0038R.color.color_buttons), ScreenWidth() / 5, ScreenWidth() / 5);
        this.btn_restart = new Instance(btn_menu_sprite, 0.0f, 0.0f, this, false);
        this.btn_restart.f80y = ((float) ScreenHeight()) - (((float) this.btn_exit.getHeight()) * 1.2f);
        this.btn_restart.f79x = ((float) ((ScreenWidth() / 2) + (this.btn_leaderboard.getWidth() / 2))) + (((float) this.btn_sound.getWidth()) * 0.5f);
        this.btn_share = new Instance(new Sprite(getResources().getString(C0038R.string.Share), (float) ((int) getResources().getDimension(2131230736)), mainFont, getResources().getColor(C0038R.color.color_share_btn)), 0.0f, 0.0f, this, false);
        this.btn_share.f80y = (((float) ScreenHeight()) * 0.65f) + ((float) (this.btn_share.getHeight() / 2));
        this.btn_share.f79x = (float) ((ScreenWidth() / 2) - (this.btn_share.getWidth() / 2));
        this.btn_like = new Instance(new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.like), ((float) ScreenWidth()) * 0.3f), 0.0f, 0.0f, this, false);
        this.btn_like.f79x = (float) (ScreenWidth() / 2);
        this.btn_like.setAnchor(0.5f, 0.0f);
        this.btn_like.f80y = (float) (-this.btn_like.getHeight());
        this.mountain_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.mountains), ((float) ScreenWidth()) * 0.6f);
        this.mountain = new Instance(this.mountain_sprite, ((float) ScreenWidth()) * 0.4f, (((float) ScreenHeight()) * 0.82f) - (((float) this.mountain_sprite.getHeight()) * 0.9f), this, true);
        this.igloo_sprite = new Sprite(BitmapFactory.decodeResource(getResources(), C0038R.drawable.igloo), ((float) ScreenWidth()) * 0.16f);
        this.igloo = new Instance(this.igloo_sprite, ((float) ScreenWidth()) * 0.15f, (((float) ScreenHeight()) * 0.82f) - (((float) this.igloo_sprite.getHeight()) * 0.4f), this, true);
        Jewel.generateSprites(this.screen);
        if (this.jewelBoard[0][0] != null) {
            Jewel.refreshBoardPositions(this.screen, this.jewelBoard);
        }
        this.timeBar = new LoadingBar(this.screen, getColorRef(C0038R.color.color_timebar_background), getColorRef(C0038R.color.color_timebar_foreground1), getColorRef(C0038R.color.color_timebar_overlay), (int) (((float) ScreenWidth()) * 0.1f), (int) (((float) ScreenHeight()) * 1.5f));
        this.timeBar.setHeight((int) (((float) ScreenHeight()) * 0.05f));
        this.timeBar.setWidth((int) (((float) ScreenWidth()) * 0.8f));
        this.timeBar.setWorld(true);
        this.snow = new Particles(BitmapFactory.decodeResource(getResources(), C0038R.drawable.snowflake), 2, 50, 180, ScreenWidth(), ScreenHeight() / 4, 50, 30);
    }

    public synchronized void Step() {
        super.Step();
        this.btn_play.Update();
        this.snow.update();
        if (this.state == 1) {
            this.btn_leaderboard.Update();
            this.btn_achievments.Update();
            this.btn_sound.Update();
            this.btn_exit.Update();
        } else if (this.state == 2) {
            this.message.update();
            this.timerMessage.update();
            if (this.game_over) {
                this.gameover_counter++;
            } else {
                this.gameover_counter = 0;
            }
            if (this.gameover_counter > 20) {
                GameOver();
            }
            if (!this.game_over) {
                if (this.timer10.elapsedTime() > 50) {
                    this.timer10.reset();
                    if (this.gameStartCountdown != 0) {
                        this.gameStartCountdown -= 5;
                    }
                }
                if (this.timer.elapsedTime() > TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT) {
                    this.timer.reset();
                    if (this.gameStartCountdown == 0) {
                        this.totalPlayingTime++;
                        if (this.totalPlayingTime == 300) {
                            this.audio.playSoundFX(this.sound_achievment);
                            showMessage(getResources().getString(C0038R.string.mins5));
                        }
                        if (this.timeLeft > 1) {
                            this.timeLeft--;
                        } else {
                            startGameOverCountDown();
                        }
                        this.timeBar.setProgress(this.timeLeft);
                        if (this.timeLeft < 20) {
                            this.timeBar.setColorForeground(getColorRef(C0038R.color.color_timebar_foreground2));
                        } else {
                            this.timeBar.setColorForeground(getColorRef(C0038R.color.color_timebar_foreground1));
                        }
                    } else if (this.gameStartCountdown > 90) {
                        this.audio.playSoundFX(this.sound_countdown);
                    }
                }
            }
            for (int x = 0; x < 8; x++) {
                for (int y = 0; y < 10; y++) {
                    this.jewelBoard[x][y].Update();
                }
            }
        } else if (this.state == 4) {
            this.btn_share.Update();
        } else if (this.state == 3) {
            this.btn_restart.Update();
            this.btn_share.Update();
            this.btn_leaderboard.Update();
            this.btn_achievments.Update();
            this.btn_sound.Update();
            this.btn_like.Update();
            this.timerLike.update();
        }
    }

    public synchronized void BackPressed() {
        if (this.state == 1) {
            Exit();
        } else if (this.state == 2) {
            this.state = 4;
            this.audio.StopMusic();
        } else if (this.state == 4) {
            this.state = 2;
            this.audio.PlayMusic();
        } else if (this.state == 3) {
            MainMenu();
        }
    }

    public synchronized void onTouch(float TouchX, float TouchY, MotionEvent event) {
        if (this.state == 1) {
            this.btn_play.expandOnTouch(event, 120, 0, 5, 20, new C00302());
            if (!this.btn_play.isNormalScale() && event.getAction() == 1) {
                this.audio.playSoundFX(this.sound_button);
                if (Rate.rateWithCounter(this.activity, 5, getResources().getString(C0038R.string.rate_title), getResources().getString(C0038R.string.rate_text), getResources().getString(C0038R.string.unable_to_reach_market), getResources().getString(C0038R.string.Alert_accept), getResources().getString(C0038R.string.Alert_cancel))) {
                    this.btn_play.animateScale(Instance.NORMAL_SCALE, 20.0f);
                } else {
                    StartGame();
                }
            }
            this.btn_sound.expandOnTouch(event, new C00313());
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_leaderboard.expandOnTouch(event, new C00324());
                this.btn_achievments.expandOnTouch(event, new C00335());
            }
            this.btn_exit.expandOnTouch(event, new C00346());
        } else if (this.state == 2) {
            if (this.gameStartCountdown == 0 && !this.game_over) {
                if (event.getAction() == 0) {
                    this.jewelSelected = touchDown(this.jewelBoard, this.jewelSelected, event, this.screen);
                } else if (event.getAction() == 2 && this.jewelSelected != null) {
                    if (TouchY < ((float) ScreenY(this.jewelSelected.y - ((float) (this.jewelSelected.getHeight() / 2))))) {
                        this.jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                        tryReplace(this.jewelBoard, this.jewelSelected.gridX, this.jewelSelected.gridY, this.jewelSelected.gridX, this.jewelSelected.gridY - 1, this.screen);
                        this.jewelSelected = null;
                    } else if (TouchX > ((float) ScreenX(this.jewelSelected.x + ((float) (this.jewelSelected.sprite.getWidth() / 2))))) {
                        this.jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                        tryReplace(this.jewelBoard, this.jewelSelected.gridX, this.jewelSelected.gridY, this.jewelSelected.gridX + 1, this.jewelSelected.gridY, this.screen);
                        this.jewelSelected = null;
                    } else if (TouchY > ((float) ScreenY(this.jewelSelected.y + ((float) (this.jewelSelected.sprite.getHeight() / 2))))) {
                        this.jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                        tryReplace(this.jewelBoard, this.jewelSelected.gridX, this.jewelSelected.gridY, this.jewelSelected.gridX, this.jewelSelected.gridY + 1, this.screen);
                        this.jewelSelected = null;
                    } else if (TouchX < ((float) ScreenX(this.jewelSelected.x - ((float) (this.jewelSelected.sprite.getWidth() / 2))))) {
                        this.jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                        tryReplace(this.jewelBoard, this.jewelSelected.gridX, this.jewelSelected.gridY, this.jewelSelected.gridX - 1, this.jewelSelected.gridY, this.screen);
                        this.jewelSelected = null;
                    }
                }
            }
        } else if (this.state == 4) {
            this.btn_share.highlightOnTouch(event, getColorRef(C0038R.color.color_share_btn_highlight), new C00357());
            this.btn_no.highlightOnTouch(event, getColorRef(C0038R.color.color_restart_text_highlight), new C00368());
            this.btn_yes.highlightOnTouch(event, getColorRef(C0038R.color.color_restart_text_highlight), new C00379());
        } else if (this.state == 3) {
            this.btn_like.expandOnTouch(event, new AnimationReadyListener() {
                public void onReady() {
                    MainGame.openFacebookPage(MainGame.this.activity, MainGame.this.getResources().getString(C0038R.string.facebook_page_name), MainGame.this.getResources().getString(C0038R.string.facebook_page_id), MainGame.this.getResources().getString(C0038R.string.unable_to_reach_page));
                }
            });
            this.btn_sound.expandOnTouch(event, new AnimationReadyListener() {
                public void onReady() {
                    if (MainGame.this.audio.toggleMasterMute()) {
                        MainGame.this.btn_sound.sprite = MainGame.this.sound_off_sprite;
                        return;
                    }
                    MainGame.this.btn_sound.sprite = MainGame.this.sound_on_sprite;
                }
            });
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_leaderboard.expandOnTouch(event, new AnimationReadyListener() {
                    public void onReady() {
                        MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
                    }
                });
                this.btn_achievments.expandOnTouch(event, new AnimationReadyListener() {
                    public void onReady() {
                        MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
                    }
                });
            }
            this.btn_restart.expandOnTouch(event, new AnimationReadyListener() {
                public void onReady() {
                    MainGame.this.StartGame();
                    MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
                }
            });
            this.btn_share.highlightOnTouch(event, getColorRef(C0038R.color.color_share_btn_highlight), new AnimationReadyListener() {
                public void onReady() {
                    MainGame.this.audio.playSoundFX(MainGame.this.sound_button);
                    MainGame.this.share();
                }
            });
        }
    }

    public void StartGame() {
        this.message.setText("");
        moveCameraY(((float) ScreenHeight()) * 0.6f, ScreenHeight() / 20);
        this.gameStartCountdown = 300;
        this.audio.PlayMusic();
        this.timer.reset();
        this.timer10.reset();
        this.timeLeft = 100;
        this.timeBar.setColorForeground(getColorRef(C0038R.color.color_timebar_foreground1));
        this.timeBar.setProgress(this.timeLeft);
        Jewel.refreshBoard(this.screen, this.jewelBoard);
        this.game_over = false;
        this.state = 2;
        this.score = 0;
        this.totalPlayingTime = 0;
    }

    public void MainMenu() {
        moveCameraY(0.0f, 150);
        this.state = 1;
        this.btn_play.animateScale(Instance.NORMAL_SCALE, 20.0f);
    }

    public synchronized void GameOver() {
        this.audio.StopMusic();
        this.btn_like.f80y = (float) (-this.btn_like.getHeight());
        this.timerLike.delay(2000, new TimerListener() {
            public void onReady() {
                MainGame.this.btn_like.animatePosition((float) (MainGame.this.ScreenWidth() / 2), 0.0f, 20.0f, null);
            }
        });
        this.state = 3;
    }

    public void startGameOverCountDown() {
        GameOver();
        this.game_over = true;
    }

    public void replace(Jewel[][] jewelBoard, int gridX, int gridY, int gridX2, int gridY2, AnimationReadyListener doneListener) {
        jewelBoard[gridX][gridY].gotoGridXY(gridX2, gridY2);
        jewelBoard[gridX2][gridY2].gotoGridXY(gridX, gridY, doneListener);
        Jewel tempJewel = jewelBoard[gridX2][gridY2];
        jewelBoard[gridX2][gridY2] = jewelBoard[gridX][gridY];
        jewelBoard[gridX][gridY] = tempJewel;
        jewelBoard[gridX][gridY].gridX = gridX;
        jewelBoard[gridX][gridY].gridY = gridY;
        jewelBoard[gridX2][gridY2].gridX = gridX2;
        jewelBoard[gridX2][gridY2].gridY = gridY2;
    }

    public void tryReplace(Jewel[][] jewelBoard, int gridX, int gridY, int gridX2, int gridY2, Screen screen) {
        if (gridY >= 0 && gridX <= jewelBoard.length - 1 && gridY <= jewelBoard[0].length - 1 && gridX >= 0 && gridY2 >= 0 && gridX2 <= jewelBoard.length - 1 && gridY2 <= jewelBoard[0].length - 1 && gridX2 >= 0) {
            final Jewel[][] jewelArr = jewelBoard;
            final int i = gridX;
            final int i2 = gridY;
            final int i3 = gridX2;
            final int i4 = gridY2;
            replace(jewelBoard, gridX, gridY, gridX2, gridY2, new AnimationReadyListener() {

                class C00251 implements AnimationReadyListener {
                    C00251() {
                    }

                    public void onReady() {
                    }
                }

                public void onReady() {
                    List<Jewel> streakList = new ArrayList();
                    streakList = jewelArr[i][i2].getAllStreaks(jewelArr);
                    streakList.addAll(jewelArr[i3][i4].getAllStreaks(jewelArr));
                    if (streakList.isEmpty()) {
                        MainGame.this.replace(jewelArr, i, i2, i3, i4, new C00251());
                        return;
                    }
                    MainGame.this.audio.playRandomSoundFX(MainGame.this.sound_gem);
                    if (streakList.size() >= 8) {
                        MainGame.this.audio.playSoundFX(MainGame.this.sound_achievment);
                        MainGame.this.showMessage(MainGame.this.getResources().getString(C0038R.string.jewels8));
                    }
                    if (streakList.size() >= 16) {
                        MainGame.this.audio.playSoundFX(MainGame.this.sound_achievment);
                        MainGame.this.showMessage(MainGame.this.getResources().getString(C0038R.string.jewels16));
                    }
                    final List<Jewel> jewelList = streakList;
                    MainGame.this.HighlightJewels(streakList, new AnimationReadyListener() {
                        public void onReady() {
                            MainGame.this.gotoScore(jewelList, jewelArr);
                        }
                    });
                }
            });
        }
    }

    public void HighlightJewels(List<Jewel> jewelList, final AnimationReadyListener doneListener) {
        for (int i = 0; i < jewelList.size() - 1; i++) {
            ((Jewel) jewelList.get(i)).animateScale(120.0f, 5.0f);
        }
        if (jewelList.size() > 0) {
            ((Jewel) jewelList.get(jewelList.size() - 1)).animateScale(120.0f, 5.0f, new AnimationReadyListener() {
                public void onReady() {
                    doneListener.onReady();
                }
            });
        }
    }

    public Jewel touchDown(Jewel[][] jewelBoard, Jewel jewelSelected, MotionEvent event, Screen screen) {
        int i = 0;
        int x = 0;
        while (x < 8) {
            int y = 0;
            while (y < 10) {
                if (!jewelBoard[x][y].isTouched(event)) {
                    y++;
                } else if (jewelSelected == null) {
                    jewelBoard[x][y].animateScale(130.0f, 8.0f);
                    return jewelBoard[x][y];
                } else if (jewelSelected == jewelBoard[x][y]) {
                    jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                    return null;
                } else {
                    int i2;
                    if (Math.abs(jewelSelected.gridX - x) == 1) {
                        i2 = 1;
                    } else {
                        i2 = 0;
                    }
                    if (Math.abs(jewelSelected.gridY - y) == 1) {
                        i = 1;
                    }
                    if ((i2 ^ i) == 0 || Math.abs(jewelSelected.gridX - x) > 1 || Math.abs(jewelSelected.gridY - y) > 1) {
                        jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                        jewelBoard[x][y].animateScale(130.0f, 8.0f);
                        return jewelBoard[x][y];
                    }
                    jewelSelected.animateScale(Instance.NORMAL_SCALE, 8.0f);
                    tryReplace(jewelBoard, x, y, jewelSelected.gridX, jewelSelected.gridY, screen);
                    return null;
                }
            }
            x++;
        }
        return jewelSelected;
    }

    public void refresh(Screen screen, Jewel[][] jewelBoard) {
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 10; y++) {
                if (jewelBoard[x][y].isDeleted) {
                    if (y > 0) {
                        for (int y2 = y; y2 > 0; y2--) {
                            jewelBoard[x][y2] = jewelBoard[x][y2 - 1];
                            jewelBoard[x][y2].gridX = x;
                            jewelBoard[x][y2].gridY = y2;
                            jewelBoard[x][y2].gotoGridXY(x, y2);
                        }
                    }
                    jewelBoard[x][0] = new Jewel(screen, Jewel.randomJewel(), x, 0);
                    jewelBoard[x][0].x = (float) Jewel.toX(screen, x);
                    jewelBoard[x][0].y = (float) Jewel.toY(screen, 0);
                    jewelBoard[x][0].setAnchor(0.5f, 0.5f);
                    jewelBoard[x][0].setScale(0.0f);
                    jewelBoard[x][0].animateScale(Instance.NORMAL_SCALE, 20.0f);
                }
            }
        }
    }

    public void gotoScore(final List<Jewel> jewelList, final Jewel[][] jewelBoard) {
        for (int i = 0; i < jewelList.size() - 1; i++) {
            ((Jewel) jewelList.get(i)).isDeleted = true;
            ((Jewel) jewelList.get(i)).animatePosition(((float) this.screen.ScreenWidth()) * 0.5f, (((float) this.screen.ScreenHeight()) * 0.2f) + this.screen.cameraY, ((float) this.screen.ScreenHeight()) * 0.02f, null);
        }
        if (jewelList.size() > 0) {
            ((Jewel) jewelList.get(jewelList.size() - 1)).isDeleted = true;
            ((Jewel) jewelList.get(jewelList.size() - 1)).animatePosition(((float) this.screen.ScreenWidth()) * 0.5f, (((float) this.screen.ScreenHeight()) * 0.2f) + this.screen.cameraY, ((float) this.screen.ScreenHeight()) * 0.02f, new AnimationReadyListener() {
                public void onReady() {
                    MainGame.this.addToScore(jewelList, jewelBoard);
                }
            });
        }
    }

    public void addToScore(List<Jewel> jewelList, final Jewel[][] jewelBoard) {
        for (int i = 0; i < jewelList.size() - 1; i++) {
            incrementScore();
            if (((Jewel) jewelList.get(i)).jewelType == Jewel.JEWEL_EXTRA_TIME) {
                this.timeLeft += 10;
                if (this.timeLeft > 100) {
                    this.timeLeft = 100;
                }
            }
            ((Jewel) jewelList.get(i)).animateScale(0.0f, 20.0f, null);
        }
        if (jewelList.size() > 0) {
            incrementScore();
            if (((Jewel) jewelList.get(jewelList.size() - 1)).jewelType == Jewel.JEWEL_EXTRA_TIME) {
                this.timeLeft += 10;
                if (this.timeLeft > 100) {
                    this.timeLeft = 100;
                }
            }
            ((Jewel) jewelList.get(jewelList.size() - 1)).animateScale(0.0f, 20.0f, new AnimationReadyListener() {
                public void onReady() {
                    MainGame.this.refresh(MainGame.this.screen, jewelBoard);
                }
            });
        }
    }

    public void incrementScore() {
        this.score++;
        if (this.score == TJAdUnitConstants.DEFAULT_VOLUME_CHECK_INTERVAL) {
            this.audio.playSoundFX(this.sound_achievment);
            showMessage(getResources().getString(C0038R.string.score_500));
        }
        if (this.score == 2000) {
            this.audio.playSoundFX(this.sound_achievment);
            showMessage(getResources().getString(C0038R.string.score_2000));
        }
    }

    public void showMessage(String text) {
        this.message.setText(text);
        this.message.animateFade(255.0f, 30.0f, new AnimationReadyListener() {

            class C00291 implements TimerListener {

                class C00281 implements AnimationReadyListener {
                    C00281() {
                    }

                    public void onReady() {
                    }
                }

                C00291() {
                }

                public void onReady() {
                    MainGame.this.message.animateFade(0.0f, 10.0f, new C00281());
                }
            }

            public void onReady() {
                MainGame.this.timerMessage.delay(2000, new C00291());
            }
        });
    }

    public void share() {
        Share sharer = new Share();
        Bitmap screenshot = Bitmap.createBitmap(ScreenWidth(), ScreenHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas();
        canvas.setBitmap(screenshot);
        int temp_state = this.state;
        this.state = 2;
        Draw(canvas);
        this.state = temp_state;
        sharer.share_screenshot(this, screenshot);
    }

    public static void openFacebookPage(Activity activity, String fbPageName, String fbPageId, String unable_to_reach_page_error) {
        Intent goToFB;
        try {
            activity.getPackageManager().getPackageInfo("com.facebook.katana", 0);
            goToFB = new Intent("android.intent.action.VIEW", Uri.parse("fb://page/" + fbPageId));
        } catch (Exception e) {
            goToFB = new Intent("android.intent.action.VIEW", Uri.parse("https://www.facebook.com/" + fbPageName));
        }
        try {
            activity.startActivity(goToFB);
        } catch (ActivityNotFoundException e2) {
            Toast.makeText(activity, unable_to_reach_page_error, 1).show();
        }
    }

    public void Draw(Canvas canvas) {
        canvas.drawColor(getColorRef(C0038R.color.color_background));
        this.mountain.draw(canvas);
        this.snow.draw(canvas, (float) (ScreenWidth() / 2), 0.0f);
        this.icePath.offset(0.0f, this.icePathY - this.cameraY);
        this.icePathY = this.cameraY;
        canvas.drawPath(this.icePath, this.ice_Paint);
        this.igloo.draw(canvas);
        canvas.drawText(getResources().getString(C0038R.string.Title), ((float) (ScreenWidth() / 2)) - (this.Title_Paint.measureText(getResources().getString(C0038R.string.Title)) / 2.0f), (((float) ScreenHeight()) * 0.15f) - this.cameraY, this.Title_Paint);
        Rect bounds = new Rect();
        this.Title_Paint.getTextBounds(getResources().getString(C0038R.string.Title), 0, getResources().getString(C0038R.string.Title).length(), bounds);
        canvas.drawText(getResources().getString(C0038R.string.Subtitle), ((float) (ScreenWidth() / 2)) - (this.subTitle_Paint.measureText(getResources().getString(C0038R.string.Subtitle)) / 2.0f), ((((float) ScreenHeight()) * 0.1f) + ((float) (bounds.height() * 2))) - this.cameraY, this.subTitle_Paint);
        this.btn_play.draw(canvas);
        if (this.state == 1) {
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_leaderboard.draw(canvas);
            }
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_achievments.draw(canvas);
            }
            this.btn_sound.draw(canvas);
            this.btn_exit.draw(canvas);
        } else if (this.state == 2 || this.state == 4 || this.state == 3) {
            for (int x = 0; x < 8; x++) {
                for (int y = 0; y < 10; y++) {
                    this.jewelBoard[x][y].draw(canvas);
                }
            }
            this.timeBar.draw(canvas);
            Text.drawText(canvas, this.score_Paint, "" + this.score, 0.0f, 0.1f * ((float) ScreenHeight()), (float) ScreenWidth(), Text.ALIGN_CENTER);
            if (this.gameStartCountdown > 0 && this.gameStartCountdown <= 300) {
                float percent = ((float) (((double) this.gameStartCountdown) - (Math.floor((double) (((float) this.gameStartCountdown) / Instance.NORMAL_SCALE)) * 100.0d))) / Instance.NORMAL_SCALE;
                if (percent != 0.0f) {
                    this.countdown_Paint.setTextSize(((float) ((int) getResources().getDimension(2131230733))) - ((getResources().getDimension(2131230733) * 0.9f) * percent));
                    if (percent > 0.8f) {
                        this.countdown_Paint.setAlpha(255);
                    } else {
                        this.countdown_Paint.setAlpha(((int) (Instance.NORMAL_SCALE * percent)) + 155);
                    }
                    Text.drawTextMiddle(canvas, this.countdown_Paint, "" + ((int) Math.ceil((double) (((float) this.gameStartCountdown) / Instance.NORMAL_SCALE))), 0.0f, 0.5f * ((float) ScreenHeight()), (float) ScreenWidth(), Text.ALIGN_CENTER);
                }
            }
            this.message.draw(canvas, 0.0f, (float) (ScreenHeight() / 2));
            if (this.state == 4) {
                canvas.drawRect(0.0f, 0.0f, (float) ScreenWidth(), (float) ScreenHeight(), this.menu_background_Paint);
                canvas.drawText(getResources().getString(C0038R.string.exit_question), ((float) (ScreenWidth() / 2)) - (this.restart_Paint.measureText(getResources().getString(C0038R.string.exit_question)) / 2.0f), ((float) ScreenHeight()) * 0.45f, this.restart_Paint);
                this.btn_no.draw(canvas);
                this.btn_yes.draw(canvas);
                this.btn_share.draw(canvas);
            }
        }
        if (this.state == 3) {
            canvas.drawRect(0.0f, 0.0f, (float) ScreenWidth(), (float) ScreenHeight(), this.game_over_win_overlay_Paint);
            this.gameover_Paint.getTextBounds(getResources().getString(C0038R.string.game_over), 0, getResources().getString(C0038R.string.game_over).length(), bounds);
            canvas.drawText(getResources().getString(C0038R.string.game_over), (float) ((ScreenWidth() / 2) - (bounds.width() / 2)), (((float) ScreenHeight()) * 0.2f) + ((float) (bounds.height() / 2)), this.gameover_Paint);
            Text.drawText(canvas, this.your_score_Paint, getResources().getString(C0038R.string.your_score), 0.0f, 0.4f * ((float) ScreenHeight()), (float) ScreenWidth(), Text.ALIGN_CENTER);
            Text.drawText(canvas, this.score_Paint, "" + this.score, 0.0f, 0.45f * ((float) ScreenHeight()), (float) ScreenWidth(), Text.ALIGN_CENTER);
            Text.drawText(canvas, this.top_score_Paint, "Top: " + this.best_score, 0.0f, 0.55f * ((float) ScreenHeight()), (float) ScreenWidth(), Text.ALIGN_CENTER);
            this.btn_restart.draw(canvas);
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_leaderboard.draw(canvas);
            }
            if (getResources().getString(C0038R.string.app_id).length() > 0) {
                this.btn_achievments.draw(canvas);
            }
            this.btn_sound.draw(canvas);
            this.btn_share.draw(canvas);
            this.btn_like.draw(canvas);
        }
        super.Draw(canvas);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    protected void onResume() {
        super.onResume();
        if (this.state == 2) {
            this.audio.unPauseMusic();
        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public void onPause() {
        this.audio.PauseMusic();
        super.onPause();
    }

    public void onDestroy() {
        this.audio.StopMusic();
        super.onDestroy();
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onStop() {
        super.onStop();
    }
}
