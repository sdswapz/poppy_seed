package com.neurondigital.JewelMiner;

import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import com.neurondigital.nudge.Animator.AnimationReadyListener;
import com.neurondigital.nudge.Instance;
import com.neurondigital.nudge.Screen;
import com.neurondigital.nudge.Sprite;
import java.util.ArrayList;
import java.util.List;

public class Jewel extends Instance {
    static final int BOTTOM = 2;
    public static int JEWEL1 = 0;
    public static int JEWEL2 = 1;
    public static int JEWEL3 = 2;
    public static int JEWEL4 = 3;
    public static int JEWEL5 = 4;
    public static int JEWEL_EXTRA_TIME = 5;
    static final int[] JEWEL_IMG_REFERENCE = new int[]{C0038R.drawable.jewel1, C0038R.drawable.jewel2, C0038R.drawable.jewel3, C0038R.drawable.jewel4, C0038R.drawable.jewel5, C0038R.drawable.jewel_time};
    static final int LEFT = 3;
    static final int RIGHT = 1;
    static final int TOP = 0;
    static Sprite[] jewel_sprite = new Sprite[JEWEL_IMG_REFERENCE.length];
    public int gridX;
    public int gridY;
    public boolean isDeleted = false;
    public int jewelType;
    Screen screen;

    class C00241 implements AnimationReadyListener {
        C00241() {
        }

        public void onReady() {
        }
    }

    public Jewel(Screen screen, int jewelType, int gridX, int gridY) {
        super(jewel_sprite[jewelType].Clone(), (float) toX(screen, gridX), (float) toY(screen, gridY), screen, true);
        this.screen = screen;
        this.jewelType = jewelType;
        this.gridX = gridX;
        this.gridY = gridY;
    }

    public static void generateSprites(Screen screen) {
        int width = (int) (((((float) screen.ScreenWidth()) - ((((float) screen.ScreenWidth()) * (0.18f * (((float) screen.ScreenWidth()) / ((float) screen.ScreenHeight())))) * 2.0f)) / 8.0f) - (0.01f * ((float) screen.ScreenWidth())));
        jewel_sprite[JEWEL1] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL1]), (float) width);
        jewel_sprite[JEWEL2] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL2]), (float) width);
        jewel_sprite[JEWEL3] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL3]), (float) width);
        jewel_sprite[JEWEL4] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL4]), (float) width);
        jewel_sprite[JEWEL5] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL5]), (float) width);
        jewel_sprite[JEWEL_EXTRA_TIME] = new Sprite(BitmapFactory.decodeResource(screen.getResources(), JEWEL_IMG_REFERENCE[JEWEL_EXTRA_TIME]), (float) width, 1, 14, 400);
    }

    public static void refreshBoard(Screen screen, Jewel[][] jewels) {
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 10; y++) {
                jewels[x][y] = new Jewel(screen, randomJewel(), x, y);
                jewels[x][y].x = (float) toX(screen, x);
                jewels[x][y].y = (float) toY(screen, y);
                jewels[x][y].setAnchor(0.5f, 0.5f);
            }
        }
    }

    public static void refreshBoardPositions(Screen screen, Jewel[][] jewels) {
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 10; y++) {
                jewels[x][y].x = (float) toX(screen, x);
                jewels[x][y].y = (float) toY(screen, y);
            }
        }
    }

    public static int randomJewel() {
        int random = (int) (Math.random() * ((double) jewel_sprite.length));
        if (random != JEWEL_EXTRA_TIME || Math.random() <= 0.30000001192092896d) {
            return random;
        }
        return (int) (Math.random() * ((double) jewel_sprite.length));
    }

    public static int toX(Screen screen, int gridX) {
        return (int) (((((float) gridX) * (((float) jewel_sprite[0].getWidth()) + (0.01f * ((float) screen.ScreenWidth())))) + ((float) (jewel_sprite[0].getWidth() / 2))) + (((float) screen.ScreenWidth()) * (0.18f * (((float) screen.ScreenWidth()) / ((float) screen.ScreenHeight())))));
    }

    public static int toY(Screen screen, int gridY) {
        return (int) ((((((float) gridY) * (((float) jewel_sprite[0].getHeight()) + (0.01f * ((float) screen.ScreenWidth())))) + ((float) (jewel_sprite[0].getHeight() / 2))) + (((float) screen.ScreenHeight()) * 0.3f)) + (((float) screen.ScreenHeight()) * 0.6f));
    }

    public void gotoGridXY(int gridX, int gridY) {
        animatePosition((float) toX(this.screen, gridX), (float) toY(this.screen, gridY), ((float) this.screen.ScreenHeight()) * 0.01f, new C00241());
    }

    public void gotoGridXY(int gridX, int gridY, AnimationReadyListener doneListener) {
        animatePosition((float) toX(this.screen, gridX), (float) toY(this.screen, gridY), ((float) this.screen.ScreenHeight()) * 0.01f, doneListener);
    }

    public List<Jewel> getStreak(Jewel[][] jewelBoard, int direction) {
        List<Jewel> streak = new ArrayList();
        streak.add(this);
        if (direction == 0) {
            if (this.gridY > 0 && jewelBoard[this.gridX][this.gridY - 1].jewelType == this.jewelType) {
                streak.addAll(jewelBoard[this.gridX][this.gridY - 1].getStreak(jewelBoard, direction));
            }
        } else if (direction == 1) {
            if (this.gridX < jewelBoard.length - 1 && jewelBoard[this.gridX + 1][this.gridY].jewelType == this.jewelType) {
                streak.addAll(jewelBoard[this.gridX + 1][this.gridY].getStreak(jewelBoard, direction));
            }
        } else if (direction == 2) {
            if (this.gridY < jewelBoard[0].length - 1 && jewelBoard[this.gridX][this.gridY + 1].jewelType == this.jewelType) {
                streak.addAll(jewelBoard[this.gridX][this.gridY + 1].getStreak(jewelBoard, direction));
            }
        } else if (direction == 3 && this.gridX > 0 && jewelBoard[this.gridX - 1][this.gridY].jewelType == this.jewelType) {
            streak.addAll(jewelBoard[this.gridX - 1][this.gridY].getStreak(jewelBoard, direction));
        }
        return streak;
    }

    public List<Jewel> getAllStreaks(Jewel[][] jewelBoard) {
        List<Jewel> streaks = new ArrayList();
        List<Jewel> tempStreakSide1 = getStreak(jewelBoard, 0);
        List<Jewel> tempStreakSide2 = getStreak(jewelBoard, 2);
        tempStreakSide1.remove(0);
        tempStreakSide2.remove(0);
        if ((tempStreakSide1.size() + tempStreakSide2.size()) + 1 >= 3) {
            streaks.addAll(tempStreakSide1);
            streaks.addAll(tempStreakSide2);
        }
        tempStreakSide1 = getStreak(jewelBoard, 3);
        tempStreakSide2 = getStreak(jewelBoard, 1);
        tempStreakSide1.remove(0);
        tempStreakSide2.remove(0);
        if ((tempStreakSide1.size() + tempStreakSide2.size()) + 1 >= 3) {
            streaks.addAll(tempStreakSide1);
            streaks.addAll(tempStreakSide2);
        }
        if (!streaks.isEmpty()) {
            streaks.add(this);
        }
        return streaks;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
    }
}
