package com.neurondigital.nudge;

import android.graphics.Canvas;
import android.graphics.Typeface;

public class LevelManager {
    private LevelButton[] LevelButtons;
    SingleScore ScoreManager;
    int TotalLevels;
    int bound_height;
    int bound_width;
    int bound_x;
    int bound_y;
    int button_size;
    int buttons_in_x;
    int buttons_in_y;
    private int currentLevel = 0;
    Typeface font;
    int level_circles_border_dp;
    Screen screen;
    int unlocked = 15454;

    public LevelManager(Screen screen, int border, int levels, Typeface font) {
        this.TotalLevels = levels;
        this.font = font;
        this.screen = screen;
        this.LevelButtons = new LevelButton[levels];
        this.level_circles_border_dp = screen.dpToPx(border);
        this.buttons_in_x = (int) Math.ceil(Math.sqrt((double) levels));
        this.buttons_in_y = (int) Math.ceil((double) (((float) this.TotalLevels) / ((float) this.buttons_in_x)));
        this.bound_x = 0;
        this.bound_y = 0;
        this.bound_height = screen.ScreenHeight();
        this.bound_width = screen.ScreenWidth();
        init();
        this.ScoreManager = new SingleScore(screen);
    }

    public LevelManager(Screen screen, int border, int levels, Typeface font, int buttons_in_x) {
        this.TotalLevels = levels;
        this.font = font;
        this.screen = screen;
        this.buttons_in_x = buttons_in_x;
        this.buttons_in_y = (int) Math.ceil((double) (((float) this.TotalLevels) / ((float) buttons_in_x)));
        this.LevelButtons = new LevelButton[levels];
        this.level_circles_border_dp = screen.dpToPx(border);
        this.bound_x = 0;
        this.bound_y = 0;
        this.bound_height = screen.ScreenHeight();
        this.bound_width = screen.ScreenWidth();
        init();
        this.ScoreManager = new SingleScore(screen);
    }

    void init() {
        if (this.bound_width > this.bound_height) {
            this.button_size = (int) ((((float) this.bound_height) - (((float) this.level_circles_border_dp) * ((float) (this.buttons_in_y + 1)))) / ((float) this.buttons_in_y));
        } else {
            this.button_size = (int) ((((float) this.bound_width) - (((float) this.level_circles_border_dp) * ((float) (this.buttons_in_x + 1)))) / ((float) this.buttons_in_x));
        }
        int current_lvl = 1;
        for (int y = 0; y < this.buttons_in_y; y++) {
            for (int x = 0; x < this.buttons_in_x; x++) {
                if (current_lvl <= this.TotalLevels) {
                    this.LevelButtons[current_lvl - 1] = new LevelButton("" + current_lvl, this.font, (float) (this.bound_x + (this.level_circles_border_dp + ((this.button_size + this.level_circles_border_dp) * x))), (float) (this.bound_y + (this.level_circles_border_dp + ((this.button_size + this.level_circles_border_dp) * y))), (float) this.button_size, this.screen);
                }
                current_lvl++;
            }
        }
    }

    public void setBounds(int x, int y, int width, int height) {
        this.bound_x = x;
        this.bound_y = y;
        this.bound_height = height;
        this.bound_width = width;
        init();
    }

    public void Update() {
        for (LevelButton Update : this.LevelButtons) {
            Update.Update();
        }
    }

    public LevelButton[] getLevelButtons() {
        return this.LevelButtons;
    }

    public void drawLevels(Canvas canvas) {
        for (LevelButton draw : this.LevelButtons) {
            draw.draw(canvas);
        }
    }

    public void loadLevels() {
        for (int i = 0; i < this.LevelButtons.length; i++) {
            this.LevelButtons[i].setLock(isLevelLocked(i));
        }
    }

    public boolean isLevelLocked(int level) {
        return this.ScoreManager.load_localscore_simple(new StringBuilder().append("unlock").append(level).toString()) != this.unlocked;
    }

    public void unlockLevel(int level) {
        this.ScoreManager.save_localscore_simple(this.unlocked, "unlock" + level);
    }

    public boolean isnextLevelUnlocked() {
        return nextLevelExists() && !isLevelLocked(this.currentLevel + 1);
    }

    public int getNextLevel() {
        return this.currentLevel + 1;
    }

    public boolean nextLevelExists() {
        return this.TotalLevels > this.currentLevel + 1;
    }

    public int getCurrentLevel() {
        return this.currentLevel;
    }

    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
    }

    public void unlockNextLevel() {
        if (nextLevelExists()) {
            unlockLevel(this.currentLevel + 1);
        }
    }
}
