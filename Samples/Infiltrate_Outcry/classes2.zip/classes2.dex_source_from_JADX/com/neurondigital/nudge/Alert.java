package com.neurondigital.nudge;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.EditText;

public class Alert extends DialogFragment {
    final int EDITTEXT = 1;
    NegativeButtonListener NegativeButtonListener;
    PositiveButtonListener PositiveButtonListener;
    final int TEXT = 0;
    String acceptText;
    Activity activity;
    String cancelText;
    Boolean exit;
    String hint;
    Context mContext;
    String text;
    String title;
    int type;

    class C00443 implements OnClickListener {
        C00443() {
        }

        public void onClick(DialogInterface dialog, int which) {
            if (Alert.this.PositiveButtonListener != null) {
                Alert.this.PositiveButtonListener.onPositiveButton("");
            }
        }
    }

    class C00454 implements OnClickListener {
        C00454() {
        }

        public void onClick(DialogInterface dialog, int which) {
            if (Alert.this.NegativeButtonListener != null) {
                Alert.this.NegativeButtonListener.onNegativeButton("");
            }
        }
    }

    public interface NegativeButtonListener {
        void onNegativeButton(String str);
    }

    public interface PositiveButtonListener {
        void onPositiveButton(String str);
    }

    public void DisplayText(String title, String text, String acceptText, String cancelText, Activity activity) {
        this.title = title;
        this.text = text;
        this.activity = activity;
        this.type = 0;
        this.acceptText = acceptText;
        this.cancelText = cancelText;
    }

    public void DisplayEditText(String title, String text, String hint, String acceptText, String cancelText, Activity activity) {
        this.title = title;
        this.activity = activity;
        this.text = text;
        this.hint = hint;
        this.type = 1;
        this.acceptText = acceptText;
        this.cancelText = cancelText;
    }

    public synchronized void setPositiveButtonListener(PositiveButtonListener PositiveButtonListener) {
        this.PositiveButtonListener = PositiveButtonListener;
    }

    public synchronized void setNegativeButtonListener(NegativeButtonListener NegativeButtonListener) {
        this.NegativeButtonListener = NegativeButtonListener;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.mContext = getActivity();
        Builder alertDialogBuilder = new Builder(this.mContext);
        alertDialogBuilder.setTitle(this.title);
        alertDialogBuilder.setMessage(this.text);
        if (this.type == 1) {
            final EditText edittext = new EditText(this.activity);
            edittext.setHint(this.hint);
            alertDialogBuilder.setView(edittext);
            alertDialogBuilder.setPositiveButton(this.acceptText, new OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (Alert.this.PositiveButtonListener != null) {
                        Alert.this.PositiveButtonListener.onPositiveButton(edittext.getText().toString());
                    }
                }
            });
            alertDialogBuilder.setNegativeButton(this.cancelText, new OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (Alert.this.NegativeButtonListener != null) {
                        Alert.this.NegativeButtonListener.onNegativeButton(edittext.getText().toString());
                    }
                }
            });
        }
        if (this.type == 0) {
            alertDialogBuilder.setPositiveButton(this.acceptText, new C00443());
            alertDialogBuilder.setNegativeButton(this.cancelText, new C00454());
        }
        return alertDialogBuilder.create();
    }
}
