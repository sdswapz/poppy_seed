package com.neurondigital.nudge;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.tapjoy.TapjoyConnectCore;

public class Particles {
    float[] Particle_x = new float[this.number];
    float[] Particle_y = new float[this.number];
    float[] alpha = new float[this.number];
    int counter = 0;
    int delay = 2;
    float[] direction = new float[this.number];
    int initialx_offset = 70;
    int initialy_offset = 40;
    float[] life = new float[this.number];
    int number = 100;
    Paint paint = new Paint();
    int particle_direction = -1;
    Bitmap particle_img;
    int particle_life;
    int speed = 1;

    public Particles(Bitmap particle_img, int delay, int speed, int particle_direction, int initialx_offset, int initialy_offset, int particle_life, int numberOfParticles) {
        this.particle_img = particle_img;
        this.delay = delay;
        this.speed = speed;
        this.particle_direction = particle_direction;
        this.initialx_offset = initialx_offset;
        this.initialy_offset = initialy_offset;
        this.particle_life = particle_life;
        this.number = numberOfParticles;
        for (int i = 0; i < this.number; i++) {
            this.Particle_x[i] = (float) ((Math.random() * ((double) initialx_offset)) - (Math.random() * ((double) initialx_offset)));
            this.Particle_y[i] = (float) ((Math.random() * ((double) initialy_offset)) - (Math.random() * ((double) initialy_offset)));
            if (particle_direction == -1) {
                this.direction[i] = (float) ((int) (Math.random() * 360.0d));
            } else {
                this.direction[i] = (float) ((((double) ((int) (Math.random() * 20.0d))) - (Math.random() * 20.0d)) + ((double) particle_direction));
            }
            this.life[i] = (float) (((int) (Math.random() * ((double) particle_life))) + particle_life);
            this.alpha[i] = (float) (((int) (Math.random() * 100.0d)) + 150);
        }
    }

    public void update() {
        this.counter++;
        if (this.counter > this.delay) {
            this.counter = 0;
            for (int i = 0; i < this.number; i++) {
                float[] fArr = this.life;
                fArr[i] = fArr[i] - TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
                if (this.life[i] > 0.0f) {
                    this.Particle_x[i] = (float) (((double) this.Particle_x[i]) + (Math.cos(-(((((double) this.direction[i]) * 3.141592653589793d) / 180.0d) - 1.5707963267948966d)) * (Math.random() * ((double) this.speed))));
                    this.Particle_y[i] = (float) (((double) this.Particle_y[i]) - (Math.sin(-(((((double) this.direction[i]) * 3.141592653589793d) / 180.0d) - 1.5707963267948966d)) * (Math.random() * ((double) this.speed))));
                } else {
                    this.Particle_x[i] = (float) ((Math.random() * ((double) this.initialx_offset)) - (Math.random() * ((double) this.initialx_offset)));
                    this.Particle_y[i] = (float) ((Math.random() * ((double) this.initialy_offset)) - (Math.random() * ((double) this.initialy_offset)));
                    if (this.particle_direction == -1) {
                        this.direction[i] = (float) ((int) (Math.random() * 360.0d));
                    } else {
                        this.direction[i] = (float) ((((double) ((int) (Math.random() * 15.0d))) - (Math.random() * 15.0d)) + ((double) this.particle_direction));
                    }
                    this.life[i] = (float) (this.particle_life + ((int) (Math.random() * ((double) this.particle_life))));
                }
            }
        }
    }

    public void setDirection(int Direction) {
        this.particle_direction = Direction;
    }

    public void draw(Canvas canvas, float x, float y) {
        for (int i = 0; i < this.number; i++) {
            this.paint.setAlpha(((int) this.life[i]) * 2);
            canvas.drawBitmap(this.particle_img, this.Particle_x[i] + x, this.Particle_y[i] + y, this.paint);
        }
    }
}
