package com.neurondigital.nudge;

import com.tapjoy.TapjoyConnectCore;
import java.util.ArrayList;

public class Effects {
    static final int BLINK = 0;
    ArrayList<Float> counter = new ArrayList();
    ArrayList<Integer> ids = new ArrayList();
    ArrayList<Float> speed = new ArrayList();
    ArrayList<Integer> type = new ArrayList();

    public void Update() {
        for (int i = 0; i < this.counter.size(); i++) {
            if (((Float) this.counter.get(i)).floatValue() >= TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER) {
                this.counter.set(i, Float.valueOf(0.0f));
            } else {
                this.counter.set(i, Float.valueOf(((Float) this.speed.get(i)).floatValue() + ((Float) this.counter.get(i)).floatValue()));
            }
        }
    }

    public float Blink(int id, float speed) {
        int i = 0;
        while (i < this.ids.size()) {
            if (((Integer) this.ids.get(i)).intValue() != id) {
                i++;
            } else if (((Float) this.counter.get(i)).floatValue() <= 0.5f) {
                return ((Float) this.counter.get(i)).floatValue() * 2.0f;
            } else {
                return TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER - ((((Float) this.counter.get(i)).floatValue() - 0.5f) * 2.0f);
            }
        }
        this.counter.add(Float.valueOf(0.0f));
        this.ids.add(Integer.valueOf(id));
        this.type.add(Integer.valueOf(0));
        this.speed.add(Float.valueOf(speed));
        return 0.0f;
    }
}
