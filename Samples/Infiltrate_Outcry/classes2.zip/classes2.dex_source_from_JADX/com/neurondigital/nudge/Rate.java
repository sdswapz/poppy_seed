package com.neurondigital.nudge;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;
import com.neurondigital.nudge.Alert.NegativeButtonListener;
import com.neurondigital.nudge.Alert.PositiveButtonListener;

public class Rate {

    static class C00522 implements NegativeButtonListener {
        C00522() {
        }

        public void onNegativeButton(String input) {
        }
    }

    public static int load_localpref(String identifier, Activity activity) {
        return PreferenceManager.getDefaultSharedPreferences(activity.getApplicationContext()).getInt("pref" + identifier, 0);
    }

    public static void save_localpref(int pref, String identifier, Activity activity) {
        Editor hiscores_editor = PreferenceManager.getDefaultSharedPreferences(activity.getApplicationContext()).edit();
        hiscores_editor.putInt("pref" + identifier, pref);
        hiscores_editor.commit();
    }

    public static boolean rateWithCounter(final FragmentActivity activity, int showRateAfterXStarts, String rate_title, String rate_text, final String unable_to_reach_market_error, String acceptText, String cancelText) {
        if (load_localpref("rate", activity) < 100) {
            save_localpref(load_localpref("rate", activity) + 1, "rate", activity);
            if (load_localpref("rate", activity) == showRateAfterXStarts || load_localpref("rate", activity) == showRateAfterXStarts * 4) {
                Alert alert = new Alert();
                alert.DisplayText(rate_title, rate_text, acceptText, cancelText, activity);
                alert.show(activity.getSupportFragmentManager(), rate_title);
                alert.setPositiveButtonListener(new PositiveButtonListener() {
                    public void onPositiveButton(String input) {
                        Rate.rate(activity, unable_to_reach_market_error);
                        Rate.save_localpref(100, "rate", activity);
                    }
                });
                alert.setNegativeButtonListener(new C00522());
                return true;
            }
        }
        return false;
    }

    public static void rate(Activity activity, String unable_to_reach_market_error) {
        try {
            activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + activity.getPackageName())));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(activity, unable_to_reach_market_error, 1).show();
        }
    }
}
