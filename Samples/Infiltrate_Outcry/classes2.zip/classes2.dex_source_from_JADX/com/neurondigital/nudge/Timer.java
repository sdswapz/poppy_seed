package com.neurondigital.nudge;

import android.os.SystemClock;

public class Timer {
    public int delayMilliSeconds;
    boolean delayOn = false;
    private long lastRefresh = SystemClock.elapsedRealtime();
    private long now = SystemClock.elapsedRealtime();
    TimerListener timerListener;

    public interface TimerListener {
        void onReady();
    }

    public void reset() {
        this.lastRefresh = SystemClock.elapsedRealtime();
    }

    public int elapsedTime() {
        this.now = SystemClock.elapsedRealtime();
        return (int) (this.now - this.lastRefresh);
    }

    public void update() {
        if (this.delayOn && elapsedTime() > this.delayMilliSeconds) {
            reset();
            this.delayOn = false;
            if (this.timerListener != null) {
                this.timerListener.onReady();
            }
        }
    }

    public void delay(int delayMilliSeconds, TimerListener listener) {
        reset();
        this.timerListener = listener;
        this.delayMilliSeconds = delayMilliSeconds;
        this.delayOn = true;
    }
}
