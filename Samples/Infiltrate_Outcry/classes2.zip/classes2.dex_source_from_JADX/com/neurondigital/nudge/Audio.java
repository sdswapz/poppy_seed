package com.neurondigital.nudge;

import android.media.MediaPlayer;
import android.media.SoundPool;
import com.tapjoy.TapjoyConnectCore;

public class Audio {
    final int PAUSED = 1;
    final int PLAYING = 2;
    final int STOPPED = 0;
    boolean master_muted = false;
    MediaPlayer music;
    int musicRef;
    int musicState = 0;
    boolean music_muted = false;
    Screen screen;
    boolean sound_muted = false;
    public SoundPool sp;

    public Audio(Screen screen, int musicRef) {
        this.screen = screen;
        screen.setVolumeControlStream(3);
        this.sp = new SoundPool(5, 3, 0);
        this.musicRef = musicRef;
        this.music = MediaPlayer.create(screen, musicRef);
    }

    public boolean isMusicMuted() {
        return this.music_muted;
    }

    public void unMuteMusic() {
        this.music_muted = false;
    }

    public void MuteMusic() {
        this.music_muted = true;
    }

    public void PlayMusic() {
        if (!isMusicMuted() && !isMasterMuted()) {
            this.music = MediaPlayer.create(this.screen, this.musicRef);
            this.music.start();
            this.music.setVolume(0.4f, 0.4f);
            this.music.setLooping(true);
            this.musicState = 2;
        }
    }

    public void StopMusic() {
        if (this.music != null) {
            this.music.stop();
        }
    }

    public void toggleMusicMute() {
        if (isMusicMuted()) {
            unMuteMusic();
            PlayMusic();
            return;
        }
        MuteMusic();
        StopMusic();
    }

    public void PauseMusic() {
        StopMusic();
        this.musicState = 1;
    }

    public void unPauseMusic() {
        if (this.musicState == 1) {
            PlayMusic();
        }
    }

    public boolean isSoundFxMuted() {
        return this.sound_muted;
    }

    public void unMuteSoundFX() {
        this.sound_muted = false;
    }

    public void MuteSoundFX() {
        this.sound_muted = true;
    }

    public boolean toggleSoundFxMute() {
        if (isSoundFxMuted()) {
            unMuteSoundFX();
        } else {
            MuteSoundFX();
        }
        return isSoundFxMuted();
    }

    public void playSoundFX(int SoundId) {
        if (SoundId != 0 && !isSoundFxMuted() && !isMasterMuted()) {
            this.sp.play(SoundId, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0, 0, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER);
        }
    }

    public void playRandomSoundFX(int[] SoundIds) {
        int random_sound = (int) (Math.random() * ((double) ((float) SoundIds.length)));
        if (SoundIds[random_sound] != 0 && !isSoundFxMuted() && !isMasterMuted()) {
            this.sp.play(SoundIds[random_sound], TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0, 0, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER);
        }
    }

    public boolean isMasterMuted() {
        return this.master_muted;
    }

    public void unMuteMaster() {
        this.master_muted = false;
    }

    public void MuteMaster() {
        this.master_muted = true;
    }

    public boolean toggleMasterMute() {
        if (isMasterMuted()) {
            unMuteMaster();
        } else {
            MuteMaster();
        }
        return isMasterMuted();
    }
}
