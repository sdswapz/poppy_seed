package com.neurondigital.nudge;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import com.tapjoy.TapjoyConnectCore;

public class Sprite {
    public static final int CIRCLE = 1;
    public static final int HORIZONTAL = 1;
    public static final int SQUARE = 0;
    public static final int VERTICAL = 0;
    float anchorX;
    float anchorY;
    int animation_speed;
    public int back_height;
    public int back_width;
    public Paint backgroundPaint;
    public int backgroundShape;
    public int current_image;
    private float direction;
    public Paint imagePaint;
    Bitmap[] image_sequence;
    private int pause_image_number;
    float scale;
    float screenPercentage_scale;
    long start_time;
    public String text;
    public Paint textPaint;
    Bitmap[] unrotated_image_sequence;

    public Sprite(Bitmap image, float scale) {
        this.current_image = 0;
        this.start_time = SystemClock.uptimeMillis();
        this.imagePaint = new Paint();
        this.scale = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
        this.pause_image_number = -1;
        this.direction = 0.0f;
        this.anchorX = 0.0f;
        this.anchorY = 0.0f;
        this.image_sequence = new Bitmap[1];
        this.screenPercentage_scale = scale;
        this.unrotated_image_sequence = new Bitmap[1];
        if (scale >= 0.0f) {
            Bitmap[] bitmapArr = this.image_sequence;
            Bitmap[] bitmapArr2 = this.unrotated_image_sequence;
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(image, (int) scale, (int) ((scale / ((float) image.getWidth())) * ((float) image.getHeight())), true);
            bitmapArr2[0] = createScaledBitmap;
            bitmapArr[0] = createScaledBitmap;
            return;
        }
        bitmapArr = this.image_sequence;
        this.unrotated_image_sequence[0] = image;
        bitmapArr[0] = image;
    }

    public Sprite(Bitmap image, float scale, boolean scale_height) {
        this.current_image = 0;
        this.start_time = SystemClock.uptimeMillis();
        this.imagePaint = new Paint();
        this.scale = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
        this.pause_image_number = -1;
        this.direction = 0.0f;
        this.anchorX = 0.0f;
        this.anchorY = 0.0f;
        this.image_sequence = new Bitmap[1];
        this.screenPercentage_scale = scale;
        this.unrotated_image_sequence = new Bitmap[1];
        if (scale >= 0.0f) {
            Bitmap[] bitmapArr = this.image_sequence;
            Bitmap[] bitmapArr2 = this.unrotated_image_sequence;
            Bitmap createScaledBitmap = Bitmap.createScaledBitmap(image, (int) ((scale / ((float) image.getHeight())) * ((float) image.getWidth())), (int) scale, true);
            bitmapArr2[0] = createScaledBitmap;
            bitmapArr[0] = createScaledBitmap;
            return;
        }
        bitmapArr = this.image_sequence;
        this.unrotated_image_sequence[0] = image;
        bitmapArr[0] = image;
    }

    public Sprite(Bitmap sprite_sheet, float scale, int itemsX, int length, int animation_speed) {
        this.current_image = 0;
        this.start_time = SystemClock.uptimeMillis();
        this.imagePaint = new Paint();
        this.scale = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
        this.pause_image_number = -1;
        this.direction = 0.0f;
        this.anchorX = 0.0f;
        this.anchorY = 0.0f;
        this.animation_speed = animation_speed;
        this.unrotated_image_sequence = convert(sprite_sheet, itemsX, length);
        this.image_sequence = new Bitmap[length];
        this.screenPercentage_scale = scale;
        int count;
        if (scale >= 0.0f) {
            for (count = 0; count < length; count++) {
                Bitmap[] bitmapArr = this.image_sequence;
                Bitmap[] bitmapArr2 = this.unrotated_image_sequence;
                Bitmap createScaledBitmap = Bitmap.createScaledBitmap(this.unrotated_image_sequence[count], (int) scale, (int) ((scale / ((float) this.unrotated_image_sequence[count].getWidth())) * ((float) this.unrotated_image_sequence[count].getHeight())), true);
                bitmapArr2[count] = createScaledBitmap;
                bitmapArr[count] = createScaledBitmap;
            }
        } else {
            for (count = 0; count < length; count++) {
                this.image_sequence[count] = this.unrotated_image_sequence[count];
            }
        }
        this.start_time = (long) (((double) SystemClock.uptimeMillis()) + (Math.random() * 400.0d));
    }

    public Sprite(String text, float dpSize, Typeface font, int color) {
        this.current_image = 0;
        this.start_time = SystemClock.uptimeMillis();
        this.imagePaint = new Paint();
        this.scale = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
        this.pause_image_number = -1;
        this.direction = 0.0f;
        this.anchorX = 0.0f;
        this.anchorY = 0.0f;
        this.textPaint = new Paint();
        this.textPaint.setTextSize(dpSize);
        this.textPaint.setAntiAlias(true);
        this.textPaint.setColor(color);
        this.textPaint.setTypeface(font);
        this.text = text;
    }

    public Sprite Clone() {
        Sprite clone;
        if (this.image_sequence != null) {
            clone = new Sprite(this.image_sequence[0], this.screenPercentage_scale);
        } else {
            clone = new Sprite(this.text, this.textPaint.getTextSize(), this.textPaint.getTypeface(), this.textPaint.getColor());
        }
        clone.rotate(this.direction);
        clone.animation_speed = this.animation_speed;
        clone.image_sequence = (Bitmap[]) this.image_sequence.clone();
        clone.unrotated_image_sequence = (Bitmap[]) this.unrotated_image_sequence.clone();
        clone.current_image = this.current_image;
        clone.scale = this.scale;
        if (this.imagePaint != null) {
            clone.imagePaint = new Paint(this.imagePaint);
        }
        clone.back_height = this.back_height;
        clone.back_width = this.back_width;
        if (this.backgroundPaint != null) {
            clone.backgroundPaint = new Paint(this.backgroundPaint);
        }
        clone.pause_image_number = this.pause_image_number;
        clone.screenPercentage_scale = this.screenPercentage_scale;
        clone.start_time = this.start_time;
        if (this.textPaint != null) {
            clone.textPaint = new Paint(this.textPaint);
        }
        return clone;
    }

    public void addBackground(int shape, int Color, int width, int height) {
        this.backgroundPaint = new Paint();
        this.backgroundPaint.setColor(Color);
        this.backgroundPaint.setAntiAlias(true);
        this.back_height = height;
        this.back_width = width;
        this.backgroundShape = shape;
    }

    public void removeBackground() {
        this.backgroundPaint = null;
    }

    public int getWidth() {
        if (this.backgroundPaint != null) {
            return this.back_width;
        }
        if (this.image_sequence != null) {
            return this.image_sequence[0].getWidth();
        }
        if (this.textPaint == null) {
            return 1;
        }
        Rect bounds = new Rect();
        this.textPaint.getTextBounds(this.text, 0, this.text.length(), bounds);
        return bounds.width();
    }

    public int getHeight() {
        if (this.backgroundPaint != null) {
            return this.back_height;
        }
        if (this.image_sequence != null) {
            return this.image_sequence[0].getHeight();
        }
        if (this.textPaint == null) {
            return 1;
        }
        Rect bounds = new Rect();
        this.textPaint.getTextBounds(this.text, 0, this.text.length(), bounds);
        return bounds.height();
    }

    public float getDirection() {
        return this.direction;
    }

    public void setScale(float scale) {
        if (scale != this.scale) {
            this.scale = scale / Instance.NORMAL_SCALE;
            if (this.image_sequence != null) {
                float scale_factor = this.screenPercentage_scale * this.scale;
                if (scale_factor != 0.0f) {
                    for (int count = 0; count < this.image_sequence.length; count++) {
                        this.image_sequence[count] = Bitmap.createScaledBitmap(this.unrotated_image_sequence[count], (int) scale_factor, (int) ((scale_factor / ((float) this.unrotated_image_sequence[count].getWidth())) * ((float) this.unrotated_image_sequence[count].getHeight())), true);
                    }
                }
            }
        }
    }

    public void setScale_keeprotation(float scale) {
        if (scale != this.scale) {
            this.scale = scale / Instance.NORMAL_SCALE;
            if (this.image_sequence != null) {
                float scale_factor = this.screenPercentage_scale * this.scale;
                if (scale_factor != 0.0f) {
                    for (int count = 0; count < this.image_sequence.length; count++) {
                        this.image_sequence[count] = Bitmap.createScaledBitmap(this.image_sequence[count], (int) scale_factor, (int) ((scale_factor / ((float) this.image_sequence[count].getWidth())) * ((float) this.image_sequence[count].getHeight())), true);
                    }
                }
            }
        }
    }

    public void PauseOn(int image_number) {
        this.pause_image_number = image_number;
    }

    public void Play() {
        this.pause_image_number = -1;
    }

    public boolean isPaused() {
        return this.pause_image_number != -1;
    }

    private Bitmap[] convert(Bitmap sprite_sheet, int itemsX, int length) {
        int itemsY = (int) Math.ceil((double) (((float) length) / ((float) itemsX)));
        int tile_height = sprite_sheet.getHeight() / itemsY;
        int tile_width = sprite_sheet.getWidth() / itemsX;
        Bitmap[] image_sequence = new Bitmap[length];
        for (int y = 0; y < itemsY; y++) {
            for (int x = 0; x < itemsX; x++) {
                if ((itemsX * y) + x < length) {
                    image_sequence[(itemsX * y) + x] = Bitmap.createBitmap(sprite_sheet, x * tile_width, y * tile_height, tile_width, tile_height);
                }
            }
        }
        return image_sequence;
    }

    public void draw(Canvas canvas, float x, float y) {
        draw(canvas, x, y, this.imagePaint);
    }

    public void draw(Canvas canvas, float x, float y, Paint paint) {
        if (this.scale != 0.0f) {
            float centerx = (x - ((float) getAnchorX())) + ((float) (getWidth() / 2));
            float centery = (y - ((float) getAnchorY())) + ((float) (getHeight() / 2));
            if (this.backgroundPaint != null) {
                if (this.backgroundShape == 0) {
                    canvas.drawRect(centerx - ((((float) this.back_width) * this.scale) * 0.5f), centery - ((((float) this.back_height) * this.scale) * 0.5f), centerx + ((((float) this.back_width) * this.scale) * 0.5f), centery + ((((float) this.back_height) * this.scale) * 0.5f), this.backgroundPaint);
                } else if (this.backgroundShape == 1) {
                    canvas.drawCircle(centerx, centery, (((float) this.back_width) * this.scale) * 0.5f, this.backgroundPaint);
                }
            }
            if (this.textPaint != null) {
                Rect bounds = new Rect();
                this.textPaint.getTextBounds(this.text, 0, this.text.length(), bounds);
                canvas.drawText(this.text, centerx - ((float) (bounds.width() / 2)), ((float) (bounds.height() / 2)) + centery, this.textPaint);
            }
            if (this.image_sequence == null) {
                return;
            }
            if (this.pause_image_number >= 0) {
                canvas.drawBitmap(this.image_sequence[this.pause_image_number], centerx - ((float) (this.image_sequence[this.current_image].getWidth() / 2)), centery - ((float) (this.image_sequence[this.current_image].getHeight() / 2)), paint);
                return;
            }
            canvas.drawBitmap(this.image_sequence[this.current_image], centerx - ((float) (this.image_sequence[this.current_image].getWidth() / 2)), centery - ((float) (this.image_sequence[this.current_image].getHeight() / 2)), paint);
            if (this.image_sequence.length > 1 && SystemClock.uptimeMillis() > this.start_time + ((long) (500 - this.animation_speed))) {
                this.start_time = SystemClock.uptimeMillis();
                this.current_image++;
                if (this.current_image + 1 > this.image_sequence.length) {
                    this.current_image = 0;
                }
            }
        }
    }

    public void setAlpha(int alpha) {
        this.imagePaint.setAlpha(alpha);
    }

    public void Highlight(int color) {
        ColorFilter filter = new LightingColorFilter(1, color);
        if (this.imagePaint != null) {
            this.imagePaint.setColorFilter(filter);
        }
        if (this.textPaint != null) {
            this.textPaint.setColorFilter(filter);
        }
    }

    public void unHighlight() {
        if (this.imagePaint != null) {
            this.imagePaint.setColorFilter(null);
        }
        if (this.textPaint != null) {
            this.textPaint.setColorFilter(null);
        }
    }

    public boolean isHighlighted() {
        boolean ishighlited = false;
        if (!(this.imagePaint == null || this.imagePaint.getColorFilter() == null)) {
            ishighlited = true;
        }
        if (this.textPaint == null || this.textPaint.getColorFilter() == null) {
            return ishighlited;
        }
        return true;
    }

    public void rotate(float direction) {
        float angle = direction;
        this.direction = direction;
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        Bitmap m = Bitmap.createBitmap(5, 5, Config.ARGB_8888);
        RectF a = new RectF(0.0f, 0.0f, (float) this.unrotated_image_sequence[0].getWidth(), (float) this.unrotated_image_sequence[0].getHeight());
        Matrix mat = new Matrix();
        mat.setRotate(direction, (float) (this.unrotated_image_sequence[0].getWidth() / 2), (float) (this.unrotated_image_sequence[0].getHeight() / 2));
        mat.mapRect(a);
        for (int i = 0; i < this.image_sequence.length; i++) {
            this.image_sequence[i] = Bitmap.createScaledBitmap(m, (int) a.width(), (int) a.height(), true);
            Canvas canvas = new Canvas(this.image_sequence[i]);
            canvas.rotate(angle, (float) (this.image_sequence[i].getWidth() / 2), (float) (this.image_sequence[i].getHeight() / 2));
            canvas.drawBitmap(this.unrotated_image_sequence[i], (float) ((this.image_sequence[i].getWidth() / 2) - (this.unrotated_image_sequence[i].getWidth() / 2)), (float) ((this.image_sequence[i].getHeight() / 2) - (this.unrotated_image_sequence[i].getHeight() / 2)), paint);
            canvas.rotate(-angle, (float) (this.image_sequence[i].getWidth() / 2), (float) (this.image_sequence[i].getHeight() / 2));
        }
    }

    public void flip(int direction) {
        Matrix m = new Matrix();
        if (direction == 0) {
            m.preScale(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, -1.0f);
        } else {
            m.preScale(-1.0f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER);
        }
        for (int i = 0; i < this.image_sequence.length; i++) {
            this.image_sequence[i] = Bitmap.createBitmap(this.image_sequence[i], 0, 0, this.image_sequence[i].getWidth(), this.image_sequence[i].getHeight(), m, false);
        }
    }

    public static Bitmap Scale(Bitmap unscaled, float scale) {
        return Bitmap.createScaledBitmap(unscaled, (int) scale, (int) ((scale / ((float) unscaled.getWidth())) * ((float) unscaled.getHeight())), true);
    }

    public void setAnchor(float x, float y) {
        this.anchorX = x;
        this.anchorY = y;
    }

    public int getAnchorX() {
        return (int) (this.anchorX * ((float) getWidth()));
    }

    public int getAnchorY() {
        return (int) (this.anchorY * ((float) getHeight()));
    }
}
