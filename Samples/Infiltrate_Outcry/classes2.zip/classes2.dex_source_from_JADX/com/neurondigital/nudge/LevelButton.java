package com.neurondigital.nudge;

import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Typeface;

public class LevelButton extends Instance {
    public boolean islocked = true;
    Sprite lock;
    Screen screen;
    Sprite unlock;

    public LevelButton(String text, Typeface font, float x, float y, float size, Screen screen) {
        super(null, x, y, screen, false);
        this.sprite = new Sprite(text, (float) ((int) screen.getResources().getDimension(C0050R.dimen.level_button)), font, -65536);
        this.sprite.addBackground(0, -65536, (int) size, (int) size);
        initAnimation();
        this.screen = screen;
        this.lock = new Sprite(BitmapFactory.decodeResource(screen.getResources(), C0050R.drawable.lock), size / 3.0f);
        this.unlock = new Sprite(BitmapFactory.decodeResource(screen.getResources(), C0050R.drawable.unlock), size / 3.0f);
    }

    public void setLock(boolean islocked) {
        this.islocked = islocked;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.islocked) {
            this.lock.draw(canvas, (this.x + ((float) getWidth())) - (((float) this.lock.getWidth()) * 0.8f), (this.y + ((float) getHeight())) - (((float) this.lock.getHeight()) * 0.8f));
        } else {
            this.unlock.draw(canvas, (this.x + ((float) getWidth())) - (((float) this.unlock.getWidth()) * 0.8f), (this.y + ((float) getHeight())) - (((float) this.unlock.getHeight()) * 0.8f));
        }
    }
}
