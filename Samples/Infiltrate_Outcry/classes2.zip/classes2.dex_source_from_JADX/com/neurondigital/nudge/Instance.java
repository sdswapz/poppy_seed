package com.neurondigital.nudge;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import com.neurondigital.nudge.Animator.AnimationListener;
import com.neurondigital.nudge.Animator.AnimationReadyListener;

public class Instance {
    public static final float NORMAL_SCALE = 100.0f;
    public float accelerationx = 0.0f;
    public float accelerationy = 0.0f;
    Boolean animationKeepRotation = Boolean.valueOf(false);
    Animator animatorScale;
    Animator animatorX;
    Animator animatorY;
    public int collision_offset_height = 0;
    public int collision_offset_width = 0;
    public int collision_offset_x = 0;
    public int collision_offset_y = 0;
    Physics physics = new Physics();
    AnimationReadyListener positionListener;
    int positionListenerXYDone = 0;
    public float scale = NORMAL_SCALE;
    AnimationReadyListener scaleListener;
    Screen screen;
    public float speedx = 0.0f;
    public float speedy = 0.0f;
    public Sprite sprite;
    public int tag = 0;
    boolean world = true;
    public float f79x;
    public float f80y;

    class C00461 implements AnimationListener {
        C00461() {
        }

        public void onReady(float value) {
            Instance.this.scale = value;
            if (Instance.this.animationKeepRotation.booleanValue()) {
                Instance.this.sprite.setScale_keeprotation(Instance.this.scale);
            } else {
                Instance.this.sprite.setScale(Instance.this.scale);
            }
            if (Instance.this.scaleListener != null) {
                Instance.this.scaleListener.onReady();
            }
        }

        public void onUpdate(float value) {
            Instance.this.scale = value;
            if (Instance.this.animationKeepRotation.booleanValue()) {
                Instance.this.sprite.setScale_keeprotation(Instance.this.scale);
            } else {
                Instance.this.sprite.setScale(Instance.this.scale);
            }
        }
    }

    class C00472 implements AnimationListener {
        C00472() {
        }

        public void onReady(float value) {
            Instance.this.f80y = value;
            Instance instance = Instance.this;
            instance.positionListenerXYDone++;
            if (Instance.this.positionListener != null && Instance.this.positionListenerXYDone == 2) {
                Instance.this.positionListener.onReady();
            }
        }

        public void onUpdate(float value) {
            Instance.this.f80y = value;
        }
    }

    class C00483 implements AnimationListener {
        C00483() {
        }

        public void onReady(float value) {
            Instance.this.f79x = value;
            Instance instance = Instance.this;
            instance.positionListenerXYDone++;
            if (Instance.this.positionListener != null && Instance.this.positionListenerXYDone == 2) {
                Instance.this.positionListener.onReady();
            }
        }

        public void onUpdate(float value) {
            Instance.this.f79x = value;
        }
    }

    public Instance(float x, float y, Screen screen, boolean world) {
        this.screen = screen;
        this.f79x = x;
        this.f80y = y;
        this.world = world;
        initAnimation();
    }

    public Instance(Sprite sprite, float x, float y, Screen screen, boolean world) {
        this.sprite = sprite;
        this.screen = screen;
        this.f79x = x;
        this.f80y = y;
        this.world = world;
        initAnimation();
    }

    public Instance(Sprite sprite, float x, float y, Screen screen, boolean world, int tag) {
        this.sprite = sprite;
        this.screen = screen;
        this.f79x = x;
        this.f80y = y;
        this.world = world;
        this.tag = tag;
        initAnimation();
    }

    public void Update() {
        this.f79x += this.speedx;
        this.f80y += this.speedy;
        this.speedx += this.accelerationx;
        this.speedy += this.accelerationy;
        if (this.animatorScale != null) {
            this.animatorScale.Update();
        }
        if (this.animatorX != null) {
            this.animatorX.Update();
        }
        if (this.animatorY != null) {
            this.animatorY.Update();
        }
    }

    public void rotate(float direction) {
        this.sprite.rotate(direction);
    }

    public float getDirection() {
        return this.sprite.getDirection();
    }

    public int getHeight() {
        return this.sprite.getHeight();
    }

    public int getWidth() {
        return this.sprite.getWidth();
    }

    public void setAnchor(float x, float y) {
        if (this.sprite != null) {
            this.sprite.setAnchor(x, y);
        }
    }

    public Instance Clone() {
        Instance clone = new Instance(this.f79x, this.f80y, this.screen, this.world);
        clone.speedx = this.speedx;
        clone.speedy = this.speedy;
        clone.f79x = this.f79x;
        clone.f80y = this.f80y;
        clone.tag = this.tag;
        if (this.sprite != null) {
            clone.sprite = this.sprite;
        }
        return clone;
    }

    public void draw(Canvas canvas) {
        if (this.sprite != null) {
            if (this.world) {
                this.sprite.draw(canvas, (float) this.screen.ScreenX((float) ((int) this.f79x)), (float) this.screen.ScreenY((float) ((int) this.f80y)));
            } else {
                this.sprite.draw(canvas, this.f79x, this.f80y);
            }
        }
        if (this.screen.debug_mode) {
            this.physics.drawDebug(canvas);
        }
    }

    public void draw(Canvas canvas, Paint paint) {
        if (this.sprite != null) {
            if (this.world) {
                this.sprite.draw(canvas, (float) this.screen.ScreenX((float) ((int) this.f79x)), (float) this.screen.ScreenY((float) ((int) this.f80y)), paint);
            } else {
                this.sprite.draw(canvas, this.f79x, this.f80y, paint);
            }
        }
        if (this.screen.debug_mode) {
            this.physics.drawDebug(canvas);
        }
    }

    public void setCollision_dimensions(int offset_x, int offset_y, int offset_width, int offset_height) {
        this.collision_offset_x = offset_x;
        this.collision_offset_y = offset_y;
        this.collision_offset_height = offset_height;
        this.collision_offset_width = offset_width;
    }

    public boolean isTouched(MotionEvent event) {
        int pointerIndex = event.getActionIndex();
        if (this.world) {
            return this.physics.intersect(this.screen.ScreenX((float) ((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX())), this.screen.ScreenY((float) ((((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY())), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, (int) event.getX(pointerIndex), (int) event.getY(pointerIndex));
        }
        return this.physics.intersect((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX(), (((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY(), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, (int) event.getX(pointerIndex), (int) event.getY(pointerIndex));
    }

    public boolean CollidedWith(Instance b) {
        return CollidedWith((((int) b.f79x) + b.collision_offset_x) - b.sprite.getAnchorX(), (((int) b.f80y) - b.collision_offset_y) - b.sprite.getAnchorY(), b.getWidth() - b.collision_offset_width, b.getHeight() - b.collision_offset_height, b.world);
    }

    public boolean CollidedWith(int x, int y, int width, int height, boolean worldCoordinates) {
        if (this.world) {
            if (worldCoordinates) {
                return this.physics.intersect(this.screen.ScreenX((float) ((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX())), this.screen.ScreenY((float) ((((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY())), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, this.screen.ScreenX((float) x), this.screen.ScreenY((float) y), width, height);
            }
            return this.physics.intersect(this.screen.ScreenX((float) ((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX())), this.screen.ScreenY((float) ((((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY())), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, x, y, width, height);
        } else if (worldCoordinates) {
            return this.physics.intersect((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX(), (((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY(), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, this.screen.ScreenX((float) x), this.screen.ScreenY((float) y), width, height);
        } else {
            return this.physics.intersect((((int) this.f79x) + this.collision_offset_x) - this.sprite.getAnchorX(), (((int) this.f80y) + this.collision_offset_y) - this.sprite.getAnchorY(), getWidth() - this.collision_offset_width, getHeight() - this.collision_offset_height, x, y, width, height);
        }
    }

    public boolean inScreen() {
        if (this.world) {
            return this.physics.intersect(this.screen.ScreenX((float) (((int) this.f79x) - this.sprite.getAnchorX())), this.screen.ScreenY((float) (((int) this.f80y) - this.sprite.getAnchorY())), getWidth(), getHeight(), 0, 0, this.screen.ScreenWidth(), this.screen.ScreenHeight());
        }
        return this.physics.intersect(((int) this.f79x) - this.sprite.getAnchorX(), ((int) this.f80y) - this.sprite.getAnchorY(), getWidth(), getHeight(), 0, 0, this.screen.ScreenWidth(), this.screen.ScreenHeight());
    }

    public void Highlight(int color) {
        this.sprite.Highlight(color);
    }

    public void unHighlight() {
        this.sprite.unHighlight();
    }

    public boolean isHighlighted() {
        return this.sprite.isHighlighted();
    }

    public void initAnimation() {
        if (this.sprite != null) {
            this.animatorScale = new Animator();
            this.animatorScale.setAnimationListener(new C00461());
        }
        this.animatorY = new Animator();
        this.animatorY.setAnimationListener(new C00472());
        this.animatorX = new Animator();
        this.animatorX.setAnimationListener(new C00483());
    }

    public void animateScale(float targetScale, float animationSpeed, boolean animationKeepRotation, AnimationReadyListener ScaleListener) {
        this.scaleListener = ScaleListener;
        this.animationKeepRotation = Boolean.valueOf(animationKeepRotation);
        if (this.animatorScale != null) {
            this.animatorScale.animate(this.scale, targetScale, animationSpeed);
        }
    }

    public void animateScale(float targetScale, float animationSpeed, AnimationReadyListener animationListener) {
        animateScale(targetScale, animationSpeed, false, animationListener);
    }

    public void animateScale(float targetScale, float animationSpeed) {
        animateScale(targetScale, animationSpeed, false, null);
    }

    public boolean isNormalScale() {
        return NORMAL_SCALE == this.scale;
    }

    public void setScale(float scale) {
        this.scale = scale;
        this.sprite.setScale(scale);
    }

    public void animatePosition(float targetX, float targetY, float animationSpeed, AnimationReadyListener positionListener) {
        this.positionListener = positionListener;
        this.positionListenerXYDone = 0;
        if (this.animatorX != null && this.animatorY != null) {
            double angle = Math.atan((double) (Math.abs(targetX - this.f79x) / Math.abs(targetY - this.f80y)));
            this.animatorX.animate(this.f79x, targetX, ((float) Math.sin(angle)) * animationSpeed);
            this.animatorY.animate(this.f80y, targetY, ((float) Math.cos(angle)) * animationSpeed);
        }
    }

    public void stopAnimation() {
        if (!(this.animatorX == null || this.animatorY == null)) {
            this.animatorX.stop();
            this.animatorY.stop();
        }
        if (this.animatorScale != null) {
            this.animatorScale.stop();
        }
    }

    public void expandOnTouch(MotionEvent event, AnimationReadyListener pressedListener) {
        if (event.getAction() == 1 && !isNormalScale()) {
            animateScale(NORMAL_SCALE, 10.0f, pressedListener);
        }
        if (event.getAction() == 0 && isTouched(event)) {
            animateScale(120.0f, 5.0f);
        }
    }

    public void expandOnTouch(MotionEvent event, int expandScale, int finalScale, int expandSpeed, int finalSpeed, AnimationReadyListener pressedListener) {
        if (event.getAction() == 1 && !isNormalScale()) {
            animateScale((float) finalScale, (float) finalSpeed, pressedListener);
        }
        if (event.getAction() == 0 && isTouched(event)) {
            animateScale((float) expandScale, (float) expandSpeed);
        }
    }

    public void highlightOnTouch(MotionEvent event, int color, AnimationReadyListener pressedListener) {
        if (event.getAction() == 1 && isHighlighted()) {
            unHighlight();
            pressedListener.onReady();
        }
        if (event.getAction() == 0 && isTouched(event)) {
            Highlight(color);
        }
    }
}
