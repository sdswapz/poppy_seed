package com.neurondigital.nudge;

import android.app.Activity;
import com.google.android.gms.analytics.GoogleAnalytics;
import com.google.android.gms.analytics.HitBuilders.AppViewBuilder;
import com.google.android.gms.analytics.Tracker;
import java.util.HashMap;

public class AnalyticsHelper {
    Activity activity;
    protected HashMap<TrackerName, Tracker> mTrackers = new HashMap();
    public Tracker tracker;

    public enum TrackerName {
        APP_TRACKER,
        GLOBAL_TRACKER,
        ECOMMERCE_TRACKER
    }

    public AnalyticsHelper(Activity activity) {
        this.activity = activity;
    }

    public synchronized Tracker initialiseAnalytics(String PROPERTY_ID) {
        if (!this.mTrackers.containsKey(TrackerName.APP_TRACKER)) {
            GoogleAnalytics analytics = GoogleAnalytics.getInstance(this.activity);
            analytics.getLogger().setLogLevel(0);
            analytics.setDryRun(false);
            this.tracker = analytics.newTracker(PROPERTY_ID);
            this.mTrackers.put(TrackerName.APP_TRACKER, this.tracker);
        }
        return (Tracker) this.mTrackers.get(TrackerName.APP_TRACKER);
    }

    public void AnalyticsView() {
        this.tracker.enableAutoActivityTracking(true);
        this.tracker.send(new AppViewBuilder().build());
        GoogleAnalytics.getInstance(this.activity.getBaseContext()).dispatchLocalHits();
    }

    protected void onStart() {
        GoogleAnalytics.getInstance(this.activity).reportActivityStart(this.activity);
    }

    protected void onStop() {
        GoogleAnalytics.getInstance(this.activity).reportActivityStop(this.activity);
    }
}
