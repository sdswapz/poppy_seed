package com.neurondigital.nudge;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import com.neurondigital.nudge.Animator.AnimationListener;
import com.neurondigital.nudge.Animator.AnimationReadyListener;
import com.tapjoy.TapjoyConnectCore;

public class Text {
    public static Alignment ALIGN_CENTER = Alignment.ALIGN_CENTER;
    public static Alignment ALIGN_NORMAL = Alignment.ALIGN_NORMAL;
    public static Alignment ALIGN_OPPOSITE = Alignment.ALIGN_OPPOSITE;
    Alignment align;
    Animator animFade;
    AnimationReadyListener fadeListener;
    float opacity = 0.0f;
    Paint paint;
    String text = "";
    float width;

    class C00541 implements AnimationListener {
        C00541() {
        }

        public void onReady(float value) {
            Text.this.opacity = value;
            if (Text.this.fadeListener != null) {
                Text.this.fadeListener.onReady();
            }
        }

        public void onUpdate(float value) {
            Text.this.opacity = value;
        }
    }

    public static StaticLayout drawText(Canvas canvas, Paint paint, String text, float x, float y, float width, Alignment align) {
        StaticLayout layout = new StaticLayout(text, new TextPaint(paint), (int) width, align, 1.2f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, false);
        canvas.translate(x, y);
        layout.draw(canvas);
        canvas.translate(-x, -y);
        return layout;
    }

    public static StaticLayout drawTextMiddle(Canvas canvas, Paint paint, String text, float x, float y, float width, Alignment align) {
        StaticLayout layout = new StaticLayout(text, new TextPaint(paint), (int) width, align, 1.2f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, false);
        int height = layout.getHeight();
        canvas.translate(x, y - ((float) (height / 2)));
        layout.draw(canvas);
        canvas.translate(-x, -(y - ((float) (height / 2))));
        return layout;
    }

    public static StaticLayout drawText(Canvas canvas, Paint paint, String text, float x, float y, float width) {
        return drawText(canvas, paint, text, x, y, width, Alignment.ALIGN_CENTER);
    }

    public Text(Paint paint, String text, float width, Alignment align, int initialOpacity) {
        this.width = width;
        this.align = align;
        this.text = text;
        this.paint = paint;
        this.opacity = (float) initialOpacity;
        this.animFade = new Animator();
        this.animFade.setAnimationListener(new C00541());
    }

    public void setText(String text) {
        this.text = text;
    }

    public void animateFade(float targetOpacity, float animationSpeed, AnimationReadyListener fadeListener) {
        this.fadeListener = fadeListener;
        if (fadeListener != null) {
            this.animFade.animate(this.opacity, targetOpacity, animationSpeed);
        }
    }

    public void update() {
        if (this.fadeListener != null) {
            this.animFade.Update();
        }
    }

    public void draw(Canvas canvas, float x, float y) {
        int temp = this.paint.getAlpha();
        this.paint.setAlpha((int) this.opacity);
        StaticLayout layout = new StaticLayout(this.text, new TextPaint(this.paint), (int) this.width, this.align, 1.2f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, false);
        int height = layout.getHeight();
        canvas.translate(x, y - ((float) (height / 2)));
        layout.draw(canvas);
        canvas.translate(-x, -(y - ((float) (height / 2))));
        this.paint.setAlpha(temp);
    }
}
