package com.neurondigital.nudge;

public class Animator {
    float AnimationSpeed;
    float Value;
    AnimationListener animationListener;
    boolean animationReady = true;
    float finalValue;
    float initialValue;

    public interface AnimationReadyListener {
        void onReady();
    }

    public interface AnimationListener {
        void onReady(float f);

        void onUpdate(float f);
    }

    public void setAnimationListener(AnimationListener animationListener) {
        this.animationListener = animationListener;
    }

    public void animate(float initialValue, float finalValue, float AnimationSpeed) {
        this.Value = initialValue;
        if (this.Value != finalValue) {
            this.initialValue = initialValue;
            this.finalValue = finalValue;
            this.animationReady = false;
            this.AnimationSpeed = AnimationSpeed;
            return;
        }
        this.animationReady = true;
        if (this.animationListener != null) {
            this.animationListener.onReady(this.Value);
        }
    }

    public void stop() {
        this.animationReady = true;
    }

    public void Update() {
        if (!this.animationReady) {
            if (this.finalValue > this.Value) {
                this.Value += this.AnimationSpeed;
            } else if (this.finalValue < this.Value) {
                this.Value -= this.AnimationSpeed;
            }
            if (this.animationListener != null) {
                this.animationListener.onUpdate(this.Value);
            }
            if (Math.abs(this.Value - this.finalValue) <= this.AnimationSpeed) {
                this.Value = this.finalValue;
                this.animationReady = true;
                if (this.animationListener != null) {
                    this.animationListener.onReady(this.Value);
                }
            }
        }
    }
}
