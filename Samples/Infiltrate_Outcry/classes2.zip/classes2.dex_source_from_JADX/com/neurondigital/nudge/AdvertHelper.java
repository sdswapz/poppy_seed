package com.neurondigital.nudge;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class AdvertHelper {
    String BannerAd_unit_id;
    String InterstitialAd_unit_id;
    boolean ShowingAd = false;
    Activity activity;
    AdRequest adRequest;
    private AdView adView;
    public BannerListener bannerListener;
    private InterstitialAd interstitial;
    public InterstitialListener interstitialListener;

    class C00391 extends AdListener {
        C00391() {
        }

        public void onAdClosed() {
            AdvertHelper.this.interstitial.loadAd(AdvertHelper.this.adRequest);
            AdvertHelper.this.ShowingAd = false;
            if (AdvertHelper.this.interstitialListener != null) {
                AdvertHelper.this.interstitialListener.onClosed();
            }
        }
    }

    public interface BannerListener {
        void onLoaded();

        void onRefreshScreenRequired();
    }

    public interface InterstitialListener {
        void onClosed();

        void onNotLoaded();
    }

    public AdvertHelper(Activity activity, String InterstitialAd_unit_id, String BannerAd_unit_id) {
        this.activity = activity;
        this.InterstitialAd_unit_id = InterstitialAd_unit_id;
        this.BannerAd_unit_id = BannerAd_unit_id;
    }

    public void initialiseInterstitialAd() {
        if (this.InterstitialAd_unit_id.length() > 0) {
            this.interstitial = new InterstitialAd(this.activity);
            this.interstitial.setAdUnitId(this.InterstitialAd_unit_id);
            this.adRequest = new Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("275D94C2B5B93B3C4014933E75F92565").addTestDevice("91608B19766D984A3F929C31EC6AB947").addTestDevice("6316D285813B01C56412DAF4D3D80B40").addTestDevice("8C416F4CAF490509A1DA82E62168AE08").addTestDevice("7B4C6D080C02BA40EF746C4900BABAD7").addTestDevice("5F0321BA219D26B16ADBF3B27F5CEC30").build();
            this.interstitial.loadAd(this.adRequest);
            this.interstitial.setAdListener(new C00391());
        }
    }

    public void openInterstitialAd(final InterstitialListener listener) {
        if (this.InterstitialAd_unit_id.length() > 0) {
            this.ShowingAd = true;
            this.activity.runOnUiThread(new Runnable() {
                public void run() {
                    AdvertHelper.this.interstitialListener = listener;
                    if (AdvertHelper.this.interstitial.isLoaded()) {
                        AdvertHelper.this.interstitial.show();
                        return;
                    }
                    if (AdvertHelper.this.interstitialListener != null) {
                        AdvertHelper.this.interstitialListener.onNotLoaded();
                    }
                    AdvertHelper.this.ShowingAd = false;
                    AdvertHelper.this.interstitial.loadAd(AdvertHelper.this.adRequest);
                }
            });
        }
    }

    public void showBanner(boolean inLayout, LinearLayout linear_layout, RelativeLayout layout, BannerListener bannerListener) {
        if (this.BannerAd_unit_id.length() > 0) {
            this.adView = new AdView(this.activity);
            this.adView.setAdSize(AdSize.SMART_BANNER);
            this.adView.setAdUnitId(this.BannerAd_unit_id);
            if (inLayout) {
                LayoutParams params1 = new LayoutParams(-1, -2);
                params1.addRule(12);
                params1.addRule(14);
                this.adView.setLayoutParams(params1);
            } else {
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
                params.gravity = 80;
                params.weight = 0.0f;
                this.adView.setLayoutParams(params);
            }
            this.adView.loadAd(new Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("275D94C2B5B93B3C4014933E75F92565").addTestDevice("91608B19766D984A3F929C31EC6AB947").addTestDevice("6316D285813B01C56412DAF4D3D80B40").addTestDevice("8C416F4CAF490509A1DA82E62168AE08").addTestDevice("EA8AA9C3AA2BD16A954F592C6F935628").addTestDevice("7B4C6D080C02BA40EF746C4900BABAD7").build());
            final BannerListener bannerListener2 = bannerListener;
            final RelativeLayout relativeLayout = layout;
            final LinearLayout linearLayout = linear_layout;
            final boolean z = inLayout;
            this.adView.setAdListener(new AdListener() {
                public void onAdLoaded() {
                    if (bannerListener2 != null) {
                        bannerListener2.onLoaded();
                    }
                    View parent = (View) AdvertHelper.this.adView.getParent();
                    if (parent == null) {
                        if (z) {
                            relativeLayout.addView(AdvertHelper.this.adView);
                        } else {
                            linearLayout.addView(AdvertHelper.this.adView);
                        }
                        if (bannerListener2 != null) {
                            bannerListener2.onRefreshScreenRequired();
                        }
                    } else if (!parent.equals(relativeLayout) && !parent.equals(linearLayout)) {
                        if (z) {
                            relativeLayout.addView(AdvertHelper.this.adView);
                        } else {
                            linearLayout.addView(AdvertHelper.this.adView);
                        }
                        if (bannerListener2 != null) {
                            bannerListener2.onRefreshScreenRequired();
                        }
                    }
                }
            });
        }
    }

    protected void onResume() {
        if (this.adView != null) {
            this.adView.resume();
        }
    }

    protected void onPause() {
        if (this.adView != null) {
            this.adView.pause();
        }
    }

    protected void onDestroy() {
        if (this.adView != null) {
            this.adView.destroy();
        }
    }
}
