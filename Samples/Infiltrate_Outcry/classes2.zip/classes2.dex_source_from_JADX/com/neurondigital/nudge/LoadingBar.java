package com.neurondigital.nudge;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

public class LoadingBar extends Instance {
    Paint PaintBackground = new Paint();
    Paint PaintForeground = new Paint();
    Paint PaintOverlay = new Paint();
    int bar_height;
    int bar_width;
    int border = 0;
    float maxProgress = Instance.NORMAL_SCALE;
    float progress = 0.0f;
    Screen screen;

    public LoadingBar(Screen screen, int ColorBackground, int ColorForeground, int ColorOverlay, int x, int y) {
        super(null, (float) x, (float) y, screen, false);
        this.PaintBackground.setColor(ColorBackground);
        this.PaintBackground.setAntiAlias(true);
        this.PaintForeground.setColor(ColorForeground);
        this.PaintForeground.setAntiAlias(true);
        this.PaintOverlay.setColor(ColorOverlay);
        this.PaintOverlay.setAntiAlias(true);
        this.screen = screen;
        this.bar_width = (int) (((float) screen.ScreenWidth()) * 0.5f);
        this.bar_height = (int) (((float) screen.ScreenHeight()) * 0.1f);
    }

    public void setColorForeground(int ColorForeground) {
        this.PaintForeground.setColor(ColorForeground);
    }

    public void setWorld(boolean isWorld) {
        this.world = isWorld;
    }

    public int getHeight() {
        return this.bar_height;
    }

    public int getWidth() {
        return this.bar_width;
    }

    public void setHeight(int bar_height) {
        this.bar_height = bar_height;
    }

    public void setWidth(int bar_width) {
        this.bar_width = bar_width;
    }

    public void setMaxProgress(int maxProgress) {
        this.maxProgress = (float) maxProgress;
    }

    public void setProgress(int progress) {
        if (((float) progress) > this.maxProgress) {
            this.progress = this.maxProgress;
        } else {
            this.progress = (float) progress;
        }
    }

    public void setBorder(int border) {
        this.border = border;
    }

    public void draw(Canvas canvas) {
        canvas.drawRoundRect(new RectF((float) ((this.screen.ScreenWidth() / 2) - (this.bar_width / 2)), this.y - this.screen.cameraY, (float) ((this.screen.ScreenWidth() / 2) + (this.bar_width / 2)), (this.y + ((float) this.bar_height)) - this.screen.cameraY), 4.0f, 4.0f, this.PaintBackground);
        canvas.drawRoundRect(new RectF((float) (((this.screen.ScreenWidth() / 2) - (this.bar_width / 2)) + this.screen.dpToPx(this.border)), (this.y + ((float) this.screen.dpToPx(this.border))) - this.screen.cameraY, ((float) ((this.screen.ScreenWidth() / 2) - ((this.bar_width + this.screen.dpToPx(this.border * 2)) / 2))) + ((this.progress / this.maxProgress) * ((float) this.bar_width)), ((this.y + ((float) this.bar_height)) - ((float) this.screen.dpToPx(this.border))) - this.screen.cameraY), 4.0f, 4.0f, this.PaintForeground);
        canvas.drawRoundRect(new RectF((float) ((this.screen.ScreenWidth() / 2) - (this.bar_width / 2)), (this.y - ((float) (this.bar_height / 2))) + this.screen.cameraY, (float) ((this.screen.ScreenWidth() / 2) + (this.bar_width / 2)), (this.y + ((float) this.bar_height)) - this.screen.cameraY), 4.0f, 4.0f, this.PaintOverlay);
    }
}
