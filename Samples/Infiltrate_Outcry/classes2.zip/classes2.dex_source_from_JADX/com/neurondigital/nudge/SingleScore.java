package com.neurondigital.nudge;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class SingleScore {
    Screen screen;

    public static class Highscore {
        public String[] Details;
        public int score;
    }

    public SingleScore(Screen screen) {
        this.screen = screen;
    }

    public Highscore load_localscore() {
        SharedPreferences hiscores = PreferenceManager.getDefaultSharedPreferences(this.screen.getApplicationContext());
        Highscore highscore = new Highscore();
        highscore.score = hiscores.getInt("score", 0);
        int length = hiscores.getInt("details_length", 0);
        if (length > 0) {
            highscore.Details = new String[length];
            for (int i = 0; i < highscore.Details.length; i++) {
                highscore.Details[i] = hiscores.getString("details" + i, "---");
            }
        }
        return highscore;
    }

    public void save_localscores(Highscore highscore) {
        Editor hiscores_editor = PreferenceManager.getDefaultSharedPreferences(this.screen.getApplicationContext()).edit();
        hiscores_editor.putInt("score", highscore.score);
        hiscores_editor.putInt("details_length", highscore.Details.length);
        for (int i = 0; i < highscore.Details.length; i++) {
            hiscores_editor.putString("details" + i, highscore.Details[i]);
        }
        hiscores_editor.commit();
    }

    public int load_localscore_simple(String identifier) {
        return PreferenceManager.getDefaultSharedPreferences(this.screen.getApplicationContext()).getInt("score" + identifier, 0);
    }

    public void save_localscore_simple(int score, String identifier) {
        Editor hiscores_editor = PreferenceManager.getDefaultSharedPreferences(this.screen.getApplicationContext()).edit();
        hiscores_editor.putInt("score" + identifier, score);
        hiscores_editor.commit();
    }

    public void save_localscore_simple(int score, String identifier, boolean largerisbetter) {
        if (largerisbetter) {
            if (score > load_localscore_simple(identifier)) {
                save_localscore_simple(score, identifier);
            }
        } else if (score < load_localscore_simple(identifier) || load_localscore_simple(identifier) == 0) {
            save_localscore_simple(score, identifier);
        }
    }
}
