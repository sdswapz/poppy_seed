package com.neurondigital.nudge;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;

public class Physics {
    RectF f82a = null;
    RectF f83b = null;

    public boolean intersect(int x, int y, int width, int height, int x2, int y2, int width2, int height2) {
        this.f82a = new RectF((float) x, (float) y, (float) (x + width), (float) (y + height));
        this.f83b = new RectF((float) x2, (float) y2, (float) (x2 + width2), (float) (y2 + height2));
        return this.f82a.intersect(this.f83b);
    }

    public boolean intersect(int x, int y, int width, int height, int pointx, int pointy) {
        this.f82a = new RectF((float) x, (float) y, (float) (x + width), (float) (y + height));
        if (pointx <= x || pointy <= y || pointx >= x + width || pointy >= y + height) {
            return false;
        }
        return true;
    }

    public void drawDebug(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(-65536);
        paint.setStyle(Style.STROKE);
        paint.setStrokeWidth(5.0f);
        if (this.f82a != null) {
            canvas.drawRect(this.f82a, paint);
        }
        if (this.f83b != null) {
            canvas.drawRect(this.f83b, paint);
        }
    }
}
