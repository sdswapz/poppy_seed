package com.neurondigital.nudge;

import android.graphics.Canvas;
import java.util.ArrayList;

public class ObjectManager {
    public static final int BOTTOM = 3;
    public static final int LEFT = 1;
    public static final int RIGHT = 2;
    public static final int TOP = 0;
    Boolean DestroyOutOfScreen = Boolean.valueOf(true);
    Instance[] DifferentObjects;
    int Direction = 0;
    public ArrayList<Instance> Objects_live = new ArrayList();
    ArrayList<Integer> endtime = new ArrayList();
    ArrayList<Integer> generation_frequency = new ArrayList();
    ArrayList<Integer[]> objecttypes = new ArrayList();
    Screen screen;
    ArrayList<Integer> starttime = new ArrayList();
    public int time = 0;

    public ObjectManager(Instance[] DifferentObjects, Screen screen, Boolean DestroyOutOfScreen, int Direction) {
        this.DifferentObjects = DifferentObjects;
        this.time = 0;
        this.screen = screen;
        this.DestroyOutOfScreen = DestroyOutOfScreen;
        this.Direction = Direction;
    }

    public void restart() {
        this.time = 0;
    }

    public void add_timeperiod(int starttime, int endtime, Integer[] obstacletypes, int generation_frequency) {
        this.starttime.add(Integer.valueOf(starttime));
        this.endtime.add(Integer.valueOf(endtime));
        this.objecttypes.add(obstacletypes);
        this.generation_frequency.add(Integer.valueOf(generation_frequency));
    }

    public void update() {
        int i;
        this.time++;
        for (i = 0; i < this.starttime.size(); i++) {
            generate_at_timeperiod(((Integer) this.starttime.get(i)).intValue(), ((Integer) this.endtime.get(i)).intValue(), (Integer[]) this.objecttypes.get(i), ((Integer) this.generation_frequency.get(i)).intValue());
        }
        i = 0;
        while (i < this.Objects_live.size()) {
            ((Instance) this.Objects_live.get(i)).Update();
            if (this.DestroyOutOfScreen.booleanValue() && !((Instance) this.Objects_live.get(i)).inScreen()) {
                if (this.Direction == 1 && ((Instance) this.Objects_live.get(i)).f79x > ((float) this.screen.ScreenWidth())) {
                    this.Objects_live.remove(i);
                }
                if (this.Direction == 2 && ((Instance) this.Objects_live.get(i)).f79x < 0.0f) {
                    this.Objects_live.remove(i);
                }
                if (this.Direction == 0 && ((Instance) this.Objects_live.get(i)).f80y < 0.0f) {
                    this.Objects_live.remove(i);
                }
                if (this.Direction == 3 && ((Instance) this.Objects_live.get(i)).f80y > ((float) this.screen.ScreenHeight())) {
                    this.Objects_live.remove(i);
                }
            }
            i++;
        }
    }

    public void drawObjects(Canvas canvas) {
        for (int i = 0; i < this.Objects_live.size(); i++) {
            ((Instance) this.Objects_live.get(i)).draw(canvas);
        }
    }

    private void generate_at_timeperiod(int starttime, int endtime, Integer[] obstacletypes, int generation_frequency) {
        if (((this.time >= starttime && endtime == -1) || (this.time >= starttime && this.time < endtime)) && this.time % (100 - generation_frequency) == 0) {
            int type = ((int) (Math.random() * ((double) obstacletypes.length))) + 1;
            this.Objects_live.add(this.DifferentObjects[obstacletypes[type - 1].intValue()].Clone());
            Sprite temp = this.DifferentObjects[obstacletypes[type - 1].intValue()].sprite.Clone();
            temp.rotate((float) (Math.random() * 360.0d));
            ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).sprite = temp;
            if (this.Direction == 2) {
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f79x = (float) (((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).getWidth() + this.screen.ScreenWidth());
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f80y = (float) ((((double) (((float) this.screen.ScreenHeight()) * 0.8f)) * Math.random()) + ((double) (((float) this.screen.ScreenHeight()) * 0.2f)));
            }
            if (this.Direction == 1) {
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f79x = (float) (-((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).getWidth());
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f80y = (float) ((((double) (((float) this.screen.ScreenHeight()) * 0.8f)) * Math.random()) + ((double) (((float) this.screen.ScreenHeight()) * 0.2f)));
            }
            if (this.Direction == 0) {
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f80y = (float) (((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).getHeight() + this.screen.ScreenHeight());
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f79x = (float) ((((double) ((0.8f - (((float) ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).getWidth()) / ((float) this.screen.ScreenWidth()))) * ((float) this.screen.ScreenWidth()))) * Math.random()) + ((double) (((float) this.screen.ScreenWidth()) * 0.1f)));
            }
            if (this.Direction == 3) {
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f80y = (float) (-((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).getHeight());
                ((Instance) this.Objects_live.get(this.Objects_live.size() - 1)).f79x = (float) ((((double) (((float) this.screen.ScreenWidth()) * 0.8f)) * Math.random()) + ((double) (((float) this.screen.ScreenWidth()) * 0.2f)));
            }
        }
    }
}
