package com.neurondigital.nudge;

import android.content.Intent;
import android.widget.Toast;
import com.google.android.gms.games.Games;
import com.google.example.games.basegameutils.GameHelper;
import com.google.example.games.basegameutils.GameHelper.GameHelperListener;

public class LeaderboardManager {
    public String App_id;
    int OPEN_ACHIEVMENTS = 1458;
    int OPEN_LEADERBOARD = 2154;
    String[] leaderboard_ids;
    GameHelperListener listener;
    public GameHelper mHelper;
    Screen screen;

    public LeaderboardManager(Screen Screen, String App_id, String[] Leaderboard_ids, final String google_Play_signed_in_successfully, final String google_Play_signed_in_error) {
        this.screen = Screen;
        this.App_id = App_id;
        this.leaderboard_ids = Leaderboard_ids;
        if (App_id.length() > 0) {
            this.mHelper = new GameHelper(this.screen, 1);
            this.mHelper.enableDebugLog(true);
            this.listener = new GameHelperListener() {
                public void onSignInSucceeded() {
                    Toast.makeText(LeaderboardManager.this.screen, google_Play_signed_in_successfully, 1).show();
                    SingleScore hiscore = new SingleScore(LeaderboardManager.this.screen);
                    for (int i = 0; i < LeaderboardManager.this.leaderboard_ids.length; i++) {
                        Games.Leaderboards.submitScore(LeaderboardManager.this.mHelper.getApiClient(), LeaderboardManager.this.leaderboard_ids[i], (long) hiscore.load_localscore_simple(LeaderboardManager.this.leaderboard_ids[i]));
                    }
                }

                public void onSignInFailed() {
                    Toast.makeText(LeaderboardManager.this.screen, google_Play_signed_in_error, 1).show();
                }
            };
            this.mHelper.setup(this.listener);
        }
    }

    public void LogIn() {
        if (this.App_id.length() > 0) {
            this.mHelper.beginUserInitiatedSignIn();
        }
    }

    public void OpenLeaderboard(String leaderboard_id) {
        if (this.App_id.length() <= 0) {
            return;
        }
        if (this.mHelper.isSignedIn()) {
            this.screen.startActivityForResult(Games.Leaderboards.getLeaderboardIntent(this.mHelper.getApiClient(), leaderboard_id), this.OPEN_LEADERBOARD);
        } else {
            LogIn();
        }
    }

    public void OpenAllLeaderBoards() {
        if (this.App_id.length() <= 0) {
            return;
        }
        if (this.mHelper.isSignedIn()) {
            this.screen.startActivityForResult(Games.Leaderboards.getAllLeaderboardsIntent(this.mHelper.getApiClient()), this.OPEN_LEADERBOARD);
        } else {
            LogIn();
        }
    }

    public void OpenAchievements() {
        if (this.App_id.length() <= 0) {
            return;
        }
        if (this.mHelper.isSignedIn()) {
            this.screen.startActivityForResult(Games.Achievements.getAchievementsIntent(this.mHelper.getApiClient()), this.OPEN_ACHIEVMENTS);
        } else {
            LogIn();
        }
    }

    public void updateScore(int score, boolean largerisbetter, String leaderboard_id) {
        new SingleScore(this.screen).save_localscore_simple(score, leaderboard_id, largerisbetter);
        if (this.App_id.length() > 0 && this.mHelper.isSignedIn()) {
            Games.Leaderboards.submitScore(this.mHelper.getApiClient(), leaderboard_id, (long) score);
        }
    }

    public void unlockAchievement(String Achievement_id) {
        if (this.App_id.length() > 0 && this.mHelper.isSignedIn()) {
            Games.Achievements.unlock(this.mHelper.getApiClient(), Achievement_id);
        }
    }

    public int getTopScore(String leaderboard_id) {
        return new SingleScore(this.screen).load_localscore_simple("" + leaderboard_id);
    }

    public void onStart() {
        if (this.App_id.length() > 0) {
            this.mHelper.onStart(this.screen);
        }
    }

    public void onStop() {
        if (this.App_id.length() > 0) {
            this.mHelper.onStop();
        }
    }

    public void onActivityResult(int request, int response, Intent data) {
        if (this.App_id.length() > 0) {
            this.mHelper.onActivityResult(request, response, data);
            if (response != 10001) {
                return;
            }
            if (request == this.OPEN_LEADERBOARD || request == this.OPEN_ACHIEVMENTS) {
                this.mHelper.disconnect();
            }
        }
    }
}
