package com.neurondigital.nudge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Share {
    public void share_screenshot(Screen screen, Bitmap bitmap) {
        Uri path = saveBitmap(bitmap, "screenshot.jpg", screen);
        System.out.println("Sharing");
        if (path != null) {
            Intent share = new Intent("android.intent.action.SEND");
            share.setType("image/jpeg");
            share.putExtra("android.intent.extra.STREAM", path);
            screen.startActivity(Intent.createChooser(share, "share"));
            System.out.println("shared");
        }
    }

    private static Bitmap takeScreenShot(Screen screen) {
        View view = screen.layout;
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null) {
            bgDrawable.draw(canvas);
        } else {
            canvas.drawColor(-1);
        }
        view.draw(canvas);
        return returnedBitmap;
    }

    private static Uri saveBitmap(Bitmap bitmap, String BitmapName, Activity activity) {
        FileNotFoundException e;
        IOException e2;
        try {
            FileOutputStream fileOutputStream;
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), BitmapName);
            FileOutputStream fos = new FileOutputStream(file);
            if (fos != null) {
                try {
                    bitmap.compress(CompressFormat.JPEG, 100, fos);
                    fos.flush();
                    fos.close();
                    System.out.println("saved");
                } catch (FileNotFoundException e3) {
                    e = e3;
                    fileOutputStream = fos;
                    e.printStackTrace();
                    Toast.makeText(activity, "You need to have an SDCard to share screenshot", 1).show();
                    return null;
                } catch (IOException e4) {
                    e2 = e4;
                    fileOutputStream = fos;
                    e2.printStackTrace();
                    return null;
                }
            }
            fileOutputStream = fos;
            return Uri.fromFile(file);
        } catch (FileNotFoundException e5) {
            e = e5;
            e.printStackTrace();
            Toast.makeText(activity, "You need to have an SDCard to share screenshot", 1).show();
            return null;
        } catch (IOException e6) {
            e2 = e6;
            e2.printStackTrace();
            return null;
        }
    }
}
