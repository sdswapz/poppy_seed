package com.neurondigital.nudge;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import com.neurondigital.nudge.Animator.AnimationListener;
import com.tapjoy.TapjoyConnectCore;

public class Screen extends FragmentActivity implements Runnable, SensorEventListener {
    public final int BOTTOM_LEFT = 1;
    private boolean Switch_GestureDetector = false;
    public final int TOP_LEFT = 0;
    public FragmentActivity activity = this;
    float calibratex = 0.0f;
    float calibratey = 0.0f;
    public float cameraX = 0.0f;
    public float cameraY = 0.0f;
    Animator cameraYAnimator;
    Canvas canvas;
    public boolean debug_mode = false;
    private boolean default_lanscape = false;
    private int default_lanscape_rotation = 0;
    private int drawtime = 0;
    public Effects effects = new Effects();
    private int fps = 0;
    private int frames = 0;
    private GestureDetector gestureDetector;
    private int height = 0;
    private SurfaceHolder holder;
    private boolean initialised = false;
    private long lastRefresh;
    private long lastfps;
    public RelativeLayout layout;
    public LinearLayout linear_layout;
    int loadingPercent = 0;
    private boolean locker = true;
    private long now = SystemClock.elapsedRealtime();
    public int origin = 0;
    int recalculateScreenCounter = 0;
    private int runtime = 0;
    Sensor f81s;
    Bitmap screenshot;
    float sensorx;
    float sensory;
    SensorManager sm;
    public int state = 0;
    public SurfaceView surface;
    private Thread thread;
    private int width = 0;

    class C00531 implements AnimationListener {
        C00531() {
        }

        public void onReady(float value) {
            Screen.this.cameraY = value;
        }

        public void onUpdate(float value) {
            Screen.this.cameraY = value;
        }
    }

    private final class GestureListener extends SimpleOnGestureListener {
        private final int SWIPE_DISTANCE_THRESHOLD;
        private final int SWIPE_VELOCITY_THRESHOLD;

        private GestureListener() {
            this.SWIPE_DISTANCE_THRESHOLD = dpToPx(50);
            this.SWIPE_VELOCITY_THRESHOLD = dpToPx(50);
        }

        int dpToPx(int dp) {
            return Math.round(((float) dp) * Screen.this.getApplicationContext().getResources().getDisplayMetrics().density);
        }

        public boolean onDown(MotionEvent e) {
            return true;
        }

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float distanceX = e2.getX() - e1.getX();
            float distanceY = e2.getY() - e1.getY();
            if (Math.abs(distanceX) <= Math.abs(distanceY) || Math.abs(distanceX) <= ((float) this.SWIPE_DISTANCE_THRESHOLD) || Math.abs(velocityX) <= ((float) this.SWIPE_VELOCITY_THRESHOLD)) {
                if (Math.abs(distanceY) <= Math.abs(distanceX) || Math.abs(distanceY) <= ((float) this.SWIPE_DISTANCE_THRESHOLD) || Math.abs(velocityY) <= ((float) this.SWIPE_VELOCITY_THRESHOLD)) {
                    return false;
                }
                if (distanceY > 0.0f) {
                    Screen.this.onSwipeDown();
                    return true;
                }
                Screen.this.onSwipeUp();
                return true;
            } else if (distanceX > 0.0f) {
                Screen.this.onSwipeRight();
                return true;
            } else {
                Screen.this.onSwipeLeft();
                return true;
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.activity = this;
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        getWindow().addFlags(128);
        this.layout = new RelativeLayout(this);
        this.surface = new SurfaceView(this);
        this.layout.addView(this.surface);
        LayoutParams params = new LayoutParams(-1, -2);
        params.weight = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
        this.layout.setLayoutParams(params);
        this.linear_layout = new LinearLayout(this);
        this.linear_layout.setOrientation(1);
        this.linear_layout.addView(this.layout);
        setContentView(this.linear_layout);
        this.holder = this.surface.getHolder();
        if (this.Switch_GestureDetector) {
            this.gestureDetector = new GestureDetector(this, new GestureListener());
        }
        this.cameraYAnimator = new Animator();
        this.cameraYAnimator.setAnimationListener(new C00531());
        this.thread = new Thread(this);
        this.thread.start();
        onCreate();
    }

    public void run() {
        synchronized ("accessibility") {
            while (this.locker) {
                this.now = SystemClock.elapsedRealtime();
                if (this.now - this.lastRefresh > 37) {
                    this.lastRefresh = SystemClock.elapsedRealtime();
                    if (this.holder.getSurface().isValid()) {
                        if (this.now - this.lastfps > 1000) {
                            this.fps = this.frames;
                            this.frames = 0;
                            this.lastfps = SystemClock.elapsedRealtime();
                        } else {
                            this.frames++;
                        }
                        if (this.initialised) {
                            Step();
                        }
                        this.runtime = (int) (SystemClock.elapsedRealtime() - this.lastRefresh);
                        this.canvas = this.holder.lockCanvas();
                        if (this.initialised) {
                            Draw(this.canvas);
                        } else {
                            this.width = this.canvas.getWidth();
                            this.height = this.canvas.getHeight();
                            Start();
                            this.initialised = true;
                        }
                        this.holder.unlockCanvasAndPost(this.canvas);
                        this.drawtime = ((int) (SystemClock.elapsedRealtime() - this.lastRefresh)) - this.runtime;
                    } else {
                        continue;
                    }
                }
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        super.onKeyDown(keyCode, event);
        if (keyCode == 4) {
            BackPressed();
        }
        return false;
    }

    public void onCreate() {
    }

    public void Start() {
    }

    public synchronized void Step() {
        if (this.recalculateScreenCounter != -1) {
            if (this.recalculateScreenCounter > 0) {
                this.recalculateScreenCounter--;
            } else {
                this.initialised = false;
                this.recalculateScreenCounter = -1;
            }
        }
        if (getLoadingPercent() != 100) {
            setLoadingPercent(LoadElements(getLoadingPercent()));
        }
        this.effects.Update();
        this.cameraYAnimator.Update();
    }

    public int LoadElements(int loadingPercent) {
        return loadingPercent;
    }

    public void Draw(Canvas canvas) {
        if (this.debug_mode) {
            Paint paint = new Paint();
            paint.setColor(-16777216);
            paint.setTextSize((float) dpToPx(20));
            canvas.drawText("Width: " + this.width + ", Height: " + this.height, 5.0f, (float) dpToPx(20), paint);
            canvas.drawText("default landscape: " + this.default_lanscape + " Rotation: " + this.default_lanscape_rotation, 5.0f, (float) ((dpToPx(20) * 2) + 5), paint);
            canvas.drawText("FPS: " + this.fps + "run_time: " + this.runtime + "draw_time: " + this.drawtime, 5.0f, (float) ((dpToPx(20) * 3) + 5), paint);
        }
    }

    public void Finish() {
    }

    public void Pause() {
        this.locker = false;
        try {
            this.thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.thread = null;
    }

    public void Resume() {
        this.locker = true;
        this.thread = new Thread(this);
        this.thread.start();
    }

    public synchronized void BackPressed() {
    }

    public synchronized void onTouch(float TouchX, float TouchY, MotionEvent event) {
    }

    public synchronized void onAccelerometer(PointF point) {
    }

    public void onSwipeLeft() {
    }

    public void onSwipeRight() {
    }

    public void onSwipeUp() {
    }

    public void onSwipeDown() {
    }

    public void Exit() {
        this.locker = false;
        this.thread = null;
        System.exit(0);
        this.activity.finish();
    }

    public int getColorRef(int colorRef) {
        return ContextCompat.getColor(this.activity, colorRef);
    }

    public int getLoadingPercent() {
        return this.loadingPercent;
    }

    public void setLoadingPercent(int loadingPercent) {
        this.loadingPercent = loadingPercent;
    }

    public Activity getActivity() {
        return this.activity;
    }

    public void setDebugMode(boolean debugModeOn) {
        this.debug_mode = debugModeOn;
    }

    public int ScreenWidth() {
        return this.width;
    }

    public int ScreenHeight() {
        return this.height;
    }

    public int ScreenX(float worldX) {
        return (int) (worldX - this.cameraX);
    }

    public int ScreenY(float worldY) {
        if (this.origin == 0) {
            return (int) (worldY - this.cameraY);
        }
        return ScreenHeight() - ((int) (worldY - this.cameraY));
    }

    public void moveCameraY(float worldY, int speed) {
        this.cameraYAnimator.animate(this.cameraY, worldY, (float) speed);
    }

    public void setOrigin(int origin) {
        this.origin = origin;
    }

    public boolean inScreen(float x, float y) {
        return ScreenY(y) > 0 && ScreenY(y) < ScreenHeight() && ScreenX(x) > 0 && ScreenX(x) < ScreenWidth();
    }

    public int dpToPx(int dp) {
        return Math.round(((float) dp) * getApplicationContext().getResources().getDisplayMetrics().density);
    }

    public void recalculateScreen() {
        this.recalculateScreenCounter = 10;
    }

    public void initialiseAccelerometer() {
        int rotation = ((WindowManager) this.activity.getSystemService("window")).getDefaultDisplay().getRotation();
        if (getRequestedOrientation() == 1) {
            if (rotation == 0) {
                this.default_lanscape = false;
            }
            if (rotation == 2) {
                this.default_lanscape = false;
            }
            if (rotation == 1) {
                this.default_lanscape = true;
            }
            if (rotation == 3) {
                this.default_lanscape = true;
            }
        } else {
            if (rotation == 0) {
                this.default_lanscape = true;
            }
            if (rotation == 2) {
                this.default_lanscape = true;
            }
            if (rotation == 1) {
                this.default_lanscape = false;
            }
            if (rotation == 3) {
                this.default_lanscape = false;
            }
        }
        this.default_lanscape_rotation = rotation;
        this.sm = (SensorManager) this.activity.getSystemService("sensor");
        if (this.sm.getSensorList(1).size() != 0) {
            this.f81s = (Sensor) this.sm.getSensorList(1).get(0);
            this.sm.registerListener(this, this.f81s, 3);
        }
    }

    public void CalibrateAccelerometer() {
        this.calibratex = this.sensorx * Math.abs(this.sensorx);
        this.calibratey = this.sensory * Math.abs(this.sensory);
    }

    public PointF getAccelerometer() {
        return new PointF((this.sensorx * Math.abs(this.sensorx)) - this.calibratex, (this.sensory * Math.abs(this.sensory)) - this.calibratey);
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.initialised) {
            int pointerIndex = event.getActionIndex();
            onTouch(event.getX(pointerIndex), event.getY(pointerIndex), event);
        }
        if (this.Switch_GestureDetector) {
            return this.gestureDetector.onTouchEvent(event);
        }
        return true;
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void onSensorChanged(SensorEvent event) {
        if (this.initialised) {
            if (getRequestedOrientation() == 1) {
                if (this.default_lanscape) {
                    this.sensorx = -event.values[1];
                    this.sensory = -event.values[0];
                } else {
                    this.sensory = event.values[1];
                    this.sensorx = -event.values[0];
                }
            } else if (this.default_lanscape) {
                this.sensory = event.values[1];
                this.sensorx = -event.values[0];
            } else {
                this.sensorx = event.values[1];
                this.sensory = event.values[0];
            }
            onAccelerometer(new PointF(this.sensorx - this.calibratex, this.sensory - this.calibratey));
        }
        try {
            Thread.sleep(16);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onStop() {
        super.onStop();
    }

    protected void onResume() {
        super.onResume();
        Resume();
    }

    protected void onPause() {
        Pause();
        super.onPause();
    }

    protected void onDestroy() {
        Finish();
        super.onDestroy();
    }
}
