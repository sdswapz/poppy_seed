package com.tapjoy.internal;

import java.util.Arrays;

abstract class gs implements fp {
    private static final String[] f1289a;

    gs() {
    }

    static {
        String[] strArr = new String[]{"reward", "purchase", "custom_action"};
        f1289a = strArr;
        Arrays.sort(strArr);
    }

    public final void mo237a(fq fqVar) {
        if (this instanceof ft) {
            ft ftVar = (ft) this;
            fqVar.mo34a(ftVar.mo238a(), ftVar.mo239b());
        } else if (this instanceof fu) {
            fu fuVar = (fu) this;
            fqVar.mo35a(fuVar.mo240a(), fuVar.mo241b(), fuVar.mo242c(), fuVar.mo243d());
        }
    }

    public static boolean m1107a(String str) {
        return Arrays.binarySearch(f1289a, str) >= 0;
    }

    public static gs m1106a(String str, bs bsVar) {
        if ("reward".equals(str)) {
            return (gs) bsVar.m371a(hc.f1349a);
        }
        if ("purchase".equals(str)) {
            return (gs) bsVar.m371a(ha.f1340a);
        }
        return null;
    }
}
