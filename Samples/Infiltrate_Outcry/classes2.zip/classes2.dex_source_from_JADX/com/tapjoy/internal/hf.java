package com.tapjoy.internal;

import com.neurondigital.nudge.Instance;

public final class hf {
    public float f1372a;
    public int f1373b;

    public static hf m1147a(String str) {
        if (ct.m463c(str)) {
            return null;
        }
        try {
            hf hfVar = new hf();
            int length = str.length();
            char charAt = str.charAt(length - 1);
            if (charAt == 'w') {
                hfVar.f1372a = Float.valueOf(str.substring(0, length - 1)).floatValue();
                hfVar.f1373b = 1;
            } else if (charAt == 'h') {
                hfVar.f1372a = Float.valueOf(str.substring(0, length - 1)).floatValue();
                hfVar.f1373b = 2;
            } else {
                hfVar.f1372a = Float.valueOf(str).floatValue();
                hfVar.f1373b = 0;
            }
            return hfVar;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public final float m1148a(float f, float f2) {
        if (this.f1373b == 1) {
            return (this.f1372a * f) / Instance.NORMAL_SCALE;
        }
        if (this.f1373b == 2) {
            return (this.f1372a * f2) / Instance.NORMAL_SCALE;
        }
        return this.f1372a;
    }
}
