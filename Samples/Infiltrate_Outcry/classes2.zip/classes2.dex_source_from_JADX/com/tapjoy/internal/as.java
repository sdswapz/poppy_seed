package com.tapjoy.internal;

public interface as {
    Object mo91a(Object obj);

    void mo92a(Object obj, Object obj2);
}
