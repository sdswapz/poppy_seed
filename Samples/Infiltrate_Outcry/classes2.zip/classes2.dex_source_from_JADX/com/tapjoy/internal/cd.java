package com.tapjoy.internal;

import java.lang.ref.WeakReference;

public final class cd {
    public WeakReference f592a;

    public final Object m438a() {
        WeakReference weakReference = this.f592a;
        return weakReference != null ? weakReference.get() : null;
    }

    public final void m439a(Object obj) {
        this.f592a = new WeakReference(obj);
    }
}
