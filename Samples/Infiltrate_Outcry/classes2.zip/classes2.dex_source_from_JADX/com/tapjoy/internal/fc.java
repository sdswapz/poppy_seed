package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJActionRequest;
import com.tapjoy.TJError;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.TapjoyConstants;
import com.tapjoy.TapjoyLog;
import java.util.Observable;
import java.util.Observer;

abstract class fc {
    volatile C0201a f1005b;

    class C0201a implements TJPlacementListener, Observer {
        final /* synthetic */ fc f1036a;
        private final Object f1037b;
        private final el f1038c;
        private volatile boolean f1039d;
        private TJPlacement f1040e;

        C0201a(fc fcVar, Object obj) {
            this(fcVar, obj, new el(TapjoyConstants.TIMER_INCREMENT));
        }

        C0201a(fc fcVar, Object obj, el elVar) {
            this.f1036a = fcVar;
            this.f1037b = obj;
            this.f1038c = elVar;
        }

        final void m835a() {
            synchronized (this) {
                if (this.f1039d) {
                } else if (this.f1038c.m769a()) {
                    m834a("Timed out");
                } else {
                    if (!TapjoyConnectCore.isConnected()) {
                        ev.f1013a.addObserver(this);
                        if (TapjoyConnectCore.isConnected()) {
                            ev.f1013a.deleteObserver(this);
                        } else {
                            return;
                        }
                    }
                    if (this.f1040e == null) {
                        if (this.f1036a.mo182a()) {
                            this.f1040e = this.f1036a.mo180a(TapjoyConnectCore.getContext(), this, this.f1037b);
                            this.f1040e.requestContent();
                            return;
                        }
                        m834a("Cannot request");
                    } else if (!this.f1040e.isContentReady()) {
                    } else if (this.f1036a.mo184a((Observer) this)) {
                        this.f1040e.showContent();
                        m834a(null);
                    }
                }
            }
        }

        private void m834a(String str) {
            synchronized (this) {
                String a = this.f1036a.mo181a(this.f1037b);
                if (str == null) {
                    TapjoyLog.m252i("SystemPlacement", "Placement " + a + " is presented now");
                } else {
                    TapjoyLog.m252i("SystemPlacement", "Cannot show placement " + a + " now (" + str + ")");
                }
                this.f1039d = true;
                this.f1040e = null;
                ev.f1013a.deleteObserver(this);
                ev.f1017e.deleteObserver(this);
                ev.f1015c.deleteObserver(this);
            }
            fc fcVar = this.f1036a;
            synchronized (fcVar) {
                if (fcVar.f1005b == this) {
                    fcVar.f1005b = null;
                }
            }
        }

        public final void update(Observable observable, Object data) {
            m835a();
        }

        public final void onRequestSuccess(TJPlacement placement) {
        }

        public final void onRequestFailure(TJPlacement placement, TJError error) {
            m834a(error.message);
        }

        public final void onContentReady(TJPlacement placement) {
            m835a();
        }

        public final void onContentShow(TJPlacement placement) {
        }

        public final void onContentDismiss(TJPlacement placement) {
        }

        public final void onPurchaseRequest(TJPlacement placement, TJActionRequest request, String productId) {
        }

        public final void onRewardRequest(TJPlacement placement, TJActionRequest request, String itemId, int quantity) {
        }
    }

    protected abstract TJPlacement mo180a(Context context, TJPlacementListener tJPlacementListener, Object obj);

    protected abstract String mo181a(Object obj);

    fc() {
    }

    public final boolean m798c(Object obj) {
        if (!mo182a()) {
            return false;
        }
        C0201a c0201a = null;
        synchronized (this) {
            if (this.f1005b == null) {
                c0201a = mo185b(obj);
                this.f1005b = c0201a;
            }
        }
        if (c0201a == null) {
            return false;
        }
        c0201a.m835a();
        return true;
    }

    protected C0201a mo185b(Object obj) {
        return new C0201a(this, obj);
    }

    protected boolean mo182a() {
        return !TapjoyConnectCore.isFullScreenViewOpen();
    }

    protected boolean mo184a(Observer observer) {
        if (TapjoyConnectCore.isFullScreenViewOpen()) {
            ev.f1017e.addObserver(observer);
            if (TapjoyConnectCore.isFullScreenViewOpen()) {
                return false;
            }
            ev.f1017e.deleteObserver(observer);
        }
        if (!gd.m956a().m975d()) {
            ev.f1015c.addObserver(observer);
            if (!gd.m956a().m975d()) {
                return false;
            }
            ev.f1015c.deleteObserver(observer);
        }
        return true;
    }
}
