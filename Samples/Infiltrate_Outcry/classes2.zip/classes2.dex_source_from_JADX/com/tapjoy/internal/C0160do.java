package com.tapjoy.internal;

import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;

public final class C0160do {
    final hx f682a;
    private long f683b = 0;
    private long f684c = Long.MAX_VALUE;
    private int f685d;
    private int f686e = 2;
    private int f687f = -1;
    private long f688g = -1;
    private dk f689h;

    public C0160do(hx hxVar) {
        this.f682a = hxVar;
    }

    public final long m579a() {
        if (this.f686e != 2) {
            throw new IllegalStateException("Unexpected call to beginMessage()");
        }
        int i = this.f685d + 1;
        this.f685d = i;
        if (i > 65) {
            throw new IOException("Wire recursion limit exceeded");
        }
        long j = this.f688g;
        this.f688g = -1;
        this.f686e = 6;
        return j;
    }

    public final void m580a(long j) {
        if (this.f686e != 6) {
            throw new IllegalStateException("Unexpected call to endMessage()");
        }
        int i = this.f685d - 1;
        this.f685d = i;
        if (i < 0 || this.f688g != -1) {
            throw new IllegalStateException("No corresponding call to beginMessage()");
        } else if (this.f683b == this.f684c || this.f685d == 0) {
            this.f684c = j;
        } else {
            throw new IOException("Expected to end at " + this.f684c + " but was " + this.f683b);
        }
    }

    public final int m581b() {
        if (this.f686e == 7) {
            this.f686e = 2;
            return this.f687f;
        } else if (this.f686e != 6) {
            throw new IllegalStateException("Unexpected call to nextTag()");
        } else {
            while (this.f683b < this.f684c && !this.f682a.mo260b()) {
                int i = m578i();
                if (i == 0) {
                    throw new ProtocolException("Unexpected tag 0");
                }
                this.f687f = i >> 3;
                i &= 7;
                switch (i) {
                    case 0:
                        this.f689h = dk.VARINT;
                        this.f686e = 0;
                        return this.f687f;
                    case 1:
                        this.f689h = dk.FIXED64;
                        this.f686e = 1;
                        return this.f687f;
                    case 2:
                        this.f689h = dk.LENGTH_DELIMITED;
                        this.f686e = 2;
                        i = m578i();
                        if (i < 0) {
                            throw new ProtocolException("Negative length: " + i);
                        } else if (this.f688g != -1) {
                            throw new IllegalStateException();
                        } else {
                            this.f688g = this.f684c;
                            this.f684c = ((long) i) + this.f683b;
                            if (this.f684c <= this.f688g) {
                                return this.f687f;
                            }
                            throw new EOFException();
                        }
                    case 3:
                        m576a(this.f687f);
                    case 4:
                        throw new ProtocolException("Unexpected end group");
                    case 5:
                        this.f689h = dk.FIXED32;
                        this.f686e = 5;
                        return this.f687f;
                    default:
                        throw new ProtocolException("Unexpected field encoding: " + i);
                }
            }
            return -1;
        }
    }

    public final dk m582c() {
        return this.f689h;
    }

    private void m576a(int i) {
        while (this.f683b < this.f684c && !this.f682a.mo260b()) {
            int i2 = m578i();
            if (i2 == 0) {
                throw new ProtocolException("Unexpected tag 0");
            }
            int i3 = i2 >> 3;
            i2 &= 7;
            switch (i2) {
                case 0:
                    this.f686e = 0;
                    m584e();
                    break;
                case 1:
                    this.f686e = 1;
                    m586g();
                    break;
                case 2:
                    i2 = m578i();
                    this.f683b += (long) i2;
                    this.f682a.mo265d((long) i2);
                    break;
                case 3:
                    m576a(i3);
                    break;
                case 4:
                    if (i3 != i) {
                        throw new ProtocolException("Unexpected end group");
                    }
                    return;
                case 5:
                    this.f686e = 5;
                    m585f();
                    break;
                default:
                    throw new ProtocolException("Unexpected field encoding: " + i2);
            }
        }
        throw new EOFException();
    }

    public final int m583d() {
        if (this.f686e == 0 || this.f686e == 2) {
            int i = m578i();
            m577b(0);
            return i;
        }
        throw new ProtocolException("Expected VARINT or LENGTH_DELIMITED but was " + this.f686e);
    }

    private int m578i() {
        this.f683b++;
        byte c = this.f682a.mo261c();
        if (c >= (byte) 0) {
            return c;
        }
        int i = c & 127;
        this.f683b++;
        byte c2 = this.f682a.mo261c();
        if (c2 >= (byte) 0) {
            return i | (c2 << 7);
        }
        i |= (c2 & 127) << 7;
        this.f683b++;
        c2 = this.f682a.mo261c();
        if (c2 >= (byte) 0) {
            return i | (c2 << 14);
        }
        i |= (c2 & 127) << 14;
        this.f683b++;
        c2 = this.f682a.mo261c();
        if (c2 >= (byte) 0) {
            return i | (c2 << 21);
        }
        i |= (c2 & 127) << 21;
        this.f683b++;
        c2 = this.f682a.mo261c();
        i |= c2 << 28;
        if (c2 >= (byte) 0) {
            return i;
        }
        for (int i2 = 0; i2 < 5; i2++) {
            this.f683b++;
            if (this.f682a.mo261c() >= (byte) 0) {
                return i;
            }
        }
        throw new ProtocolException("Malformed VARINT");
    }

    public final long m584e() {
        if (this.f686e == 0 || this.f686e == 2) {
            long j = 0;
            for (int i = 0; i < 64; i += 7) {
                this.f683b++;
                byte c = this.f682a.mo261c();
                j |= ((long) (c & 127)) << i;
                if ((c & 128) == 0) {
                    m577b(0);
                    return j;
                }
            }
            throw new ProtocolException("WireInput encountered a malformed varint");
        }
        throw new ProtocolException("Expected VARINT or LENGTH_DELIMITED but was " + this.f686e);
    }

    public final int m585f() {
        if (this.f686e == 5 || this.f686e == 2) {
            this.f682a.mo254a(4);
            this.f683b += 4;
            int e = this.f682a.mo266e();
            m577b(5);
            return e;
        }
        throw new ProtocolException("Expected FIXED32 or LENGTH_DELIMITED but was " + this.f686e);
    }

    public final long m586g() {
        if (this.f686e == 1 || this.f686e == 2) {
            this.f682a.mo254a(8);
            this.f683b += 8;
            long f = this.f682a.mo268f();
            m577b(1);
            return f;
        }
        throw new ProtocolException("Expected FIXED64 or LENGTH_DELIMITED but was " + this.f686e);
    }

    private void m577b(int i) {
        if (this.f686e == i) {
            this.f686e = 6;
        } else if (this.f683b > this.f684c) {
            throw new IOException("Expected to end at " + this.f684c + " but was " + this.f683b);
        } else if (this.f683b == this.f684c) {
            this.f684c = this.f688g;
            this.f688g = -1;
            this.f686e = 6;
        } else {
            this.f686e = 7;
        }
    }

    final long m587h() {
        if (this.f686e != 2) {
            throw new ProtocolException("Expected LENGTH_DELIMITED but was " + this.f686e);
        }
        long j = this.f684c - this.f683b;
        this.f682a.mo254a(j);
        this.f686e = 6;
        this.f683b = this.f684c;
        this.f684c = this.f688g;
        this.f688g = -1;
        return j;
    }
}
