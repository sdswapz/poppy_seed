package com.tapjoy.internal;

import android.content.SharedPreferences;

public final class C0277j extends C0276o {
    private final boolean f1538c = false;

    public C0277j(SharedPreferences sharedPreferences, String str) {
        super(sharedPreferences, str);
    }

    public final void m1321a(boolean z) {
        this.a.edit().putBoolean(this.b, z).commit();
    }

    public final Boolean m1320a() {
        return Boolean.valueOf(this.a.getBoolean(this.b, this.f1538c));
    }
}
