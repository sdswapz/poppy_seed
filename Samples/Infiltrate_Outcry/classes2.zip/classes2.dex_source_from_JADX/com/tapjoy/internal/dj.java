package com.tapjoy.internal;

import com.tapjoy.internal.dn.C0159a;

public abstract class dj extends dn {
    public abstract dq mo178a(int i);

    public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
        dpVar.m594c(((dq) obj).mo179a());
    }

    protected dj(Class cls) {
        super(dk.VARINT, cls);
    }

    public final /* synthetic */ Object mo126a(C0160do c0160do) {
        int d = c0160do.m583d();
        dq a = mo178a(d);
        if (a != null) {
            return a;
        }
        throw new C0159a(d, this.a);
    }
}
