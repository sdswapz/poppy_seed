package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJPlacementListener;

abstract class ff {
    private static final ff f1067a;
    private static ff f1068b;

    public abstract Object mo192a(Context context, String str, TJPlacementListener tJPlacementListener);

    ff() {
    }

    static {
        ff fgVar = new fg();
        f1067a = fgVar;
        f1068b = fgVar;
    }

    static ff m847a() {
        return f1068b;
    }
}
