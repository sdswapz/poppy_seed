package com.tapjoy.internal;

import java.io.Closeable;

public interface bu extends Closeable {
    void close();

    void mo103f();

    void mo104g();

    void mo105h();

    void mo106i();

    boolean mo107j();

    bx mo108k();

    String mo109l();

    String mo110m();

    boolean mo111n();

    void mo112o();

    double mo113p();

    long mo114q();

    int mo115r();

    void mo116s();
}
