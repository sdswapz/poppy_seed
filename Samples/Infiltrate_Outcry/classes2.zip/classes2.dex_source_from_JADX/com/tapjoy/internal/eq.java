package com.tapjoy.internal;

import android.os.Handler;
import android.os.Looper;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public final class eq {

    static class C0194a implements InvocationHandler {
        private final Object f994a;
        private final Thread f995b;
        private final Looper f996c;

        public C0194a(Object obj, Thread thread, Looper looper) {
            this.f994a = obj;
            this.f995b = thread;
            this.f996c = looper;
        }

        public final Object invoke(Object proxy, final Method method, final Object[] args) {
            if (this.f995b == Thread.currentThread()) {
                return method.invoke(this.f994a, args);
            }
            if (method.getReturnType().equals(Void.TYPE)) {
                Runnable c01931 = new Runnable(this) {
                    final /* synthetic */ C0194a f993c;

                    public final void run() {
                        try {
                            method.invoke(this.f993c.f994a, args);
                        } catch (Throwable e) {
                            throw cu.m464a(e);
                        } catch (Throwable e2) {
                            throw cu.m464a(e2);
                        } catch (Throwable e22) {
                            throw cu.m464a(e22);
                        }
                    }
                };
                if (this.f996c != null && new Handler(this.f996c).post(c01931)) {
                    return null;
                }
                if (this.f995b == fv.m917b() && fv.f1107a.mo201a(c01931)) {
                    return null;
                }
                Looper mainLooper = Looper.getMainLooper();
                if (mainLooper == null || !new Handler(mainLooper).post(c01931)) {
                    return method.invoke(this.f994a, args);
                }
                return null;
            }
            throw new UnsupportedOperationException("method not return void: " + method.getName());
        }
    }

    public static Object m791a(Object obj, Class cls) {
        return Proxy.newProxyInstance(cls.getClassLoader(), new Class[]{cls}, new C0194a(obj, Thread.currentThread(), Looper.myLooper()));
    }
}
