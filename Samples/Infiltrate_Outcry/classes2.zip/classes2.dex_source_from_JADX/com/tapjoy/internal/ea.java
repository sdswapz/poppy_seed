package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.internal.dl.C0149a;
import com.tapjoy.internal.dn.C0159a;

public final class ea extends dl {
    public static final dn f794c = new C0171b();
    public static final eb f795d = eb.APP;
    public final eb f796e;
    public final String f797f;
    public final String f798g;

    public static final class C0170a extends C0149a {
        public eb f791c;
        public String f792d;
        public String f793e;

        public final ea m724b() {
            if (this.f791c != null && this.f792d != null) {
                return new ea(this.f791c, this.f792d, this.f793e, super.m529a());
            }
            throw ds.m599a(this.f791c, "type", this.f792d, String.USAGE_TRACKER_NAME);
        }
    }

    static final class C0171b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            ea eaVar = (ea) obj;
            return ((eaVar.f798g != null ? dn.f662p.mo128a(3, eaVar.f798g) : 0) + (dn.f662p.mo128a(2, eaVar.f797f) + eb.ADAPTER.mo128a(1, eaVar.f796e))) + eaVar.m530a().mo277c();
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return C0171b.m725b(c0160do);
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ea eaVar = (ea) obj;
            eb.ADAPTER.mo129a(dpVar, 1, eaVar.f796e);
            dn.f662p.mo129a(dpVar, 2, eaVar.f797f);
            if (eaVar.f798g != null) {
                dn.f662p.mo129a(dpVar, 3, eaVar.f798g);
            }
            dpVar.m593a(eaVar.m530a());
        }

        C0171b() {
            super(dk.LENGTH_DELIMITED, ea.class);
        }

        private static ea m725b(C0160do c0160do) {
            C0170a c0170a = new C0170a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            try {
                                c0170a.f791c = (eb) eb.ADAPTER.mo126a(c0160do);
                                break;
                            } catch (C0159a e) {
                                c0170a.m527a(b, dk.VARINT, Long.valueOf((long) e.f681a));
                                break;
                            }
                        case 2:
                            c0170a.f792d = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 3:
                            c0170a.f793e = (String) dn.f662p.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0170a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0170a.m724b();
            }
        }
    }

    public ea(eb ebVar, String str, String str2, hy hyVar) {
        super(f794c, hyVar);
        this.f796e = ebVar;
        this.f797f = str;
        this.f798g = str2;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ea)) {
            return false;
        }
        ea eaVar = (ea) other;
        if (m530a().equals(eaVar.m530a()) && this.f796e.equals(eaVar.f796e) && this.f797f.equals(eaVar.f797f) && ds.m602a(this.f798g, eaVar.f798g)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (this.f798g != null ? this.f798g.hashCode() : 0) + (((((m530a().hashCode() * 37) + this.f796e.hashCode()) * 37) + this.f797f.hashCode()) * 37);
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", type=").append(this.f796e);
        stringBuilder.append(", name=").append(this.f797f);
        if (this.f798g != null) {
            stringBuilder.append(", category=").append(this.f798g);
        }
        return stringBuilder.replace(0, 2, "EventGroup{").append('}').toString();
    }
}
