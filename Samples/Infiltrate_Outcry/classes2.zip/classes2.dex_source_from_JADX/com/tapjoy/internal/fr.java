package com.tapjoy.internal;

import android.app.Activity;
import java.io.IOException;
import java.util.Locale;
import java.util.Map;

public final class fr {
    public static void m902a(Activity activity) {
        gd a = gd.m956a();
        if (ga.m939a((Object) activity, "onActivityStart: The given activity was null")) {
            ga.m943c("onActivityStart");
            C0140d.m473a(activity.getApplication());
            C0140d.m474b(activity);
            if (a.m972b("onActivityStart") && a.m976e()) {
                fx.m802b(activity);
            }
        }
    }

    public static void m907b(Activity activity) {
        gd a = gd.m956a();
        if (ga.m939a((Object) activity, "onActivityStop: The given activity was null")) {
            ga.m943c("onActivityStop");
            C0140d.m477c(activity);
            if (a.m972b("onActivityStop") && !C0140d.m475b()) {
                a.f1167h.m1101a();
            }
        }
    }

    public static void m901a() {
        gd a = gd.m956a();
        if (a.m972b("startSession") && a.m976e()) {
            fx.m802b(null);
        }
    }

    public static void m906b() {
        gd a = gd.m956a();
        if (a.m972b("endSession")) {
            a.f1167h.m1101a();
        }
    }

    public static void m904a(String str, String str2, String str3, String str4, long j) {
        gd a = gd.m956a();
        if (a.m974c("trackEvent") && ga.m939a((Object) str2, "trackEvent: name was null")) {
            Map map = null;
            if (j != 0) {
                map = cx.m469b();
                map.put("value", Long.valueOf(j));
            }
            a.f1166g.m952a(str, str2, str3, str4, map);
            ga.m938a("trackEvent category:{}, name:{}, p1:{}, p2:{}, values:{} called", str, str2, str3, str4, map);
        }
    }

    public static void m905a(String str, String str2, String str3, String str4, String str5, long j, String str6, long j2, String str7, long j3) {
        gd a = gd.m956a();
        if (a.m974c("trackEvent") && ga.m939a((Object) str2, "trackEvent: name was null")) {
            Map b = cx.m469b();
            if (!(str5 == null || j == 0)) {
                b.put(str5, Long.valueOf(j));
            }
            if (!(str6 == null || j2 == 0)) {
                b.put(str6, Long.valueOf(j2));
            }
            if (!(str7 == null || j3 == 0)) {
                b.put(str7, Long.valueOf(j3));
            }
            if (b.isEmpty()) {
                b = null;
            }
            a.f1166g.m952a(str, str2, str3, str4, b);
            ga.m938a("trackEvent category:{}, name:{}, p1:{}, p2:{}, values:{} called", str, str2, str3, str4, b);
        }
    }

    public static void m903a(String str, String str2, String str3, String str4) {
        gd a = gd.m956a();
        if (a.m972b("trackPurchase")) {
            try {
                C0224g c0224g = new C0224g(str);
                String b = fy.m922b(c0224g.f1134a);
                String b2 = fy.m922b(c0224g.f1139f);
                if (b == null || b2 == null) {
                    ga.m937a("trackPurchase", "skuDetails", "insufficient fields");
                } else if (b2.length() != 3) {
                    ga.m937a("trackPurchase", "skuDetails", "invalid currency code");
                } else {
                    String b3 = fy.m922b(str2);
                    String b4 = fy.m922b(str3);
                    if (b3 != null) {
                        if (b4 != null) {
                            try {
                                C0257h c0257h = new C0257h(b3);
                                if (ct.m463c(c0257h.f1333a) || ct.m463c(c0257h.f1334b) || ct.m463c(c0257h.f1335c) || c0257h.f1336d == 0) {
                                    ga.m937a("trackPurchase", "purchaseData", "insufficient fields");
                                }
                            } catch (IOException e) {
                                ga.m937a("trackPurchase", "purchaseData", "invalid PurchaseData JSON");
                            }
                        } else {
                            ga.m937a("trackPurchase", "dataSignature", "is null, skipping purchase validation");
                        }
                    } else if (b4 != null) {
                        ga.m937a("trackPurchase", "purchaseData", "is null. skipping purchase validation");
                    }
                    a.f1166g.m950a(b, b2.toUpperCase(Locale.US), ((double) c0224g.f1140g) / 1000000.0d, b3, b4, fy.m922b(str4));
                    if (b3 == null || b4 == null) {
                        ga.m936a("trackPurchase without purchaseData called");
                    } else {
                        ga.m936a("trackPurchase with purchaseData called");
                    }
                }
            } catch (IOException e2) {
                ga.m937a("trackPurchase", "skuDetails", "invalid SkuDetails JSON");
            }
        }
    }
}
