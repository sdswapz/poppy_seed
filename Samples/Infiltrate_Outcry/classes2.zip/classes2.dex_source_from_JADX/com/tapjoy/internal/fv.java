package com.tapjoy.internal;

import android.app.Activity;
import android.opengl.GLSurfaceView;

public final class fv {
    public static final bf f1107a = new C02181();
    private static Activity f1108b;
    private static final cd f1109c = new cd();
    private static final cd f1110d = new cd();

    static class C02181 implements bf {
        C02181() {
        }

        public final boolean mo201a(Runnable runnable) {
            GLSurfaceView gLSurfaceView = (GLSurfaceView) fv.f1109c.m438a();
            if (gLSurfaceView == null) {
                return false;
            }
            gLSurfaceView.queueEvent(runnable);
            return true;
        }
    }

    static class C02192 implements Runnable {
        C02192() {
        }

        public final void run() {
            Thread currentThread = Thread.currentThread();
            new Object[1][0] = currentThread;
            fv.f1110d.m439a(currentThread);
        }
    }

    static void m916a(GLSurfaceView gLSurfaceView) {
        new Object[1][0] = gLSurfaceView;
        f1109c.m439a(gLSurfaceView);
        gLSurfaceView.queueEvent(new C02192());
    }

    public static Activity m915a() {
        Activity activity = f1108b;
        if (activity == null) {
            return C0140d.m471a();
        }
        return activity;
    }

    public static Thread m917b() {
        return (Thread) f1110d.m438a();
    }
}
