package com.tapjoy.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

public final class hr extends View {
    public boolean f1456a = false;
    private Bitmap f1457b = null;
    private Rect f1458c = null;
    private Rect f1459d = null;
    private Rect f1460e = null;
    private Rect f1461f = new Rect();

    public hr(Context context) {
        super(context);
    }

    public final void setImageBitmap(Bitmap bitmap) {
        this.f1457b = bitmap;
        int width = this.f1457b.getWidth();
        int height = this.f1457b.getHeight();
        this.f1459d = new Rect(0, 0, width / 2, height);
        this.f1458c = new Rect(width / 2, 0, width, height);
        m1202a();
    }

    final void m1202a() {
        if (this.f1456a) {
            this.f1460e = this.f1458c;
        } else {
            this.f1460e = this.f1459d;
        }
    }

    public final void onDraw(Canvas canvas) {
        if (this.f1460e != null && this.f1457b != null) {
            getDrawingRect(this.f1461f);
            canvas.drawBitmap(this.f1457b, this.f1460e, this.f1461f, null);
        }
    }
}
