package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;

public final class hd {
    public static final bn f1354n = new C02611();
    public hf f1355a;
    public hf f1356b;
    public hf f1357c;
    public hf f1358d;
    public int f1359e = 9;
    public int f1360f = 10;
    public String f1361g;
    public String f1362h;
    public String f1363i;
    public boolean f1364j = false;
    public String f1365k;
    public hb f1366l;
    public hb f1367m;

    static class C02611 implements bn {
        C02611() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            return new hd(bsVar);
        }
    }

    public hd(bs bsVar) {
        bsVar.mo105h();
        while (bsVar.mo107j()) {
            String l = bsVar.mo109l();
            if ("x".equals(l)) {
                this.f1355a = hf.m1147a(bsVar.mo110m());
            } else if ("y".equals(l)) {
                this.f1356b = hf.m1147a(bsVar.mo110m());
            } else if ("width".equals(l)) {
                this.f1357c = hf.m1147a(bsVar.mo110m());
            } else if ("height".equals(l)) {
                this.f1358d = hf.m1147a(bsVar.mo110m());
            } else if (String.URL.equals(l)) {
                this.f1361g = bsVar.mo110m();
            } else if (TapjoyConstants.TJC_REDIRECT_URL.equals(l)) {
                this.f1362h = bsVar.mo110m();
            } else if ("ad_content".equals(l)) {
                this.f1363i = bsVar.mo110m();
            } else if (TapjoyConstants.TJC_FULLSCREEN_AD_DISMISS_URL.equals(l)) {
                this.f1364j = bsVar.mo111n();
            } else if ("value".equals(l)) {
                this.f1365k = bsVar.mo110m();
            } else if ("image".equals(l)) {
                this.f1366l = (hb) hb.f1343e.mo97a(bsVar);
            } else if ("image_clicked".equals(l)) {
                this.f1367m = (hb) hb.f1343e.mo97a(bsVar);
            } else if ("align".equals(l)) {
                l = bsVar.mo110m();
                if ("left".equals(l)) {
                    this.f1359e = 9;
                } else if ("right".equals(l)) {
                    this.f1359e = 11;
                } else if ("center".equals(l)) {
                    this.f1359e = 14;
                } else {
                    bsVar.mo116s();
                }
            } else if ("valign".equals(l)) {
                l = bsVar.mo110m();
                if ("top".equals(l)) {
                    this.f1360f = 10;
                } else if ("middle".equals(l)) {
                    this.f1360f = 15;
                } else if ("bottom".equals(l)) {
                    this.f1360f = 12;
                } else {
                    bsVar.mo116s();
                }
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
    }
}
