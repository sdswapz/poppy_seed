package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;

public final class eg extends dl {
    public static final dn f873c = new C0182b();
    public static final Integer f874d = Integer.valueOf(1);
    public static final Double f875e = Double.valueOf(0.0d);
    public static final Integer f876f = Integer.valueOf(0);
    public static final Long f877g = Long.valueOf(0);
    public final String f878h;
    public final Integer f879i;
    public final Double f880j;
    public final String f881k;
    public final String f882l;
    public final String f883m;
    public final String f884n;
    public final String f885o;
    public final Integer f886p;
    public final Long f887q;
    public final String f888r;
    public final String f889s;
    public final String f890t;
    public final String f891u;

    public static final class C0181a extends C0149a {
        public String f859c;
        public Integer f860d;
        public Double f861e;
        public String f862f;
        public String f863g;
        public String f864h;
        public String f865i;
        public String f866j;
        public Integer f867k;
        public Long f868l;
        public String f869m;
        public String f870n;
        public String f871o;
        public String f872p;

        public final eg m748b() {
            if (this.f859c != null) {
                return new eg(this.f859c, this.f860d, this.f861e, this.f862f, this.f863g, this.f864h, this.f865i, this.f866j, this.f867k, this.f868l, this.f869m, this.f870n, this.f871o, this.f872p, super.m529a());
            }
            throw ds.m599a(this.f859c, "productId");
        }
    }

    static final class C0182b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            eg egVar = (eg) obj;
            int a2 = dn.f662p.mo128a(1, egVar.f878h) + (egVar.f879i != null ? dn.f650d.mo128a(2, egVar.f879i) : 0);
            if (egVar.f880j != null) {
                a = dn.f661o.mo128a(3, egVar.f880j);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f881k != null) {
                a = dn.f662p.mo128a(4, egVar.f881k);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f882l != null) {
                a = dn.f662p.mo128a(5, egVar.f882l);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f883m != null) {
                a = dn.f662p.mo128a(6, egVar.f883m);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f884n != null) {
                a = dn.f662p.mo128a(7, egVar.f884n);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f885o != null) {
                a = dn.f662p.mo128a(8, egVar.f885o);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f886p != null) {
                a = dn.f650d.mo128a(9, egVar.f886p);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f887q != null) {
                a = dn.f655i.mo128a(10, egVar.f887q);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f888r != null) {
                a = dn.f662p.mo128a(11, egVar.f888r);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f889s != null) {
                a = dn.f662p.mo128a(12, egVar.f889s);
            } else {
                a = 0;
            }
            a2 += a;
            if (egVar.f890t != null) {
                a = dn.f662p.mo128a(13, egVar.f890t);
            } else {
                a = 0;
            }
            a += a2;
            if (egVar.f891u != null) {
                i = dn.f662p.mo128a(14, egVar.f891u);
            }
            return (a + i) + egVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            eg egVar = (eg) obj;
            dn.f662p.mo129a(dpVar, 1, egVar.f878h);
            if (egVar.f879i != null) {
                dn.f650d.mo129a(dpVar, 2, egVar.f879i);
            }
            if (egVar.f880j != null) {
                dn.f661o.mo129a(dpVar, 3, egVar.f880j);
            }
            if (egVar.f881k != null) {
                dn.f662p.mo129a(dpVar, 4, egVar.f881k);
            }
            if (egVar.f882l != null) {
                dn.f662p.mo129a(dpVar, 5, egVar.f882l);
            }
            if (egVar.f883m != null) {
                dn.f662p.mo129a(dpVar, 6, egVar.f883m);
            }
            if (egVar.f884n != null) {
                dn.f662p.mo129a(dpVar, 7, egVar.f884n);
            }
            if (egVar.f885o != null) {
                dn.f662p.mo129a(dpVar, 8, egVar.f885o);
            }
            if (egVar.f886p != null) {
                dn.f650d.mo129a(dpVar, 9, egVar.f886p);
            }
            if (egVar.f887q != null) {
                dn.f655i.mo129a(dpVar, 10, egVar.f887q);
            }
            if (egVar.f888r != null) {
                dn.f662p.mo129a(dpVar, 11, egVar.f888r);
            }
            if (egVar.f889s != null) {
                dn.f662p.mo129a(dpVar, 12, egVar.f889s);
            }
            if (egVar.f890t != null) {
                dn.f662p.mo129a(dpVar, 13, egVar.f890t);
            }
            if (egVar.f891u != null) {
                dn.f662p.mo129a(dpVar, 14, egVar.f891u);
            }
            dpVar.m593a(egVar.m530a());
        }

        C0182b() {
            super(dk.LENGTH_DELIMITED, eg.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0181a c0181a = new C0181a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0181a.f859c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0181a.f860d = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 3:
                            c0181a.f861e = (Double) dn.f661o.mo126a(c0160do);
                            break;
                        case 4:
                            c0181a.f862f = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 5:
                            c0181a.f863g = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 6:
                            c0181a.f864h = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 7:
                            c0181a.f865i = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 8:
                            c0181a.f866j = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 9:
                            c0181a.f867k = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 10:
                            c0181a.f868l = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 11:
                            c0181a.f869m = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 12:
                            c0181a.f870n = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 13:
                            c0181a.f871o = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 14:
                            c0181a.f872p = (String) dn.f662p.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0181a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0181a.m748b();
            }
        }
    }

    public eg(String str, Integer num, Double d, String str2, String str3, String str4, String str5, String str6, Integer num2, Long l, String str7, String str8, String str9, String str10, hy hyVar) {
        super(f873c, hyVar);
        this.f878h = str;
        this.f879i = num;
        this.f880j = d;
        this.f881k = str2;
        this.f882l = str3;
        this.f883m = str4;
        this.f884n = str5;
        this.f885o = str6;
        this.f886p = num2;
        this.f887q = l;
        this.f888r = str7;
        this.f889s = str8;
        this.f890t = str9;
        this.f891u = str10;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof eg)) {
            return false;
        }
        eg egVar = (eg) other;
        if (m530a().equals(egVar.m530a()) && this.f878h.equals(egVar.f878h) && ds.m602a(this.f879i, egVar.f879i) && ds.m602a(this.f880j, egVar.f880j) && ds.m602a(this.f881k, egVar.f881k) && ds.m602a(this.f882l, egVar.f882l) && ds.m602a(this.f883m, egVar.f883m) && ds.m602a(this.f884n, egVar.f884n) && ds.m602a(this.f885o, egVar.f885o) && ds.m602a(this.f886p, egVar.f886p) && ds.m602a(this.f887q, egVar.f887q) && ds.m602a(this.f888r, egVar.f888r) && ds.m602a(this.f889s, egVar.f889s) && ds.m602a(this.f890t, egVar.f890t) && ds.m602a(this.f891u, egVar.f891u)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f879i != null ? this.f879i.hashCode() : 0) + (((m530a().hashCode() * 37) + this.f878h.hashCode()) * 37)) * 37;
        if (this.f880j != null) {
            i2 = this.f880j.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f881k != null) {
            i2 = this.f881k.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f882l != null) {
            i2 = this.f882l.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f883m != null) {
            i2 = this.f883m.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f884n != null) {
            i2 = this.f884n.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f885o != null) {
            i2 = this.f885o.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f886p != null) {
            i2 = this.f886p.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f887q != null) {
            i2 = this.f887q.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f888r != null) {
            i2 = this.f888r.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f889s != null) {
            i2 = this.f889s.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f890t != null) {
            i2 = this.f890t.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f891u != null) {
            i = this.f891u.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", productId=").append(this.f878h);
        if (this.f879i != null) {
            stringBuilder.append(", productQuantity=").append(this.f879i);
        }
        if (this.f880j != null) {
            stringBuilder.append(", productPrice=").append(this.f880j);
        }
        if (this.f881k != null) {
            stringBuilder.append(", productPriceCurrency=").append(this.f881k);
        }
        if (this.f882l != null) {
            stringBuilder.append(", productType=").append(this.f882l);
        }
        if (this.f883m != null) {
            stringBuilder.append(", productTitle=").append(this.f883m);
        }
        if (this.f884n != null) {
            stringBuilder.append(", productDescription=").append(this.f884n);
        }
        if (this.f885o != null) {
            stringBuilder.append(", transactionId=").append(this.f885o);
        }
        if (this.f886p != null) {
            stringBuilder.append(", transactionState=").append(this.f886p);
        }
        if (this.f887q != null) {
            stringBuilder.append(", transactionDate=").append(this.f887q);
        }
        if (this.f888r != null) {
            stringBuilder.append(", campaignId=").append(this.f888r);
        }
        if (this.f889s != null) {
            stringBuilder.append(", currencyPrice=").append(this.f889s);
        }
        if (this.f890t != null) {
            stringBuilder.append(", receipt=").append(this.f890t);
        }
        if (this.f891u != null) {
            stringBuilder.append(", signature=").append(this.f891u);
        }
        return stringBuilder.replace(0, 2, "Purchase{").append('}').toString();
    }
}
