package com.tapjoy.internal;

import android.app.Dialog;
import android.content.Context;

public final class C0169e extends Dialog {
    private boolean f790a = false;

    public C0169e(Context context) {
        super(context, 16973835);
        requestWindowFeature(1);
        getWindow().setBackgroundDrawableResource(17170445);
    }

    public final void show() {
        this.f790a = false;
        super.show();
    }

    public final void cancel() {
        this.f790a = true;
        super.cancel();
    }
}
