package com.tapjoy.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public final class C0282q extends C0276o {
    private final String f1542c = null;

    public C0282q(SharedPreferences sharedPreferences, String str) {
        super(sharedPreferences, str);
    }

    public final String m1338a() {
        return this.a.getString(this.b, this.f1542c);
    }

    public final void m1339a(String str) {
        this.a.edit().putString(this.b, str).commit();
    }

    public final Editor m1337a(Editor editor, String str) {
        return str != null ? editor.putString(this.b, str) : editor.remove(this.b);
    }
}
