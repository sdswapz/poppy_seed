package com.tapjoy.internal;

public interface dq {
    int mo179a();
}
