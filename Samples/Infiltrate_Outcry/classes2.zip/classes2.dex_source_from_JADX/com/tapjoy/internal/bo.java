package com.tapjoy.internal;

import android.graphics.Point;
import android.graphics.Rect;

public final class bo {
    public static final bn f542a = new C01281();
    public static final bn f543b = new C01292();

    static class C01281 implements bn {
        C01281() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            Point point = new Point();
            bsVar.mo105h();
            while (bsVar.mo107j()) {
                String l = bsVar.mo109l();
                if ("x".equals(l)) {
                    point.x = bsVar.mo115r();
                } else if ("y".equals(l)) {
                    point.y = bsVar.mo115r();
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return point;
        }
    }

    static class C01292 implements bn {
        C01292() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            Rect rect = new Rect();
            switch (bsVar.mo108k()) {
                case BEGIN_ARRAY:
                    bsVar.mo103f();
                    rect.left = bsVar.mo115r();
                    rect.top = bsVar.mo115r();
                    rect.right = bsVar.mo115r();
                    rect.bottom = bsVar.mo115r();
                    while (bsVar.mo107j()) {
                        bsVar.mo116s();
                    }
                    bsVar.mo104g();
                    break;
                case BEGIN_OBJECT:
                    bsVar.mo105h();
                    while (bsVar.mo107j()) {
                        String l = bsVar.mo109l();
                        if ("left".equals(l)) {
                            rect.left = bsVar.mo115r();
                        } else if ("top".equals(l)) {
                            rect.top = bsVar.mo115r();
                        } else if ("right".equals(l)) {
                            rect.right = bsVar.mo115r();
                        } else if ("bottom".equals(l)) {
                            rect.bottom = bsVar.mo115r();
                        } else {
                            bsVar.mo116s();
                        }
                    }
                    bsVar.mo106i();
                    break;
                default:
                    throw new IllegalStateException("Unexpected token: " + bsVar.mo108k());
            }
            return rect;
        }
    }
}
