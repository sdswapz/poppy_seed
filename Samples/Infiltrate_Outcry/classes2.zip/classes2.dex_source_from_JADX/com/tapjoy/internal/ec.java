package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.internal.dl.C0149a;

public final class ec extends dl {
    public static final dn f803c = new C0174b();
    public static final Long f804d = Long.valueOf(0);
    public final String f805e;
    public final Long f806f;

    public static final class C0173a extends C0149a {
        public String f801c;
        public Long f802d;

        public final ec m732b() {
            if (this.f801c != null && this.f802d != null) {
                return new ec(this.f801c, this.f802d, super.m529a());
            }
            throw ds.m599a(this.f801c, String.USAGE_TRACKER_NAME, this.f802d, "value");
        }
    }

    static final class C0174b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            ec ecVar = (ec) obj;
            return (dn.f662p.mo128a(1, ecVar.f805e) + dn.f655i.mo128a(2, ecVar.f806f)) + ecVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ec ecVar = (ec) obj;
            dn.f662p.mo129a(dpVar, 1, ecVar.f805e);
            dn.f655i.mo129a(dpVar, 2, ecVar.f806f);
            dpVar.m593a(ecVar.m530a());
        }

        C0174b() {
            super(dk.LENGTH_DELIMITED, ec.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0173a c0173a = new C0173a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0173a.f801c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0173a.f802d = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0173a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0173a.m732b();
            }
        }
    }

    public ec(String str, Long l) {
        this(str, l, hy.f1496b);
    }

    public ec(String str, Long l, hy hyVar) {
        super(f803c, hyVar);
        this.f805e = str;
        this.f806f = l;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ec)) {
            return false;
        }
        ec ecVar = (ec) other;
        if (m530a().equals(ecVar.m530a()) && this.f805e.equals(ecVar.f805e) && this.f806f.equals(ecVar.f806f)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (((m530a().hashCode() * 37) + this.f805e.hashCode()) * 37) + this.f806f.hashCode();
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", name=").append(this.f805e);
        stringBuilder.append(", value=").append(this.f806f);
        return stringBuilder.replace(0, 2, "EventValue{").append('}').toString();
    }
}
