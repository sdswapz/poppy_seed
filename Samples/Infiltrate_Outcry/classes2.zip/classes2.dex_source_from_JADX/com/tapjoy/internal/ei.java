package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;
import java.util.List;

public final class ei extends dl {
    public static final dn f902c = new C0186b();
    public final List f903d;

    public static final class C0185a extends C0149a {
        public List f901c = ds.m600a();

        public final ei m757b() {
            return new ei(this.f901c, super.m529a());
        }
    }

    static final class C0186b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            ei eiVar = (ei) obj;
            return eh.f895c.m514a().mo128a(1, eiVar.f903d) + eiVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ei eiVar = (ei) obj;
            eh.f895c.m514a().mo129a(dpVar, 1, eiVar.f903d);
            dpVar.m593a(eiVar.m530a());
        }

        C0186b() {
            super(dk.LENGTH_DELIMITED, ei.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0185a c0185a = new C0185a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0185a.f901c.add(eh.f895c.mo126a(c0160do));
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0185a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0185a.m757b();
            }
        }
    }

    public ei(List list) {
        this(list, hy.f1496b);
    }

    public ei(List list, hy hyVar) {
        super(f902c, hyVar);
        this.f903d = ds.m601a("pushes", list);
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ei)) {
            return false;
        }
        ei eiVar = (ei) other;
        if (m530a().equals(eiVar.m530a()) && this.f903d.equals(eiVar.f903d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (m530a().hashCode() * 37) + this.f903d.hashCode();
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (!this.f903d.isEmpty()) {
            stringBuilder.append(", pushes=").append(this.f903d);
        }
        return stringBuilder.replace(0, 2, "PushList{").append('}').toString();
    }
}
