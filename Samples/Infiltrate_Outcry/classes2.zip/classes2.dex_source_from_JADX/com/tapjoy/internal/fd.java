package com.tapjoy.internal;

import android.content.Context;
import android.content.SharedPreferences;
import com.tapjoy.TapjoyConstants;
import com.tapjoy.internal.fn.C0217a;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

public final class fd {
    private static final fd f1042b;
    private static fd f1043c;
    public final fb f1044a = new fb();
    private Context f1045d;

    class C02021 implements Observer {
        final /* synthetic */ fd f1041a;

        C02021(fd fdVar) {
            this.f1041a = fdVar;
        }

        public final void update(Observable observable, Object data) {
            Object a;
            fj.m876a(this.f1041a.f1044a.m828a("usage_tracking_enabled", false));
            String str = "usage_tracking_exclude";
            Class cls = List.class;
            for (C0217a a2 : this.f1041a.f1044a.f1029b) {
                a = a2.m896a(str);
                if (a != null && cls.isInstance(a)) {
                    a = cls.cast(a);
                    break;
                }
            }
            a = null;
            fj.m875a((Collection) a);
        }
    }

    static {
        fd fdVar = new fd();
        f1042b = fdVar;
        f1043c = fdVar;
    }

    public static fd m836a() {
        return f1043c;
    }

    public static fb m837b() {
        return f1043c.f1044a;
    }

    fd() {
    }

    public final synchronized void m838a(Context context) {
        if (context != null) {
            if (this.f1045d == null) {
                this.f1045d = context;
                SharedPreferences c = m839c();
                String string = m839c().getString(TapjoyConstants.PREF_SERVER_PROVIDED_CONFIGURATIONS, null);
                if (string != null) {
                    bs b;
                    try {
                        b = bs.m367b(string);
                        Map d = b.m380d();
                        b.close();
                        this.f1044a.m833a(d);
                    } catch (Exception e) {
                        c.edit().remove(TapjoyConstants.PREF_SERVER_PROVIDED_CONFIGURATIONS).commit();
                    } catch (Throwable th) {
                        b.close();
                    }
                }
                Observer c02021 = new C02021(this);
                this.f1044a.addObserver(c02021);
                c02021.update(this.f1044a, null);
            }
        }
    }

    public final SharedPreferences m839c() {
        return this.f1045d.getSharedPreferences(TapjoyConstants.TJC_PREFERENCE, 0);
    }
}
