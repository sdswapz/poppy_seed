package com.tapjoy.internal;

import android.os.SystemClock;

public abstract class hq implements Runnable {
    private final long f1142a = 300;

    public abstract boolean mo207a();

    public void run() {
        long elapsedRealtime = SystemClock.elapsedRealtime() + this.f1142a;
        while (!mo207a() && elapsedRealtime - SystemClock.elapsedRealtime() > 0) {
            try {
                Thread.sleep(0);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
