package com.tapjoy.internal;

public enum dk {
    VARINT(0),
    FIXED64(1),
    LENGTH_DELIMITED(2),
    FIXED32(5);
    
    final int f673e;

    private dk(int i) {
        this.f673e = i;
    }

    public final dn m526a() {
        switch (this) {
            case VARINT:
                return dn.f656j;
            case FIXED32:
                return dn.f653g;
            case FIXED64:
                return dn.f658l;
            case LENGTH_DELIMITED:
                return dn.f663q;
            default:
                throw new AssertionError();
        }
    }
}
