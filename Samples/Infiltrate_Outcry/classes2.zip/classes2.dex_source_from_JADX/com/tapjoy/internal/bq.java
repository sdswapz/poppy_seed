package com.tapjoy.internal;

import java.io.Writer;

public interface bq {
    void mo96a(Writer writer);
}
