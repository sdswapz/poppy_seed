package com.tapjoy.internal;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources.NotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.Html;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyReceiver;
import com.tapjoy.internal.C0120a.C0109l;
import com.tapjoy.internal.C0120a.C0111c;
import com.tapjoy.internal.C0120a.C0112d;
import com.tapjoy.internal.dy.C0165a;

public final class gf extends C0237r {
    private static gf f1201c;

    class C02351 implements C0234t {
        C02351() {
        }

        public final String mo210a(Context context) {
            return gn.m1090a(context).f1243b.getString("gcm.senderIds", "");
        }

        public final void mo213a(Context context, String str) {
            C0281p.m1335a(gn.m1090a(context).f1243b, "gcm.senderIds", str);
        }

        public final String mo215b(Context context) {
            return gn.m1090a(context).f1243b.getString("gcm.regId", "");
        }

        public final void mo217b(Context context, String str) {
            C0281p.m1335a(gn.m1090a(context).f1243b, "gcm.regId", str);
        }

        public final boolean mo219c(Context context) {
            return gn.m1090a(context).f1243b.getBoolean("gcm.stale", true);
        }

        public final void mo214a(Context context, boolean z) {
            C0281p.m1336a(gn.m1090a(context).f1243b, "gcm.stale", z);
        }

        public final int mo220d(Context context) {
            return gn.m1090a(context).f1243b.getInt("gcm.appVersion", Integer.MIN_VALUE);
        }

        public final void mo211a(Context context, int i) {
            C0281p.m1334a(gn.m1090a(context).f1243b, "gcm.appVersion", i);
        }

        public final boolean mo221e(Context context) {
            return gn.m1090a(context).f1243b.getBoolean("gcm.onServer", false);
        }

        public final void mo218b(Context context, boolean z) {
            gn.m1090a(context).m1092a(z);
        }

        public final long mo222f(Context context) {
            return gn.m1090a(context).f1243b.getLong("gcm.onServerExpirationTime", 0);
        }

        public final void mo212a(Context context, long j) {
            Editor edit = gn.m1090a(context).f1243b.edit();
            edit.putLong("gcm.onServerExpirationTime", j);
            edit.commit();
        }

        public final int mo223g(Context context) {
            return gn.m1090a(context).f1243b.getInt("gcm.backoff", 0);
        }

        public final void mo216b(Context context, int i) {
            C0281p.m1334a(gn.m1090a(context).f1243b, "gcm.backoff", i);
        }
    }

    public static synchronized gf m1039b(Context context) {
        gf gfVar;
        synchronized (gf.class) {
            if (f1201c == null) {
                f1201c = new gf(context);
            }
            gfVar = f1201c;
        }
        return gfVar;
    }

    private gf(Context context) {
        super(context, new C02351());
    }

    final void mo230e(String str) {
        if (str != null && str.length() > 0) {
            String[] strArr = new String[]{str};
            super.m1031a(this.f1198a);
            super.m1032a(strArr[0]);
        }
    }

    protected final void mo225a(Context context, String str) {
        new Object[1][0] = str;
        gd.m957a(context).m965a(str);
    }

    protected final void mo227b(String str) {
        new Object[1][0] = str;
        m1033a();
    }

    protected final boolean mo226a(Context context, Intent intent) {
        Object[] objArr = new Object[]{intent, intent.getExtras()};
        String stringExtra = intent.getStringExtra("fiverocks");
        if (stringExtra == null) {
            return false;
        }
        if (gg.m1049a(context).m1067f()) {
            gc gcVar = gd.m957a(context).f1166g;
            C0165a a = gcVar.m948a(eb.APP, "push_ignore");
            a.f743s = new ef(null, null, stringExtra);
            gcVar.m949a(a);
            return true;
        }
        String stringExtra2 = intent.getStringExtra(String.TITLE);
        String stringExtra3 = intent.getStringExtra(String.MESSAGE);
        if (stringExtra3 != null) {
            boolean z;
            Bundle extras = intent.getExtras();
            Object obj = extras.get("rich");
            Object obj2 = extras.get("sound");
            Object obj3 = extras.get("important");
            String string = extras.getString("payload");
            Object obj4 = extras.get("always");
            obj4 = ("true".equals(obj4) || Boolean.TRUE.equals(obj4)) ? 1 : null;
            Object obj5 = extras.get("repeatable");
            if ("true".equals(obj5) || Boolean.TRUE.equals(obj5)) {
                z = true;
            } else {
                z = false;
            }
            String string2 = extras.getString("placement");
            int b = m1038b(extras.get("nid"));
            if (!(obj4 == null && gd.m957a(context).m975d())) {
                String a2 = ct.m461a(stringExtra2);
                boolean a3 = m1037a(obj);
                boolean a4 = m1037a(obj2);
                m1037a(obj3);
                Notification a5 = m1036a(context, stringExtra, a2, stringExtra3, a3, a4, string, string2, b);
                gd a6 = gd.m957a(context);
                long currentTimeMillis = System.currentTimeMillis();
                a6.m971b(context);
                if (a6.f1165f.m1058a(stringExtra, currentTimeMillis, z)) {
                    gcVar = a6.f1166g;
                    C0165a a7 = gcVar.m948a(eb.APP, "push_show");
                    a7.f743s = new ef(null, null, stringExtra);
                    gcVar.m949a(a7);
                    obj4 = 1;
                } else {
                    obj4 = null;
                }
                if (obj4 != null) {
                    ((NotificationManager) context.getSystemService("notification")).notify(b, a5);
                }
            }
        }
        return true;
    }

    private static boolean m1037a(Object obj) {
        return Boolean.TRUE.equals(obj) || "true".equals(obj);
    }

    private static int m1038b(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        if (obj instanceof String) {
            try {
                return Integer.parseInt((String) obj);
            } catch (NumberFormatException e) {
            }
        }
        return 0;
    }

    protected final void mo224a(int i) {
        new Object[1][0] = Integer.valueOf(i);
    }

    protected final boolean mo228c(String str) {
        new Object[1][0] = str;
        return true;
    }

    protected final boolean mo229d(String str) {
        new Object[1][0] = str;
        return false;
    }

    private static Notification m1036a(Context context, String str, String str2, String str3, boolean z, boolean z2, String str4, String str5, int i) {
        Bitmap bitmap = null;
        Intent intent = new Intent(context.getApplicationContext(), TapjoyReceiver.class);
        intent.setAction("com.tapjoy.PUSH_CLICK");
        intent.putExtra("com.tapjoy.PUSH_ID", str);
        if (str4 != null) {
            intent.putExtra("com.tapjoy.PUSH_PAYLOAD", str4);
        }
        if (str5 != null) {
            intent.putExtra("com.tapjoy.PUSH_PLACEMENT", str5);
        }
        int i2 = 134217728;
        if (VERSION.SDK_INT == 19) {
            i2 = 268435456;
        }
        PendingIntent broadcast = PendingIntent.getBroadcast(context.getApplicationContext(), i, intent, i2);
        if (broadcast == null) {
            return null;
        }
        PackageManager packageManager = context.getPackageManager();
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128);
            if (str2.length() == 0) {
                str2 = packageManager.getApplicationLabel(applicationInfo);
            } else if (z) {
                str2 = Html.fromHtml(str2);
            }
            if (z) {
                str3 = Html.fromHtml(str3);
            }
            i2 = m1035a(applicationInfo.metaData, "com.tapjoy.notification.icon", context);
            if (i2 == 0) {
                i2 = applicationInfo.icon != 0 ? applicationInfo.icon : 17301651;
            }
            int a = m1035a(applicationInfo.metaData, "com.tapjoy.notification.icon.large", context);
            if (a != 0) {
                bitmap = BitmapFactory.decodeResource(context.getResources(), a);
            }
            C0112d c0112d = new C0112d(context);
            c0112d.f454r.icon = i2;
            c0112d.f454r.tickerText = str2;
            c0112d.f438b = str2;
            c0112d.f439c = str3;
            c0112d.f440d = broadcast;
            Notification notification = c0112d.f454r;
            notification.flags |= 16;
            C0109l c0111c = new C0111c();
            c0111c.e = str2;
            c0111c.f436a = str3;
            C0112d a2 = c0112d.m256a(c0111c);
            if (z2) {
                a2.f454r.defaults = 1;
            }
            if (bitmap != null) {
                a2.f443g = bitmap;
            }
            return C0120a.f456a.mo86a(a2);
        } catch (NameNotFoundException e) {
            return null;
        }
    }

    private static int m1035a(Bundle bundle, String str, Context context) {
        if (bundle != null) {
            Object obj = bundle.get(str);
            if (obj instanceof Integer) {
                int intValue = ((Integer) obj).intValue();
                try {
                    if ("drawable".equals(context.getResources().getResourceTypeName(intValue))) {
                        return intValue;
                    }
                } catch (NotFoundException e) {
                }
            }
            if (obj != null) {
                String str2 = "meta-data of {} invalid";
                Object[] objArr = new Object[]{str};
                if (ga.f1141a) {
                    ac.m267a(4, "Tapjoy", str2, objArr);
                }
            }
        }
        return 0;
    }
}
