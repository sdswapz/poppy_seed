package com.tapjoy.internal;

public final class fm {
    public static final fm f1095a = new fm(0, 0, 0, 0.0d);
    public final long f1096b;
    public final long f1097c;
    public final double f1098d;
    public long f1099e;
    private final long f1100f;

    public fm(long j, long j2, long j3, double d) {
        this.f1100f = j;
        this.f1096b = j2;
        this.f1097c = j3;
        this.f1098d = d;
        this.f1099e = j;
    }

    public final boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        fm fmVar = (fm) o;
        if (this.f1100f == fmVar.f1100f && this.f1096b == fmVar.f1096b && this.f1097c == fmVar.f1097c && this.f1098d == fmVar.f1098d && this.f1099e == fmVar.f1099e) {
            return true;
        }
        return false;
    }
}
