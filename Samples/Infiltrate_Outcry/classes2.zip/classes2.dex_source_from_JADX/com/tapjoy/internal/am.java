package com.tapjoy.internal;

import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;

public final class am {
    protected int f505a = 0;
    protected float f506b = 0.0f;
    protected int f507c = 0;
    protected float f508d = 0.0f;
    protected int f509e = 0;
    protected float f510f = 0.0f;
    protected int f511g = 0;
    protected float f512h = 0.0f;

    public final Animation m289a() {
        return new TranslateAnimation(this.f505a, this.f506b, this.f507c, this.f508d, this.f509e, this.f510f, this.f511g, this.f512h);
    }

    public final am m290a(float f) {
        this.f505a = 1;
        this.f506b = f;
        return this;
    }

    public final am m291b(float f) {
        this.f509e = 1;
        this.f510f = f;
        return this;
    }
}
