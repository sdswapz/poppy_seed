package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;
import java.util.List;

public final class dz extends dl {
    public static final dn f788c = new C0168b();
    public final List f789d;

    public static final class C0167a extends C0149a {
        public List f787c = ds.m600a();

        public final dz m720b() {
            return new dz(this.f787c, super.m529a());
        }
    }

    static final class C0168b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            dz dzVar = (dz) obj;
            return dy.f751c.m514a().mo128a(1, dzVar.f789d) + dzVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dz dzVar = (dz) obj;
            dy.f751c.m514a().mo129a(dpVar, 1, dzVar.f789d);
            dpVar.m593a(dzVar.m530a());
        }

        C0168b() {
            super(dk.LENGTH_DELIMITED, dz.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0167a c0167a = new C0167a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0167a.f787c.add(dy.f751c.mo126a(c0160do));
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0167a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0167a.m720b();
            }
        }
    }

    public dz(List list, hy hyVar) {
        super(f788c, hyVar);
        this.f789d = ds.m601a("events", list);
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof dz)) {
            return false;
        }
        dz dzVar = (dz) other;
        if (m530a().equals(dzVar.m530a()) && this.f789d.equals(dzVar.f789d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (m530a().hashCode() * 37) + this.f789d.hashCode();
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (!this.f789d.isEmpty()) {
            stringBuilder.append(", events=").append(this.f789d);
        }
        return stringBuilder.replace(0, 2, "EventBatch{").append('}').toString();
    }
}
