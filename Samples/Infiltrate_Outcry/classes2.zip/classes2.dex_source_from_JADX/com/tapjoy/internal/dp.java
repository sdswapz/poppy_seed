package com.tapjoy.internal;

public final class dp {
    final hw f690a;

    static int m589a(int i, dk dkVar) {
        return (i << 3) | dkVar.f673e;
    }

    static int m588a(int i) {
        if ((i & -128) == 0) {
            return 1;
        }
        if ((i & -16384) == 0) {
            return 2;
        }
        if ((-2097152 & i) == 0) {
            return 3;
        }
        if ((-268435456 & i) == 0) {
            return 4;
        }
        return 5;
    }

    static int m590a(long j) {
        if ((-128 & j) == 0) {
            return 1;
        }
        if ((-16384 & j) == 0) {
            return 2;
        }
        if ((-2097152 & j) == 0) {
            return 3;
        }
        if ((-268435456 & j) == 0) {
            return 4;
        }
        if ((-34359738368L & j) == 0) {
            return 5;
        }
        if ((-4398046511104L & j) == 0) {
            return 6;
        }
        if ((-562949953421312L & j) == 0) {
            return 7;
        }
        if ((-72057594037927936L & j) == 0) {
            return 8;
        }
        if ((Long.MIN_VALUE & j) == 0) {
            return 9;
        }
        return 10;
    }

    static int m591b(int i) {
        return (i << 1) ^ (i >> 31);
    }

    static long m592b(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public dp(hw hwVar) {
        this.f690a = hwVar;
    }

    public final void m593a(hy hyVar) {
        this.f690a.mo257b(hyVar);
    }

    public final void m594c(int i) {
        while ((i & -128) != 0) {
            this.f690a.mo267e((i & 127) | 128);
            i >>>= 7;
        }
        this.f690a.mo267e(i);
    }

    public final void m595c(long j) {
        while ((-128 & j) != 0) {
            this.f690a.mo267e((((int) j) & 127) | 128);
            j >>>= 7;
        }
        this.f690a.mo267e((int) j);
    }

    public final void m596d(int i) {
        this.f690a.mo264d(i);
    }

    public final void m597d(long j) {
        this.f690a.mo269f(j);
    }
}
