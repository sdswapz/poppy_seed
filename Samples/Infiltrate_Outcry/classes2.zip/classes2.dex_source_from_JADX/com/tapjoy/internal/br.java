package com.tapjoy.internal;

import java.io.Writer;

public final class br implements bq {
    public final String f544a;

    public br(String str) {
        this.f544a = str;
    }

    public final void mo96a(Writer writer) {
        writer.write(this.f544a);
    }

    public final boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof br)) {
            return false;
        }
        return this.f544a.equals(((br) o).f544a);
    }

    public final int hashCode() {
        return this.f544a.hashCode();
    }

    public final String toString() {
        return this.f544a;
    }
}
