package com.tapjoy.internal;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class gr {
    public static final ScheduledExecutorService f1283a = Executors.newScheduledThreadPool(1);
    public static final CountDownLatch f1284b = new CountDownLatch(1);
    public static final CountDownLatch f1285c = new CountDownLatch(1);
    private static final Runnable f1286d = new C02481();
    private static String f1287e;
    private static boolean f1288f;

    static class C02481 implements Runnable {
        C02481() {
        }

        public final void run() {
            if (C0289y.m1353c()) {
                gr.f1284b.countDown();
            } else if (C0289y.m1351a()) {
                gr.f1284b.countDown();
            } else {
                gr.f1283a.schedule(this, 300, TimeUnit.SECONDS);
            }
        }
    }

    public static void m1102a() {
        f1283a.execute(f1286d);
    }

    public static void m1103a(String str, boolean z) {
        f1287e = str;
        f1288f = z;
        f1285c.countDown();
    }

    public static String m1104b() {
        return f1287e;
    }

    public static boolean m1105c() {
        return f1288f;
    }
}
