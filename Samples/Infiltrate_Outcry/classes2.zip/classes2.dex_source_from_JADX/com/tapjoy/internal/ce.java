package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import java.io.InputStream;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class ce extends cf {
    public abstract Object mo247a(bs bsVar);

    public final Map mo118a() {
        Map linkedHashMap = new LinkedHashMap();
        linkedHashMap.put("Accept", "application/json");
        return linkedHashMap;
    }

    public final Object mo117a(URI uri, InputStream inputStream) {
        Object obj = null;
        bs a = bs.m365a(inputStream);
        a.mo99a("BASE_URI", uri);
        try {
            a.mo105h();
            int i = 0;
            String str = null;
            while (a.mo107j()) {
                String l = a.mo109l();
                if ("status".equals(l)) {
                    i = a.mo115r();
                } else if (String.MESSAGE.equals(l)) {
                    str = a.mo110m();
                } else if (String.DATA.equals(l)) {
                    obj = mo247a(a);
                } else {
                    a.mo116s();
                }
            }
            a.mo106i();
            if (i == 200) {
                return obj;
            }
            throw new cg(i, str);
        } finally {
            a.close();
        }
    }
}
