package com.tapjoy.internal;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Logger;

public final class hz {
    static final Logger f1504a = Logger.getLogger(hz.class.getName());

    private hz() {
    }

    public static hx m1261a(ig igVar) {
        if (igVar != null) {
            return new ib(igVar);
        }
        throw new IllegalArgumentException("source == null");
    }

    public static hw m1260a(C0271if c0271if) {
        if (c0271if != null) {
            return new ia(c0271if);
        }
        throw new IllegalArgumentException("sink == null");
    }

    public static C0271if m1262a(final OutputStream outputStream) {
        final ih ihVar = new ih();
        if (outputStream != null) {
            return new C0271if() {
                public final void mo255a(hv hvVar, long j) {
                    ii.m1305a(hvVar.f1494b, 0, j);
                    while (j > 0) {
                        ihVar.mo282a();
                        ic icVar = hvVar.f1493a;
                        int min = (int) Math.min(j, (long) (icVar.f1516c - icVar.f1515b));
                        outputStream.write(icVar.f1514a, icVar.f1515b, min);
                        icVar.f1515b += min;
                        j -= (long) min;
                        hvVar.f1494b -= (long) min;
                        if (icVar.f1515b == icVar.f1516c) {
                            hvVar.f1493a = icVar.m1286a();
                            id.m1290a(icVar);
                        }
                    }
                }

                public final void flush() {
                    outputStream.flush();
                }

                public final void close() {
                    outputStream.close();
                }

                public final String toString() {
                    return "sink(" + outputStream + ")";
                }
            };
        }
        throw new IllegalArgumentException("out == null");
    }

    public static ig m1263a(final InputStream inputStream) {
        final ih ihVar = new ih();
        if (inputStream != null) {
            return new ig() {
                public final long mo256b(hv hvVar, long j) {
                    if (j < 0) {
                        throw new IllegalArgumentException("byteCount < 0: " + j);
                    } else if (j == 0) {
                        return 0;
                    } else {
                        try {
                            ihVar.mo282a();
                            ic c = hvVar.m1238c(1);
                            int read = inputStream.read(c.f1514a, c.f1516c, (int) Math.min(j, (long) (8192 - c.f1516c)));
                            if (read == -1) {
                                return -1;
                            }
                            c.f1516c += read;
                            hvVar.f1494b += (long) read;
                            return (long) read;
                        } catch (AssertionError e) {
                            if (hz.m1264a(e)) {
                                throw new IOException(e);
                            }
                            throw e;
                        }
                    }
                }

                public final void close() {
                    inputStream.close();
                }

                public final String toString() {
                    return "source(" + inputStream + ")";
                }
            };
        }
        throw new IllegalArgumentException("in == null");
    }

    static boolean m1264a(AssertionError assertionError) {
        return (assertionError.getCause() == null || assertionError.getMessage() == null || !assertionError.getMessage().contains("getsockname failed")) ? false : true;
    }
}
