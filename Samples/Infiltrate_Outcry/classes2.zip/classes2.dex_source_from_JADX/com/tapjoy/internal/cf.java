package com.tapjoy.internal;

import java.io.InputStream;
import java.net.URI;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public abstract class cf {
    public static ExecutorService f593a;
    public static ci f594b;
    private Future f595c;

    public abstract Object mo117a(URI uri, InputStream inputStream);

    public abstract String mo248b();

    public abstract String mo252c();

    public Map mo118a() {
        return Collections.emptyMap();
    }

    public String mo249d() {
        return null;
    }

    public Map mo250e() {
        return new LinkedHashMap();
    }

    public final synchronized void m442a(ck ckVar, ExecutorService executorService) {
        Object obj;
        if (this.f595c == null || this.f595c.isDone()) {
            obj = 1;
        } else {
            obj = null;
        }
        String str = "Call has not completed";
        if (obj == null) {
            throw new IllegalStateException(String.valueOf(str));
        }
        this.f595c = executorService.submit(new ch(this, ckVar));
    }

    public Object mo251f() {
        return f594b.mo119a(this);
    }
}
