package com.tapjoy.internal;

import com.tapjoy.internal.di.C0147a;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;

public abstract class df implements di {
    private final ReentrantLock f623a = new ReentrantLock();
    private final C0145a f624b = new C0145a();
    private final C0145a f625c = new C0145a();
    private C0147a f626d = C0147a.NEW;
    private boolean f627e = false;

    class C0145a extends de {
        final /* synthetic */ df f636a;

        private C0145a(df dfVar) {
            this.f636a = dfVar;
        }

        public final /* synthetic */ Object get(long x0, TimeUnit x1) {
            return m507a(x0, x1);
        }

        private C0147a m507a(long j, TimeUnit timeUnit) {
            try {
                return (C0147a) super.get(j, timeUnit);
            } catch (TimeoutException e) {
                throw new TimeoutException(this.f636a.toString());
            }
        }
    }

    protected abstract void mo122a();

    protected abstract void mo123b();

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final com.tapjoy.internal.dh mo120e() {
        /*
        r2 = this;
        r0 = r2.f623a;
        r0.lock();
        r0 = r2.f626d;	 Catch:{ Throwable -> 0x001a }
        r1 = com.tapjoy.internal.di.C0147a.NEW;	 Catch:{ Throwable -> 0x001a }
        if (r0 != r1) goto L_0x0012;
    L_0x000b:
        r0 = com.tapjoy.internal.di.C0147a.STARTING;	 Catch:{ Throwable -> 0x001a }
        r2.f626d = r0;	 Catch:{ Throwable -> 0x001a }
        r2.mo122a();	 Catch:{ Throwable -> 0x001a }
    L_0x0012:
        r0 = r2.f623a;
        r0.unlock();
    L_0x0017:
        r0 = r2.f624b;
        return r0;
    L_0x001a:
        r0 = move-exception;
        r2.m486a(r0);	 Catch:{ all -> 0x0024 }
        r0 = r2.f623a;
        r0.unlock();
        goto L_0x0017;
    L_0x0024:
        r0 = move-exception;
        r1 = r2.f623a;
        r1.unlock();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tapjoy.internal.df.e():com.tapjoy.internal.dh");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.tapjoy.internal.dh m484g() {
        /*
        r2 = this;
        r0 = r2.f623a;
        r0.lock();
        r0 = r2.f626d;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.NEW;	 Catch:{ Throwable -> 0x0036 }
        if (r0 != r1) goto L_0x0025;
    L_0x000b:
        r0 = com.tapjoy.internal.di.C0147a.TERMINATED;	 Catch:{ Throwable -> 0x0036 }
        r2.f626d = r0;	 Catch:{ Throwable -> 0x0036 }
        r0 = r2.f624b;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.TERMINATED;	 Catch:{ Throwable -> 0x0036 }
        r0.m505a(r1);	 Catch:{ Throwable -> 0x0036 }
        r0 = r2.f625c;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.TERMINATED;	 Catch:{ Throwable -> 0x0036 }
        r0.m505a(r1);	 Catch:{ Throwable -> 0x0036 }
    L_0x001d:
        r0 = r2.f623a;
        r0.unlock();
    L_0x0022:
        r0 = r2.f625c;
        return r0;
    L_0x0025:
        r0 = r2.f626d;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.STARTING;	 Catch:{ Throwable -> 0x0036 }
        if (r0 != r1) goto L_0x0040;
    L_0x002b:
        r0 = 1;
        r2.f627e = r0;	 Catch:{ Throwable -> 0x0036 }
        r0 = r2.f624b;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.STOPPING;	 Catch:{ Throwable -> 0x0036 }
        r0.m505a(r1);	 Catch:{ Throwable -> 0x0036 }
        goto L_0x001d;
    L_0x0036:
        r0 = move-exception;
        r2.m486a(r0);	 Catch:{ all -> 0x004e }
        r0 = r2.f623a;
        r0.unlock();
        goto L_0x0022;
    L_0x0040:
        r0 = r2.f626d;	 Catch:{ Throwable -> 0x0036 }
        r1 = com.tapjoy.internal.di.C0147a.RUNNING;	 Catch:{ Throwable -> 0x0036 }
        if (r0 != r1) goto L_0x001d;
    L_0x0046:
        r0 = com.tapjoy.internal.di.C0147a.STOPPING;	 Catch:{ Throwable -> 0x0036 }
        r2.f626d = r0;	 Catch:{ Throwable -> 0x0036 }
        r2.mo123b();	 Catch:{ Throwable -> 0x0036 }
        goto L_0x001d;
    L_0x004e:
        r0 = move-exception;
        r1 = r2.f623a;
        r1.unlock();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tapjoy.internal.df.g():com.tapjoy.internal.dh");
    }

    protected final void m488c() {
        this.f623a.lock();
        try {
            if (this.f626d != C0147a.STARTING) {
                Throwable illegalStateException = new IllegalStateException("Cannot notifyStarted() when the service is " + this.f626d);
                m486a(illegalStateException);
                throw illegalStateException;
            }
            this.f626d = C0147a.RUNNING;
            if (this.f627e) {
                m484g();
            } else {
                this.f624b.m505a((Object) C0147a.RUNNING);
            }
            this.f623a.unlock();
        } catch (Throwable th) {
            this.f623a.unlock();
        }
    }

    protected final void m489d() {
        this.f623a.lock();
        try {
            if (this.f626d == C0147a.STOPPING || this.f626d == C0147a.RUNNING) {
                this.f626d = C0147a.TERMINATED;
                this.f625c.m505a((Object) C0147a.TERMINATED);
                return;
            }
            Throwable illegalStateException = new IllegalStateException("Cannot notifyStopped() when the service is " + this.f626d);
            m486a(illegalStateException);
            throw illegalStateException;
        } finally {
            this.f623a.unlock();
        }
    }

    protected final void m486a(Throwable th) {
        cs.m459a((Object) th);
        this.f623a.lock();
        try {
            if (this.f626d == C0147a.STARTING) {
                this.f624b.m506a(th);
                this.f625c.m506a(new Exception("Service failed to start.", th));
            } else if (this.f626d == C0147a.STOPPING) {
                this.f625c.m506a(th);
            } else if (this.f626d == C0147a.RUNNING) {
                this.f625c.m506a(new Exception("Service failed while running", th));
            } else if (this.f626d == C0147a.NEW || this.f626d == C0147a.TERMINATED) {
                throw new IllegalStateException("Failed while in state:" + this.f626d, th);
            }
            this.f626d = C0147a.FAILED;
        } finally {
            this.f623a.unlock();
        }
    }

    public final C0147a mo121f() {
        this.f623a.lock();
        try {
            C0147a c0147a;
            if (this.f627e && this.f626d == C0147a.STARTING) {
                c0147a = C0147a.STOPPING;
                return c0147a;
            }
            c0147a = this.f626d;
            this.f623a.unlock();
            return c0147a;
        } finally {
            this.f623a.unlock();
        }
    }

    public String toString() {
        return getClass().getSimpleName() + " [" + mo121f() + "]";
    }
}
