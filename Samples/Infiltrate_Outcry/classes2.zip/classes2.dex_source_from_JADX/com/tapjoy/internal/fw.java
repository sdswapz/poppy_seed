package com.tapjoy.internal;

import android.content.Context;

public interface fw {
    void mo68a(Context context, String str, String str2);
}
