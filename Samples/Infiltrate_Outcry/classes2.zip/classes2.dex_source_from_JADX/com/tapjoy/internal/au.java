package com.tapjoy.internal;

public final class au {

    public static final class C0125a implements ax {
        private final av f524a;

        public C0125a(av avVar) {
            this.f524a = avVar;
        }

        public final Object mo91a(Object obj) {
            synchronized (this.f524a) {
                at a = this.f524a.mo93a(obj, false);
            }
            if (a == null) {
                return null;
            }
            Object a2;
            synchronized (a) {
                a2 = a.mo89a();
            }
            return a2;
        }

        public final void mo92a(Object obj, Object obj2) {
            synchronized (this.f524a) {
                at a = this.f524a.mo93a(obj, true);
            }
            synchronized (a) {
                a.mo90a(obj2);
            }
        }
    }
}
