package com.tapjoy.internal;

public final class C0257h {
    public String f1333a;
    public String f1334b;
    public String f1335c;
    public long f1336d;
    public int f1337e;
    public String f1338f;
    public String f1339g;

    public C0257h(String str) {
        bs b = bs.m367b(str);
        b.mo105h();
        while (b.mo107j()) {
            String l = b.mo109l();
            if ("orderId".equals(l)) {
                this.f1333a = b.mo110m();
            } else if ("packageName".equals(l)) {
                this.f1334b = b.mo110m();
            } else if ("productId".equals(l)) {
                this.f1335c = b.mo110m();
            } else if ("purchaseTime".equals(l)) {
                this.f1336d = b.mo114q();
            } else if ("purchaseState".equals(l)) {
                this.f1337e = b.mo115r();
            } else if ("developerPayload".equals(l)) {
                this.f1338f = b.mo110m();
            } else if ("purchaseToken".equals(l)) {
                this.f1339g = b.mo110m();
            } else {
                b.mo116s();
            }
        }
        b.mo106i();
    }
}
