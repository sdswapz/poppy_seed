package com.tapjoy.internal;

import com.tapjoy.internal.bs.C0132a;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public final class bt extends bs {
    public static final C0132a f549a = new C01331();
    private final co f550b = new co();
    private final Reader f551c;
    private boolean f552d = false;
    private final char[] f553e = new char[1024];
    private int f554f = 0;
    private int f555g = 0;
    private int f556h = 1;
    private int f557i = 1;
    private final List f558j = new ArrayList();
    private bx f559k;
    private String f560l;
    private String f561m;
    private int f562n;
    private int f563o;
    private boolean f564p;

    static class C01331 extends C0132a {
        C01331() {
        }

        public final bs mo100a(Reader reader) {
            return new bt(reader);
        }

        public final bs mo101a(String str) {
            return new bt(new StringReader(str));
        }
    }

    public bt(Reader reader) {
        m387a(bv.EMPTY_DOCUMENT);
        this.f564p = false;
        if (reader == null) {
            throw new NullPointerException("in == null");
        }
        this.f551c = reader;
    }

    public final void mo103f() {
        m388a(bx.BEGIN_ARRAY);
    }

    public final void mo104g() {
        m388a(bx.END_ARRAY);
    }

    public final void mo105h() {
        m388a(bx.BEGIN_OBJECT);
    }

    public final void mo106i() {
        m388a(bx.END_OBJECT);
    }

    private void m388a(bx bxVar) {
        mo108k();
        if (this.f559k != bxVar) {
            throw new IllegalStateException("Expected " + bxVar + " but was " + mo108k());
        }
        m394t();
    }

    public final boolean mo107j() {
        mo108k();
        return (this.f559k == bx.END_OBJECT || this.f559k == bx.END_ARRAY) ? false : true;
    }

    public final bx mo108k() {
        if (this.f559k != null) {
            return this.f559k;
        }
        bx v;
        switch ((bv) this.f558j.get(this.f558j.size() - 1)) {
            case EMPTY_DOCUMENT:
                m391b(bv.NONEMPTY_DOCUMENT);
                v = m396v();
                if (this.f552d || this.f559k == bx.BEGIN_ARRAY || this.f559k == bx.BEGIN_OBJECT) {
                    return v;
                }
                throw new IOException("Expected JSON document to start with '[' or '{' but was " + this.f559k);
            case EMPTY_ARRAY:
                return m385a(true);
            case NONEMPTY_ARRAY:
                return m385a(false);
            case EMPTY_OBJECT:
                return m390b(true);
            case DANGLING_NAME:
                switch (m399y()) {
                    case 58:
                        break;
                    case 61:
                        m400z();
                        if ((this.f554f < this.f555g || m389a(1)) && this.f553e[this.f554f] == '>') {
                            this.f554f++;
                            break;
                        }
                    default:
                        throw m393d("Expected ':'");
                }
                m391b(bv.NONEMPTY_OBJECT);
                return m396v();
            case NONEMPTY_OBJECT:
                return m390b(false);
            case NONEMPTY_DOCUMENT:
                try {
                    v = m396v();
                    if (this.f552d) {
                        return v;
                    }
                    throw m393d("Expected EOF");
                } catch (EOFException e) {
                    v = bx.END_DOCUMENT;
                    this.f559k = v;
                    return v;
                }
            case CLOSED:
                throw new IllegalStateException("JsonReader is closed");
            default:
                throw new AssertionError();
        }
    }

    private bx m394t() {
        mo108k();
        bx bxVar = this.f559k;
        this.f559k = null;
        this.f561m = null;
        this.f560l = null;
        return bxVar;
    }

    public final String mo109l() {
        mo108k();
        if (this.f559k != bx.NAME) {
            throw new IllegalStateException("Expected a name but was " + mo108k());
        }
        String str = this.f560l;
        m394t();
        return str;
    }

    public final String mo110m() {
        mo108k();
        if (this.f559k == bx.STRING || this.f559k == bx.NUMBER) {
            String str = this.f561m;
            m394t();
            return str;
        }
        throw new IllegalStateException("Expected a string but was " + mo108k());
    }

    public final boolean mo111n() {
        mo108k();
        if (this.f559k != bx.BOOLEAN) {
            throw new IllegalStateException("Expected a boolean but was " + this.f559k);
        }
        boolean z = this.f561m == "true";
        m394t();
        return z;
    }

    public final void mo112o() {
        mo108k();
        if (this.f559k != bx.NULL) {
            throw new IllegalStateException("Expected null but was " + this.f559k);
        }
        m394t();
    }

    public final double mo113p() {
        mo108k();
        if (this.f559k == bx.STRING || this.f559k == bx.NUMBER) {
            double parseDouble = Double.parseDouble(this.f561m);
            m394t();
            return parseDouble;
        }
        throw new IllegalStateException("Expected a double but was " + this.f559k);
    }

    public final long mo114q() {
        mo108k();
        if (this.f559k == bx.STRING || this.f559k == bx.NUMBER) {
            long parseLong;
            try {
                parseLong = Long.parseLong(this.f561m);
            } catch (NumberFormatException e) {
                double parseDouble = Double.parseDouble(this.f561m);
                parseLong = (long) parseDouble;
                if (((double) parseLong) != parseDouble) {
                    throw new NumberFormatException(this.f561m);
                }
            }
            m394t();
            return parseLong;
        }
        throw new IllegalStateException("Expected a long but was " + this.f559k);
    }

    public final int mo115r() {
        int parseInt;
        mo108k();
        if (this.f559k == bx.STRING || this.f559k == bx.NUMBER) {
            try {
                parseInt = Integer.parseInt(this.f561m);
            } catch (NumberFormatException e) {
                double parseDouble = Double.parseDouble(this.f561m);
                parseInt = (int) parseDouble;
                if (((double) parseInt) != parseDouble) {
                    throw new NumberFormatException(this.f561m);
                }
            }
            m394t();
            return parseInt;
        }
        throw new IllegalStateException("Expected an int but was " + this.f559k);
    }

    public final void close() {
        this.f561m = null;
        this.f559k = null;
        this.f558j.clear();
        this.f558j.add(bv.CLOSED);
        this.f551c.close();
    }

    public final void mo116s() {
        mo108k();
        if (this.f559k == bx.END_ARRAY || this.f559k == bx.END_OBJECT) {
            throw new IllegalStateException("Expected a value but was " + this.f559k);
        }
        this.f564p = true;
        int i = 0;
        while (true) {
            try {
                bx t = m394t();
                if (t == bx.BEGIN_ARRAY || t == bx.BEGIN_OBJECT) {
                    i++;
                    continue;
                } else if (t == bx.END_ARRAY || t == bx.END_OBJECT) {
                    i--;
                    continue;
                }
                if (i == 0) {
                    break;
                }
            } finally {
                this.f564p = false;
            }
        }
    }

    private bv m395u() {
        return (bv) this.f558j.remove(this.f558j.size() - 1);
    }

    private void m387a(bv bvVar) {
        this.f558j.add(bvVar);
    }

    private void m391b(bv bvVar) {
        this.f558j.set(this.f558j.size() - 1, bvVar);
    }

    private bx m385a(boolean z) {
        bx bxVar;
        if (z) {
            m391b(bv.NONEMPTY_ARRAY);
        } else {
            switch (m399y()) {
                case 44:
                    break;
                case 59:
                    m400z();
                    break;
                case 93:
                    m395u();
                    bxVar = bx.END_ARRAY;
                    this.f559k = bxVar;
                    return bxVar;
                default:
                    throw m393d("Unterminated array");
            }
        }
        switch (m399y()) {
            case 44:
            case 59:
                break;
            case 93:
                if (z) {
                    m395u();
                    bxVar = bx.END_ARRAY;
                    this.f559k = bxVar;
                    return bxVar;
                }
                break;
            default:
                this.f554f--;
                return m396v();
        }
        m400z();
        this.f554f--;
        this.f561m = "null";
        bxVar = bx.NULL;
        this.f559k = bxVar;
        return bxVar;
    }

    private bx m390b(boolean z) {
        bx bxVar;
        if (z) {
            switch (m399y()) {
                case 125:
                    m395u();
                    bxVar = bx.END_OBJECT;
                    this.f559k = bxVar;
                    return bxVar;
                default:
                    this.f554f--;
                    break;
            }
        }
        switch (m399y()) {
            case 44:
            case 59:
                break;
            case 125:
                m395u();
                bxVar = bx.END_OBJECT;
                this.f559k = bxVar;
                return bxVar;
            default:
                throw m393d("Unterminated object");
        }
        int y = m399y();
        switch (y) {
            case 34:
                break;
            case 39:
                m400z();
                break;
            default:
                m400z();
                this.f554f--;
                this.f560l = m392c(false);
                if (this.f560l.length() == 0) {
                    throw m393d("Expected name");
                }
                break;
        }
        this.f560l = m386a((char) y);
        m391b(bv.DANGLING_NAME);
        bxVar = bx.NAME;
        this.f559k = bxVar;
        return bxVar;
    }

    private bx m396v() {
        bx bxVar;
        int y = m399y();
        switch (y) {
            case 34:
                break;
            case 39:
                m400z();
                break;
            case 91:
                m387a(bv.EMPTY_ARRAY);
                bxVar = bx.BEGIN_ARRAY;
                this.f559k = bxVar;
                return bxVar;
            case 123:
                m387a(bv.EMPTY_OBJECT);
                bxVar = bx.BEGIN_OBJECT;
                this.f559k = bxVar;
                return bxVar;
            default:
                this.f554f--;
                this.f561m = m392c(true);
                if (this.f563o == 0) {
                    throw m393d("Expected literal value");
                }
                if (this.f562n != -1) {
                    if (this.f563o == 4 && (('n' == this.f553e[this.f562n] || 'N' == this.f553e[this.f562n]) && (('u' == this.f553e[this.f562n + 1] || 'U' == this.f553e[this.f562n + 1]) && (('l' == this.f553e[this.f562n + 2] || 'L' == this.f553e[this.f562n + 2]) && ('l' == this.f553e[this.f562n + 3] || 'L' == this.f553e[this.f562n + 3]))))) {
                        this.f561m = "null";
                        bxVar = bx.NULL;
                        this.f559k = bxVar;
                        if (this.f559k == bx.STRING) {
                            m400z();
                        }
                        return this.f559k;
                    } else if (this.f563o == 4 && (('t' == this.f553e[this.f562n] || 'T' == this.f553e[this.f562n]) && (('r' == this.f553e[this.f562n + 1] || 'R' == this.f553e[this.f562n + 1]) && (('u' == this.f553e[this.f562n + 2] || 'U' == this.f553e[this.f562n + 2]) && ('e' == this.f553e[this.f562n + 3] || 'E' == this.f553e[this.f562n + 3]))))) {
                        this.f561m = "true";
                        bxVar = bx.BOOLEAN;
                        this.f559k = bxVar;
                        if (this.f559k == bx.STRING) {
                            m400z();
                        }
                        return this.f559k;
                    } else if (this.f563o == 5 && (('f' == this.f553e[this.f562n] || 'F' == this.f553e[this.f562n]) && (('a' == this.f553e[this.f562n + 1] || 'A' == this.f553e[this.f562n + 1]) && (('l' == this.f553e[this.f562n + 2] || 'L' == this.f553e[this.f562n + 2]) && (('s' == this.f553e[this.f562n + 3] || 'S' == this.f553e[this.f562n + 3]) && ('e' == this.f553e[this.f562n + 4] || 'E' == this.f553e[this.f562n + 4])))))) {
                        this.f561m = "false";
                        bxVar = bx.BOOLEAN;
                        this.f559k = bxVar;
                        if (this.f559k == bx.STRING) {
                            m400z();
                        }
                        return this.f559k;
                    } else {
                        int i;
                        this.f561m = this.f550b.m456a(this.f553e, this.f562n, this.f563o);
                        char[] cArr = this.f553e;
                        int i2 = this.f562n;
                        int i3 = this.f563o;
                        char c = cArr[i2];
                        if (c == '-') {
                            i = i2 + 1;
                            c = cArr[i];
                        } else {
                            i = i2;
                        }
                        if (c == '0') {
                            i++;
                            c = cArr[i];
                        } else if (c < '1' || c > '9') {
                            bxVar = bx.STRING;
                            this.f559k = bxVar;
                            if (this.f559k == bx.STRING) {
                                m400z();
                            }
                            return this.f559k;
                        } else {
                            i++;
                            c = cArr[i];
                            while (c >= '0' && c <= '9') {
                                i++;
                                c = cArr[i];
                            }
                        }
                        if (c == '.') {
                            i++;
                            c = cArr[i];
                            while (c >= '0' && c <= '9') {
                                i++;
                                c = cArr[i];
                            }
                        }
                        char c2 = c;
                        y = i;
                        char c3 = c2;
                        if (c3 == 'e' || c3 == 'E') {
                            i = y + 1;
                            c = cArr[i];
                            if (c == '+' || c == '-') {
                                i++;
                                c = cArr[i];
                            }
                            if (c < '0' || c > '9') {
                                bxVar = bx.STRING;
                                this.f559k = bxVar;
                                if (this.f559k == bx.STRING) {
                                    m400z();
                                }
                                return this.f559k;
                            }
                            i++;
                            y = i;
                            c3 = cArr[i];
                            while (c3 >= '0' && c3 <= '9') {
                                i = y + 1;
                                y = i;
                                c3 = cArr[i];
                            }
                        }
                        if (y == i2 + i3) {
                            bxVar = bx.NUMBER;
                            this.f559k = bxVar;
                            if (this.f559k == bx.STRING) {
                                m400z();
                            }
                            return this.f559k;
                        }
                    }
                }
                bxVar = bx.STRING;
                this.f559k = bxVar;
                if (this.f559k == bx.STRING) {
                    m400z();
                }
                return this.f559k;
        }
        this.f561m = m386a((char) y);
        bxVar = bx.STRING;
        this.f559k = bxVar;
        return bxVar;
    }

    private boolean m389a(int i) {
        int i2;
        for (i2 = 0; i2 < this.f554f; i2++) {
            if (this.f553e[i2] == '\n') {
                this.f556h++;
                this.f557i = 1;
            } else {
                this.f557i++;
            }
        }
        if (this.f555g != this.f554f) {
            this.f555g -= this.f554f;
            System.arraycopy(this.f553e, this.f554f, this.f553e, 0, this.f555g);
        } else {
            this.f555g = 0;
        }
        this.f554f = 0;
        do {
            i2 = this.f551c.read(this.f553e, this.f555g, this.f553e.length - this.f555g);
            if (i2 == -1) {
                return false;
            }
            this.f555g = i2 + this.f555g;
            if (this.f556h == 1 && this.f557i == 1 && this.f555g > 0 && this.f553e[0] == '﻿') {
                this.f554f++;
                this.f557i--;
            }
        } while (this.f555g < i);
        return true;
    }

    private int m397w() {
        int i = this.f556h;
        for (int i2 = 0; i2 < this.f554f; i2++) {
            if (this.f553e[i2] == '\n') {
                i++;
            }
        }
        return i;
    }

    private int m398x() {
        int i = this.f557i;
        for (int i2 = 0; i2 < this.f554f; i2++) {
            if (this.f553e[i2] == '\n') {
                i = 1;
            } else {
                i++;
            }
        }
        return i;
    }

    private int m399y() {
        while (true) {
            if (this.f554f < this.f555g || m389a(1)) {
                char[] cArr = this.f553e;
                int i = this.f554f;
                this.f554f = i + 1;
                char c = cArr[i];
                switch (c) {
                    case '\t':
                    case '\n':
                    case '\r':
                    case ' ':
                        break;
                    case '#':
                        m400z();
                        m384A();
                        continue;
                    case '/':
                        if (this.f554f == this.f555g && !m389a(1)) {
                            break;
                        }
                        m400z();
                        switch (this.f553e[this.f554f]) {
                            case '*':
                                this.f554f++;
                                String str = "*/";
                                while (true) {
                                    int i2;
                                    if (this.f554f + str.length() <= this.f555g || m389a(str.length())) {
                                        i2 = 0;
                                        while (i2 < str.length()) {
                                            if (this.f553e[this.f554f + i2] == str.charAt(i2)) {
                                                i2++;
                                            } else {
                                                this.f554f++;
                                            }
                                        }
                                        i2 = 1;
                                    } else {
                                        i2 = 0;
                                    }
                                    if (i2 == 0) {
                                        throw m393d("Unterminated comment");
                                    }
                                    this.f554f += 2;
                                    continue;
                                    continue;
                                }
                            case '/':
                                this.f554f++;
                                m384A();
                                continue;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
                return c;
            }
            throw new EOFException("End of input");
        }
    }

    private void m400z() {
        if (!this.f552d) {
            throw m393d("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    private void m384A() {
        char c;
        do {
            if (this.f554f < this.f555g || m389a(1)) {
                char[] cArr = this.f553e;
                int i = this.f554f;
                this.f554f = i + 1;
                c = cArr[i];
                if (c == '\r') {
                    return;
                }
            } else {
                return;
            }
        } while (c != '\n');
    }

    private String m386a(char c) {
        StringBuilder stringBuilder = null;
        do {
            int i = this.f554f;
            while (this.f554f < this.f555g) {
                char[] cArr = this.f553e;
                int i2 = this.f554f;
                this.f554f = i2 + 1;
                char c2 = cArr[i2];
                if (c2 != c) {
                    StringBuilder stringBuilder2;
                    int i3;
                    int i4;
                    if (c2 == '\\') {
                        if (stringBuilder == null) {
                            stringBuilder = new StringBuilder();
                        }
                        stringBuilder.append(this.f553e, i, (this.f554f - i) - 1);
                        if (this.f554f != this.f555g || m389a(1)) {
                            char[] cArr2 = this.f553e;
                            int i5 = this.f554f;
                            this.f554f = i5 + 1;
                            char c3 = cArr2[i5];
                            switch (c3) {
                                case 'b':
                                    c3 = '\b';
                                    break;
                                case 'f':
                                    c3 = '\f';
                                    break;
                                case 'n':
                                    c3 = '\n';
                                    break;
                                case 'r':
                                    c3 = '\r';
                                    break;
                                case 't':
                                    c3 = '\t';
                                    break;
                                case 'u':
                                    if (this.f554f + 4 <= this.f555g || m389a(4)) {
                                        String a = this.f550b.m456a(this.f553e, this.f554f, 4);
                                        this.f554f += 4;
                                        c3 = (char) Integer.parseInt(a, 16);
                                        break;
                                    }
                                    throw m393d("Unterminated escape sequence");
                            }
                            stringBuilder.append(c3);
                            stringBuilder2 = stringBuilder;
                            i3 = this.f554f;
                        } else {
                            throw m393d("Unterminated escape sequence");
                        }
                    }
                    i4 = i;
                    stringBuilder2 = stringBuilder;
                    i3 = i4;
                    i4 = i3;
                    stringBuilder = stringBuilder2;
                    i = i4;
                } else if (this.f564p) {
                    return "skipped!";
                } else {
                    if (stringBuilder == null) {
                        return this.f550b.m456a(this.f553e, i, (this.f554f - i) - 1);
                    }
                    stringBuilder.append(this.f553e, i, (this.f554f - i) - 1);
                    return stringBuilder.toString();
                }
            }
            if (stringBuilder == null) {
                stringBuilder = new StringBuilder();
            }
            stringBuilder.append(this.f553e, i, this.f554f - i);
        } while (m389a(1));
        throw m393d("Unterminated string");
    }

    private String m392c(boolean z) {
        String str = null;
        this.f562n = -1;
        this.f563o = 0;
        int i = 0;
        StringBuilder stringBuilder = null;
        while (true) {
            if (this.f554f + i < this.f555g) {
                switch (this.f553e[this.f554f + i]) {
                    case '\t':
                    case '\n':
                    case '\f':
                    case '\r':
                    case ' ':
                    case ',':
                    case ':':
                    case '[':
                    case ']':
                    case '{':
                    case '}':
                        break;
                    case '#':
                    case '/':
                    case ';':
                    case '=':
                    case '\\':
                        m400z();
                        break;
                    default:
                        i++;
                        continue;
                }
            } else if (i >= this.f553e.length) {
                if (stringBuilder == null) {
                    stringBuilder = new StringBuilder();
                }
                stringBuilder.append(this.f553e, this.f554f, i);
                this.f563o += i;
                this.f554f = i + this.f554f;
                if (m389a(1)) {
                    i = 0;
                } else {
                    i = 0;
                }
            } else if (!m389a(i + 1)) {
                this.f553e[this.f555g] = '\u0000';
            }
            if (z && stringBuilder == null) {
                this.f562n = this.f554f;
            } else if (this.f564p) {
                str = "skipped!";
            } else if (stringBuilder == null) {
                str = this.f550b.m456a(this.f553e, this.f554f, i);
            } else {
                stringBuilder.append(this.f553e, this.f554f, i);
                str = stringBuilder.toString();
            }
            this.f563o += i;
            this.f554f += i;
            return str;
        }
    }

    public final String toString() {
        StringBuilder append = new StringBuilder().append(getClass().getSimpleName()).append(" near ");
        StringBuilder stringBuilder = new StringBuilder();
        int min = Math.min(this.f554f, 20);
        stringBuilder.append(this.f553e, this.f554f - min, min);
        stringBuilder.append(this.f553e, this.f554f, Math.min(this.f555g - this.f554f, 20));
        return append.append(stringBuilder).toString();
    }

    private IOException m393d(String str) {
        throw new bz(str + " at line " + m397w() + " column " + m398x());
    }
}
