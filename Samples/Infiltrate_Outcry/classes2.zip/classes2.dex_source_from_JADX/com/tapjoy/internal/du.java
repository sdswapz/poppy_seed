package com.tapjoy.internal;

import android.app.Activity;
import android.content.Context;
import android.opengl.GLSurfaceView;
import com.tapjoy.TJAwardCurrencyListener;
import com.tapjoy.TJConnectListener;
import com.tapjoy.TJEarnedCurrencyListener;
import com.tapjoy.TJGetCurrencyBalanceListener;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TJSetUserIDListener;
import com.tapjoy.TJSpendCurrencyListener;
import com.tapjoy.TJVideoListener;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public abstract class du {
    private static final du f694b;
    private static du f695c;
    protected volatile boolean f696a = false;

    public abstract TJPlacement mo130a(String str, TJPlacementListener tJPlacementListener);

    public abstract void mo131a(float f);

    public abstract void mo132a(int i);

    public abstract void mo133a(int i, TJAwardCurrencyListener tJAwardCurrencyListener);

    public abstract void mo134a(int i, TJSpendCurrencyListener tJSpendCurrencyListener);

    public abstract void mo135a(int i, String str);

    public abstract void mo136a(Activity activity);

    public abstract void mo137a(GLSurfaceView gLSurfaceView);

    public abstract void mo138a(TJEarnedCurrencyListener tJEarnedCurrencyListener);

    public abstract void mo139a(TJGetCurrencyBalanceListener tJGetCurrencyBalanceListener);

    public abstract void mo140a(TJVideoListener tJVideoListener);

    public abstract void mo141a(String str);

    public abstract void mo142a(String str, long j);

    public abstract void mo143a(String str, TJSetUserIDListener tJSetUserIDListener);

    public abstract void mo144a(String str, String str2);

    public abstract void mo145a(String str, String str2, double d, String str3);

    public abstract void mo146a(String str, String str2, long j);

    public abstract void mo147a(String str, String str2, String str3, String str4);

    public abstract void mo148a(String str, String str2, String str3, String str4, long j);

    public abstract void mo149a(String str, String str2, String str3, String str4, String str5, long j);

    public abstract void mo150a(String str, String str2, String str3, String str4, String str5, long j, String str6, long j2);

    public abstract void mo151a(String str, String str2, String str3, String str4, String str5, long j, String str6, long j2, String str7, long j3);

    public abstract void mo152a(String str, String str2, String str3, String str4, Map map);

    public abstract void mo153a(Set set);

    public abstract void mo154a(boolean z);

    public abstract boolean mo155a(Context context, String str);

    public abstract boolean mo156a(Context context, String str, Hashtable hashtable, TJConnectListener tJConnectListener);

    public abstract String mo157b();

    public abstract void mo158b(int i);

    public abstract void mo159b(Activity activity);

    public abstract void mo160b(String str);

    public abstract void mo161b(String str, String str2, String str3, String str4);

    public abstract void mo162b(boolean z);

    public abstract float mo163c();

    public abstract void mo164c(Activity activity);

    public abstract void mo165c(String str);

    public abstract void mo166d();

    public abstract void mo167d(String str);

    public abstract void mo168e();

    public abstract void mo169e(String str);

    public abstract Set mo170f();

    public abstract void mo171f(String str);

    public abstract String mo172g(String str);

    public abstract void mo173g();

    public abstract boolean mo174h();

    public abstract boolean mo175i();

    du() {
    }

    static {
        fa.m823a();
        es.m804a();
        du dwVar = new dw();
        f694b = dwVar;
        f695c = dwVar;
    }

    public static du m603a() {
        return f695c;
    }
}
