package com.tapjoy.internal;

import java.io.InputStream;

public interface bj {
    Object mo236b(InputStream inputStream);
}
