package com.tapjoy.internal;

import android.os.Looper;

public final class ga {
    public static boolean f1141a;

    public static void m936a(String str) {
        if (f1141a) {
            ac.m266a(4, "Tapjoy", str, null);
        }
    }

    public static void m938a(String str, Object... objArr) {
        if (f1141a) {
            ac.m267a(4, "Tapjoy", str, objArr);
        }
    }

    public static void m941b(String str) {
        if (f1141a) {
            ac.m266a(6, "Tapjoy", str, null);
        }
    }

    public static void m942b(String str, Object... objArr) {
        if (f1141a) {
            ac.m268a("Tapjoy", str, objArr);
        }
    }

    public static void m937a(String str, String str2, String str3) {
        if (f1141a) {
            ac.m268a("Tapjoy", "{}: {} {}", str, str2, str3);
        }
    }

    public static boolean m939a(Object obj, String str) {
        if (obj != null) {
            return true;
        }
        if (f1141a) {
            m941b(str);
        }
        return false;
    }

    public static boolean m940a(boolean z, String str) {
        if (!f1141a || z) {
            return z;
        }
        m941b(str);
        throw new IllegalStateException(str);
    }

    public static boolean m943c(String str) {
        return m940a(Looper.myLooper() == Looper.getMainLooper(), str + ": Must be called on the main/ui thread");
    }
}
