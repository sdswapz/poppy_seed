package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;

final class hc extends gs implements fu {
    public static final bn f1349a = new C02601();
    private final String f1350b;
    private final String f1351c;
    private final int f1352d;
    private final String f1353e;

    static class C02601 implements bn {
        C02601() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            String str = null;
            int i = 1;
            bsVar.mo105h();
            String str2 = null;
            String str3 = null;
            while (bsVar.mo107j()) {
                String l = bsVar.mo109l();
                if ("id".equals(l)) {
                    str3 = bsVar.mo110m();
                } else if (String.USAGE_TRACKER_NAME.equals(l)) {
                    str2 = bsVar.mo110m();
                } else if ("quantity".equals(l)) {
                    i = bsVar.mo115r();
                } else if ("token".equals(l)) {
                    str = bsVar.mo110m();
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return new hc(str3, str2, i, str);
        }
    }

    hc(String str, String str2, int i, String str3) {
        this.f1350b = str;
        this.f1351c = str2;
        this.f1352d = i;
        this.f1353e = str3;
    }

    public final String mo240a() {
        return this.f1350b;
    }

    public final String mo241b() {
        return this.f1351c;
    }

    public final int mo242c() {
        return this.f1352d;
    }

    public final String mo243d() {
        return this.f1353e;
    }
}
