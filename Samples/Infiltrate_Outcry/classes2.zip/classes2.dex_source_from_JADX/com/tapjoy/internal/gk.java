package com.tapjoy.internal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public abstract class gk {
    long f1116h;
    boolean f1117i;
    public fw f1118j;
    public String f1119k;
    et f1120l;

    public abstract void mo204a();

    public abstract void mo205a(ge geVar, ez ezVar);

    public boolean mo206b() {
        return true;
    }

    static void m927a(Context context, String str) {
        if (!ct.m463c(str)) {
            try {
                context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            } catch (Exception e) {
            }
        }
    }
}
