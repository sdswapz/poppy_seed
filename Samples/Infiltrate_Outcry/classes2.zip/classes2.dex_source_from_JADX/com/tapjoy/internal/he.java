package com.tapjoy.internal;

import android.graphics.PointF;
import com.tapjoy.TJAdUnitConstants.String;
import java.util.ArrayList;

public final class he {
    public static final bn f1368d = new C02621();
    public af f1369a = af.UNSPECIFIED;
    public PointF f1370b;
    public ArrayList f1371c = new ArrayList();

    static class C02621 implements bn {
        C02621() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            return new he(bsVar);
        }
    }

    public he(bs bsVar) {
        bsVar.mo105h();
        while (bsVar.mo107j()) {
            String l = bsVar.mo109l();
            if (String.BUTTONS.equals(l)) {
                Object obj;
                if (bsVar.mo108k() == bx.BEGIN_ARRAY) {
                    obj = 1;
                } else {
                    obj = null;
                }
                if (obj != null) {
                    bsVar.m374a(this.f1371c, hd.f1354n);
                } else {
                    bsVar.mo116s();
                }
            } else if ("window_aspect_ratio".equals(l)) {
                if (bsVar.m376a()) {
                    PointF pointF = new PointF();
                    bsVar.mo105h();
                    while (bsVar.mo107j()) {
                        String l2 = bsVar.mo109l();
                        if ("width".equals(l2)) {
                            pointF.x = (float) bsVar.mo113p();
                        } else if ("height".equals(l2)) {
                            pointF.y = (float) bsVar.mo113p();
                        } else {
                            bsVar.mo116s();
                        }
                    }
                    bsVar.mo106i();
                    if (!(pointF.x == 0.0f || pointF.y == 0.0f)) {
                        this.f1370b = pointF;
                    }
                } else {
                    bsVar.mo116s();
                }
            } else if (String.ORIENTATION.equals(l)) {
                l = bsVar.mo110m();
                if (String.LANDSCAPE.equals(l)) {
                    this.f1369a = af.LANDSCAPE;
                } else if ("portrait".equals(l)) {
                    this.f1369a = af.PORTRAIT;
                }
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
    }
}
