package com.tapjoy.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.BadTokenException;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.tapjoy.TJContentActivity;
import com.tapjoy.TJContentActivity.AbstractContentProducer;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.internal.ai.C01231;
import com.tapjoy.internal.ai.C0124a;
import com.tapjoy.internal.hu.C0242a;

public final class gi extends gk {
    public static gi f1222a;
    final gd f1223b;
    final String f1224c;
    final gy f1225d;
    C0169e f1226e;
    long f1227f;
    boolean f1228g = false;
    private boolean f1229m;
    private Context f1230n;

    public gi(gd gdVar, String str, gy gyVar, Context context) {
        this.f1223b = gdVar;
        this.f1224c = str;
        this.f1225d = gyVar;
        this.f1230n = context;
    }

    public final void mo204a() {
        gy gyVar = this.f1225d;
        if (gyVar.f1316a != null) {
            gyVar.f1316a.m1139b();
        }
        if (gyVar.f1317b != null) {
            gyVar.f1317b.m1139b();
        }
        gyVar.f1318c.m1139b();
        if (gyVar.f1320e != null) {
            gyVar.f1320e.m1139b();
        }
        if (gyVar.f1321f != null) {
            gyVar.f1321f.m1139b();
        }
        if (gyVar.f1328m != null && gyVar.f1328m.f1330a != null) {
            gyVar.f1328m.f1330a.m1139b();
        }
    }

    public final boolean mo206b() {
        gy gyVar = this.f1225d;
        return (gyVar.f1318c == null || gyVar.f1318c.f1346b == null || ((gyVar.f1328m != null && gyVar.f1328m.f1330a != null && gyVar.f1328m.f1330a.f1346b == null) || ((gyVar.f1317b == null || gyVar.f1321f == null || gyVar.f1317b.f1346b == null || gyVar.f1321f.f1346b == null) && (gyVar.f1316a == null || gyVar.f1320e == null || gyVar.f1316a.f1346b == null || gyVar.f1320e.f1346b == null)))) ? false : true;
    }

    public final void mo205a(final ge geVar, final ez ezVar) {
        Activity a = C0136c.m436a(this.f1230n);
        if (!(a == null || a.isFinishing())) {
            try {
                m1078a(a, geVar, ezVar);
                new Object[1][0] = this.f1224c;
                return;
            } catch (BadTokenException e) {
            }
        }
        Activity a2 = fv.m915a();
        boolean z = a2 != null ? (a2.getWindow().getAttributes().flags & 1024) != 0 : false;
        try {
            TJContentActivity.start(gd.m956a().f1164e, new AbstractContentProducer(this) {
                final /* synthetic */ gi f1213c;

                public final void show(Activity activity) {
                    try {
                        this.f1213c.m1078a(activity, geVar, ezVar);
                    } catch (BadTokenException e) {
                        ga.m942b("Failed to show the content for \"{}\" caused by invalid activity", this.f1213c.f1224c);
                        geVar.mo38a(this.f1213c.f1224c, this.f1213c.k, null);
                    }
                }

                public final void dismiss(Activity activity) {
                    this.f1213c.m1081c();
                }
            }, z);
            new Object[1][0] = this.f1224c;
        } catch (ActivityNotFoundException e2) {
            if (!(a2 == null || a2.isFinishing())) {
                try {
                    m1078a(a2, geVar, ezVar);
                    new Object[1][0] = this.f1224c;
                    return;
                } catch (BadTokenException e3) {
                    ga.m942b("Failed to show the content for \"{}\" caused by no registration of TJContentActivity", this.f1224c);
                    geVar.mo38a(this.f1224c, this.k, null);
                }
            }
            ga.m942b("Failed to show the content for \"{}\" caused by no registration of TJContentActivity", this.f1224c);
            geVar.mo38a(this.f1224c, this.k, null);
        }
    }

    final void m1078a(final Activity activity, final ge geVar, ez ezVar) {
        cs.m460a(!this.f1229m);
        this.f1229m = true;
        f1222a = this;
        this.l = ezVar.f1020a;
        this.f1226e = new C0169e(activity);
        this.f1226e.setOnCancelListener(new OnCancelListener(this) {
            final /* synthetic */ gi f1215b;

            public final void onCancel(DialogInterface dialog) {
                geVar.mo41d(this.f1215b.f1224c);
            }
        });
        this.f1226e.setOnDismissListener(new OnDismissListener(this) {
            final /* synthetic */ gi f1218c;

            public final void onDismiss(DialogInterface dialog) {
                gi.f1222a = null;
                gk.m927a(activity, this.f1218c.f1225d.f1322g);
                this.f1218c.f1223b.m967a(this.f1218c.f1225d.f1326k, SystemClock.elapsedRealtime() - this.f1218c.f1227f);
                if (!this.f1218c.i) {
                    geVar.mo38a(this.f1218c.f1224c, this.f1218c.k, this.f1218c.f1225d.f1323h);
                }
                if (this.f1218c.f1228g && this.f1218c.f1225d.f1326k != null && this.f1218c.f1225d.f1326k.containsKey("action_id")) {
                    String obj = this.f1218c.f1225d.f1326k.get("action_id").toString();
                    if (obj != null && obj.length() > 0) {
                        gd gdVar = this.f1218c.f1223b;
                        if (gdVar.f1161b != null) {
                            Object obj2;
                            gm gmVar = gdVar.f1161b;
                            String a = gm.m1088a();
                            String a2 = gmVar.f1236b.m1338a();
                            String a3 = gmVar.f1235a.m1338a();
                            if (a3 == null || !a.equals(a3)) {
                                gmVar.f1235a.m1339a(a);
                                a2 = "";
                            }
                            if (a2.length() == 0) {
                                obj2 = 1;
                            } else {
                                obj2 = null;
                            }
                            if (obj2 != null) {
                                a2 = obj;
                            } else if (!a2.contains(obj)) {
                                a2 = a2.concat("," + obj);
                            }
                            gmVar.f1236b.m1339a(a2);
                        }
                    }
                }
                if (activity instanceof TJContentActivity) {
                    activity.finish();
                }
            }
        });
        this.f1226e.setCanceledOnTouchOutside(false);
        View htVar = new ht(activity, this.f1225d, new hu(activity, this.f1225d, new C0242a(this) {
            final /* synthetic */ gi f1221c;

            public final void mo232a() {
                this.f1221c.f1226e.cancel();
            }

            public final void mo233a(gw gwVar) {
                if (this.f1221c.l instanceof ex) {
                    ex exVar = (ex) this.f1221c.l;
                    if (!(exVar == null || exVar.f1018c == null)) {
                        exVar.f1018c.m781a();
                    }
                }
                this.f1221c.f1223b.m968a(this.f1221c.f1225d.f1326k, gwVar.f1297b);
                gk.m927a(activity, gwVar.f1299d);
                if (!ct.m463c(gwVar.f1300e)) {
                    this.f1221c.j.mo68a(activity, gwVar.f1300e, ct.m462b(gwVar.f1301f));
                    this.f1221c.i = true;
                }
                geVar.mo37a(this.f1221c.f1224c, gwVar.f1302g);
                if (gwVar.f1298c) {
                    this.f1221c.f1226e.dismiss();
                }
            }

            public final void mo234b() {
                boolean z;
                gi giVar = this.f1221c;
                if (this.f1221c.f1228g) {
                    z = false;
                } else {
                    z = true;
                }
                giVar.f1228g = z;
            }
        }));
        View frameLayout = new FrameLayout(activity);
        frameLayout.addView(htVar, new LayoutParams(-2, -2, 17));
        this.f1226e.setContentView(frameLayout);
        if (Boolean.FALSE.booleanValue()) {
            boolean z;
            int i;
            aj ajVar;
            al alVar;
            Window window = this.f1226e.getWindow();
            if (VERSION.SDK_INT == 16 && "4.1.2".equals(VERSION.RELEASE)) {
                if (Boolean.FALSE.equals(m1076a(window.getContext()))) {
                    z = false;
                    if (z) {
                        i = C0124a.f482b;
                        ajVar = new aj();
                        switch (C01231.f480a[i - 1]) {
                            case 1:
                                alVar = new al();
                                alVar.f498a = false;
                                alVar.f499b = 60.0f;
                                ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER).m291b(0.3f).m289a());
                                break;
                            case 2:
                                alVar = new al();
                                alVar.f498a = false;
                                alVar.f499b = -60.0f;
                                ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(-0.4f).m291b(0.3f).m289a());
                                break;
                            case 3:
                                alVar = new al();
                                alVar.f498a = true;
                                alVar.f499b = -60.0f;
                                ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(0.3f).m291b(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER).m289a());
                                break;
                            case 4:
                                alVar = new al();
                                alVar.f498a = true;
                                alVar.f499b = 60.0f;
                                ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(0.3f).m291b(-0.4f).m289a());
                                break;
                        }
                        htVar.startAnimation(ajVar.m285b().mo87a());
                    }
                } else {
                    window.setFlags(16777216, 16777216);
                }
            }
            z = true;
            if (z) {
                i = C0124a.f482b;
                ajVar = new aj();
                switch (C01231.f480a[i - 1]) {
                    case 1:
                        alVar = new al();
                        alVar.f498a = false;
                        alVar.f499b = 60.0f;
                        ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER).m291b(0.3f).m289a());
                        break;
                    case 2:
                        alVar = new al();
                        alVar.f498a = false;
                        alVar.f499b = -60.0f;
                        ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(-0.4f).m291b(0.3f).m289a());
                        break;
                    case 3:
                        alVar = new al();
                        alVar.f498a = true;
                        alVar.f499b = -60.0f;
                        ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(0.3f).m291b(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER).m289a());
                        break;
                    case 4:
                        alVar = new al();
                        alVar.f498a = true;
                        alVar.f499b = 60.0f;
                        ajVar.m287a(alVar.m288a()).m287a(new ScaleAnimation(0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER, 0.4f, TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER)).m287a(new am().m290a(0.3f).m291b(-0.4f).m289a());
                        break;
                }
                htVar.startAnimation(ajVar.m285b().mo87a());
            }
        }
        try {
            this.f1226e.show();
            this.f1226e.getWindow().setLayout(-1, -1);
            if ((activity.getWindow().getAttributes().flags & 1024) != 0) {
                this.f1226e.getWindow().setFlags(1024, 1024);
            }
            this.f1227f = SystemClock.elapsedRealtime();
            this.f1223b.m966a(this.f1225d.f1326k);
            ezVar.m809a();
            et etVar = this.l;
            if (etVar != null) {
                etVar.m784b();
            }
            geVar.mo40c(this.f1224c);
        } catch (BadTokenException e) {
            throw e;
        }
    }

    public final void m1081c() {
        if (this.f1226e != null) {
            this.f1226e.dismiss();
        }
    }

    private static Boolean m1076a(Context context) {
        try {
            Bundle bundle = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
            if (bundle != null) {
                Object obj = bundle.get("tapjoy:hardwareAccelerated");
                if (obj instanceof Boolean) {
                    return (Boolean) obj;
                }
            }
        } catch (NameNotFoundException e) {
        }
        return null;
    }
}
