package com.tapjoy.internal;

import java.io.IOException;

public final class ca extends IOException {
    public ca(Throwable th) {
        super(th.getMessage());
    }
}
