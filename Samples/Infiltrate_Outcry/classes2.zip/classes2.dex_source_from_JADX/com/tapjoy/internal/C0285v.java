package com.tapjoy.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import java.io.OutputStream;

public final class C0285v implements bi {
    public static final C0285v f1546a = new C0285v();

    public final /* synthetic */ void mo235a(OutputStream outputStream, Object obj) {
        if (!((Bitmap) obj).compress(CompressFormat.PNG, 100, outputStream)) {
            throw new RuntimeException();
        }
    }

    public final /* synthetic */ Object mo236b(InputStream inputStream) {
        return m1342a(inputStream);
    }

    private C0285v() {
    }

    public final Bitmap m1342a(final InputStream inputStream) {
        try {
            return (Bitmap) ad.m269a(new bg(this) {
                final /* synthetic */ C0285v f1545b;

                public final /* synthetic */ Object call() {
                    if (inputStream instanceof bh) {
                        return BitmapFactory.decodeStream(inputStream);
                    }
                    return BitmapFactory.decodeStream(new bh(inputStream));
                }
            });
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
}
