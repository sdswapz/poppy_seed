package com.tapjoy.internal;

import java.util.ArrayList;
import java.util.List;

public final class hi {
    int[] f1410a = null;
    public int f1411b = 0;
    int f1412c = 0;
    hh f1413d;
    List f1414e = new ArrayList();
    int f1415f;
    int f1416g;
    boolean f1417h;
    int f1418i;
    int f1419j;
    int f1420k;
    int f1421l;
    int f1422m = 0;
}
