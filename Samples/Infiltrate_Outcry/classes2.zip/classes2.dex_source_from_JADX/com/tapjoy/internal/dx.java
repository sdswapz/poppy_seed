package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;

public final class dx extends dl {
    public static final dn f719c = new C0164b();
    public static final Integer f720d = Integer.valueOf(0);
    public final String f721e;
    public final Integer f722f;
    public final String f723g;
    public final String f724h;
    public final String f725i;

    public static final class C0163a extends C0149a {
        public String f714c;
        public Integer f715d;
        public String f716e;
        public String f717f;
        public String f718g;

        public final dx m711b() {
            return new dx(this.f714c, this.f715d, this.f716e, this.f717f, this.f718g, super.m529a());
        }
    }

    static final class C0164b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            dx dxVar = (dx) obj;
            int a2 = dxVar.f721e != null ? dn.f662p.mo128a(1, dxVar.f721e) : 0;
            if (dxVar.f722f != null) {
                a = dn.f650d.mo128a(2, dxVar.f722f);
            } else {
                a = 0;
            }
            a += a2;
            if (dxVar.f723g != null) {
                a2 = dn.f662p.mo128a(3, dxVar.f723g);
            } else {
                a2 = 0;
            }
            a += a2;
            if (dxVar.f724h != null) {
                a2 = dn.f662p.mo128a(4, dxVar.f724h);
            } else {
                a2 = 0;
            }
            a2 += a;
            if (dxVar.f725i != null) {
                i = dn.f662p.mo128a(5, dxVar.f725i);
            }
            return (a2 + i) + dxVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dx dxVar = (dx) obj;
            if (dxVar.f721e != null) {
                dn.f662p.mo129a(dpVar, 1, dxVar.f721e);
            }
            if (dxVar.f722f != null) {
                dn.f650d.mo129a(dpVar, 2, dxVar.f722f);
            }
            if (dxVar.f723g != null) {
                dn.f662p.mo129a(dpVar, 3, dxVar.f723g);
            }
            if (dxVar.f724h != null) {
                dn.f662p.mo129a(dpVar, 4, dxVar.f724h);
            }
            if (dxVar.f725i != null) {
                dn.f662p.mo129a(dpVar, 5, dxVar.f725i);
            }
            dpVar.m593a(dxVar.m530a());
        }

        C0164b() {
            super(dk.LENGTH_DELIMITED, dx.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0163a c0163a = new C0163a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0163a.f714c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0163a.f715d = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 3:
                            c0163a.f716e = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 4:
                            c0163a.f717f = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 5:
                            c0163a.f718g = (String) dn.f662p.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0163a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0163a.m711b();
            }
        }
    }

    public dx(String str, Integer num, String str2, String str3, String str4, hy hyVar) {
        super(f719c, hyVar);
        this.f721e = str;
        this.f722f = num;
        this.f723g = str2;
        this.f724h = str3;
        this.f725i = str4;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof dx)) {
            return false;
        }
        dx dxVar = (dx) other;
        if (m530a().equals(dxVar.m530a()) && ds.m602a(this.f721e, dxVar.f721e) && ds.m602a(this.f722f, dxVar.f722f) && ds.m602a(this.f723g, dxVar.f723g) && ds.m602a(this.f724h, dxVar.f724h) && ds.m602a(this.f725i, dxVar.f725i)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f721e != null ? this.f721e.hashCode() : 0) + (m530a().hashCode() * 37)) * 37;
        if (this.f722f != null) {
            i2 = this.f722f.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f723g != null) {
            i2 = this.f723g.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f724h != null) {
            i2 = this.f724h.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f725i != null) {
            i = this.f725i.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.f721e != null) {
            stringBuilder.append(", pkgVer=").append(this.f721e);
        }
        if (this.f722f != null) {
            stringBuilder.append(", pkgRev=").append(this.f722f);
        }
        if (this.f723g != null) {
            stringBuilder.append(", dataVer=").append(this.f723g);
        }
        if (this.f724h != null) {
            stringBuilder.append(", installer=").append(this.f724h);
        }
        if (this.f725i != null) {
            stringBuilder.append(", store=").append(this.f725i);
        }
        return stringBuilder.replace(0, 2, "App{").append('}').toString();
    }
}
