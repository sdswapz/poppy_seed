package com.tapjoy.internal;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public final class ba implements bc {
    private final List f535a;

    public ba(List list) {
        this.f535a = list;
    }

    public final boolean add(Object object) {
        return this.f535a.add(object);
    }

    public final boolean addAll(Collection collection) {
        return this.f535a.addAll(collection);
    }

    public final void clear() {
        this.f535a.clear();
    }

    public final boolean contains(Object object) {
        return this.f535a.contains(object);
    }

    public final boolean containsAll(Collection collection) {
        return this.f535a.containsAll(collection);
    }

    public final boolean equals(Object object) {
        return this.f535a.equals(object);
    }

    public final Object mo94a(int i) {
        return this.f535a.get(i);
    }

    public final int hashCode() {
        return this.f535a.hashCode();
    }

    public final boolean isEmpty() {
        return this.f535a.isEmpty();
    }

    public final Iterator iterator() {
        return this.f535a.iterator();
    }

    public final boolean remove(Object object) {
        return this.f535a.remove(object);
    }

    public final boolean removeAll(Collection collection) {
        return this.f535a.removeAll(collection);
    }

    public final boolean retainAll(Collection collection) {
        return this.f535a.retainAll(collection);
    }

    public final int size() {
        return this.f535a.size();
    }

    public final Object[] toArray() {
        return this.f535a.toArray();
    }

    public final Object[] toArray(Object[] array) {
        return this.f535a.toArray(array);
    }

    public final boolean offer(Object e) {
        return this.f535a.add(e);
    }

    public final Object remove() {
        Object poll = poll();
        if (poll != null) {
            return poll;
        }
        throw new NoSuchElementException();
    }

    public final Object poll() {
        return this.f535a.isEmpty() ? null : this.f535a.remove(0);
    }

    public final Object element() {
        Object peek = peek();
        if (peek != null) {
            return peek;
        }
        throw new NoSuchElementException();
    }

    public final Object peek() {
        return this.f535a.isEmpty() ? null : this.f535a.get(0);
    }

    public final void mo95b(int i) {
        bb.m315a(this.f535a, i);
    }
}
