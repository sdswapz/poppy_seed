package com.tapjoy.internal;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Map;
import java.util.Map.Entry;

public final class cj implements ci {
    private final String f599a;
    private final URL f600b;

    public cj(String str, URL url) {
        this.f599a = str;
        this.f600b = url;
    }

    public final Object mo119a(cf cfVar) {
        URL url = new URL(this.f600b, cfVar.mo252c());
        String b = cfVar.mo248b();
        if ("GET".equals(b) || "DELETE".equals(b)) {
            Map e = cfVar.mo250e();
            if (!e.isEmpty()) {
                url = new URL(url, url.getPath() + "?" + en.m773a(e));
            }
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) em.m772a(url);
        httpURLConnection.setRequestMethod(b);
        httpURLConnection.setRequestProperty("User-Agent", this.f599a);
        for (Entry entry : cfVar.mo118a().entrySet()) {
            httpURLConnection.setRequestProperty((String) entry.getKey(), entry.getValue().toString());
        }
        if (!("GET".equals(b) || "DELETE".equals(b))) {
            if ("POST".equals(b) || "PUT".equals(b)) {
                String d = cfVar.mo249d();
                if (d == null) {
                    en.m774a(httpURLConnection, "application/x-www-form-urlencoded", en.m773a(cfVar.mo250e()), cp.f605c);
                } else if ("application/json".equals(d)) {
                    en.m774a(httpURLConnection, "application/json; charset=utf-8", bm.m327a(cfVar.mo250e()), cp.f605c);
                } else {
                    throw new IllegalArgumentException("Unknown content type: " + d);
                }
            }
            throw new IllegalArgumentException("Unknown method: " + b);
        }
        httpURLConnection.connect();
        switch (httpURLConnection.getResponseCode()) {
            case 200:
            case 201:
            case 409:
                URI toURI;
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    toURI = httpURLConnection.getURL().toURI();
                } catch (URISyntaxException e2) {
                    toURI = null;
                }
                try {
                    Object a = cfVar.mo117a(toURI, inputStream);
                    return a;
                } finally {
                    inputStream.close();
                }
            default:
                throw new IOException("Unexpected status code: " + httpURLConnection.getResponseCode());
        }
    }
}
