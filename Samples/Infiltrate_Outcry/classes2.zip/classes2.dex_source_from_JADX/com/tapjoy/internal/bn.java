package com.tapjoy.internal;

public interface bn {
    Object mo97a(bs bsVar);
}
