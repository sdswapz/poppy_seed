package com.tapjoy.internal;

import android.os.Handler;
import android.os.Looper;

public final class C0288x {
    private static Handler f1550a;

    public static synchronized Handler m1347a() {
        Handler handler;
        synchronized (C0288x.class) {
            if (f1550a == null) {
                f1550a = new Handler(Looper.getMainLooper());
            }
            handler = f1550a;
        }
        return handler;
    }

    public static bf m1348a(final Handler handler) {
        return new bf() {
            public final boolean mo201a(Runnable runnable) {
                return handler.post(runnable);
            }
        };
    }
}
