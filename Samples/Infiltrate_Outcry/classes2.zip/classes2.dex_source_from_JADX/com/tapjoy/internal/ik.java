package com.tapjoy.internal;

public final class ik {
    public static ik f1532a = new ik(null);
    public String f1533b;
    public Throwable f1534c;
    private Object[] f1535d;

    public ik(String str) {
        this(str, null, null);
    }

    public ik(String str, Object[] objArr, Throwable th) {
        this.f1533b = str;
        this.f1534c = th;
        if (th == null) {
            this.f1535d = objArr;
        } else if (objArr == null || objArr.length == 0) {
            throw new IllegalStateException("non-sensical empty or null argument array");
        } else {
            int length = objArr.length - 1;
            Object obj = new Object[length];
            System.arraycopy(objArr, 0, obj, 0, length);
            this.f1535d = obj;
        }
    }
}
