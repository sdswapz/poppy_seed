package com.tapjoy.internal;

import java.io.EOFException;
import java.nio.charset.Charset;

public final class hv implements hw, hx, Cloneable {
    private static final byte[] f1492c = new byte[]{(byte) 48, (byte) 49, (byte) 50, (byte) 51, (byte) 52, (byte) 53, (byte) 54, (byte) 55, (byte) 56, (byte) 57, (byte) 97, (byte) 98, (byte) 99, (byte) 100, (byte) 101, (byte) 102};
    ic f1493a;
    long f1494b;

    public final /* synthetic */ hw mo257b(hy hyVar) {
        return m1225a(hyVar);
    }

    public final /* synthetic */ hw mo258b(String str) {
        return m1226a(str);
    }

    public final /* synthetic */ Object clone() {
        return m1249h();
    }

    public final /* synthetic */ hw mo264d(int i) {
        return m1232b(i);
    }

    public final /* synthetic */ hw mo267e(int i) {
        return m1224a(i);
    }

    public final /* synthetic */ hw mo269f(long j) {
        return m1244e(j);
    }

    public final hw mo253a() {
        return this;
    }

    public final boolean mo260b() {
        return this.f1494b == 0;
    }

    public final void mo254a(long j) {
        if (this.f1494b < j) {
            throw new EOFException();
        }
    }

    public final byte mo261c() {
        if (this.f1494b == 0) {
            throw new IllegalStateException("size == 0");
        }
        ic icVar = this.f1493a;
        int i = icVar.f1515b;
        int i2 = icVar.f1516c;
        int i3 = i + 1;
        byte b = icVar.f1514a[i];
        this.f1494b--;
        if (i3 == i2) {
            this.f1493a = icVar.m1286a();
            id.m1290a(icVar);
        } else {
            icVar.f1515b = i3;
        }
        return b;
    }

    public final int m1240d() {
        if (this.f1494b < 4) {
            throw new IllegalStateException("size < 4: " + this.f1494b);
        }
        ic icVar = this.f1493a;
        int i = icVar.f1515b;
        int i2 = icVar.f1516c;
        if (i2 - i < 4) {
            return ((((mo261c() & 255) << 24) | ((mo261c() & 255) << 16)) | ((mo261c() & 255) << 8)) | (mo261c() & 255);
        }
        byte[] bArr = icVar.f1514a;
        int i3 = i + 1;
        int i4 = i3 + 1;
        i = ((bArr[i] & 255) << 24) | ((bArr[i3] & 255) << 16);
        i3 = i4 + 1;
        i |= (bArr[i4] & 255) << 8;
        i4 = i3 + 1;
        i |= bArr[i3] & 255;
        this.f1494b -= 4;
        if (i4 == i2) {
            this.f1493a = icVar.m1286a();
            id.m1290a(icVar);
            return i;
        }
        icVar.f1515b = i4;
        return i;
    }

    public final int mo266e() {
        return ii.m1303a(m1240d());
    }

    public final hy mo259b(long j) {
        return new hy(m1223g(j));
    }

    public final String mo262c(long j) {
        Charset charset = ii.f1528a;
        ii.m1305a(this.f1494b, 0, j);
        if (charset == null) {
            throw new IllegalArgumentException("charset == null");
        } else if (j > 2147483647L) {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j);
        } else if (j == 0) {
            return "";
        } else {
            ic icVar = this.f1493a;
            if (((long) icVar.f1515b) + j > ((long) icVar.f1516c)) {
                return new String(m1223g(j), charset);
            }
            String str = new String(icVar.f1514a, icVar.f1515b, (int) j, charset);
            icVar.f1515b = (int) (((long) icVar.f1515b) + j);
            this.f1494b -= j;
            if (icVar.f1515b != icVar.f1516c) {
                return str;
            }
            this.f1493a = icVar.m1286a();
            id.m1290a(icVar);
            return str;
        }
    }

    public final byte[] m1248g() {
        try {
            return m1223g(this.f1494b);
        } catch (EOFException e) {
            throw new AssertionError(e);
        }
    }

    private byte[] m1223g(long j) {
        ii.m1305a(this.f1494b, 0, j);
        if (j > 2147483647L) {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j);
        }
        byte[] bArr = new byte[((int) j)];
        m1222a(bArr);
        return bArr;
    }

    private void m1222a(byte[] bArr) {
        int i = 0;
        while (i < bArr.length) {
            int i2;
            int length = bArr.length - i;
            ii.m1305a((long) bArr.length, (long) i, (long) length);
            ic icVar = this.f1493a;
            if (icVar == null) {
                i2 = -1;
            } else {
                i2 = Math.min(length, icVar.f1516c - icVar.f1515b);
                System.arraycopy(icVar.f1514a, icVar.f1515b, bArr, i, i2);
                icVar.f1515b += i2;
                this.f1494b -= (long) i2;
                if (icVar.f1515b == icVar.f1516c) {
                    this.f1493a = icVar.m1286a();
                    id.m1290a(icVar);
                }
            }
            if (i2 == -1) {
                throw new EOFException();
            }
            i = i2 + i;
        }
    }

    public final void mo265d(long j) {
        while (j > 0) {
            if (this.f1493a == null) {
                throw new EOFException();
            }
            int min = (int) Math.min(j, (long) (this.f1493a.f1516c - this.f1493a.f1515b));
            this.f1494b -= (long) min;
            j -= (long) min;
            ic icVar = this.f1493a;
            icVar.f1515b = min + icVar.f1515b;
            if (this.f1493a.f1515b == this.f1493a.f1516c) {
                ic icVar2 = this.f1493a;
                this.f1493a = icVar2.m1286a();
                id.m1290a(icVar2);
            }
        }
    }

    public final hv m1225a(hy hyVar) {
        if (hyVar == null) {
            throw new IllegalArgumentException("byteString == null");
        }
        hyVar.mo274a(this);
        return this;
    }

    public final hv m1226a(String str) {
        int length = str.length();
        if (str == null) {
            throw new IllegalArgumentException("string == null");
        } else if (length < 0) {
            throw new IllegalArgumentException("endIndex < beginIndex: " + length + " < 0");
        } else if (length > str.length()) {
            throw new IllegalArgumentException("endIndex > string.length: " + length + " > " + str.length());
        } else {
            int i = 0;
            while (i < length) {
                char charAt = str.charAt(i);
                int i2;
                if (charAt < '') {
                    ic c = m1238c(1);
                    byte[] bArr = c.f1514a;
                    int i3 = c.f1516c - i;
                    int min = Math.min(length, 8192 - i3);
                    i2 = i + 1;
                    bArr[i + i3] = (byte) charAt;
                    while (i2 < min) {
                        charAt = str.charAt(i2);
                        if (charAt >= '') {
                            break;
                        }
                        i = i2 + 1;
                        bArr[i2 + i3] = (byte) charAt;
                        i2 = i;
                    }
                    i = (i2 + i3) - c.f1516c;
                    c.f1516c += i;
                    this.f1494b += (long) i;
                    i = i2;
                } else if (charAt < 'ࠀ') {
                    m1224a((charAt >> 6) | 192);
                    m1224a((charAt & 63) | 128);
                    i++;
                } else if (charAt < '?' || charAt > '?') {
                    m1224a((charAt >> 12) | 224);
                    m1224a(((charAt >> 6) & 63) | 128);
                    m1224a((charAt & 63) | 128);
                    i++;
                } else {
                    if (i + 1 < length) {
                        i2 = str.charAt(i + 1);
                    } else {
                        i2 = 0;
                    }
                    if (charAt > '?' || i2 < 56320 || i2 > 57343) {
                        m1224a(63);
                        i++;
                    } else {
                        i2 = ((i2 & -56321) | ((charAt & -55297) << 10)) + 65536;
                        m1224a((i2 >> 18) | 240);
                        m1224a(((i2 >> 12) & 63) | 128);
                        m1224a(((i2 >> 6) & 63) | 128);
                        m1224a((i2 & 63) | 128);
                        i += 2;
                    }
                }
            }
            return this;
        }
    }

    public final hv m1227a(byte[] bArr, int i, int i2) {
        if (bArr == null) {
            throw new IllegalArgumentException("source == null");
        }
        ii.m1305a((long) bArr.length, 0, (long) i2);
        int i3 = i2 + 0;
        while (i < i3) {
            ic c = m1238c(1);
            int min = Math.min(i3 - i, 8192 - c.f1516c);
            System.arraycopy(bArr, i, c.f1514a, c.f1516c, min);
            i += min;
            c.f1516c = min + c.f1516c;
        }
        this.f1494b += (long) i2;
        return this;
    }

    public final hv m1224a(int i) {
        ic c = m1238c(1);
        byte[] bArr = c.f1514a;
        int i2 = c.f1516c;
        c.f1516c = i2 + 1;
        bArr[i2] = (byte) i;
        this.f1494b++;
        return this;
    }

    public final hv m1232b(int i) {
        int a = ii.m1303a(i);
        ic c = m1238c(4);
        byte[] bArr = c.f1514a;
        int i2 = c.f1516c;
        int i3 = i2 + 1;
        bArr[i2] = (byte) ((a >>> 24) & 255);
        i2 = i3 + 1;
        bArr[i3] = (byte) ((a >>> 16) & 255);
        i3 = i2 + 1;
        bArr[i2] = (byte) ((a >>> 8) & 255);
        i2 = i3 + 1;
        bArr[i3] = (byte) (a & 255);
        c.f1516c = i2;
        this.f1494b += 4;
        return this;
    }

    public final hv m1244e(long j) {
        long a = ii.m1304a(j);
        ic c = m1238c(8);
        byte[] bArr = c.f1514a;
        int i = c.f1516c;
        int i2 = i + 1;
        bArr[i] = (byte) ((int) ((a >>> 56) & 255));
        i = i2 + 1;
        bArr[i2] = (byte) ((int) ((a >>> 48) & 255));
        i2 = i + 1;
        bArr[i] = (byte) ((int) ((a >>> 40) & 255));
        i = i2 + 1;
        bArr[i2] = (byte) ((int) ((a >>> 32) & 255));
        i2 = i + 1;
        bArr[i] = (byte) ((int) ((a >>> 24) & 255));
        i = i2 + 1;
        bArr[i2] = (byte) ((int) ((a >>> 16) & 255));
        i2 = i + 1;
        bArr[i] = (byte) ((int) ((a >>> 8) & 255));
        i = i2 + 1;
        bArr[i2] = (byte) ((int) (a & 255));
        c.f1516c = i;
        this.f1494b += 8;
        return this;
    }

    final ic m1238c(int i) {
        if (i <= 0 || i > 8192) {
            throw new IllegalArgumentException();
        } else if (this.f1493a == null) {
            this.f1493a = id.m1289a();
            ic icVar = this.f1493a;
            ic icVar2 = this.f1493a;
            r0 = this.f1493a;
            icVar2.f1520g = r0;
            icVar.f1519f = r0;
            return r0;
        } else {
            r0 = this.f1493a.f1520g;
            if (r0.f1516c + i > 8192 || !r0.f1518e) {
                return r0.m1287a(id.m1289a());
            }
            return r0;
        }
    }

    public final void mo255a(hv hvVar, long j) {
        if (hvVar == null) {
            throw new IllegalArgumentException("source == null");
        } else if (hvVar == this) {
            throw new IllegalArgumentException("source == this");
        } else {
            ii.m1305a(hvVar.f1494b, 0, j);
            while (j > 0) {
                ic icVar;
                ic icVar2;
                if (j < ((long) (hvVar.f1493a.f1516c - hvVar.f1493a.f1515b))) {
                    icVar = this.f1493a != null ? this.f1493a.f1520g : null;
                    if (icVar != null && icVar.f1518e) {
                        if ((((long) icVar.f1516c) + j) - ((long) (icVar.f1517d ? 0 : icVar.f1515b)) <= 8192) {
                            hvVar.f1493a.m1288a(icVar, (int) j);
                            hvVar.f1494b -= j;
                            this.f1494b += j;
                            return;
                        }
                    }
                    icVar = hvVar.f1493a;
                    int i = (int) j;
                    if (i <= 0 || i > icVar.f1516c - icVar.f1515b) {
                        throw new IllegalArgumentException();
                    }
                    if (i >= 1024) {
                        icVar2 = new ic(icVar);
                    } else {
                        icVar2 = id.m1289a();
                        System.arraycopy(icVar.f1514a, icVar.f1515b, icVar2.f1514a, 0, i);
                    }
                    icVar2.f1516c = icVar2.f1515b + i;
                    icVar.f1515b = i + icVar.f1515b;
                    icVar.f1520g.m1287a(icVar2);
                    hvVar.f1493a = icVar2;
                }
                icVar2 = hvVar.f1493a;
                long j2 = (long) (icVar2.f1516c - icVar2.f1515b);
                hvVar.f1493a = icVar2.m1286a();
                if (this.f1493a == null) {
                    this.f1493a = icVar2;
                    icVar2 = this.f1493a;
                    icVar = this.f1493a;
                    ic icVar3 = this.f1493a;
                    icVar.f1520g = icVar3;
                    icVar2.f1519f = icVar3;
                } else {
                    icVar = this.f1493a.f1520g.m1287a(icVar2);
                    if (icVar.f1520g == icVar) {
                        throw new IllegalStateException();
                    } else if (icVar.f1520g.f1518e) {
                        int i2 = icVar.f1516c - icVar.f1515b;
                        if (i2 <= (icVar.f1520g.f1517d ? 0 : icVar.f1520g.f1515b) + (8192 - icVar.f1520g.f1516c)) {
                            icVar.m1288a(icVar.f1520g, i2);
                            icVar.m1286a();
                            id.m1290a(icVar);
                        }
                    }
                }
                hvVar.f1494b -= j2;
                this.f1494b += j2;
                j -= j2;
            }
        }
    }

    public final long mo256b(hv hvVar, long j) {
        if (hvVar == null) {
            throw new IllegalArgumentException("sink == null");
        } else if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j);
        } else if (this.f1494b == 0) {
            return -1;
        } else {
            if (j > this.f1494b) {
                j = this.f1494b;
            }
            hvVar.mo255a(this, j);
            return j;
        }
    }

    public final void flush() {
    }

    public final void close() {
    }

    public final boolean equals(Object o) {
        long j = 0;
        if (this == o) {
            return true;
        }
        if (!(o instanceof hv)) {
            return false;
        }
        hv hvVar = (hv) o;
        if (this.f1494b != hvVar.f1494b) {
            return false;
        }
        if (this.f1494b == 0) {
            return true;
        }
        ic icVar = this.f1493a;
        ic icVar2 = hvVar.f1493a;
        int i = icVar.f1515b;
        int i2 = icVar2.f1515b;
        while (j < this.f1494b) {
            long min = (long) Math.min(icVar.f1516c - i, icVar2.f1516c - i2);
            int i3 = 0;
            while (((long) i3) < min) {
                int i4 = i + 1;
                byte b = icVar.f1514a[i];
                i = i2 + 1;
                if (b != icVar2.f1514a[i2]) {
                    return false;
                }
                i3++;
                i2 = i;
                i = i4;
            }
            if (i == icVar.f1516c) {
                icVar = icVar.f1519f;
                i = icVar.f1515b;
            }
            if (i2 == icVar2.f1516c) {
                icVar2 = icVar2.f1519f;
                i2 = icVar2.f1515b;
            }
            j += min;
        }
        return true;
    }

    public final int hashCode() {
        ic icVar = this.f1493a;
        if (icVar == null) {
            return 0;
        }
        int i = 1;
        do {
            int i2 = icVar.f1515b;
            while (i2 < icVar.f1516c) {
                int i3 = icVar.f1514a[i2] + (i * 31);
                i2++;
                i = i3;
            }
            icVar = icVar.f1519f;
        } while (icVar != this.f1493a);
        return i;
    }

    public final hv m1249h() {
        hv hvVar = new hv();
        if (this.f1494b == 0) {
            return hvVar;
        }
        hvVar.f1493a = new ic(this.f1493a);
        ic icVar = hvVar.f1493a;
        ic icVar2 = hvVar.f1493a;
        ic icVar3 = hvVar.f1493a;
        icVar2.f1520g = icVar3;
        icVar.f1519f = icVar3;
        for (icVar = this.f1493a.f1519f; icVar != this.f1493a; icVar = icVar.f1519f) {
            hvVar.f1493a.f1520g.m1287a(new ic(icVar));
        }
        hvVar.f1494b = this.f1494b;
        return hvVar;
    }

    public final long mo268f() {
        if (this.f1494b < 8) {
            throw new IllegalStateException("size < 8: " + this.f1494b);
        }
        long d;
        ic icVar = this.f1493a;
        int i = icVar.f1515b;
        int i2 = icVar.f1516c;
        if (i2 - i < 8) {
            d = ((((long) m1240d()) & 4294967295L) << 32) | (((long) m1240d()) & 4294967295L);
        } else {
            byte[] bArr = icVar.f1514a;
            int i3 = i + 1;
            long j = (((long) bArr[i]) & 255) << 56;
            i = i3 + 1;
            long j2 = ((((long) bArr[i3]) & 255) << 48) | j;
            int i4 = i + 1;
            i = i4 + 1;
            j2 = (j2 | ((((long) bArr[i]) & 255) << 40)) | ((((long) bArr[i4]) & 255) << 32);
            i4 = i + 1;
            i = i4 + 1;
            j2 = (j2 | ((((long) bArr[i]) & 255) << 24)) | ((((long) bArr[i4]) & 255) << 16);
            i4 = i + 1;
            int i5 = i4 + 1;
            d = (((long) bArr[i4]) & 255) | (j2 | ((((long) bArr[i]) & 255) << 8));
            this.f1494b -= 8;
            if (i5 == i2) {
                this.f1493a = icVar.m1286a();
                id.m1290a(icVar);
            } else {
                icVar.f1515b = i5;
            }
        }
        return ii.m1304a(d);
    }

    public final String toString() {
        if (this.f1494b > 2147483647L) {
            throw new IllegalArgumentException("size > Integer.MAX_VALUE: " + this.f1494b);
        }
        hy hyVar;
        int i = (int) this.f1494b;
        if (i == 0) {
            hyVar = hy.f1496b;
        } else {
            hyVar = new ie(this, i);
        }
        return hyVar.toString();
    }
}
