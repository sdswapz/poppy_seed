package com.tapjoy.internal;

import java.io.IOException;
import java.io.Serializable;

public abstract class dl implements Serializable {
    transient int f676a = 0;
    protected transient int f677b = 0;
    private final transient dn f678c;
    private final transient hy f679d;

    public static abstract class C0149a {
        hv f674a;
        dp f675b;

        protected C0149a() {
        }

        public final C0149a m528a(hy hyVar) {
            if (hyVar.mo277c() > 0) {
                if (this.f675b == null) {
                    this.f674a = new hv();
                    this.f675b = new dp(this.f674a);
                }
                try {
                    this.f675b.m593a(hyVar);
                } catch (IOException e) {
                    throw new AssertionError();
                }
            }
            return this;
        }

        public final C0149a m527a(int i, dk dkVar, Object obj) {
            if (this.f675b == null) {
                this.f674a = new hv();
                this.f675b = new dp(this.f674a);
            }
            try {
                dkVar.m526a().mo129a(this.f675b, i, obj);
                return this;
            } catch (IOException e) {
                throw new AssertionError();
            }
        }

        public final hy m529a() {
            return this.f674a != null ? new hy(this.f674a.m1249h().m1248g()) : hy.f1496b;
        }
    }

    protected dl(dn dnVar, hy hyVar) {
        if (dnVar == null) {
            throw new NullPointerException("adapter == null");
        } else if (hyVar == null) {
            throw new NullPointerException("unknownFields == null");
        } else {
            this.f678c = dnVar;
            this.f679d = hyVar;
        }
    }

    public final hy m530a() {
        hy hyVar = this.f679d;
        return hyVar != null ? hyVar : hy.f1496b;
    }

    public String toString() {
        return dn.m511c(this);
    }
}
