package com.tapjoy.internal;

import android.os.SystemClock;

public abstract class go {
    protected static C0244a f1026a;
    private static go f1027b;

    public static class C0244a {
        public final String f1268a;
        public final String f1269b;
        public final long f1270c = SystemClock.elapsedRealtime();
        public final el f1271d = new el(60000);

        public C0244a(String str, String str2) {
            this.f1268a = str;
            this.f1269b = str2;
        }
    }

    public abstract void mo186a(C0244a c0244a);

    public abstract boolean mo187b();

    protected static void m818a(go goVar) {
        synchronized (go.class) {
            f1027b = goVar;
            C0244a c0244a = f1026a;
            if (c0244a != null) {
                f1026a = null;
                goVar.mo186a(c0244a);
            }
        }
    }

    public static void m819a(String str, String str2) {
        synchronized (go.class) {
            C0244a c0244a = new C0244a(str, str2);
            if (f1027b != null) {
                f1026a = null;
                f1027b.mo186a(c0244a);
            } else {
                f1026a = c0244a;
            }
        }
    }

    public static boolean m820c() {
        if (f1027b != null && f1027b.mo187b()) {
            return true;
        }
        C0244a c0244a = f1026a;
        if (c0244a == null || c0244a.f1271d.m769a()) {
            return false;
        }
        return true;
    }
}
