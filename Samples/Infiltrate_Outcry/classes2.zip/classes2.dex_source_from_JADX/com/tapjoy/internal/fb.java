package com.tapjoy.internal;

import com.tapjoy.TapjoyConstants;
import com.tapjoy.internal.fn.C0217a;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;

public final class fb extends fn {
    static final Map f1030a = Collections.unmodifiableMap(new HashMap());
    private final C0217a f1031c = m827a("BuildConfig");
    private final C0217a f1032d = m827a("ServerFinal");
    private final C0217a f1033e = m827a("AppRuntime");
    private final C0217a f1034f = m827a("ConnectFlags");
    private final C0217a f1035g = m827a("ServerDefault");

    fb() {
        C0217a a = m827a("SDKDefault");
        if (!"".isEmpty()) {
            try {
                this.f1031c.f1102b = bs.m367b("").m380d();
            } catch (Throwable e) {
                throw new Error("BuildConfig.TJC_CONFIGURATION malformed", e);
            }
        }
        Map hashMap = new HashMap();
        hashMap.put("placement_request_content_retry_timeout", Integer.valueOf(-1));
        hashMap.put("placement_request_content_retry_backoff", Arrays.asList(new Number[]{Long.valueOf(0), Long.valueOf(500), Long.valueOf(TapjoyConstants.TIMER_INCREMENT), Double.valueOf(2.0d)}));
        a.f1102b = hashMap;
    }

    public final void m833a(Map map) {
        Map map2;
        Map map3 = null;
        if (map != null) {
            map2 = (Map) map.get("final");
            map3 = (Map) map.get("default");
        } else {
            map2 = null;
        }
        this.f1032d.f1102b = map2;
        this.f1035g.f1102b = map3;
        setChanged();
    }

    public final void m832a(Hashtable hashtable) {
        Map hashMap = new HashMap();
        for (Entry entry : hashtable.entrySet()) {
            Object obj = (String) f1030a.get(entry.getKey());
            if (obj == null) {
                obj = (String) entry.getKey();
            }
            this.f1033e.f1102b.remove(obj);
            hashMap.put(obj, entry.getValue());
        }
        this.f1034f.f1102b = hashMap;
        setChanged();
    }
}
