package com.tapjoy.internal;

import android.graphics.Rect;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;

public final class gw {
    public static final bn f1295h = new C02511();
    public final Rect f1296a;
    public final String f1297b;
    public final boolean f1298c;
    public final String f1299d;
    public String f1300e;
    public String f1301f;
    public final fp f1302g;

    static class C02511 implements bn {
        C02511() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            fp fpVar = null;
            boolean z = false;
            String str = "";
            bsVar.mo105h();
            String str2 = null;
            String str3 = null;
            String str4 = null;
            Rect rect = null;
            while (bsVar.mo107j()) {
                String l = bsVar.mo109l();
                if ("region".equals(l)) {
                    rect = (Rect) bo.f543b.mo97a(bsVar);
                } else if ("value".equals(l)) {
                    str4 = bsVar.mo110m();
                } else if (TapjoyConstants.TJC_FULLSCREEN_AD_DISMISS_URL.equals(l)) {
                    z = bsVar.mo111n();
                } else if (String.URL.equals(l)) {
                    str = bsVar.mo110m();
                } else if (TapjoyConstants.TJC_REDIRECT_URL.equals(l)) {
                    str3 = bsVar.m377b();
                } else if ("ad_content".equals(l)) {
                    str2 = bsVar.m377b();
                } else if (gs.m1107a(l)) {
                    fpVar = gs.m1106a(l, bsVar);
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return new gw(rect, str4, z, str, str3, str2, fpVar);
        }
    }

    gw(Rect rect, String str, boolean z, String str2, String str3, String str4, fp fpVar) {
        this.f1296a = rect;
        this.f1297b = str;
        this.f1298c = z;
        this.f1299d = str2;
        this.f1300e = str3;
        this.f1301f = str4;
        this.f1302g = fpVar;
    }
}
