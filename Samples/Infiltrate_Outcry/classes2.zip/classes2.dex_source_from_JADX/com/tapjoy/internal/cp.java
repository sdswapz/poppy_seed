package com.tapjoy.internal;

import java.nio.charset.Charset;

public final class cp {
    public static final Charset f603a = Charset.forName("US-ASCII");
    public static final Charset f604b = Charset.forName("ISO-8859-1");
    public static final Charset f605c = Charset.forName("UTF-8");
    public static final Charset f606d = Charset.forName("UTF-16BE");
    public static final Charset f607e = Charset.forName("UTF-16LE");
    public static final Charset f608f = Charset.forName("UTF-16");
}
