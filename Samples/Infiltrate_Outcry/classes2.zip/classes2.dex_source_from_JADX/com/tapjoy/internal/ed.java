package com.tapjoy.internal;

import android.os.Build;
import android.os.Build.VERSION;
import com.tapjoy.internal.dl.C0149a;
import java.util.Locale;
import java.util.TimeZone;

public final class ed extends dl {
    public static final dn f824c = new C0176b();
    public static final Integer f825d = Integer.valueOf(0);
    public static final Integer f826e = Integer.valueOf(0);
    public static final Integer f827f = Integer.valueOf(0);
    public final String f828g;
    public final String f829h;
    public final String f830i;
    public final String f831j;
    public final String f832k;
    public final String f833l;
    public final Integer f834m;
    public final Integer f835n;
    public final Integer f836o;
    public final String f837p;
    public final String f838q;
    public final String f839r;
    public final String f840s;
    public final String f841t;
    public final String f842u;
    public final String f843v;
    public final String f844w;

    public static final class C0175a extends C0149a {
        public String f807c;
        public String f808d;
        public String f809e = Build.MANUFACTURER;
        public String f810f = Build.MODEL;
        public String f811g = "Android";
        public String f812h = VERSION.RELEASE;
        public Integer f813i;
        public Integer f814j;
        public Integer f815k;
        public String f816l = Locale.getDefault().toString();
        public String f817m = TimeZone.getDefault().getID();
        public String f818n;
        public String f819o;
        public String f820p = "11.11.0/Android";
        public String f821q;
        public String f822r;
        public String f823s;

        public final ed m736b() {
            return new ed(this.f807c, this.f808d, this.f809e, this.f810f, this.f811g, this.f812h, this.f813i, this.f814j, this.f815k, this.f816l, this.f817m, this.f818n, this.f819o, this.f820p, this.f821q, this.f822r, this.f823s, super.m529a());
        }
    }

    static final class C0176b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            ed edVar = (ed) obj;
            int a2 = edVar.f828g != null ? dn.f662p.mo128a(1, edVar.f828g) : 0;
            if (edVar.f829h != null) {
                a = dn.f662p.mo128a(2, edVar.f829h);
            } else {
                a = 0;
            }
            a += a2;
            if (edVar.f830i != null) {
                a2 = dn.f662p.mo128a(3, edVar.f830i);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f831j != null) {
                a2 = dn.f662p.mo128a(4, edVar.f831j);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f832k != null) {
                a2 = dn.f662p.mo128a(5, edVar.f832k);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f833l != null) {
                a2 = dn.f662p.mo128a(6, edVar.f833l);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f834m != null) {
                a2 = dn.f650d.mo128a(7, edVar.f834m);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f835n != null) {
                a2 = dn.f650d.mo128a(8, edVar.f835n);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f836o != null) {
                a2 = dn.f650d.mo128a(9, edVar.f836o);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f837p != null) {
                a2 = dn.f662p.mo128a(10, edVar.f837p);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f838q != null) {
                a2 = dn.f662p.mo128a(11, edVar.f838q);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f839r != null) {
                a2 = dn.f662p.mo128a(12, edVar.f839r);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f840s != null) {
                a2 = dn.f662p.mo128a(13, edVar.f840s);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f841t != null) {
                a2 = dn.f662p.mo128a(14, edVar.f841t);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f842u != null) {
                a2 = dn.f662p.mo128a(15, edVar.f842u);
            } else {
                a2 = 0;
            }
            a += a2;
            if (edVar.f843v != null) {
                a2 = dn.f662p.mo128a(16, edVar.f843v);
            } else {
                a2 = 0;
            }
            a2 += a;
            if (edVar.f844w != null) {
                i = dn.f662p.mo128a(17, edVar.f844w);
            }
            return (a2 + i) + edVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ed edVar = (ed) obj;
            if (edVar.f828g != null) {
                dn.f662p.mo129a(dpVar, 1, edVar.f828g);
            }
            if (edVar.f829h != null) {
                dn.f662p.mo129a(dpVar, 2, edVar.f829h);
            }
            if (edVar.f830i != null) {
                dn.f662p.mo129a(dpVar, 3, edVar.f830i);
            }
            if (edVar.f831j != null) {
                dn.f662p.mo129a(dpVar, 4, edVar.f831j);
            }
            if (edVar.f832k != null) {
                dn.f662p.mo129a(dpVar, 5, edVar.f832k);
            }
            if (edVar.f833l != null) {
                dn.f662p.mo129a(dpVar, 6, edVar.f833l);
            }
            if (edVar.f834m != null) {
                dn.f650d.mo129a(dpVar, 7, edVar.f834m);
            }
            if (edVar.f835n != null) {
                dn.f650d.mo129a(dpVar, 8, edVar.f835n);
            }
            if (edVar.f836o != null) {
                dn.f650d.mo129a(dpVar, 9, edVar.f836o);
            }
            if (edVar.f837p != null) {
                dn.f662p.mo129a(dpVar, 10, edVar.f837p);
            }
            if (edVar.f838q != null) {
                dn.f662p.mo129a(dpVar, 11, edVar.f838q);
            }
            if (edVar.f839r != null) {
                dn.f662p.mo129a(dpVar, 12, edVar.f839r);
            }
            if (edVar.f840s != null) {
                dn.f662p.mo129a(dpVar, 13, edVar.f840s);
            }
            if (edVar.f841t != null) {
                dn.f662p.mo129a(dpVar, 14, edVar.f841t);
            }
            if (edVar.f842u != null) {
                dn.f662p.mo129a(dpVar, 15, edVar.f842u);
            }
            if (edVar.f843v != null) {
                dn.f662p.mo129a(dpVar, 16, edVar.f843v);
            }
            if (edVar.f844w != null) {
                dn.f662p.mo129a(dpVar, 17, edVar.f844w);
            }
            dpVar.m593a(edVar.m530a());
        }

        C0176b() {
            super(dk.LENGTH_DELIMITED, ed.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0175a c0175a = new C0175a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0175a.f807c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0175a.f808d = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 3:
                            c0175a.f809e = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 4:
                            c0175a.f810f = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 5:
                            c0175a.f811g = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 6:
                            c0175a.f812h = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 7:
                            c0175a.f813i = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 8:
                            c0175a.f814j = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 9:
                            c0175a.f815k = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 10:
                            c0175a.f816l = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 11:
                            c0175a.f817m = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 12:
                            c0175a.f818n = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 13:
                            c0175a.f819o = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 14:
                            c0175a.f820p = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 15:
                            c0175a.f821q = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 16:
                            c0175a.f822r = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 17:
                            c0175a.f823s = (String) dn.f662p.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0175a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0175a.m736b();
            }
        }
    }

    public ed(String str, String str2, String str3, String str4, String str5, String str6, Integer num, Integer num2, Integer num3, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, hy hyVar) {
        super(f824c, hyVar);
        this.f828g = str;
        this.f829h = str2;
        this.f830i = str3;
        this.f831j = str4;
        this.f832k = str5;
        this.f833l = str6;
        this.f834m = num;
        this.f835n = num2;
        this.f836o = num3;
        this.f837p = str7;
        this.f838q = str8;
        this.f839r = str9;
        this.f840s = str10;
        this.f841t = str11;
        this.f842u = str12;
        this.f843v = str13;
        this.f844w = str14;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ed)) {
            return false;
        }
        ed edVar = (ed) other;
        if (m530a().equals(edVar.m530a()) && ds.m602a(this.f828g, edVar.f828g) && ds.m602a(this.f829h, edVar.f829h) && ds.m602a(this.f830i, edVar.f830i) && ds.m602a(this.f831j, edVar.f831j) && ds.m602a(this.f832k, edVar.f832k) && ds.m602a(this.f833l, edVar.f833l) && ds.m602a(this.f834m, edVar.f834m) && ds.m602a(this.f835n, edVar.f835n) && ds.m602a(this.f836o, edVar.f836o) && ds.m602a(this.f837p, edVar.f837p) && ds.m602a(this.f838q, edVar.f838q) && ds.m602a(this.f839r, edVar.f839r) && ds.m602a(this.f840s, edVar.f840s) && ds.m602a(this.f841t, edVar.f841t) && ds.m602a(this.f842u, edVar.f842u) && ds.m602a(this.f843v, edVar.f843v) && ds.m602a(this.f844w, edVar.f844w)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f828g != null ? this.f828g.hashCode() : 0) + (m530a().hashCode() * 37)) * 37;
        if (this.f829h != null) {
            i2 = this.f829h.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f830i != null) {
            i2 = this.f830i.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f831j != null) {
            i2 = this.f831j.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f832k != null) {
            i2 = this.f832k.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f833l != null) {
            i2 = this.f833l.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f834m != null) {
            i2 = this.f834m.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f835n != null) {
            i2 = this.f835n.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f836o != null) {
            i2 = this.f836o.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f837p != null) {
            i2 = this.f837p.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f838q != null) {
            i2 = this.f838q.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f839r != null) {
            i2 = this.f839r.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f840s != null) {
            i2 = this.f840s.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f841t != null) {
            i2 = this.f841t.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f842u != null) {
            i2 = this.f842u.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f843v != null) {
            i2 = this.f843v.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f844w != null) {
            i = this.f844w.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.f828g != null) {
            stringBuilder.append(", mac=").append(this.f828g);
        }
        if (this.f829h != null) {
            stringBuilder.append(", deviceId=").append(this.f829h);
        }
        if (this.f830i != null) {
            stringBuilder.append(", deviceMaker=").append(this.f830i);
        }
        if (this.f831j != null) {
            stringBuilder.append(", deviceModel=").append(this.f831j);
        }
        if (this.f832k != null) {
            stringBuilder.append(", osName=").append(this.f832k);
        }
        if (this.f833l != null) {
            stringBuilder.append(", osVer=").append(this.f833l);
        }
        if (this.f834m != null) {
            stringBuilder.append(", displayD=").append(this.f834m);
        }
        if (this.f835n != null) {
            stringBuilder.append(", displayW=").append(this.f835n);
        }
        if (this.f836o != null) {
            stringBuilder.append(", displayH=").append(this.f836o);
        }
        if (this.f837p != null) {
            stringBuilder.append(", locale=").append(this.f837p);
        }
        if (this.f838q != null) {
            stringBuilder.append(", timezone=").append(this.f838q);
        }
        if (this.f839r != null) {
            stringBuilder.append(", pkgId=").append(this.f839r);
        }
        if (this.f840s != null) {
            stringBuilder.append(", pkgSign=").append(this.f840s);
        }
        if (this.f841t != null) {
            stringBuilder.append(", sdk=").append(this.f841t);
        }
        if (this.f842u != null) {
            stringBuilder.append(", countrySim=").append(this.f842u);
        }
        if (this.f843v != null) {
            stringBuilder.append(", countryNet=").append(this.f843v);
        }
        if (this.f844w != null) {
            stringBuilder.append(", imei=").append(this.f844w);
        }
        return stringBuilder.replace(0, 2, "Info{").append('}').toString();
    }
}
