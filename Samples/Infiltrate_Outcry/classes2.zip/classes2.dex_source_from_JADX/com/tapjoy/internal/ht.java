package com.tapjoy.internal;

import android.content.Context;
import android.view.ViewGroup.LayoutParams;

public final class ht extends an {
    private final gy f1480a;
    private final hu f1481b;
    private af f1482c = null;

    public ht(Context context, gy gyVar, hu huVar) {
        super(context);
        this.f1480a = gyVar;
        this.f1481b = huVar;
        addView(huVar, new LayoutParams(-1, -1));
    }

    protected final void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        af afVar;
        af a = af.m276a(getContext());
        if (!this.f1480a.m1129a()) {
            afVar = af.LANDSCAPE;
            if (!a.m278a()) {
                setRotationCount(0);
            } else if (a.m280c() == 3) {
                setRotationCount(1);
            } else {
                setRotationCount(1);
            }
        } else if (this.f1480a.m1130b()) {
            if (a.m278a()) {
                afVar = af.PORTRAIT;
            } else if (a.m279b() || !af.m277b(getContext()).m278a()) {
                afVar = af.LANDSCAPE;
            } else {
                afVar = af.PORTRAIT;
            }
            setRotationCount(0);
        } else {
            afVar = af.PORTRAIT;
            if (!a.m279b()) {
                setRotationCount(0);
            } else if (a.m280c() == 3) {
                setRotationCount(1);
            } else {
                setRotationCount(3);
            }
        }
        if (this.f1482c != afVar) {
            this.f1482c = afVar;
            this.f1481b.setLandscape(this.f1482c.m279b());
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
}
