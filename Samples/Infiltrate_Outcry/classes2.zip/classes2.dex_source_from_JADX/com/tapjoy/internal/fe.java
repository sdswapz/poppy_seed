package com.tapjoy.internal;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.tapjoy.TJConnectListener;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public abstract class fe {
    private final ReentrantLock f704a = new ReentrantLock();
    volatile int f705b = C0210c.f1061a;
    C0209b f706c;
    long f707d = 1000;
    C0206a f708e;
    private final Condition f709f = this.f704a.newCondition();
    private final LinkedList f710g = new LinkedList();
    private C0206a f711h;

    class C02031 implements Observer {
        final /* synthetic */ fe f1046a;

        C02031(fe feVar) {
            this.f1046a = feVar;
        }

        public final void update(Observable observable, Object data) {
            ev.f1014b.deleteObserver(this);
            if (!Boolean.valueOf(Boolean.TRUE.equals(data)).booleanValue() && this.f1046a.f708e != null && this.f1046a.f708e.f1049a != null) {
                this.f1046a.f706c = new C0209b();
                this.f1046a.f706c.mo120e();
            }
        }
    }

    class C02042 implements TJConnectListener {
        final /* synthetic */ fe f1047a;

        C02042(fe feVar) {
            this.f1047a = feVar;
        }

        public final void onConnectSuccess() {
            fe feVar = this.f1047a;
            int i = C0210c.f1065e;
            int i2 = C0210c.f1062b;
            feVar.m702a(i);
            this.f1047a.m703a(true);
        }

        public final void onConnectFailure() {
            this.f1047a.m703a(false);
        }
    }

    static /* synthetic */ class C02053 {
        static final /* synthetic */ int[] f1048a = new int[C0210c.m846a().length];

        static {
            try {
                f1048a[C0210c.f1065e - 1] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f1048a[C0210c.f1061a - 1] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f1048a[C0210c.f1062b - 1] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                f1048a[C0210c.f1063c - 1] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                f1048a[C0210c.f1064d - 1] = 5;
            } catch (NoSuchFieldError e5) {
            }
        }
    }

    class C0206a {
        public final Context f1049a;
        public final String f1050b;
        public final Hashtable f1051c;
        final /* synthetic */ fe f1052d;

        public C0206a(fe feVar, Context context, String str, Hashtable hashtable) {
            this.f1052d = feVar;
            Context context2 = null;
            if (context != null) {
                if (context instanceof Application) {
                    context2 = context;
                } else {
                    context2 = context.getApplicationContext();
                }
            }
            if (context2 != null) {
                context = context2;
            }
            this.f1049a = context;
            this.f1050b = str;
            this.f1051c = hashtable;
        }
    }

    class C0209b extends dd {
        final /* synthetic */ fe f1056a;
        private boolean f1057b;
        private boolean f1058c;
        private Context f1059d;
        private BroadcastReceiver f1060e;

        class C02082 extends BroadcastReceiver {
            final /* synthetic */ C0209b f1055a;

            C02082(C0209b c0209b) {
                this.f1055a = c0209b;
            }

            public final void onReceive(Context context, Intent intent) {
                this.f1055a.f1056a.m706b();
            }
        }

        private C0209b(fe feVar) {
            this.f1056a = feVar;
            this.f1060e = new C02082(this);
        }

        protected final void mo191d() {
            this.f1057b = true;
            this.f1056a.m706b();
        }

        protected final void mo188a() {
            fe feVar = this.f1056a;
            int i = C0210c.f1063c;
            int i2 = C0210c.f1062b;
            feVar.m702a(i);
        }

        protected final void mo190c() {
            if (this.f1056a.f706c == this) {
                this.f1056a.f706c = null;
            }
            if (this.f1056a.f705b == C0210c.f1063c) {
                fe feVar = this.f1056a;
                int i = C0210c.f1061a;
                int i2 = C0210c.f1063c;
                feVar.m702a(i);
            }
        }

        protected final void mo189b() {
            this.f1059d = this.f1056a.m701a().f1049a;
            this.f1059d.registerReceiver(this.f1060e, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
            while (!this.f1057b) {
                final CountDownLatch countDownLatch = new CountDownLatch(1);
                ev.f1014b.addObserver(new Observer(this) {
                    final /* synthetic */ C0209b f1054b;

                    public final void update(Observable observable, Object data) {
                        ev.f1014b.deleteObserver(this);
                        this.f1054b.f1058c = Boolean.TRUE.equals(data);
                        countDownLatch.countDown();
                    }
                });
                C0206a a = this.f1056a.m701a();
                if (this.f1056a.mo176a(a.f1049a, a.f1050b, a.f1051c, null)) {
                    try {
                        countDownLatch.await();
                    } catch (InterruptedException e) {
                    }
                    if (this.f1058c) {
                        fe feVar = this.f1056a;
                        int i = C0210c.f1065e;
                        int i2 = C0210c.f1063c;
                        feVar.m702a(i);
                        this.f1056a.m703a(true);
                        return;
                    }
                    try {
                        this.f1056a.m703a(false);
                        long max = Math.max(this.f1056a.f707d, 1000);
                        this.f1056a.f707d = Math.min(max << 2, 3600000);
                        this.f1056a.m704a(max);
                    } finally {
                        m841h();
                    }
                } else {
                    this.f1056a.m703a(false);
                    m841h();
                    return;
                }
            }
            m841h();
        }

        private void m841h() {
            this.f1059d.unregisterReceiver(this.f1060e);
        }
    }

    enum C0210c {
        ;

        public static int[] m846a() {
            return (int[]) f1066f.clone();
        }

        static {
            f1061a = 1;
            f1062b = 2;
            f1063c = 3;
            f1064d = 4;
            f1065e = 5;
            f1066f = new int[]{f1061a, f1062b, f1063c, f1064d, f1065e};
        }
    }

    public abstract boolean mo176a(Context context, String str, Hashtable hashtable, TJConnectListener tJConnectListener);

    public final boolean m707b(Context context, String str, Hashtable hashtable, TJConnectListener tJConnectListener) {
        this.f704a.lock();
        if (tJConnectListener != null) {
            try {
                this.f710g.addLast(eq.m791a(tJConnectListener, TJConnectListener.class));
            } catch (Throwable th) {
                this.f704a.unlock();
            }
        }
        C0206a c0206a = new C0206a(this, context, str, hashtable);
        switch (C02053.f1048a[this.f705b - 1]) {
            case 1:
                m703a(true);
                this.f704a.unlock();
                return true;
            case 2:
                this.f708e = c0206a;
                ev.f1014b.addObserver(new C02031(this));
                if (mo176a(c0206a.f1049a, c0206a.f1050b, c0206a.f1051c, new C02042(this))) {
                    int i = C0210c.f1062b;
                    int i2 = C0210c.f1061a;
                    m702a(i);
                    this.f704a.unlock();
                    return true;
                }
                this.f710g.clear();
                this.f704a.unlock();
                return false;
            case 3:
            case 4:
                this.f711h = c0206a;
                this.f704a.unlock();
                return true;
            case 5:
                this.f711h = c0206a;
                m706b();
                this.f704a.unlock();
                return true;
            default:
                m702a(C0210c.f1061a);
                this.f704a.unlock();
                return false;
        }
        this.f704a.unlock();
    }

    final void m702a(int i) {
        this.f704a.lock();
        try {
            int i2 = this.f705b;
            this.f705b = i;
        } finally {
            this.f704a.unlock();
        }
    }

    final C0206a m701a() {
        this.f704a.lock();
        try {
            if (this.f711h != null) {
                this.f708e = this.f711h;
                this.f711h = null;
            }
            C0206a c0206a = this.f708e;
            return c0206a;
        } finally {
            this.f704a.unlock();
        }
    }

    final void m703a(boolean z) {
        this.f704a.lock();
        try {
            if (this.f710g.size() != 0) {
                ArrayList arrayList = new ArrayList(this.f710g);
                this.f710g.clear();
                this.f704a.unlock();
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    TJConnectListener tJConnectListener = (TJConnectListener) it.next();
                    if (z) {
                        tJConnectListener.onConnectSuccess();
                    } else {
                        tJConnectListener.onConnectFailure();
                    }
                }
            }
        } finally {
            this.f704a.unlock();
        }
    }

    final void m706b() {
        this.f704a.lock();
        try {
            this.f707d = 1000;
            this.f709f.signal();
        } finally {
            this.f704a.unlock();
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    final boolean m704a(long r4) {
        /*
        r3 = this;
        r2 = 0;
        r0 = r3.f704a;
        r0.lock();
        r0 = com.tapjoy.internal.fe.C0210c.f1064d;	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        r1 = com.tapjoy.internal.fe.C0210c.f1063c;	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        r3.m702a(r0);	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        r0 = r3.f709f;	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        r1 = java.util.concurrent.TimeUnit.MILLISECONDS;	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        r0 = r0.await(r4, r1);	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
        if (r0 == 0) goto L_0x001b;
    L_0x0017:
        r0 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r3.f707d = r0;	 Catch:{ InterruptedException -> 0x0028, all -> 0x0036 }
    L_0x001b:
        r0 = com.tapjoy.internal.fe.C0210c.f1063c;
        r1 = com.tapjoy.internal.fe.C0210c.f1064d;
        r3.m702a(r0);
        r0 = r3.f704a;
        r0.unlock();
    L_0x0027:
        return r2;
    L_0x0028:
        r0 = move-exception;
        r0 = com.tapjoy.internal.fe.C0210c.f1063c;
        r1 = com.tapjoy.internal.fe.C0210c.f1064d;
        r3.m702a(r0);
        r0 = r3.f704a;
        r0.unlock();
        goto L_0x0027;
    L_0x0036:
        r0 = move-exception;
        r1 = com.tapjoy.internal.fe.C0210c.f1063c;
        r2 = com.tapjoy.internal.fe.C0210c.f1064d;
        r3.m702a(r1);
        r1 = r3.f704a;
        r1.unlock();
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tapjoy.internal.fe.a(long):boolean");
    }
}
