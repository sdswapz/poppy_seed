package com.tapjoy.internal;

import java.util.concurrent.Future;

public interface dh extends Future {
}
