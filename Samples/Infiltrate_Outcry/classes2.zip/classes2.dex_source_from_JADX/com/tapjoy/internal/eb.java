package com.tapjoy.internal;

public enum eb implements dq {
    APP(0),
    CAMPAIGN(1),
    CUSTOM(2),
    USAGES(3);
    
    public static final dn ADAPTER = null;
    private final int f800a;

    static final class C0172a extends dj {
        C0172a() {
            super(eb.class);
        }

        protected final /* bridge */ /* synthetic */ dq mo178a(int i) {
            return eb.m730a(i);
        }
    }

    static {
        ADAPTER = new C0172a();
    }

    private eb(int i) {
        this.f800a = i;
    }

    public static eb m730a(int i) {
        switch (i) {
            case 0:
                return APP;
            case 1:
                return CAMPAIGN;
            case 2:
                return CUSTOM;
            case 3:
                return USAGES;
            default:
                return null;
        }
    }

    public final int mo179a() {
        return this.f800a;
    }
}
