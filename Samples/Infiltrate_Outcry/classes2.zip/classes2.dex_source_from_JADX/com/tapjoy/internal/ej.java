package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;
import java.util.List;

public final class ej extends dl {
    public static final dn f905c = new C0188b();
    public final List f906d;

    public static final class C0187a extends C0149a {
        public List f904c = ds.m600a();

        public final ej m761b() {
            return new ej(this.f904c, super.m529a());
        }
    }

    static final class C0188b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            ej ejVar = (ej) obj;
            return dn.f662p.m514a().mo128a(1, ejVar.f906d) + ejVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ej ejVar = (ej) obj;
            dn.f662p.m514a().mo129a(dpVar, 1, ejVar.f906d);
            dpVar.m593a(ejVar.m530a());
        }

        C0188b() {
            super(dk.LENGTH_DELIMITED, ej.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0187a c0187a = new C0187a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0187a.f904c.add(dn.f662p.mo126a(c0160do));
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0187a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0187a.m761b();
            }
        }
    }

    public ej(List list) {
        this(list, hy.f1496b);
    }

    public ej(List list, hy hyVar) {
        super(f905c, hyVar);
        this.f906d = ds.m601a("elements", list);
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ej)) {
            return false;
        }
        ej ejVar = (ej) other;
        if (m530a().equals(ejVar.m530a()) && this.f906d.equals(ejVar.f906d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (m530a().hashCode() * 37) + this.f906d.hashCode();
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (!this.f906d.isEmpty()) {
            stringBuilder.append(", elements=").append(this.f906d);
        }
        return stringBuilder.replace(0, 2, "StringList{").append('}').toString();
    }
}
