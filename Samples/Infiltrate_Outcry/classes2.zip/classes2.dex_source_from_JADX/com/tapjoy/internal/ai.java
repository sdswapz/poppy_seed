package com.tapjoy.internal;

import android.view.animation.Animation;

public class ai {
    protected final Animation f486a;

    public static /* synthetic */ class C01231 {
        public static final /* synthetic */ int[] f480a = new int[C0124a.m283a().length];

        static {
            try {
                f480a[C0124a.f481a - 1] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                f480a[C0124a.f482b - 1] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                f480a[C0124a.f483c - 1] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                f480a[C0124a.f484d - 1] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public enum C0124a {
        ;

        public static int[] m283a() {
            return (int[]) f485e.clone();
        }

        static {
            f481a = 1;
            f482b = 2;
            f483c = 3;
            f484d = 4;
            f485e = new int[]{f481a, f482b, f483c, f484d};
        }
    }

    public ai(Animation animation) {
        this.f486a = animation;
        animation.setDuration(400);
    }

    public Animation mo87a() {
        return this.f486a;
    }

    public final ai m285b() {
        this.f486a.setDuration(600);
        return this;
    }
}
