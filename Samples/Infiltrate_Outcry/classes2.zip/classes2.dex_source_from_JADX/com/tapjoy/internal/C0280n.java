package com.tapjoy.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public final class C0280n extends C0276o {
    private final long f1541c = 0;

    public C0280n(SharedPreferences sharedPreferences, String str) {
        super(sharedPreferences, str);
    }

    public final long m1330a() {
        return this.a.getLong(this.b, this.f1541c);
    }

    public final void m1333a(long j) {
        this.a.edit().putLong(this.b, j).commit();
    }

    public final Editor m1331a(Editor editor) {
        return editor.remove(this.b);
    }

    public final Editor m1332a(Editor editor, long j) {
        return editor.putLong(this.b, j);
    }
}
