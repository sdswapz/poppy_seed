package com.tapjoy.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import java.nio.ByteBuffer;

public final class hk extends ImageView implements Runnable {
    private hg f1429a;
    private Bitmap f1430b;
    private final Handler f1431c = new Handler(Looper.getMainLooper());
    private boolean f1432d;
    private boolean f1433e;
    private boolean f1434f;
    private Thread f1435g;
    private C0267b f1436h = null;
    private long f1437i = -1;
    private C0266a f1438j = null;
    private final Runnable f1439k = new C02641(this);
    private final Runnable f1440l = new C02652(this);

    class C02641 implements Runnable {
        final /* synthetic */ hk f1427a;

        C02641(hk hkVar) {
            this.f1427a = hkVar;
        }

        public final void run() {
            if (this.f1427a.f1430b != null && !this.f1427a.f1430b.isRecycled()) {
                this.f1427a.setImageBitmap(this.f1427a.f1430b);
            }
        }
    }

    class C02652 implements Runnable {
        final /* synthetic */ hk f1428a;

        C02652(hk hkVar) {
            this.f1428a = hkVar;
        }

        public final void run() {
            this.f1428a.f1430b = null;
            this.f1428a.f1429a = null;
            this.f1428a.f1435g = null;
            this.f1428a.f1434f = false;
        }
    }

    public interface C0266a {
    }

    public interface C0267b {
        Bitmap m1172a();
    }

    public hk(Context context) {
        super(context);
    }

    public final void m1181a(hi hiVar, byte[] bArr) {
        try {
            this.f1429a = new hg(new hl(), hiVar, ByteBuffer.wrap(bArr));
            if (this.f1432d) {
                m1178e();
            } else {
                m1177d();
            }
        } catch (Exception e) {
            this.f1429a = null;
            new Object[1][0] = e;
        }
    }

    public final void setBytes(byte[] bytes) {
        this.f1429a = new hg();
        try {
            this.f1429a.m1160a(bytes);
            if (this.f1432d) {
                m1178e();
            } else {
                m1177d();
            }
        } catch (Exception e) {
            this.f1429a = null;
            new Object[1][0] = e;
        }
    }

    public final long getFramesDisplayDuration() {
        return this.f1437i;
    }

    public final void setFramesDisplayDuration(long framesDisplayDuration) {
        this.f1437i = framesDisplayDuration;
    }

    public final void m1180a() {
        this.f1432d = true;
        m1178e();
    }

    public final void m1182b() {
        this.f1432d = false;
        if (this.f1435g != null) {
            this.f1435g.interrupt();
            this.f1435g = null;
        }
    }

    private void m1177d() {
        if (this.f1429a.f1375a != 0) {
            boolean z;
            hg hgVar = this.f1429a;
            if (-1 >= hgVar.f1377c.f1412c) {
                z = false;
            } else {
                hgVar.f1375a = -1;
                z = true;
            }
            if (z && !this.f1432d) {
                this.f1433e = true;
                m1178e();
            }
        }
    }

    public final void m1183c() {
        this.f1432d = false;
        this.f1433e = false;
        this.f1434f = true;
        m1182b();
        this.f1431c.post(this.f1440l);
    }

    public final int getGifWidth() {
        return this.f1429a.f1377c.f1415f;
    }

    public final int getGifHeight() {
        return this.f1429a.f1377c.f1416g;
    }

    public final void run() {
        ArrayIndexOutOfBoundsException e;
        IllegalArgumentException e2;
        do {
            if (!this.f1432d && !this.f1433e) {
                break;
            }
            long nanoTime;
            hg hgVar = this.f1429a;
            boolean z;
            if (hgVar.f1377c.f1412c <= 0) {
                z = false;
            } else {
                if (hgVar.f1375a == hgVar.f1377c.f1412c - 1) {
                    hgVar.f1376b++;
                }
                if (hgVar.f1377c.f1422m == -1 || hgVar.f1376b <= hgVar.f1377c.f1422m) {
                    hgVar.f1375a = (hgVar.f1375a + 1) % hgVar.f1377c.f1412c;
                    z = true;
                } else {
                    z = false;
                }
            }
            try {
                nanoTime = System.nanoTime();
                this.f1430b = this.f1429a.m1161a();
                if (this.f1436h != null) {
                    this.f1430b = this.f1436h.m1172a();
                }
                nanoTime = (System.nanoTime() - nanoTime) / 1000000;
                try {
                    this.f1431c.post(this.f1439k);
                } catch (ArrayIndexOutOfBoundsException e3) {
                    e = e3;
                    new Object[1][0] = e;
                    this.f1433e = false;
                    if (this.f1432d) {
                    }
                    this.f1432d = false;
                    if (this.f1434f) {
                        this.f1431c.post(this.f1440l);
                    }
                    this.f1435g = null;
                } catch (IllegalArgumentException e4) {
                    e2 = e4;
                    new Object[1][0] = e2;
                    this.f1433e = false;
                    if (this.f1432d) {
                    }
                    this.f1432d = false;
                    if (this.f1434f) {
                        this.f1431c.post(this.f1440l);
                    }
                    this.f1435g = null;
                }
            } catch (ArrayIndexOutOfBoundsException e5) {
                e = e5;
                nanoTime = 0;
                new Object[1][0] = e;
                this.f1433e = false;
                if (this.f1432d) {
                }
                this.f1432d = false;
                if (this.f1434f) {
                    this.f1431c.post(this.f1440l);
                }
                this.f1435g = null;
            } catch (IllegalArgumentException e6) {
                e2 = e6;
                nanoTime = 0;
                new Object[1][0] = e2;
                this.f1433e = false;
                if (this.f1432d) {
                }
                this.f1432d = false;
                if (this.f1434f) {
                    this.f1431c.post(this.f1440l);
                }
                this.f1435g = null;
            }
            this.f1433e = false;
            if (this.f1432d || !r0) {
                this.f1432d = false;
                break;
            }
            try {
                int i;
                hgVar = this.f1429a;
                if (hgVar.f1377c.f1412c <= 0 || hgVar.f1375a < 0) {
                    i = 0;
                } else {
                    int i2 = hgVar.f1375a;
                    if (i2 < 0 || i2 >= hgVar.f1377c.f1412c) {
                        i = -1;
                    } else {
                        i = ((hh) hgVar.f1377c.f1414e.get(i2)).f1407i;
                    }
                }
                i = (int) (((long) i) - nanoTime);
                if (i > 0) {
                    Thread.sleep(this.f1437i > 0 ? this.f1437i : (long) i);
                }
            } catch (InterruptedException e7) {
            }
        } while (this.f1432d);
        if (this.f1434f) {
            this.f1431c.post(this.f1440l);
        }
        this.f1435g = null;
    }

    public final C0267b getOnFrameAvailable() {
        return this.f1436h;
    }

    public final void setOnFrameAvailable(C0267b frameProcessor) {
        this.f1436h = frameProcessor;
    }

    public final C0266a getOnAnimationStop() {
        return this.f1438j;
    }

    public final void setOnAnimationStop(C0266a animationStop) {
        this.f1438j = animationStop;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m1183c();
    }

    private void m1178e() {
        Object obj;
        if ((this.f1432d || this.f1433e) && this.f1429a != null && this.f1435g == null) {
            obj = 1;
        } else {
            obj = null;
        }
        if (obj != null) {
            this.f1435g = new Thread(this);
            this.f1435g.start();
        }
    }
}
