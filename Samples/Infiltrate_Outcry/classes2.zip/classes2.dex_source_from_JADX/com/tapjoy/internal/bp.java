package com.tapjoy.internal;

public interface bp {
    Object mo98a(String str);

    void mo99a(String str, Object obj);
}
