package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;
import java.util.Map;

public final class hp extends hm {
    private final ed f1452c;
    private final dx f1453d;
    private final ek f1454e;
    private final String f1455f;

    private hp(ed edVar, dx dxVar, ek ekVar, String str) {
        this.f1452c = edVar;
        this.f1453d = dxVar;
        this.f1454e = ekVar;
        this.f1455f = str;
    }

    public hp(ee eeVar, String str) {
        this(eeVar.f849d, eeVar.f850e, eeVar.f851f, str);
    }

    public final String mo252c() {
        return "api/v1/tokens";
    }

    public final Map mo250e() {
        Map e = super.mo250e();
        e.put(String.VIDEO_INFO, new br(gt.m1113a(this.f1452c)));
        e.put(TapjoyConstants.TJC_APP_PLACEMENT, new br(gt.m1109a(this.f1453d)));
        e.put("user", new br(gt.m1114a(this.f1454e)));
        if (!aq.m292a(this.f1455f)) {
            e.put("push_token", this.f1455f);
        }
        return e;
    }
}
