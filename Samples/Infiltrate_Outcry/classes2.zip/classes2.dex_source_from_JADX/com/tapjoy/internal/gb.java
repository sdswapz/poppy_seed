package com.tapjoy.internal;

import java.io.File;
import java.util.concurrent.TimeUnit;

public final class gb implements Runnable {
    final gp f1144a;
    ci f1145b;
    private final Object f1146c = this.f1144a;
    private final Thread f1147d;
    private boolean f1148e;

    class C02251 extends hq {
        final /* synthetic */ gb f1143a;

        C02251(gb gbVar) {
            this.f1143a = gbVar;
        }

        protected final boolean mo207a() {
            return !this.f1143a.f1144a.m1100c();
        }
    }

    public gb(File file) {
        this.f1144a = new gp(file);
        new Object[1][0] = Integer.valueOf(this.f1144a.m1098b());
        this.f1147d = new Thread(this, "5Rocks");
        this.f1147d.start();
    }

    public final void run() {
        Object obj;
        Object[] objArr;
        int i = 1;
        while (true) {
            long j = 0;
            while (this.f1145b != null && this.f1144a.m1098b() > 0 && j <= 0) {
                try {
                    if (this.f1144a.m1098b() > 10000) {
                        this.f1144a.m1097a(this.f1144a.m1098b() - 10000);
                    }
                    dy b = this.f1144a.m1099b(0);
                    if (b == null) {
                        break;
                    }
                    ek ekVar = b.f783w;
                    if (ekVar != null && ekVar.f955G == null) {
                        gr.f1285c.await(3, TimeUnit.SECONDS);
                    }
                    if (!C0289y.m1353c()) {
                        gr.f1284b.await(3, TimeUnit.SECONDS);
                    }
                    if (this.f1148e || b.f774n == eb.APP || this.f1144a.m1098b() >= 100 || b.f776p.longValue() > System.currentTimeMillis()) {
                        j = 0;
                    } else {
                        j = Math.min(Math.max((b.f776p.longValue() + 60000) - System.currentTimeMillis(), 0), 60000);
                    }
                    if (j <= 0) {
                        cf hoVar = new ho();
                        hoVar.m1196a(b);
                        new Object[1][0] = b;
                        int i2 = 1;
                        while (i2 < 100 && i2 < this.f1144a.m1098b()) {
                            dy b2 = this.f1144a.m1099b(i2);
                            if (b2 == null || !hoVar.m1196a(b2)) {
                                break;
                            }
                            new Object[1][0] = b2;
                            i2++;
                        }
                        try {
                            Object[] objArr2 = new Object[]{Integer.valueOf(hoVar.m1199g()), Integer.valueOf(i + 1)};
                            this.f1145b.mo119a(hoVar);
                            this.f1144a.m1097a(hoVar.m1199g());
                        } catch (Exception e) {
                            obj = e;
                            i = i2;
                            objArr = new Object[]{Integer.valueOf(hoVar.m1199g()), obj};
                            j = 300000;
                        } catch (InterruptedException e2) {
                            return;
                        }
                        try {
                            new Object[1][0] = Integer.valueOf(hoVar.m1199g());
                            i = 0;
                        } catch (Exception e3) {
                            Exception exception = e3;
                            i = 0;
                            objArr = new Object[]{Integer.valueOf(hoVar.m1199g()), obj};
                            j = 300000;
                        } catch (InterruptedException e22) {
                            return;
                        }
                    }
                } catch (InterruptedException e222) {
                    return;
                } catch (Exception e4) {
                    return;
                }
            }
            this.f1144a.flush();
            if (j > 0) {
                synchronized (this.f1146c) {
                    this.f1148e = false;
                    new Object[1][0] = Long.valueOf(j);
                    this.f1146c.wait(j);
                }
            } else {
                synchronized (this.f1146c) {
                    this.f1148e = false;
                    if (this.f1145b == null || this.f1144a.m1100c()) {
                        this.f1146c.wait();
                    }
                }
            }
        }
    }

    final void m947a(boolean z) {
        synchronized (this.f1146c) {
            this.f1148e = z;
            this.f1146c.notify();
        }
    }

    public final void m946a() {
        if (this.f1145b != null && !this.f1144a.m1100c()) {
            m947a(true);
        }
    }
}
