package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJPlacementListener;

@ew
public class TapjoyNative {
    @ew
    public static Object createPlacement(Context context, String placementName, TJPlacementListener listener) {
        return ff.m847a().mo192a(context, placementName, listener);
    }
}
