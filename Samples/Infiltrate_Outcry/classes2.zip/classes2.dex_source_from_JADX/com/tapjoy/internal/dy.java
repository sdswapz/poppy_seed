package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.internal.dl.C0149a;
import com.tapjoy.internal.dn.C0159a;
import java.util.List;

public final class dy extends dl {
    public static final dn f751c = new C0166b();
    public static final eb f752d = eb.APP;
    public static final Long f753e = Long.valueOf(0);
    public static final Long f754f = Long.valueOf(0);
    public static final Long f755g = Long.valueOf(0);
    public static final Long f756h = Long.valueOf(0);
    public static final Integer f757i = Integer.valueOf(0);
    public static final Integer f758j = Integer.valueOf(0);
    public static final Integer f759k = Integer.valueOf(0);
    public static final Long f760l = Long.valueOf(0);
    public static final Long f761m = Long.valueOf(0);
    public final eg f762A;
    public final String f763B;
    public final String f764C;
    public final ef f765D;
    public final String f766E;
    public final String f767F;
    public final String f768G;
    public final List f769H;
    public final String f770I;
    public final Integer f771J;
    public final Long f772K;
    public final Long f773L;
    public final eb f774n;
    public final String f775o;
    public final Long f776p;
    public final Long f777q;
    public final String f778r;
    public final Long f779s;
    public final Long f780t;
    public final ed f781u;
    public final dx f782v;
    public final ek f783w;
    public final Integer f784x;
    public final Integer f785y;
    public final ea f786z;

    public static final class C0165a extends C0149a {
        public Long f726A;
        public eb f727c;
        public String f728d;
        public Long f729e;
        public Long f730f;
        public String f731g;
        public Long f732h;
        public Long f733i;
        public ed f734j;
        public dx f735k;
        public ek f736l;
        public Integer f737m;
        public Integer f738n;
        public ea f739o;
        public eg f740p;
        public String f741q;
        public String f742r;
        public ef f743s;
        public String f744t;
        public String f745u;
        public String f746v;
        public List f747w = ds.m600a();
        public String f748x;
        public Integer f749y;
        public Long f750z;

        public final dy m715b() {
            if (this.f727c != null && this.f728d != null && this.f729e != null) {
                return new dy(this.f727c, this.f728d, this.f729e, this.f730f, this.f731g, this.f732h, this.f733i, this.f734j, this.f735k, this.f736l, this.f737m, this.f738n, this.f739o, this.f740p, this.f741q, this.f742r, this.f743s, this.f744t, this.f745u, this.f746v, this.f747w, this.f748x, this.f749y, this.f750z, this.f726A, super.m529a());
            }
            throw ds.m599a(this.f727c, "type", this.f728d, String.USAGE_TRACKER_NAME, this.f729e, "time");
        }
    }

    static final class C0166b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            dy dyVar = (dy) obj;
            int a2 = (dn.f655i.mo128a(3, dyVar.f776p) + (eb.ADAPTER.mo128a(1, dyVar.f774n) + dn.f662p.mo128a(2, dyVar.f775o))) + (dyVar.f777q != null ? dn.f655i.mo128a(19, dyVar.f777q) : 0);
            if (dyVar.f778r != null) {
                a = dn.f662p.mo128a(20, dyVar.f778r);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f779s != null) {
                a = dn.f655i.mo128a(21, dyVar.f779s);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f780t != null) {
                a = dn.f655i.mo128a(4, dyVar.f780t);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f781u != null) {
                a = ed.f824c.mo128a(5, dyVar.f781u);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f782v != null) {
                a = dx.f719c.mo128a(6, dyVar.f782v);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f783w != null) {
                a = ek.f933c.mo128a(7, dyVar.f783w);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f784x != null) {
                a = dn.f650d.mo128a(8, dyVar.f784x);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f785y != null) {
                a = dn.f650d.mo128a(9, dyVar.f785y);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f786z != null) {
                a = ea.f794c.mo128a(10, dyVar.f786z);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f762A != null) {
                a = eg.f873c.mo128a(11, dyVar.f762A);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f763B != null) {
                a = dn.f662p.mo128a(12, dyVar.f763B);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f764C != null) {
                a = dn.f662p.mo128a(13, dyVar.f764C);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f765D != null) {
                a = ef.f855c.mo128a(18, dyVar.f765D);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f766E != null) {
                a = dn.f662p.mo128a(14, dyVar.f766E);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f767F != null) {
                a = dn.f662p.mo128a(15, dyVar.f767F);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f768G != null) {
                a = dn.f662p.mo128a(16, dyVar.f768G);
            } else {
                a = 0;
            }
            a2 = ec.f803c.m514a().mo128a(17, dyVar.f769H) + (a + a2);
            if (dyVar.f770I != null) {
                a = dn.f662p.mo128a(22, dyVar.f770I);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f771J != null) {
                a = dn.f650d.mo128a(23, dyVar.f771J);
            } else {
                a = 0;
            }
            a2 += a;
            if (dyVar.f772K != null) {
                a = dn.f655i.mo128a(24, dyVar.f772K);
            } else {
                a = 0;
            }
            a += a2;
            if (dyVar.f773L != null) {
                i = dn.f655i.mo128a(25, dyVar.f773L);
            }
            return (a + i) + dyVar.m530a().mo277c();
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return C0166b.m716b(c0160do);
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dy dyVar = (dy) obj;
            eb.ADAPTER.mo129a(dpVar, 1, dyVar.f774n);
            dn.f662p.mo129a(dpVar, 2, dyVar.f775o);
            dn.f655i.mo129a(dpVar, 3, dyVar.f776p);
            if (dyVar.f777q != null) {
                dn.f655i.mo129a(dpVar, 19, dyVar.f777q);
            }
            if (dyVar.f778r != null) {
                dn.f662p.mo129a(dpVar, 20, dyVar.f778r);
            }
            if (dyVar.f779s != null) {
                dn.f655i.mo129a(dpVar, 21, dyVar.f779s);
            }
            if (dyVar.f780t != null) {
                dn.f655i.mo129a(dpVar, 4, dyVar.f780t);
            }
            if (dyVar.f781u != null) {
                ed.f824c.mo129a(dpVar, 5, dyVar.f781u);
            }
            if (dyVar.f782v != null) {
                dx.f719c.mo129a(dpVar, 6, dyVar.f782v);
            }
            if (dyVar.f783w != null) {
                ek.f933c.mo129a(dpVar, 7, dyVar.f783w);
            }
            if (dyVar.f784x != null) {
                dn.f650d.mo129a(dpVar, 8, dyVar.f784x);
            }
            if (dyVar.f785y != null) {
                dn.f650d.mo129a(dpVar, 9, dyVar.f785y);
            }
            if (dyVar.f786z != null) {
                ea.f794c.mo129a(dpVar, 10, dyVar.f786z);
            }
            if (dyVar.f762A != null) {
                eg.f873c.mo129a(dpVar, 11, dyVar.f762A);
            }
            if (dyVar.f763B != null) {
                dn.f662p.mo129a(dpVar, 12, dyVar.f763B);
            }
            if (dyVar.f764C != null) {
                dn.f662p.mo129a(dpVar, 13, dyVar.f764C);
            }
            if (dyVar.f765D != null) {
                ef.f855c.mo129a(dpVar, 18, dyVar.f765D);
            }
            if (dyVar.f766E != null) {
                dn.f662p.mo129a(dpVar, 14, dyVar.f766E);
            }
            if (dyVar.f767F != null) {
                dn.f662p.mo129a(dpVar, 15, dyVar.f767F);
            }
            if (dyVar.f768G != null) {
                dn.f662p.mo129a(dpVar, 16, dyVar.f768G);
            }
            ec.f803c.m514a().mo129a(dpVar, 17, dyVar.f769H);
            if (dyVar.f770I != null) {
                dn.f662p.mo129a(dpVar, 22, dyVar.f770I);
            }
            if (dyVar.f771J != null) {
                dn.f650d.mo129a(dpVar, 23, dyVar.f771J);
            }
            if (dyVar.f772K != null) {
                dn.f655i.mo129a(dpVar, 24, dyVar.f772K);
            }
            if (dyVar.f773L != null) {
                dn.f655i.mo129a(dpVar, 25, dyVar.f773L);
            }
            dpVar.m593a(dyVar.m530a());
        }

        C0166b() {
            super(dk.LENGTH_DELIMITED, dy.class);
        }

        private static dy m716b(C0160do c0160do) {
            C0165a c0165a = new C0165a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            try {
                                c0165a.f727c = (eb) eb.ADAPTER.mo126a(c0160do);
                                break;
                            } catch (C0159a e) {
                                c0165a.m527a(b, dk.VARINT, Long.valueOf((long) e.f681a));
                                break;
                            }
                        case 2:
                            c0165a.f728d = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 3:
                            c0165a.f729e = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 4:
                            c0165a.f733i = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 5:
                            c0165a.f734j = (ed) ed.f824c.mo126a(c0160do);
                            break;
                        case 6:
                            c0165a.f735k = (dx) dx.f719c.mo126a(c0160do);
                            break;
                        case 7:
                            c0165a.f736l = (ek) ek.f933c.mo126a(c0160do);
                            break;
                        case 8:
                            c0165a.f737m = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 9:
                            c0165a.f738n = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 10:
                            c0165a.f739o = (ea) ea.f794c.mo126a(c0160do);
                            break;
                        case 11:
                            c0165a.f740p = (eg) eg.f873c.mo126a(c0160do);
                            break;
                        case 12:
                            c0165a.f741q = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 13:
                            c0165a.f742r = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 14:
                            c0165a.f744t = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 15:
                            c0165a.f745u = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 16:
                            c0165a.f746v = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 17:
                            c0165a.f747w.add(ec.f803c.mo126a(c0160do));
                            break;
                        case 18:
                            c0165a.f743s = (ef) ef.f855c.mo126a(c0160do);
                            break;
                        case 19:
                            c0165a.f730f = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 20:
                            c0165a.f731g = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 21:
                            c0165a.f732h = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 22:
                            c0165a.f748x = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 23:
                            c0165a.f749y = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 24:
                            c0165a.f750z = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 25:
                            c0165a.f726A = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0165a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0165a.m715b();
            }
        }
    }

    public dy(eb ebVar, String str, Long l, Long l2, String str2, Long l3, Long l4, ed edVar, dx dxVar, ek ekVar, Integer num, Integer num2, ea eaVar, eg egVar, String str3, String str4, ef efVar, String str5, String str6, String str7, List list, String str8, Integer num3, Long l5, Long l6, hy hyVar) {
        super(f751c, hyVar);
        this.f774n = ebVar;
        this.f775o = str;
        this.f776p = l;
        this.f777q = l2;
        this.f778r = str2;
        this.f779s = l3;
        this.f780t = l4;
        this.f781u = edVar;
        this.f782v = dxVar;
        this.f783w = ekVar;
        this.f784x = num;
        this.f785y = num2;
        this.f786z = eaVar;
        this.f762A = egVar;
        this.f763B = str3;
        this.f764C = str4;
        this.f765D = efVar;
        this.f766E = str5;
        this.f767F = str6;
        this.f768G = str7;
        this.f769H = ds.m601a(String.USAGE_TRACKER_VALUES, list);
        this.f770I = str8;
        this.f771J = num3;
        this.f772K = l5;
        this.f773L = l6;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof dy)) {
            return false;
        }
        dy dyVar = (dy) other;
        if (m530a().equals(dyVar.m530a()) && this.f774n.equals(dyVar.f774n) && this.f775o.equals(dyVar.f775o) && this.f776p.equals(dyVar.f776p) && ds.m602a(this.f777q, dyVar.f777q) && ds.m602a(this.f778r, dyVar.f778r) && ds.m602a(this.f779s, dyVar.f779s) && ds.m602a(this.f780t, dyVar.f780t) && ds.m602a(this.f781u, dyVar.f781u) && ds.m602a(this.f782v, dyVar.f782v) && ds.m602a(this.f783w, dyVar.f783w) && ds.m602a(this.f784x, dyVar.f784x) && ds.m602a(this.f785y, dyVar.f785y) && ds.m602a(this.f786z, dyVar.f786z) && ds.m602a(this.f762A, dyVar.f762A) && ds.m602a(this.f763B, dyVar.f763B) && ds.m602a(this.f764C, dyVar.f764C) && ds.m602a(this.f765D, dyVar.f765D) && ds.m602a(this.f766E, dyVar.f766E) && ds.m602a(this.f767F, dyVar.f767F) && ds.m602a(this.f768G, dyVar.f768G) && this.f769H.equals(dyVar.f769H) && ds.m602a(this.f770I, dyVar.f770I) && ds.m602a(this.f771J, dyVar.f771J) && ds.m602a(this.f772K, dyVar.f772K) && ds.m602a(this.f773L, dyVar.f773L)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f777q != null ? this.f777q.hashCode() : 0) + (((((((m530a().hashCode() * 37) + this.f774n.hashCode()) * 37) + this.f775o.hashCode()) * 37) + this.f776p.hashCode()) * 37)) * 37;
        if (this.f778r != null) {
            i2 = this.f778r.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f779s != null) {
            i2 = this.f779s.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f780t != null) {
            i2 = this.f780t.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f781u != null) {
            i2 = this.f781u.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f782v != null) {
            i2 = this.f782v.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f783w != null) {
            i2 = this.f783w.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f784x != null) {
            i2 = this.f784x.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f785y != null) {
            i2 = this.f785y.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f786z != null) {
            i2 = this.f786z.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f762A != null) {
            i2 = this.f762A.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f763B != null) {
            i2 = this.f763B.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f764C != null) {
            i2 = this.f764C.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f765D != null) {
            i2 = this.f765D.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f766E != null) {
            i2 = this.f766E.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f767F != null) {
            i2 = this.f767F.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f768G != null) {
            i2 = this.f768G.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (((i2 + hashCode) * 37) + this.f769H.hashCode()) * 37;
        if (this.f770I != null) {
            i2 = this.f770I.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f771J != null) {
            i2 = this.f771J.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f772K != null) {
            i2 = this.f772K.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f773L != null) {
            i = this.f773L.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", type=").append(this.f774n);
        stringBuilder.append(", name=").append(this.f775o);
        stringBuilder.append(", time=").append(this.f776p);
        if (this.f777q != null) {
            stringBuilder.append(", systemTime=").append(this.f777q);
        }
        if (this.f778r != null) {
            stringBuilder.append(", instanceId=").append(this.f778r);
        }
        if (this.f779s != null) {
            stringBuilder.append(", elapsedRealtime=").append(this.f779s);
        }
        if (this.f780t != null) {
            stringBuilder.append(", duration=").append(this.f780t);
        }
        if (this.f781u != null) {
            stringBuilder.append(", info=").append(this.f781u);
        }
        if (this.f782v != null) {
            stringBuilder.append(", app=").append(this.f782v);
        }
        if (this.f783w != null) {
            stringBuilder.append(", user=").append(this.f783w);
        }
        if (this.f784x != null) {
            stringBuilder.append(", xxx_session_seq=").append(this.f784x);
        }
        if (this.f785y != null) {
            stringBuilder.append(", eventSeq=").append(this.f785y);
        }
        if (this.f786z != null) {
            stringBuilder.append(", eventPrev=").append(this.f786z);
        }
        if (this.f762A != null) {
            stringBuilder.append(", purchase=").append(this.f762A);
        }
        if (this.f763B != null) {
            stringBuilder.append(", exception=").append(this.f763B);
        }
        if (this.f764C != null) {
            stringBuilder.append(", metaBase=").append(this.f764C);
        }
        if (this.f765D != null) {
            stringBuilder.append(", meta=").append(this.f765D);
        }
        if (this.f766E != null) {
            stringBuilder.append(", category=").append(this.f766E);
        }
        if (this.f767F != null) {
            stringBuilder.append(", p1=").append(this.f767F);
        }
        if (this.f768G != null) {
            stringBuilder.append(", p2=").append(this.f768G);
        }
        if (!this.f769H.isEmpty()) {
            stringBuilder.append(", values=").append(this.f769H);
        }
        if (this.f770I != null) {
            stringBuilder.append(", dimensions=").append(this.f770I);
        }
        if (this.f771J != null) {
            stringBuilder.append(", count=").append(this.f771J);
        }
        if (this.f772K != null) {
            stringBuilder.append(", firstTime=").append(this.f772K);
        }
        if (this.f773L != null) {
            stringBuilder.append(", lastTime=").append(this.f773L);
        }
        return stringBuilder.replace(0, 2, "Event{").append('}').toString();
    }
}
