package com.tapjoy.internal;

import android.view.animation.Animation;
import android.view.animation.AnimationSet;

public final class aj extends ai {
    private final AnimationSet f487b = ((AnimationSet) this.a);

    public aj() {
        super(new AnimationSet(true));
    }

    public final aj m287a(Animation animation) {
        this.f487b.addAnimation(animation);
        return this;
    }

    public final /* bridge */ /* synthetic */ Animation mo87a() {
        return this.f487b;
    }
}
