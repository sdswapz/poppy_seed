package com.tapjoy.internal;

import android.graphics.Point;
import android.os.SystemClock;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public final class gy extends gu {
    public static final bn f1315n = new C02551();
    public hb f1316a;
    public hb f1317b;
    public hb f1318c;
    public Point f1319d;
    public hb f1320e;
    public hb f1321f;
    public String f1322g;
    public fp f1323h;
    public ArrayList f1324i = new ArrayList();
    public ArrayList f1325j = new ArrayList();
    public Map f1326k;
    public long f1327l;
    public gz f1328m;

    static class C02551 implements bn {
        C02551() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            return new gy(bsVar);
        }
    }

    gy(bs bsVar) {
        Iterator it;
        gw gwVar;
        bsVar.mo105h();
        String str = null;
        String str2 = null;
        while (bsVar.mo107j()) {
            String l = bsVar.mo109l();
            if ("frame".equals(l)) {
                bsVar.mo105h();
                while (bsVar.mo107j()) {
                    l = bsVar.mo109l();
                    if ("portrait".equals(l)) {
                        this.f1316a = (hb) hb.f1343e.mo97a(bsVar);
                    } else if (String.LANDSCAPE.equals(l)) {
                        this.f1317b = (hb) hb.f1343e.mo97a(bsVar);
                    } else if ("close_button".equals(l)) {
                        this.f1318c = (hb) hb.f1343e.mo97a(bsVar);
                    } else if ("close_button_offset".equals(l)) {
                        this.f1319d = (Point) bo.f542a.mo97a(bsVar);
                    } else {
                        bsVar.mo116s();
                    }
                }
                bsVar.mo106i();
            } else if ("creative".equals(l)) {
                bsVar.mo105h();
                while (bsVar.mo107j()) {
                    l = bsVar.mo109l();
                    if ("portrait".equals(l)) {
                        this.f1320e = (hb) hb.f1343e.mo97a(bsVar);
                    } else if (String.LANDSCAPE.equals(l)) {
                        this.f1321f = (hb) hb.f1343e.mo97a(bsVar);
                    } else {
                        bsVar.mo116s();
                    }
                }
                bsVar.mo106i();
            } else if (String.URL.equals(l)) {
                this.f1322g = bsVar.m377b();
            } else if (gs.m1107a(l)) {
                this.f1323h = gs.m1106a(l, bsVar);
            } else if ("mappings".equals(l)) {
                bsVar.mo105h();
                while (bsVar.mo107j()) {
                    l = bsVar.mo109l();
                    if ("portrait".equals(l)) {
                        bsVar.m374a(this.f1324i, gw.f1295h);
                    } else if (String.LANDSCAPE.equals(l)) {
                        bsVar.m374a(this.f1325j, gw.f1295h);
                    } else {
                        bsVar.mo116s();
                    }
                }
                bsVar.mo106i();
            } else if ("meta".equals(l)) {
                this.f1326k = bsVar.m380d();
            } else if ("ttl".equals(l)) {
                this.f1327l = ((long) (bsVar.mo113p() * 1000.0d)) + SystemClock.elapsedRealtime();
            } else if ("no_more_today".equals(l)) {
                this.f1328m = (gz) gz.f1329d.mo97a(bsVar);
            } else if ("ad_content".equals(l)) {
                str = bsVar.m377b();
            } else if (TapjoyConstants.TJC_REDIRECT_URL.equals(l)) {
                str2 = bsVar.m377b();
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
        if (this.f1322g == null) {
            this.f1322g = "";
        }
        if (this.f1324i != null) {
            it = this.f1324i.iterator();
            while (it.hasNext()) {
                gwVar = (gw) it.next();
                if (gwVar.f1301f == null) {
                    gwVar.f1301f = str;
                }
                if (gwVar.f1300e == null) {
                    gwVar.f1300e = str2;
                }
            }
        }
        if (this.f1325j != null) {
            it = this.f1325j.iterator();
            while (it.hasNext()) {
                gwVar = (gw) it.next();
                if (gwVar.f1301f == null) {
                    gwVar.f1301f = str;
                }
                if (gwVar.f1300e == null) {
                    gwVar.f1300e = str2;
                }
            }
        }
    }

    public final boolean m1129a() {
        return (this.f1318c == null || this.f1316a == null || this.f1320e == null) ? false : true;
    }

    public final boolean m1130b() {
        return (this.f1318c == null || this.f1317b == null || this.f1321f == null) ? false : true;
    }
}
