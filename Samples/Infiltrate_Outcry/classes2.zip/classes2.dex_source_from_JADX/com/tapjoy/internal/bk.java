package com.tapjoy.internal;

import java.io.OutputStream;

public interface bk {
    void mo235a(OutputStream outputStream, Object obj);
}
