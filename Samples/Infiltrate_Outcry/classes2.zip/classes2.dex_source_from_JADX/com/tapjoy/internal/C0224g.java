package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;

public final class C0224g {
    public String f1134a;
    public String f1135b;
    public String f1136c;
    public String f1137d;
    public String f1138e;
    public String f1139f;
    public long f1140g;

    public C0224g(String str) {
        bs b = bs.m367b(str);
        b.mo105h();
        while (b.mo107j()) {
            String l = b.mo109l();
            if ("productId".equals(l)) {
                this.f1134a = b.mo110m();
            } else if ("type".equals(l)) {
                this.f1135b = b.mo110m();
            } else if ("price".equals(l)) {
                this.f1136c = b.mo110m();
            } else if (String.TITLE.equals(l)) {
                this.f1137d = b.mo110m();
            } else if ("description".equals(l)) {
                this.f1138e = b.mo110m();
            } else if ("price_currency_code".equals(l)) {
                this.f1139f = b.mo110m();
            } else if ("price_amount_micros".equals(l)) {
                this.f1140g = b.mo114q();
            } else {
                b.mo116s();
            }
        }
        b.mo106i();
    }
}
