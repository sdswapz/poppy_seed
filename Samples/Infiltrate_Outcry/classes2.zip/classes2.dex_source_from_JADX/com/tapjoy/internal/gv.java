package com.tapjoy.internal;

import com.tapjoy.TapjoyConstants;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public final class gv extends gu {
    public static final bn f1291d = new C02501();
    public ArrayList f1292a = new ArrayList();
    public Map f1293b;
    public float f1294c;

    static class C02501 implements bn {
        C02501() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            return new gv(bsVar);
        }
    }

    public gv(bs bsVar) {
        bsVar.mo105h();
        String str = null;
        String str2 = null;
        while (bsVar.mo107j()) {
            String l = bsVar.mo109l();
            if ("layouts".equals(l)) {
                bsVar.m374a(this.f1292a, he.f1368d);
            } else if ("meta".equals(l)) {
                this.f1293b = bsVar.m380d();
            } else if ("max_show_time".equals(l)) {
                this.f1294c = (float) bsVar.mo113p();
            } else if ("ad_content".equals(l)) {
                str2 = bsVar.m377b();
            } else if (TapjoyConstants.TJC_REDIRECT_URL.equals(l)) {
                str = bsVar.m377b();
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
        if (this.f1292a != null) {
            Iterator it = this.f1292a.iterator();
            while (it.hasNext()) {
                he heVar = (he) it.next();
                if (heVar.f1371c != null) {
                    Iterator it2 = heVar.f1371c.iterator();
                    while (it2.hasNext()) {
                        hd hdVar = (hd) it2.next();
                        if (hdVar.f1363i == null) {
                            hdVar.f1363i = str2;
                        }
                        if (hdVar.f1362h == null) {
                            hdVar.f1362h = str;
                        }
                    }
                }
            }
        }
    }
}
