package com.tapjoy.internal;

public final class cs {
    public static void m460a(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }

    public static Object m459a(Object obj) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException();
    }
}
