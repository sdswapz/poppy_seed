package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;
import java.util.List;
import java.util.Map;

public final class hn extends hm {
    public final String f1443c;
    public boolean f1444d = false;
    private final gd f1445e;
    private final ed f1446f;
    private final dx f1447g;
    private final ek f1448h;
    private Context f1449i;

    public static class C0268a {
        public gk f1441a;
        public final List f1442b;

        public C0268a(gk gkVar, List list) {
            this.f1441a = gkVar;
            this.f1442b = list;
        }
    }

    protected final /* synthetic */ Object mo247a(bs bsVar) {
        bsVar.mo105h();
        List list = null;
        gv gvVar = null;
        gy gyVar = null;
        while (bsVar.mo107j()) {
            String l = bsVar.mo109l();
            if ("interstitial".equals(l)) {
                gyVar = (gy) bsVar.m371a(gy.f1315n);
            } else if ("contextual_button".equals(l)) {
                gvVar = (gv) bsVar.m371a(gv.f1291d);
            } else if ("enabled_placements".equals(l)) {
                list = bsVar.m379c();
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
        if (gyVar != null && (gyVar.m1129a() || gyVar.m1130b())) {
            return new C0268a(new gi(this.f1445e, this.f1443c, gyVar, this.f1449i), list);
        }
        if (gvVar != null) {
            return new C0268a(new fz(this.f1445e, this.f1443c, gvVar, this.f1449i), list);
        }
        return new C0268a(new gj(), list);
    }

    public hn(gd gdVar, ed edVar, dx dxVar, ek ekVar, String str, Context context) {
        this.f1445e = gdVar;
        this.f1446f = edVar;
        this.f1447g = dxVar;
        this.f1448h = ekVar;
        this.f1443c = str;
        this.f1449i = context;
    }

    public final String mo252c() {
        return "placement";
    }

    public final Map mo250e() {
        Map e = super.mo250e();
        e.put(String.VIDEO_INFO, new br(gt.m1113a(this.f1446f)));
        e.put(TapjoyConstants.TJC_APP_PLACEMENT, new br(gt.m1109a(this.f1447g)));
        e.put("user", new br(gt.m1114a(this.f1448h)));
        e.put("placement", this.f1443c);
        return e;
    }

    protected final /* synthetic */ Object mo251f() {
        C0268a c0268a = (C0268a) super.mo251f();
        if (!(c0268a.f1441a instanceof gj)) {
            c0268a.f1441a.mo204a();
            if (!c0268a.f1441a.mo206b()) {
                new Object[1][0] = this.f1443c;
                c0268a.f1441a = new gj();
            }
        }
        return c0268a;
    }
}
