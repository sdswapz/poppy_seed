package com.tapjoy.internal;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

public final class bl {
    public static String m323a(File file, Charset charset) {
        Closeable fileInputStream = new FileInputStream(file);
        try {
            String a = db.m480a(new InputStreamReader(fileInputStream, charset));
            return a;
        } finally {
            dc.m481a(fileInputStream);
        }
    }

    public static void m324a(File file, String str) {
        OutputStream fileOutputStream = new FileOutputStream(file);
        try {
            m325a(fileOutputStream, str);
        } finally {
            dc.m481a(fileOutputStream);
        }
    }

    public static void m325a(OutputStream outputStream, String str) {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, ap.f518c);
        outputStreamWriter.write(str);
        outputStreamWriter.flush();
    }

    public static String m322a(File file) {
        try {
            return m323a(file, ap.f518c);
        } catch (IOException e) {
            return null;
        }
    }
}
