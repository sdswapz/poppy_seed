package com.tapjoy.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import com.tapjoy.internal.hg.C0263a;

final class hl implements C0263a {
    hl() {
    }

    public final Bitmap mo244a(int i, int i2, Config config) {
        return Bitmap.createBitmap(i, i2, config);
    }

    public final byte[] mo245a(int i) {
        return new byte[i];
    }

    public final int[] mo246b(int i) {
        return new int[i];
    }
}
