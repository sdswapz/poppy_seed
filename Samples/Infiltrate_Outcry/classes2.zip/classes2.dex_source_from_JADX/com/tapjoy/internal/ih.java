package com.tapjoy.internal;

import java.io.InterruptedIOException;

public class ih {
    public static final ih f1525a = new C02751();
    private boolean f1526b;
    private long f1527c;

    static class C02751 extends ih {
        C02751() {
        }

        public final void mo282a() {
        }
    }

    public void mo282a() {
        if (Thread.interrupted()) {
            throw new InterruptedIOException("thread interrupted");
        } else if (this.f1526b && this.f1527c - System.nanoTime() <= 0) {
            throw new InterruptedIOException("deadline reached");
        }
    }
}
