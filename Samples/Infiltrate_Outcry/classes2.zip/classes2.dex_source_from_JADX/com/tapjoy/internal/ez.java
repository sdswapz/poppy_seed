package com.tapjoy.internal;

import com.tapjoy.internal.fj.C0215a;

public final class ez {
    public et f1020a;
    public volatile C0215a f1021b;
    public int f1022c;
    public volatile C0215a f1023d;
    public volatile C0215a f1024e;

    public final void m809a() {
        m810a(16);
        C0215a c0215a = this.f1023d;
        if (c0215a != null) {
            this.f1023d = null;
            c0215a.m866b().m869c();
        }
    }

    public final synchronized void m810a(int i) {
        C0215a c0215a = this.f1021b;
        if (c0215a != null && this.f1022c < i) {
            this.f1022c |= i;
            c0215a.m864a("state", Integer.valueOf(this.f1022c)).m866b().m869c();
        }
    }
}
