package com.tapjoy.internal;

import java.util.Collection;

public final class cv {
    static final cq f612a = new cq(", ");

    public static Collection m466a(Iterable iterable) {
        return (Collection) iterable;
    }
}
