package com.tapjoy.internal;

import com.tapjoy.internal.dz.C0167a;
import java.util.Map;

public final class ho extends hm {
    private final C0167a f1450c = new C0167a();
    private eb f1451d = null;

    public final String mo252c() {
        return this.f1451d == eb.USAGES ? "api/v1/usages" : "api/v1/cevs";
    }

    public final boolean m1196a(dy dyVar) {
        if (this.f1451d == null) {
            this.f1451d = dyVar.f774n;
        } else if (dyVar.f774n != this.f1451d) {
            return false;
        }
        this.f1450c.f787c.add(dyVar);
        return true;
    }

    public final int m1199g() {
        return this.f1450c.f787c.size();
    }

    public final Map mo250e() {
        Map e = super.mo250e();
        e.put("events", new br(gt.m1111a(this.f1450c.m720b())));
        return e;
    }
}
