package com.tapjoy.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager.BadTokenException;
import android.widget.FrameLayout;
import com.tapjoy.TJContentActivity;
import com.tapjoy.internal.hs.C0221a;
import java.util.Iterator;

public final class fz extends gk {
    public static fz f1121a;
    final gd f1122b;
    final String f1123c;
    final gv f1124d;
    private boolean f1125e;
    private boolean f1126f;
    private long f1127g;
    private Context f1128m;
    private hs f1129n;
    private Activity f1130o;
    private ge f1131p;
    private Handler f1132q;
    private Runnable f1133r;

    public static class C02201 implements Runnable {
        final /* synthetic */ fz f1111a;

        public C02201(fz fzVar) {
            this.f1111a = fzVar;
        }

        public final void run() {
            fz.m932a(this.f1111a);
        }
    }

    class C02233 implements Runnable {
        final /* synthetic */ fz f1115a;

        C02233(fz fzVar) {
            this.f1115a = fzVar;
        }

        public final void run() {
            fz.m932a(this.f1115a);
        }
    }

    static /* synthetic */ void m932a(fz fzVar) {
        if (fzVar.f1126f) {
            fzVar.f1126f = false;
            if (fzVar.f1132q != null) {
                fzVar.f1132q.removeCallbacks(fzVar.f1133r);
                fzVar.f1133r = null;
                fzVar.f1132q = null;
            }
            if (f1121a == fzVar) {
                f1121a = null;
            }
            fzVar.f1122b.m967a(fzVar.f1124d.f1293b, SystemClock.elapsedRealtime() - fzVar.f1127g);
            if (!(fzVar.i || fzVar.f1131p == null)) {
                fzVar.f1131p.mo38a(fzVar.f1123c, fzVar.k, null);
                fzVar.f1131p = null;
            }
            ViewGroup viewGroup = (ViewGroup) fzVar.f1129n.getParent();
            if (viewGroup != null) {
                viewGroup.removeView(fzVar.f1129n);
            }
            fzVar.f1129n = null;
            if (fzVar.f1130o instanceof TJContentActivity) {
                fzVar.f1130o.finish();
            }
            fzVar.f1130o = null;
        }
    }

    public fz(gd gdVar, String str, gv gvVar, Context context) {
        this.f1122b = gdVar;
        this.f1123c = str;
        this.f1124d = gvVar;
        this.f1128m = context;
    }

    public final void mo204a() {
        Iterator it = this.f1124d.f1292a.iterator();
        while (it.hasNext()) {
            Iterator it2 = ((he) it.next()).f1371c.iterator();
            while (it2.hasNext()) {
                hd hdVar = (hd) it2.next();
                if (hdVar.f1366l != null) {
                    hdVar.f1366l.m1139b();
                }
                if (hdVar.f1367m != null) {
                    hdVar.f1367m.m1139b();
                }
            }
        }
    }

    public final boolean mo206b() {
        Iterator it = this.f1124d.f1292a.iterator();
        boolean z = true;
        while (it.hasNext()) {
            Iterator it2 = ((he) it.next()).f1371c.iterator();
            while (it2.hasNext()) {
                hd hdVar = (hd) it2.next();
                if ((hdVar.f1366l != null && !hdVar.f1366l.m1138a()) || (hdVar.f1367m != null && !hdVar.f1367m.m1138a())) {
                    z = false;
                    continue;
                    break;
                }
            }
            z = true;
            continue;
            if (!z) {
                return false;
            }
        }
        return z;
    }

    public final void mo205a(ge geVar, ez ezVar) {
        this.f1131p = geVar;
        this.f1130o = fv.m915a();
        if (!(this.f1130o == null || this.f1130o.isFinishing())) {
            try {
                m931a(this.f1130o, geVar, ezVar);
                new Object[1][0] = this.f1123c;
                return;
            } catch (BadTokenException e) {
            }
        }
        this.f1130o = C0136c.m436a(this.f1128m);
        if (!(this.f1130o == null || this.f1130o.isFinishing())) {
            try {
                m931a(this.f1130o, geVar, ezVar);
                new Object[1][0] = this.f1123c;
                return;
            } catch (BadTokenException e2) {
            }
        }
        ga.m942b("Failed to show the content for \"{}\". No usable activity found.", this.f1123c);
        geVar.mo38a(this.f1123c, this.k, null);
    }

    private void m931a(final Activity activity, final ge geVar, ez ezVar) {
        cs.m460a(!this.f1125e);
        this.f1125e = true;
        this.f1126f = true;
        f1121a = this;
        this.l = ezVar.f1020a;
        this.f1129n = new hs(activity, this.f1124d, new C0221a(this) {
            final /* synthetic */ fz f1114c;

            public final void mo203a(hd hdVar) {
                if (this.f1114c.l instanceof ey) {
                    ey eyVar = (ey) this.f1114c.l;
                    if (!(eyVar == null || eyVar.f1019c == null)) {
                        eyVar.f1019c.m781a();
                    }
                }
                this.f1114c.f1122b.m968a(this.f1114c.f1124d.f1293b, hdVar.f1365k);
                if (!ct.m463c(hdVar.f1362h)) {
                    this.f1114c.j.mo68a(activity, hdVar.f1362h, ct.m462b(hdVar.f1363i));
                    this.f1114c.i = true;
                } else if (!ct.m463c(hdVar.f1361g)) {
                    gk.m927a(activity, hdVar.f1361g);
                }
                geVar.mo37a(this.f1114c.f1123c, null);
                if (hdVar.f1364j) {
                    fz.m932a(this.f1114c);
                }
            }

            public final void mo202a() {
                fz.m932a(this.f1114c);
            }
        });
        Window window = activity.getWindow();
        View view = this.f1129n;
        LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1, 17);
        Callback callback = window.getCallback();
        window.setCallback(null);
        window.addContentView(view, layoutParams);
        window.setCallback(callback);
        this.f1127g = SystemClock.elapsedRealtime();
        this.f1122b.m966a(this.f1124d.f1293b);
        ezVar.m809a();
        et etVar = this.l;
        if (etVar != null) {
            etVar.m784b();
        }
        geVar.mo40c(this.f1123c);
        if (this.f1124d.f1294c > 0.0f) {
            this.f1132q = new Handler(Looper.getMainLooper());
            this.f1133r = new C02233(this);
            this.f1132q.postDelayed(this.f1133r, (long) (this.f1124d.f1294c * 1000.0f));
        }
    }
}
