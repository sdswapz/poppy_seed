package com.tapjoy.internal;

final class id {
    static ic f1521a;
    static long f1522b;

    private id() {
    }

    static ic m1289a() {
        synchronized (id.class) {
            if (f1521a != null) {
                ic icVar = f1521a;
                f1521a = icVar.f1519f;
                icVar.f1519f = null;
                f1522b -= 8192;
                return icVar;
            }
            return new ic();
        }
    }

    static void m1290a(ic icVar) {
        if (icVar.f1519f != null || icVar.f1520g != null) {
            throw new IllegalArgumentException();
        } else if (!icVar.f1517d) {
            synchronized (id.class) {
                if (f1522b + 8192 > 65536) {
                    return;
                }
                f1522b += 8192;
                icVar.f1519f = f1521a;
                icVar.f1516c = 0;
                icVar.f1515b = 0;
                f1521a = icVar;
            }
        }
    }
}
