package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TJPlacementManager;

public final class eu {
    private static final fc f1012a = new C01971();

    static class C01971 extends fc {
        C01971() {
        }

        protected final /* bridge */ /* synthetic */ String mo181a(Object obj) {
            return "InsufficientCurrency";
        }

        protected final /* synthetic */ TJPlacement mo180a(Context context, TJPlacementListener tJPlacementListener, Object obj) {
            return TJPlacementManager.createPlacement(context, "InsufficientCurrency", true, tJPlacementListener);
        }
    }

    public static void m808a() {
        f1012a.m798c(null);
    }
}
