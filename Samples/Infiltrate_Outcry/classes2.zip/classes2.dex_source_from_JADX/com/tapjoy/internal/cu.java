package com.tapjoy.internal;

public final class cu {
    private static void m465a(Throwable th, Class cls) {
        if (th != null && cls.isInstance(th)) {
            throw ((Throwable) cls.cast(th));
        }
    }

    public static RuntimeException m464a(Throwable th) {
        Throwable th2 = (Throwable) cs.m459a((Object) th);
        m465a(th2, Error.class);
        m465a(th2, RuntimeException.class);
        throw new RuntimeException(th);
    }
}
