package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;

public final class ee extends dl {
    public static final dn f848c = new C0178b();
    public final ed f849d;
    public final dx f850e;
    public final ek f851f;

    public static final class C0177a extends C0149a {
        public ed f845c;
        public dx f846d;
        public ek f847e;

        public final ee m740b() {
            return new ee(this.f845c, this.f846d, this.f847e, super.m529a());
        }
    }

    static final class C0178b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            ee eeVar = (ee) obj;
            int a2 = eeVar.f849d != null ? ed.f824c.mo128a(1, eeVar.f849d) : 0;
            if (eeVar.f850e != null) {
                a = dx.f719c.mo128a(2, eeVar.f850e);
            } else {
                a = 0;
            }
            a2 += a;
            if (eeVar.f851f != null) {
                i = ek.f933c.mo128a(3, eeVar.f851f);
            }
            return (a2 + i) + eeVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ee eeVar = (ee) obj;
            if (eeVar.f849d != null) {
                ed.f824c.mo129a(dpVar, 1, eeVar.f849d);
            }
            if (eeVar.f850e != null) {
                dx.f719c.mo129a(dpVar, 2, eeVar.f850e);
            }
            if (eeVar.f851f != null) {
                ek.f933c.mo129a(dpVar, 3, eeVar.f851f);
            }
            dpVar.m593a(eeVar.m530a());
        }

        C0178b() {
            super(dk.LENGTH_DELIMITED, ee.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0177a c0177a = new C0177a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0177a.f845c = (ed) ed.f824c.mo126a(c0160do);
                            break;
                        case 2:
                            c0177a.f846d = (dx) dx.f719c.mo126a(c0160do);
                            break;
                        case 3:
                            c0177a.f847e = (ek) ek.f933c.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0177a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0177a.m740b();
            }
        }
    }

    public ee(ed edVar, dx dxVar, ek ekVar) {
        this(edVar, dxVar, ekVar, hy.f1496b);
    }

    public ee(ed edVar, dx dxVar, ek ekVar, hy hyVar) {
        super(f848c, hyVar);
        this.f849d = edVar;
        this.f850e = dxVar;
        this.f851f = ekVar;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ee)) {
            return false;
        }
        ee eeVar = (ee) other;
        if (m530a().equals(eeVar.m530a()) && ds.m602a(this.f849d, eeVar.f849d) && ds.m602a(this.f850e, eeVar.f850e) && ds.m602a(this.f851f, eeVar.f851f)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f849d != null ? this.f849d.hashCode() : 0) + (m530a().hashCode() * 37)) * 37;
        if (this.f850e != null) {
            i2 = this.f850e.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f851f != null) {
            i = this.f851f.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.f849d != null) {
            stringBuilder.append(", info=").append(this.f849d);
        }
        if (this.f850e != null) {
            stringBuilder.append(", app=").append(this.f850e);
        }
        if (this.f851f != null) {
            stringBuilder.append(", user=").append(this.f851f);
        }
        return stringBuilder.replace(0, 2, "InfoSet{").append('}').toString();
    }
}
