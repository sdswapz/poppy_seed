package com.tapjoy.internal;

import android.os.Handler;
import android.os.Looper;

public class ge implements fs {
    private static final ge f1180a = new C02271();
    private final fs f1181b;
    private final bf f1182c;

    static class C02271 extends ge {
        C02271() {
            super();
        }

        public final void mo36a(String str) {
        }

        public final void mo39b(String str) {
        }

        public final void mo40c(String str) {
        }

        public final void mo41d(String str) {
        }

        public final void mo37a(String str, fp fpVar) {
        }

        public final void mo38a(String str, String str2, fp fpVar) {
        }
    }

    public static ge m978a(fs fsVar) {
        Object obj;
        if (fsVar instanceof ge) {
            obj = null;
        } else {
            obj = 1;
        }
        if (obj == null) {
            throw new IllegalArgumentException();
        } else if (fsVar != null) {
            return new ge(fsVar);
        } else {
            return f1180a;
        }
    }

    private ge() {
        this.f1181b = null;
        this.f1182c = null;
    }

    private ge(fs fsVar) {
        Handler a;
        this.f1181b = fsVar;
        Looper myLooper = Looper.myLooper();
        if (myLooper != null) {
            cs.m459a((Object) myLooper);
            a = myLooper == Looper.getMainLooper() ? C0288x.m1347a() : new Handler(myLooper);
        } else {
            a = null;
        }
        if (a != null) {
            this.f1182c = C0288x.m1348a(a);
            new Object[1][0] = a.getLooper();
        } else if (Thread.currentThread() == fv.m917b()) {
            this.f1182c = fv.f1107a;
        } else {
            this.f1182c = C0288x.m1348a(C0288x.m1347a());
        }
    }

    public void mo36a(final String str) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1184b;

            public final void run() {
                this.f1184b.f1181b.mo36a(str);
            }
        });
    }

    public void mo39b(final String str) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1186b;

            public final void run() {
                this.f1186b.f1181b.mo39b(str);
            }
        });
    }

    public void mo40c(final String str) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1188b;

            public final void run() {
                this.f1188b.f1181b.mo40c(str);
            }
        });
    }

    public void mo41d(final String str) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1190b;

            public final void run() {
                this.f1190b.f1181b.mo41d(str);
            }
        });
    }

    public void mo37a(final String str, final fp fpVar) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1193c;

            public final void run() {
                this.f1193c.f1181b.mo37a(str, fpVar);
            }
        });
    }

    public void mo38a(final String str, final String str2, final fp fpVar) {
        this.f1182c.mo201a(new Runnable(this) {
            final /* synthetic */ ge f1197d;

            public final void run() {
                this.f1197d.f1181b.mo38a(str, str2, fpVar);
            }
        });
    }
}
