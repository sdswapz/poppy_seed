package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;

public final class ef extends dl {
    public static final dn f855c = new C0180b();
    public final String f856d;
    public final String f857e;
    public final String f858f;

    public static final class C0179a extends C0149a {
        public String f852c;
        public String f853d;
        public String f854e;

        public final ef m744b() {
            return new ef(this.f852c, this.f853d, this.f854e, super.m529a());
        }
    }

    static final class C0180b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            ef efVar = (ef) obj;
            int a2 = efVar.f856d != null ? dn.f662p.mo128a(1, efVar.f856d) : 0;
            if (efVar.f857e != null) {
                a = dn.f662p.mo128a(2, efVar.f857e);
            } else {
                a = 0;
            }
            a2 += a;
            if (efVar.f858f != null) {
                i = dn.f662p.mo128a(3, efVar.f858f);
            }
            return (a2 + i) + efVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ef efVar = (ef) obj;
            if (efVar.f856d != null) {
                dn.f662p.mo129a(dpVar, 1, efVar.f856d);
            }
            if (efVar.f857e != null) {
                dn.f662p.mo129a(dpVar, 2, efVar.f857e);
            }
            if (efVar.f858f != null) {
                dn.f662p.mo129a(dpVar, 3, efVar.f858f);
            }
            dpVar.m593a(efVar.m530a());
        }

        C0180b() {
            super(dk.LENGTH_DELIMITED, ef.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0179a c0179a = new C0179a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0179a.f852c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0179a.f853d = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 3:
                            c0179a.f854e = (String) dn.f662p.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0179a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0179a.m744b();
            }
        }
    }

    public ef(String str, String str2, String str3) {
        this(str, str2, str3, hy.f1496b);
    }

    public ef(String str, String str2, String str3, hy hyVar) {
        super(f855c, hyVar);
        this.f856d = str;
        this.f857e = str2;
        this.f858f = str3;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ef)) {
            return false;
        }
        ef efVar = (ef) other;
        if (m530a().equals(efVar.m530a()) && ds.m602a(this.f856d, efVar.f856d) && ds.m602a(this.f857e, efVar.f857e) && ds.m602a(this.f858f, efVar.f858f)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f856d != null ? this.f856d.hashCode() : 0) + (m530a().hashCode() * 37)) * 37;
        if (this.f857e != null) {
            i2 = this.f857e.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (i2 + hashCode) * 37;
        if (this.f858f != null) {
            i = this.f858f.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.f856d != null) {
            stringBuilder.append(", fq7Change=").append(this.f856d);
        }
        if (this.f857e != null) {
            stringBuilder.append(", fq30Change=").append(this.f857e);
        }
        if (this.f858f != null) {
            stringBuilder.append(", pushId=").append(this.f858f);
        }
        return stringBuilder.replace(0, 2, "Meta{").append('}').toString();
    }
}
