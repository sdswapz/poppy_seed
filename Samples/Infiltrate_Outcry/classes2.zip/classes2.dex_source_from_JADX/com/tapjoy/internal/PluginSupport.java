package com.tapjoy.internal;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@ew
public final class PluginSupport {
    private PluginSupport() {
    }

    @ew
    public static void trackUsage(String name, String dimensions, String values) {
        Map map = null;
        bs b;
        try {
            TreeMap treeMap;
            if (aq.m292a(dimensions)) {
                treeMap = null;
            } else {
                treeMap = new TreeMap();
                b = bs.m367b(dimensions);
                b.m375a((Map) treeMap);
                b.close();
            }
            if (!aq.m292a(values)) {
                map = new HashMap();
                b = bs.m367b(values);
                b.mo105h();
                while (b.mo107j()) {
                    map.put(b.mo109l(), Long.valueOf(b.mo114q()));
                }
                b.mo106i();
                b.close();
            }
            fj.m874a(name, treeMap, map);
        } catch (Exception e) {
        } catch (Throwable th) {
            b.close();
        }
    }
}
