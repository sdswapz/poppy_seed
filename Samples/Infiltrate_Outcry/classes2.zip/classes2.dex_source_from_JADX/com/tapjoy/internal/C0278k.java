package com.tapjoy.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public final class C0278k extends C0276o {
    private final double f1539c = 0.0d;

    public C0278k(SharedPreferences sharedPreferences, String str) {
        super(sharedPreferences, str);
    }

    public final double m1322a() {
        String string = this.a.getString(this.b, null);
        if (string != null) {
            try {
                return Double.parseDouble(string);
            } catch (NumberFormatException e) {
            }
        }
        return this.f1539c;
    }

    public final Editor m1323a(Editor editor) {
        return editor.remove(this.b);
    }

    public final Editor m1324a(Editor editor, double d) {
        return editor.putString(this.b, Double.toString(d));
    }
}
