package com.tapjoy.internal;

public final class ex extends et {
    public final ep f1018c;

    public ex(String str, String str2, ep epVar) {
        super(str, str2, "mm");
        m783a("content_card", "m2e");
        this.f1018c = epVar;
    }
}
