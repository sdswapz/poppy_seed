package com.tapjoy.internal;

import android.content.SharedPreferences.Editor;
import android.os.SystemClock;
import com.tapjoy.internal.dy.C0165a;
import com.tapjoy.internal.ea.C0170a;
import com.tapjoy.internal.eg.C0181a;
import java.util.Map;
import java.util.Map.Entry;

public final class gc {
    final gg f1149a;
    final gb f1150b;
    long f1151c;
    private int f1152d = 1;
    private final C0170a f1153e = new C0170a();

    gc(gg ggVar, gb gbVar) {
        this.f1149a = ggVar;
        this.f1150b = gbVar;
    }

    public final void m950a(String str, String str2, double d, String str3, String str4, String str5) {
        gg ggVar = this.f1149a;
        synchronized (ggVar) {
            int b;
            double a;
            Editor a2 = ggVar.f1206c.m1091a();
            if (str2.equals(ggVar.f1206c.f1253l.m1338a())) {
                b = ggVar.f1206c.f1254m.m1329b() + 1;
                ggVar.f1206c.f1254m.m1325a(a2, b);
                a = ggVar.f1206c.f1255n.m1322a() + d;
                ggVar.f1206c.f1255n.m1324a(a2, a);
                a2.commit();
            } else {
                ggVar.f1206c.f1253l.m1337a(a2, str2);
                ggVar.f1206c.f1254m.m1325a(a2, 1);
                ggVar.f1206c.f1255n.m1324a(a2, d);
                ggVar.f1206c.f1256o.m1331a(a2);
                ggVar.f1206c.f1257p.m1323a(a2);
                a2.commit();
                ggVar.f1205b.f918l = str2;
                ggVar.f1205b.f921o = null;
                ggVar.f1205b.f922p = null;
                b = 1;
                a = d;
            }
            ggVar.f1205b.f919m = Integer.valueOf(b);
            ggVar.f1205b.f920n = Double.valueOf(a);
        }
        C0165a a3 = m948a(eb.APP, "purchase");
        C0181a c0181a = new C0181a();
        c0181a.f859c = str;
        if (str2 != null) {
            c0181a.f862f = str2;
        }
        c0181a.f861e = Double.valueOf(d);
        if (str5 != null) {
            c0181a.f869m = str5;
        }
        if (str3 != null) {
            c0181a.f871o = str3;
        }
        if (str4 != null) {
            c0181a.f872p = str4;
        }
        a3.f740p = c0181a.m748b();
        m949a(a3);
        gg ggVar2 = this.f1149a;
        long longValue = a3.f729e.longValue();
        synchronized (ggVar2) {
            Editor a4 = ggVar2.f1206c.m1091a();
            ggVar2.f1206c.f1256o.m1332a(a4, longValue);
            ggVar2.f1206c.f1257p.m1324a(a4, d);
            a4.commit();
            ggVar2.f1205b.f921o = Long.valueOf(longValue);
            ggVar2.f1205b.f922p = Double.valueOf(d);
        }
    }

    public final void m952a(String str, String str2, String str3, String str4, Map map) {
        C0165a a = m948a(eb.CUSTOM, str2);
        a.f744t = str;
        a.f745u = str3;
        a.f746v = str4;
        if (map != null) {
            for (Entry entry : map.entrySet()) {
                a.f747w.add(new ec((String) entry.getKey(), (Long) entry.getValue()));
            }
        }
        m949a(a);
    }

    public final void m951a(String str, String str2, int i, long j, long j2, Map map) {
        C0165a a = m948a(eb.USAGES, str);
        a.f748x = str2;
        a.f749y = Integer.valueOf(i);
        a.f750z = Long.valueOf(j);
        a.f726A = Long.valueOf(j2);
        if (map != null) {
            for (Entry entry : map.entrySet()) {
                a.f747w.add(new ec((String) entry.getKey(), (Long) entry.getValue()));
            }
        }
        m949a(a);
    }

    public final C0165a m948a(eb ebVar, String str) {
        ee b = this.f1149a.m1060b();
        C0165a c0165a = new C0165a();
        c0165a.f731g = gg.f1203a;
        c0165a.f727c = ebVar;
        c0165a.f728d = str;
        if (C0289y.m1353c()) {
            c0165a.f729e = Long.valueOf(C0289y.m1352b());
            c0165a.f730f = Long.valueOf(System.currentTimeMillis());
        } else {
            c0165a.f729e = Long.valueOf(System.currentTimeMillis());
            c0165a.f732h = Long.valueOf(SystemClock.elapsedRealtime());
        }
        c0165a.f734j = b.f849d;
        c0165a.f735k = b.f850e;
        c0165a.f736l = b.f851f;
        return c0165a;
    }

    public final synchronized void m949a(C0165a c0165a) {
        if (c0165a.f727c != eb.USAGES) {
            int i = this.f1152d;
            this.f1152d = i + 1;
            c0165a.f738n = Integer.valueOf(i);
            if (this.f1153e.f791c != null) {
                c0165a.f739o = this.f1153e.m724b();
            }
            this.f1153e.f791c = c0165a.f727c;
            this.f1153e.f792d = c0165a.f728d;
            this.f1153e.f793e = c0165a.f744t;
        }
        gb gbVar = this.f1150b;
        dy b = c0165a.m715b();
        try {
            gp gpVar = gbVar.f1144a;
            synchronized (gpVar.f1273a) {
                try {
                    gpVar.f1274b.add(b);
                } catch (Exception e) {
                    gpVar.m1096a();
                    try {
                        gpVar.f1274b.add(b);
                    } catch (Exception e2) {
                    }
                }
            }
            if (gbVar.f1145b == null) {
                gbVar.f1144a.flush();
            } else if (ga.f1141a || b.f774n != eb.CUSTOM) {
                gbVar.m947a(true);
            } else {
                gbVar.m947a(false);
            }
        } catch (Exception e3) {
        }
    }
}
