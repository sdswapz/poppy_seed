package com.tapjoy.internal;

public abstract class av implements as {
    protected abstract at mo93a(Object obj, boolean z);

    public final Object mo91a(Object obj) {
        at a = mo93a(obj, false);
        return a != null ? a.mo89a() : null;
    }

    public void mo92a(Object obj, Object obj2) {
        mo93a(obj, true).mo90a(obj2);
    }
}
