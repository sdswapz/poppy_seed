package com.tapjoy.internal;

final class hh {
    int f1399a;
    int f1400b;
    int f1401c;
    int f1402d;
    boolean f1403e;
    boolean f1404f;
    int f1405g;
    int f1406h;
    int f1407i;
    int f1408j;
    int[] f1409k;

    hh() {
    }
}
