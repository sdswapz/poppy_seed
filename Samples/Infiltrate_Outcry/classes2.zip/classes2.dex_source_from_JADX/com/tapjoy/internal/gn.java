package com.tapjoy.internal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.tapjoy.TapjoyConstants;
import java.io.File;
import java.io.IOException;

public final class gn {
    final C0282q f1238A = new C0282q(this.f1243b, "idfa");
    final C0277j f1239B = new C0277j(this.f1243b, "idfa.optout");
    final C0277j f1240C = new C0277j(this.f1243b, "push.optout");
    final C0282q f1241D = new C0282q(this.f1243b, "appId");
    final Context f1242a;
    final SharedPreferences f1243b;
    final C0282q f1244c = new C0282q(this.f1243b, TapjoyConstants.TJC_SDK_PLACEMENT);
    final C0282q f1245d = new C0282q(this.f1243b, "ir");
    final C0279m f1246e = new C0279m(this.f1243b, "fql", 0);
    final C0279m f1247f = new C0279m(this.f1243b, "fq", 0);
    final C0282q f1248g = new C0282q(this.f1243b, "push");
    final C0279m f1249h = new C0279m(this.f1243b, "ss", 0);
    final C0280n f1250i = new C0280n(this.f1243b, "std");
    final C0280n f1251j = new C0280n(this.f1243b, "slt");
    final C0280n f1252k = new C0280n(this.f1243b, "sld");
    final C0282q f1253l = new C0282q(this.f1243b, "ptc");
    final C0279m f1254m = new C0279m(this.f1243b, "pc", 0);
    final C0278k f1255n = new C0278k(this.f1243b, "ptp");
    final C0280n f1256o = new C0280n(this.f1243b, "lpt");
    final C0278k f1257p = new C0278k(this.f1243b, "plp");
    final C0282q f1258q = new C0282q(this.f1243b, "adv");
    final C0282q f1259r = new C0282q(this.f1243b, "ui");
    final C0279m f1260s = new C0279m(this.f1243b, "ul", -1);
    final C0279m f1261t = new C0279m(this.f1243b, "uf", -1);
    final C0282q f1262u = new C0282q(this.f1243b, TapjoyConstants.TJC_USER_VARIABLE_1);
    final C0282q f1263v = new C0282q(this.f1243b, TapjoyConstants.TJC_USER_VARIABLE_2);
    final C0282q f1264w = new C0282q(this.f1243b, TapjoyConstants.TJC_USER_VARIABLE_3);
    final C0282q f1265x = new C0282q(this.f1243b, TapjoyConstants.TJC_USER_VARIABLE_4);
    final C0282q f1266y = new C0282q(this.f1243b, TapjoyConstants.TJC_USER_VARIABLE_5);
    final C0282q f1267z = new C0282q(this.f1243b, "utags");

    public static gn m1090a(Context context) {
        return new gn(context);
    }

    private gn(Context context) {
        Context applicationContext = context.getApplicationContext();
        this.f1242a = applicationContext;
        this.f1243b = applicationContext.getSharedPreferences("fiverocks", 0);
    }

    final Editor m1091a() {
        return this.f1243b.edit();
    }

    public final String m1093b() {
        String string = this.f1243b.getString("ir", null);
        if (string == null) {
            File file = new File(gd.m961c(this.f1242a), TapjoyConstants.TJC_REFERRER);
            if (file.exists()) {
                try {
                    string = bl.m323a(file, ap.f518c);
                } catch (IOException e) {
                }
            }
            this.f1243b.edit().putString("ir", string != null ? string : "").commit();
            return (string == null || string.length() <= 0) ? null : string;
        } else if (string.length() > 0) {
            return string;
        } else {
            return null;
        }
    }

    public final void m1092a(boolean z) {
        C0281p.m1336a(this.f1243b, "gcm.onServer", z);
    }
}
