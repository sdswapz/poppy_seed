package com.tapjoy.internal;

import android.util.Base64;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;
import java.util.zip.CRC32;

public final class er {
    public final C0195a f999a;
    public final String f1000b;
    public final String f1001c;
    public final String f1002d;
    private final String f1003e;
    private final int f1004f;

    public enum C0195a {
        SDK_ANDROID((byte) 2),
        RPC_ANALYTICS((byte) 49);
        
        public byte f998a;

        private C0195a(byte b) {
            this.f998a = b;
        }

        public static C0195a m792a(byte b) {
            for (C0195a c0195a : C0195a.values()) {
                if (c0195a.f998a == b) {
                    return c0195a;
                }
            }
            return null;
        }
    }

    public er(String str) {
        int length = str.length();
        if (str.matches("[A-Za-z0-9\\-_]*") && length >= 60 && (length & 3) == 0) {
            try {
                Object decode = Base64.decode(str, 8);
                int length2 = decode.length;
                ByteBuffer wrap = ByteBuffer.wrap(decode);
                wrap.order(ByteOrder.BIG_ENDIAN);
                int length3 = decode.length - 4;
                int i = wrap.getInt(length3);
                CRC32 crc32 = new CRC32();
                crc32.update(decode, 0, length3);
                if (i != ((int) crc32.getValue())) {
                    throw new IllegalArgumentException("The given API key was invalid.");
                }
                this.f1003e = str;
                this.f1000b = new UUID(wrap.getLong(0), wrap.getLong(8)).toString();
                this.f1004f = wrap.get(16);
                this.f999a = C0195a.m792a(wrap.get(17));
                this.f1001c = str.substring(24, 44);
                if (this.f1004f == 1) {
                    this.f1002d = null;
                    return;
                } else if (this.f1004f != 2 || this.f999a != C0195a.SDK_ANDROID) {
                    throw new IllegalArgumentException("The given API key was not supported.");
                } else if (length2 < 57) {
                    throw new IllegalArgumentException("The given API key was invalid.");
                } else {
                    Object obj = new byte[12];
                    System.arraycopy(decode, 33, obj, 0, 12);
                    this.f1002d = new String(ij.m1308a(obj));
                    return;
                }
            } catch (Throwable e) {
                throw new IllegalArgumentException("The given API key was malformed.", e);
            }
        }
        throw new IllegalArgumentException("The given API key was malformed.");
    }

    public final boolean equals(Object o) {
        if (o instanceof er) {
            return this.f1003e.equals(((er) o).f1003e);
        }
        return false;
    }

    public final String toString() {
        return this.f1003e;
    }
}
