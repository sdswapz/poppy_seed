package com.tapjoy.internal;

import java.io.Serializable;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.RandomAccess;

final class dt extends AbstractList implements Serializable, RandomAccess {
    List f692a;
    private final List f693b;

    dt(List list) {
        this.f693b = list;
        this.f692a = list;
    }

    public final Object get(int index) {
        return this.f692a.get(index);
    }

    public final int size() {
        return this.f692a.size();
    }

    public final Object set(int index, Object element) {
        if (this.f692a == this.f693b) {
            this.f692a = new ArrayList(this.f693b);
        }
        return this.f692a.set(index, element);
    }

    public final void add(int index, Object element) {
        if (this.f692a == this.f693b) {
            this.f692a = new ArrayList(this.f693b);
        }
        this.f692a.add(index, element);
    }

    public final Object remove(int index) {
        if (this.f692a == this.f693b) {
            this.f692a = new ArrayList(this.f693b);
        }
        return this.f692a.remove(index);
    }
}
