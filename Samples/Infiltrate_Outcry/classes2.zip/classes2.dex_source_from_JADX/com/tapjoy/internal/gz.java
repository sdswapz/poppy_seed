package com.tapjoy.internal;

import android.graphics.Point;
import com.tapjoy.TJAdUnitConstants.String;
import java.net.URL;

public final class gz {
    public static final bn f1329d = new C02561();
    public final hb f1330a;
    public final Point f1331b;
    public final Point f1332c;

    static class C02561 implements bn {
        C02561() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            hb hbVar = null;
            bsVar.mo105h();
            Point point = null;
            Point point2 = null;
            while (bsVar.mo107j()) {
                String l = bsVar.mo109l();
                if ("image".equals(l)) {
                    l = bsVar.mo110m();
                    if (!ct.m463c(l)) {
                        hbVar = new hb(new URL(l));
                    }
                } else if (String.LANDSCAPE.equals(l)) {
                    point2 = C02561.m1131b(bsVar);
                } else if ("portrait".equals(l)) {
                    point = C02561.m1131b(bsVar);
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return new gz(hbVar, point2, point);
        }

        private static Point m1131b(bs bsVar) {
            Point point = null;
            bsVar.mo105h();
            while (bsVar.mo107j()) {
                if ("offset".equals(bsVar.mo109l())) {
                    bsVar.mo105h();
                    int i = 0;
                    int i2 = 0;
                    while (bsVar.mo107j()) {
                        String l = bsVar.mo109l();
                        if ("x".equals(l)) {
                            i2 = bsVar.mo115r();
                        } else if ("y".equals(l)) {
                            i = bsVar.mo115r();
                        } else {
                            bsVar.mo116s();
                        }
                    }
                    bsVar.mo106i();
                    point = new Point(i2, i);
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return point;
        }
    }

    public gz(hb hbVar, Point point, Point point2) {
        this.f1330a = hbVar;
        this.f1331b = point;
        this.f1332c = point2;
    }
}
