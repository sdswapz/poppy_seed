package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;
import java.util.List;

public final class ek extends dl {
    public static final dn f933c = new C0190b();
    public static final Long f934d = Long.valueOf(0);
    public static final Integer f935e = Integer.valueOf(0);
    public static final Integer f936f = Integer.valueOf(0);
    public static final Integer f937g = Integer.valueOf(0);
    public static final Long f938h = Long.valueOf(0);
    public static final Long f939i = Long.valueOf(0);
    public static final Long f940j = Long.valueOf(0);
    public static final Integer f941k = Integer.valueOf(0);
    public static final Double f942l = Double.valueOf(0.0d);
    public static final Long f943m = Long.valueOf(0);
    public static final Double f944n = Double.valueOf(0.0d);
    public static final Boolean f945o = Boolean.valueOf(false);
    public static final Integer f946p = Integer.valueOf(0);
    public static final Integer f947q = Integer.valueOf(0);
    public static final Boolean f948r = Boolean.valueOf(false);
    public final Long f949A;
    public final String f950B;
    public final Integer f951C;
    public final Double f952D;
    public final Long f953E;
    public final Double f954F;
    public final String f955G;
    public final Boolean f956H;
    public final String f957I;
    public final Integer f958J;
    public final Integer f959K;
    public final String f960L;
    public final String f961M;
    public final String f962N;
    public final String f963O;
    public final String f964P;
    public final List f965Q;
    public final Boolean f966R;
    public final Long f967s;
    public final String f968t;
    public final Integer f969u;
    public final Integer f970v;
    public final List f971w;
    public final Integer f972x;
    public final Long f973y;
    public final Long f974z;

    public static final class C0189a extends C0149a {
        public List f907A = ds.m600a();
        public Boolean f908B;
        public Long f909c;
        public String f910d;
        public Integer f911e;
        public Integer f912f;
        public List f913g = ds.m600a();
        public Integer f914h;
        public Long f915i;
        public Long f916j;
        public Long f917k;
        public String f918l;
        public Integer f919m;
        public Double f920n;
        public Long f921o;
        public Double f922p;
        public String f923q;
        public Boolean f924r;
        public String f925s;
        public Integer f926t;
        public Integer f927u;
        public String f928v;
        public String f929w;
        public String f930x;
        public String f931y;
        public String f932z;

        public final ek m765b() {
            return new ek(this.f909c, this.f910d, this.f911e, this.f912f, this.f913g, this.f914h, this.f915i, this.f916j, this.f917k, this.f918l, this.f919m, this.f920n, this.f921o, this.f922p, this.f923q, this.f924r, this.f925s, this.f926t, this.f927u, this.f928v, this.f929w, this.f930x, this.f931y, this.f932z, this.f907A, this.f908B, super.m529a());
        }
    }

    static final class C0190b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            int a;
            int i = 0;
            ek ekVar = (ek) obj;
            int a2 = ekVar.f967s != null ? dn.f655i.mo128a(1, ekVar.f967s) : 0;
            if (ekVar.f968t != null) {
                a = dn.f662p.mo128a(2, ekVar.f968t);
            } else {
                a = 0;
            }
            a += a2;
            if (ekVar.f969u != null) {
                a2 = dn.f650d.mo128a(13, ekVar.f969u);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f970v != null) {
                a2 = dn.f650d.mo128a(14, ekVar.f970v);
            } else {
                a2 = 0;
            }
            a = eh.f895c.m514a().mo128a(15, ekVar.f971w) + (a2 + a);
            if (ekVar.f972x != null) {
                a2 = dn.f650d.mo128a(16, ekVar.f972x);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f973y != null) {
                a2 = dn.f655i.mo128a(17, ekVar.f973y);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f974z != null) {
                a2 = dn.f655i.mo128a(18, ekVar.f974z);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f949A != null) {
                a2 = dn.f655i.mo128a(19, ekVar.f949A);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f950B != null) {
                a2 = dn.f662p.mo128a(20, ekVar.f950B);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f951C != null) {
                a2 = dn.f650d.mo128a(3, ekVar.f951C);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f952D != null) {
                a2 = dn.f661o.mo128a(21, ekVar.f952D);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f953E != null) {
                a2 = dn.f655i.mo128a(4, ekVar.f953E);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f954F != null) {
                a2 = dn.f661o.mo128a(22, ekVar.f954F);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f955G != null) {
                a2 = dn.f662p.mo128a(23, ekVar.f955G);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f956H != null) {
                a2 = dn.f649c.mo128a(24, ekVar.f956H);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f957I != null) {
                a2 = dn.f662p.mo128a(5, ekVar.f957I);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f958J != null) {
                a2 = dn.f650d.mo128a(6, ekVar.f958J);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f959K != null) {
                a2 = dn.f650d.mo128a(7, ekVar.f959K);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f960L != null) {
                a2 = dn.f662p.mo128a(8, ekVar.f960L);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f961M != null) {
                a2 = dn.f662p.mo128a(9, ekVar.f961M);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f962N != null) {
                a2 = dn.f662p.mo128a(10, ekVar.f962N);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f963O != null) {
                a2 = dn.f662p.mo128a(11, ekVar.f963O);
            } else {
                a2 = 0;
            }
            a += a2;
            if (ekVar.f964P != null) {
                a2 = dn.f662p.mo128a(12, ekVar.f964P);
            } else {
                a2 = 0;
            }
            a2 = (a2 + a) + dn.f662p.m514a().mo128a(26, ekVar.f965Q);
            if (ekVar.f966R != null) {
                i = dn.f649c.mo128a(25, ekVar.f966R);
            }
            return (a2 + i) + ekVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            ek ekVar = (ek) obj;
            if (ekVar.f967s != null) {
                dn.f655i.mo129a(dpVar, 1, ekVar.f967s);
            }
            if (ekVar.f968t != null) {
                dn.f662p.mo129a(dpVar, 2, ekVar.f968t);
            }
            if (ekVar.f969u != null) {
                dn.f650d.mo129a(dpVar, 13, ekVar.f969u);
            }
            if (ekVar.f970v != null) {
                dn.f650d.mo129a(dpVar, 14, ekVar.f970v);
            }
            eh.f895c.m514a().mo129a(dpVar, 15, ekVar.f971w);
            if (ekVar.f972x != null) {
                dn.f650d.mo129a(dpVar, 16, ekVar.f972x);
            }
            if (ekVar.f973y != null) {
                dn.f655i.mo129a(dpVar, 17, ekVar.f973y);
            }
            if (ekVar.f974z != null) {
                dn.f655i.mo129a(dpVar, 18, ekVar.f974z);
            }
            if (ekVar.f949A != null) {
                dn.f655i.mo129a(dpVar, 19, ekVar.f949A);
            }
            if (ekVar.f950B != null) {
                dn.f662p.mo129a(dpVar, 20, ekVar.f950B);
            }
            if (ekVar.f951C != null) {
                dn.f650d.mo129a(dpVar, 3, ekVar.f951C);
            }
            if (ekVar.f952D != null) {
                dn.f661o.mo129a(dpVar, 21, ekVar.f952D);
            }
            if (ekVar.f953E != null) {
                dn.f655i.mo129a(dpVar, 4, ekVar.f953E);
            }
            if (ekVar.f954F != null) {
                dn.f661o.mo129a(dpVar, 22, ekVar.f954F);
            }
            if (ekVar.f955G != null) {
                dn.f662p.mo129a(dpVar, 23, ekVar.f955G);
            }
            if (ekVar.f956H != null) {
                dn.f649c.mo129a(dpVar, 24, ekVar.f956H);
            }
            if (ekVar.f957I != null) {
                dn.f662p.mo129a(dpVar, 5, ekVar.f957I);
            }
            if (ekVar.f958J != null) {
                dn.f650d.mo129a(dpVar, 6, ekVar.f958J);
            }
            if (ekVar.f959K != null) {
                dn.f650d.mo129a(dpVar, 7, ekVar.f959K);
            }
            if (ekVar.f960L != null) {
                dn.f662p.mo129a(dpVar, 8, ekVar.f960L);
            }
            if (ekVar.f961M != null) {
                dn.f662p.mo129a(dpVar, 9, ekVar.f961M);
            }
            if (ekVar.f962N != null) {
                dn.f662p.mo129a(dpVar, 10, ekVar.f962N);
            }
            if (ekVar.f963O != null) {
                dn.f662p.mo129a(dpVar, 11, ekVar.f963O);
            }
            if (ekVar.f964P != null) {
                dn.f662p.mo129a(dpVar, 12, ekVar.f964P);
            }
            dn.f662p.m514a().mo129a(dpVar, 26, ekVar.f965Q);
            if (ekVar.f966R != null) {
                dn.f649c.mo129a(dpVar, 25, ekVar.f966R);
            }
            dpVar.m593a(ekVar.m530a());
        }

        C0190b() {
            super(dk.LENGTH_DELIMITED, ek.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0189a c0189a = new C0189a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0189a.f909c = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 2:
                            c0189a.f910d = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 3:
                            c0189a.f919m = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 4:
                            c0189a.f921o = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 5:
                            c0189a.f925s = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 6:
                            c0189a.f926t = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 7:
                            c0189a.f927u = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 8:
                            c0189a.f928v = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 9:
                            c0189a.f929w = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 10:
                            c0189a.f930x = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 11:
                            c0189a.f931y = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 12:
                            c0189a.f932z = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 13:
                            c0189a.f911e = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 14:
                            c0189a.f912f = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 15:
                            c0189a.f913g.add(eh.f895c.mo126a(c0160do));
                            break;
                        case 16:
                            c0189a.f914h = (Integer) dn.f650d.mo126a(c0160do);
                            break;
                        case 17:
                            c0189a.f915i = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 18:
                            c0189a.f916j = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 19:
                            c0189a.f917k = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 20:
                            c0189a.f918l = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 21:
                            c0189a.f920n = (Double) dn.f661o.mo126a(c0160do);
                            break;
                        case 22:
                            c0189a.f922p = (Double) dn.f661o.mo126a(c0160do);
                            break;
                        case 23:
                            c0189a.f923q = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 24:
                            c0189a.f924r = (Boolean) dn.f649c.mo126a(c0160do);
                            break;
                        case 25:
                            c0189a.f908B = (Boolean) dn.f649c.mo126a(c0160do);
                            break;
                        case 26:
                            c0189a.f907A.add(dn.f662p.mo126a(c0160do));
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0189a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0189a.m765b();
            }
        }
    }

    public ek(Long l, String str, Integer num, Integer num2, List list, Integer num3, Long l2, Long l3, Long l4, String str2, Integer num4, Double d, Long l5, Double d2, String str3, Boolean bool, String str4, Integer num5, Integer num6, String str5, String str6, String str7, String str8, String str9, List list2, Boolean bool2, hy hyVar) {
        super(f933c, hyVar);
        this.f967s = l;
        this.f968t = str;
        this.f969u = num;
        this.f970v = num2;
        this.f971w = ds.m601a("pushes", list);
        this.f972x = num3;
        this.f973y = l2;
        this.f974z = l3;
        this.f949A = l4;
        this.f950B = str2;
        this.f951C = num4;
        this.f952D = d;
        this.f953E = l5;
        this.f954F = d2;
        this.f955G = str3;
        this.f956H = bool;
        this.f957I = str4;
        this.f958J = num5;
        this.f959K = num6;
        this.f960L = str5;
        this.f961M = str6;
        this.f962N = str7;
        this.f963O = str8;
        this.f964P = str9;
        this.f965Q = ds.m601a("tags", list2);
        this.f966R = bool2;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ek)) {
            return false;
        }
        ek ekVar = (ek) other;
        if (m530a().equals(ekVar.m530a()) && ds.m602a(this.f967s, ekVar.f967s) && ds.m602a(this.f968t, ekVar.f968t) && ds.m602a(this.f969u, ekVar.f969u) && ds.m602a(this.f970v, ekVar.f970v) && this.f971w.equals(ekVar.f971w) && ds.m602a(this.f972x, ekVar.f972x) && ds.m602a(this.f973y, ekVar.f973y) && ds.m602a(this.f974z, ekVar.f974z) && ds.m602a(this.f949A, ekVar.f949A) && ds.m602a(this.f950B, ekVar.f950B) && ds.m602a(this.f951C, ekVar.f951C) && ds.m602a(this.f952D, ekVar.f952D) && ds.m602a(this.f953E, ekVar.f953E) && ds.m602a(this.f954F, ekVar.f954F) && ds.m602a(this.f955G, ekVar.f955G) && ds.m602a(this.f956H, ekVar.f956H) && ds.m602a(this.f957I, ekVar.f957I) && ds.m602a(this.f958J, ekVar.f958J) && ds.m602a(this.f959K, ekVar.f959K) && ds.m602a(this.f960L, ekVar.f960L) && ds.m602a(this.f961M, ekVar.f961M) && ds.m602a(this.f962N, ekVar.f962N) && ds.m602a(this.f963O, ekVar.f963O) && ds.m602a(this.f964P, ekVar.f964P) && this.f965Q.equals(ekVar.f965Q) && ds.m602a(this.f966R, ekVar.f966R)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = this.f677b;
        if (i2 != 0) {
            return i2;
        }
        int hashCode = ((this.f967s != null ? this.f967s.hashCode() : 0) + (m530a().hashCode() * 37)) * 37;
        if (this.f968t != null) {
            i2 = this.f968t.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f969u != null) {
            i2 = this.f969u.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f970v != null) {
            i2 = this.f970v.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (((i2 + hashCode) * 37) + this.f971w.hashCode()) * 37;
        if (this.f972x != null) {
            i2 = this.f972x.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f973y != null) {
            i2 = this.f973y.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f974z != null) {
            i2 = this.f974z.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f949A != null) {
            i2 = this.f949A.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f950B != null) {
            i2 = this.f950B.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f951C != null) {
            i2 = this.f951C.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f952D != null) {
            i2 = this.f952D.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f953E != null) {
            i2 = this.f953E.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f954F != null) {
            i2 = this.f954F.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f955G != null) {
            i2 = this.f955G.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f956H != null) {
            i2 = this.f956H.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f957I != null) {
            i2 = this.f957I.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f958J != null) {
            i2 = this.f958J.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f959K != null) {
            i2 = this.f959K.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f960L != null) {
            i2 = this.f960L.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f961M != null) {
            i2 = this.f961M.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f962N != null) {
            i2 = this.f962N.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f963O != null) {
            i2 = this.f963O.hashCode();
        } else {
            i2 = 0;
        }
        hashCode = (i2 + hashCode) * 37;
        if (this.f964P != null) {
            i2 = this.f964P.hashCode();
        } else {
            i2 = 0;
        }
        i2 = (((i2 + hashCode) * 37) + this.f965Q.hashCode()) * 37;
        if (this.f966R != null) {
            i = this.f966R.hashCode();
        }
        i2 += i;
        this.f677b = i2;
        return i2;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.f967s != null) {
            stringBuilder.append(", installed=").append(this.f967s);
        }
        if (this.f968t != null) {
            stringBuilder.append(", referrer=").append(this.f968t);
        }
        if (this.f969u != null) {
            stringBuilder.append(", fq7=").append(this.f969u);
        }
        if (this.f970v != null) {
            stringBuilder.append(", fq30=").append(this.f970v);
        }
        if (!this.f971w.isEmpty()) {
            stringBuilder.append(", pushes=").append(this.f971w);
        }
        if (this.f972x != null) {
            stringBuilder.append(", sessionTotalCount=").append(this.f972x);
        }
        if (this.f973y != null) {
            stringBuilder.append(", sessionTotalDuration=").append(this.f973y);
        }
        if (this.f974z != null) {
            stringBuilder.append(", sessionLastTime=").append(this.f974z);
        }
        if (this.f949A != null) {
            stringBuilder.append(", sessionLastDuration=").append(this.f949A);
        }
        if (this.f950B != null) {
            stringBuilder.append(", purchaseCurrency=").append(this.f950B);
        }
        if (this.f951C != null) {
            stringBuilder.append(", purchaseTotalCount=").append(this.f951C);
        }
        if (this.f952D != null) {
            stringBuilder.append(", purchaseTotalPrice=").append(this.f952D);
        }
        if (this.f953E != null) {
            stringBuilder.append(", purchaseLastTime=").append(this.f953E);
        }
        if (this.f954F != null) {
            stringBuilder.append(", purchaseLastPrice=").append(this.f954F);
        }
        if (this.f955G != null) {
            stringBuilder.append(", idfa=").append(this.f955G);
        }
        if (this.f956H != null) {
            stringBuilder.append(", idfaOptout=").append(this.f956H);
        }
        if (this.f957I != null) {
            stringBuilder.append(", userId=").append(this.f957I);
        }
        if (this.f958J != null) {
            stringBuilder.append(", userLevel=").append(this.f958J);
        }
        if (this.f959K != null) {
            stringBuilder.append(", friendCount=").append(this.f959K);
        }
        if (this.f960L != null) {
            stringBuilder.append(", uv1=").append(this.f960L);
        }
        if (this.f961M != null) {
            stringBuilder.append(", uv2=").append(this.f961M);
        }
        if (this.f962N != null) {
            stringBuilder.append(", uv3=").append(this.f962N);
        }
        if (this.f963O != null) {
            stringBuilder.append(", uv4=").append(this.f963O);
        }
        if (this.f964P != null) {
            stringBuilder.append(", uv5=").append(this.f964P);
        }
        if (!this.f965Q.isEmpty()) {
            stringBuilder.append(", tags=").append(this.f965Q);
        }
        if (this.f966R != null) {
            stringBuilder.append(", pushOptout=").append(this.f966R);
        }
        return stringBuilder.replace(0, 2, "User{").append('}').toString();
    }
}
