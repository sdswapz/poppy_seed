package com.tapjoy.internal;

import android.app.Notification;
import android.app.Notification.BigPictureStyle;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build.VERSION;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;

public final class C0120a {
    private static final C0114f f456a;

    public static class C0108a {
        public int f426a;
        public CharSequence f427b;
        public PendingIntent f428c;
    }

    public static abstract class C0109l {
        C0112d f429d;
        public CharSequence f430e;
        CharSequence f431f;
        boolean f432g = false;
    }

    public static class C0110b extends C0109l {
        Bitmap f433a;
        Bitmap f434b;
        boolean f435c;
    }

    public static class C0111c extends C0109l {
        public CharSequence f436a;
    }

    public static class C0112d {
        Context f437a;
        public CharSequence f438b;
        public CharSequence f439c;
        public PendingIntent f440d;
        PendingIntent f441e;
        RemoteViews f442f;
        public Bitmap f443g;
        CharSequence f444h;
        int f445i;
        int f446j;
        boolean f447k;
        C0109l f448l;
        CharSequence f449m;
        int f450n;
        int f451o;
        boolean f452p;
        ArrayList f453q = new ArrayList();
        public Notification f454r = new Notification();

        public C0112d(Context context) {
            this.f437a = context;
            this.f454r.when = System.currentTimeMillis();
            this.f454r.audioStreamType = -1;
            this.f446j = 0;
        }

        public final C0112d m256a(C0109l c0109l) {
            if (this.f448l != c0109l) {
                this.f448l = c0109l;
                if (this.f448l != null) {
                    C0109l c0109l2 = this.f448l;
                    if (c0109l2.f429d != this) {
                        c0109l2.f429d = this;
                        if (c0109l2.f429d != null) {
                            c0109l2.f429d.m256a(c0109l2);
                        }
                    }
                }
            }
            return this;
        }
    }

    public static class C0113e extends C0109l {
        ArrayList f455a = new ArrayList();
    }

    public interface C0114f {
        Notification mo86a(C0112d c0112d);
    }

    static class C0115g implements C0114f {
        C0115g() {
        }

        public Notification mo86a(C0112d c0112d) {
            Notification notification = c0112d.f454r;
            notification.setLatestEventInfo(c0112d.f437a, c0112d.f438b, c0112d.f439c, c0112d.f440d);
            if (c0112d.f446j > 0) {
                notification.flags |= 128;
            }
            return notification;
        }
    }

    static class C0116h extends C0115g {
        C0116h() {
        }

        public final Notification mo86a(C0112d c0112d) {
            Notification notification = c0112d.f454r;
            notification.setLatestEventInfo(c0112d.f437a, c0112d.f438b, c0112d.f439c, c0112d.f440d);
            Context context = c0112d.f437a;
            CharSequence charSequence = c0112d.f438b;
            CharSequence charSequence2 = c0112d.f439c;
            PendingIntent pendingIntent = c0112d.f440d;
            PendingIntent pendingIntent2 = c0112d.f441e;
            notification.setLatestEventInfo(context, charSequence, charSequence2, pendingIntent);
            notification.fullScreenIntent = pendingIntent2;
            if (c0112d.f446j > 0) {
                notification.flags |= 128;
            }
            return notification;
        }
    }

    static class C0117i implements C0114f {
        C0117i() {
        }

        public final Notification mo86a(C0112d c0112d) {
            boolean z;
            Context context = c0112d.f437a;
            Notification notification = c0112d.f454r;
            CharSequence charSequence = c0112d.f438b;
            CharSequence charSequence2 = c0112d.f439c;
            CharSequence charSequence3 = c0112d.f444h;
            RemoteViews remoteViews = c0112d.f442f;
            int i = c0112d.f445i;
            PendingIntent pendingIntent = c0112d.f440d;
            PendingIntent pendingIntent2 = c0112d.f441e;
            Bitmap bitmap = c0112d.f443g;
            Builder lights = new Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
            if ((notification.flags & 2) != 0) {
                z = true;
            } else {
                z = false;
            }
            lights = lights.setOngoing(z);
            if ((notification.flags & 8) != 0) {
                z = true;
            } else {
                z = false;
            }
            lights = lights.setOnlyAlertOnce(z);
            if ((notification.flags & 16) != 0) {
                z = true;
            } else {
                z = false;
            }
            Builder deleteIntent = lights.setAutoCancel(z).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent);
            if ((notification.flags & 128) != 0) {
                z = true;
            } else {
                z = false;
            }
            return deleteIntent.setFullScreenIntent(pendingIntent2, z).setLargeIcon(bitmap).setNumber(i).getNotification();
        }
    }

    static class C0118j implements C0114f {
        C0118j() {
        }

        public final Notification mo86a(C0112d c0112d) {
            boolean z;
            Context context = c0112d.f437a;
            Notification notification = c0112d.f454r;
            CharSequence charSequence = c0112d.f438b;
            CharSequence charSequence2 = c0112d.f439c;
            CharSequence charSequence3 = c0112d.f444h;
            RemoteViews remoteViews = c0112d.f442f;
            int i = c0112d.f445i;
            PendingIntent pendingIntent = c0112d.f440d;
            PendingIntent pendingIntent2 = c0112d.f441e;
            Bitmap bitmap = c0112d.f443g;
            int i2 = c0112d.f450n;
            int i3 = c0112d.f451o;
            boolean z2 = c0112d.f452p;
            Builder lights = new Builder(context).setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
            if ((notification.flags & 2) != 0) {
                z = true;
            } else {
                z = false;
            }
            lights = lights.setOngoing(z);
            if ((notification.flags & 8) != 0) {
                z = true;
            } else {
                z = false;
            }
            lights = lights.setOnlyAlertOnce(z);
            if ((notification.flags & 16) != 0) {
                z = true;
            } else {
                z = false;
            }
            Builder deleteIntent = lights.setAutoCancel(z).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent);
            if ((notification.flags & 128) != 0) {
                z = true;
            } else {
                z = false;
            }
            return deleteIntent.setFullScreenIntent(pendingIntent2, z).setLargeIcon(bitmap).setNumber(i).setProgress(i2, i3, z2).getNotification();
        }
    }

    static class C0119k implements C0114f {
        C0119k() {
        }

        public final Notification mo86a(C0112d c0112d) {
            C0127b c0127b = new C0127b(c0112d.f437a, c0112d.f454r, c0112d.f438b, c0112d.f439c, c0112d.f444h, c0112d.f442f, c0112d.f445i, c0112d.f440d, c0112d.f441e, c0112d.f443g, c0112d.f450n, c0112d.f451o, c0112d.f452p, c0112d.f447k, c0112d.f446j, c0112d.f449m);
            Iterator it = c0112d.f453q.iterator();
            while (it.hasNext()) {
                C0108a c0108a = (C0108a) it.next();
                c0127b.f534a.addAction(c0108a.f426a, c0108a.f427b, c0108a.f428c);
            }
            if (c0112d.f448l != null) {
                CharSequence charSequence;
                boolean z;
                CharSequence charSequence2;
                if (c0112d.f448l instanceof C0111c) {
                    C0111c c0111c = (C0111c) c0112d.f448l;
                    charSequence = c0111c.e;
                    z = c0111c.g;
                    charSequence2 = c0111c.f;
                    BigTextStyle bigText = new BigTextStyle(c0127b.f534a).setBigContentTitle(charSequence).bigText(c0111c.f436a);
                    if (z) {
                        bigText.setSummaryText(charSequence2);
                    }
                } else if (c0112d.f448l instanceof C0113e) {
                    C0113e c0113e = (C0113e) c0112d.f448l;
                    c0127b.m312a(c0113e.e, c0113e.g, c0113e.f, c0113e.f455a);
                } else if (c0112d.f448l instanceof C0110b) {
                    C0110b c0110b = (C0110b) c0112d.f448l;
                    charSequence = c0110b.e;
                    z = c0110b.g;
                    charSequence2 = c0110b.f;
                    Bitmap bitmap = c0110b.f433a;
                    Bitmap bitmap2 = c0110b.f434b;
                    boolean z2 = c0110b.f435c;
                    BigPictureStyle bigPicture = new BigPictureStyle(c0127b.f534a).setBigContentTitle(charSequence).bigPicture(bitmap);
                    if (z2) {
                        bigPicture.bigLargeIcon(bitmap2);
                    }
                    if (z) {
                        bigPicture.setSummaryText(charSequence2);
                    }
                }
            }
            return c0127b.f534a.build();
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            f456a = new C0119k();
        } else if (VERSION.SDK_INT >= 14) {
            f456a = new C0118j();
        } else if (VERSION.SDK_INT >= 11) {
            f456a = new C0117i();
        } else if (VERSION.SDK_INT >= 9) {
            f456a = new C0116h();
        } else {
            f456a = new C0115g();
        }
    }
}
