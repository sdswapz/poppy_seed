package com.tapjoy.internal;

public interface fq {
    void mo34a(String str, String str2);

    void mo35a(String str, String str2, int i, String str3);
}
