package com.tapjoy.internal;

public final class cg extends RuntimeException {
    public final int f596a;

    public cg(int i, String str) {
        super(str);
        this.f596a = i;
    }
}
