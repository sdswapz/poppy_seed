package com.tapjoy.internal;

import java.util.Iterator;
import java.util.NoSuchElementException;

public final class cw {
    static final cz f613a = new C01381();
    private static final Iterator f614b = new C01392();

    static class C01381 extends cz {
        C01381() {
        }

        public final boolean hasNext() {
            return false;
        }

        public final Object next() {
            throw new NoSuchElementException();
        }
    }

    static class C01392 implements Iterator {
        C01392() {
        }

        public final boolean hasNext() {
            return false;
        }

        public final Object next() {
            throw new NoSuchElementException();
        }

        public final void remove() {
            throw new IllegalStateException();
        }
    }

    public static Object m467a(Iterator it) {
        return it.hasNext() ? it.next() : null;
    }
}
