package com.tapjoy.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.ImageView.ScaleType;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.tapjoy.TapjoyConnectCore;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

public final class hs extends RelativeLayout {
    private gv f1472a;
    private C0221a f1473b;
    private af f1474c = af.UNSPECIFIED;
    private int f1475d = 0;
    private int f1476e = 0;
    private he f1477f = null;
    private ArrayList f1478g = null;
    private ArrayList f1479h = null;

    public interface C0221a {
        void mo202a();

        void mo203a(hd hdVar);
    }

    public hs(Context context, gv gvVar, C0221a c0221a) {
        super(context);
        this.f1472a = gvVar;
        this.f1473b = c0221a;
    }

    protected final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f1473b.mo202a();
    }

    protected final void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = MeasureSpec.getSize(widthMeasureSpec);
        int size2 = MeasureSpec.getSize(heightMeasureSpec);
        if (size >= size2) {
            if (this.f1474c != af.LANDSCAPE) {
                this.f1474c = af.LANDSCAPE;
                m1204a();
            }
        } else if (this.f1474c != af.PORTRAIT) {
            this.f1474c = af.PORTRAIT;
            m1204a();
        }
        if (!(this.f1475d == size && this.f1476e == size2)) {
            float f;
            float f2;
            float f3;
            LayoutParams layoutParams;
            hd hdVar;
            float a;
            float a2;
            float a3;
            float a4;
            int i;
            this.f1475d = size;
            this.f1476e = size2;
            float f4 = (float) size;
            float f5 = (float) size2;
            if (!(this.f1477f == null || this.f1477f.f1370b == null)) {
                float f6 = ((this.f1477f.f1370b.y * f4) / this.f1477f.f1370b.x) / f5;
                if (f6 < TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER) {
                    f6 = (this.f1477f.f1370b.y * f4) / this.f1477f.f1370b.x;
                    f = f4;
                    f2 = 0.0f;
                    f3 = (f5 - f6) / 2.0f;
                    f4 = f6;
                } else if (f6 > TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER) {
                    f6 = (this.f1477f.f1370b.x * f5) / this.f1477f.f1370b.y;
                    f3 = 0.0f;
                    f2 = (f4 - f6) / 2.0f;
                    f4 = f5;
                    f = f6;
                }
                for (View view : ah.m282a(this)) {
                    layoutParams = (LayoutParams) view.getLayoutParams();
                    hdVar = (hd) view.getTag();
                    a = hdVar.f1355a.m1148a(f, f4);
                    a2 = hdVar.f1356b.m1148a(f, f4);
                    a3 = hdVar.f1357c.m1148a(f, f4);
                    a4 = hdVar.f1358d.m1148a(f, f4);
                    i = hdVar.f1359e;
                    size = hdVar.f1360f;
                    if (i == 14) {
                        i = 9;
                        a += (f - a3) / 2.0f;
                    }
                    if (size == 15) {
                        size = 10;
                        a2 += (f4 - a4) / 2.0f;
                    }
                    layoutParams.addRule(i, -1);
                    layoutParams.addRule(size, -1);
                    layoutParams.width = Math.round(a3);
                    layoutParams.height = Math.round(a4);
                    if (i == 9) {
                        layoutParams.leftMargin = Math.round(f2 + a);
                    } else if (i == 11) {
                        layoutParams.rightMargin = Math.round(f2 + a);
                    }
                    if (size == 10) {
                        layoutParams.topMargin = Math.round(f3 + a2);
                    } else if (size == 12) {
                        layoutParams.bottomMargin = Math.round(f3 + a2);
                    }
                }
            }
            f2 = 0.0f;
            f3 = 0.0f;
            f = f4;
            f4 = f5;
            for (View view2 : ah.m282a(this)) {
                layoutParams = (LayoutParams) view2.getLayoutParams();
                hdVar = (hd) view2.getTag();
                a = hdVar.f1355a.m1148a(f, f4);
                a2 = hdVar.f1356b.m1148a(f, f4);
                a3 = hdVar.f1357c.m1148a(f, f4);
                a4 = hdVar.f1358d.m1148a(f, f4);
                i = hdVar.f1359e;
                size = hdVar.f1360f;
                if (i == 14) {
                    i = 9;
                    a += (f - a3) / 2.0f;
                }
                if (size == 15) {
                    size = 10;
                    a2 += (f4 - a4) / 2.0f;
                }
                layoutParams.addRule(i, -1);
                layoutParams.addRule(size, -1);
                layoutParams.width = Math.round(a3);
                layoutParams.height = Math.round(a4);
                if (i == 9) {
                    layoutParams.leftMargin = Math.round(f2 + a);
                } else if (i == 11) {
                    layoutParams.rightMargin = Math.round(f2 + a);
                }
                if (size == 10) {
                    layoutParams.topMargin = Math.round(f3 + a2);
                } else if (size == 12) {
                    layoutParams.bottomMargin = Math.round(f3 + a2);
                }
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    protected final void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        Iterator it;
        hk hkVar;
        if (visibility == 0) {
            if (this.f1479h != null) {
                it = this.f1479h.iterator();
                while (it.hasNext()) {
                    hkVar = (hk) ((WeakReference) it.next()).get();
                    if (hkVar != null) {
                        hkVar.setVisibility(4);
                        hkVar.m1182b();
                    }
                }
            }
            if (this.f1478g != null) {
                it = this.f1478g.iterator();
                while (it.hasNext()) {
                    hkVar = (hk) ((WeakReference) it.next()).get();
                    if (hkVar != null) {
                        hkVar.setVisibility(0);
                        hkVar.m1180a();
                    }
                }
                return;
            }
            return;
        }
        if (this.f1478g != null) {
            it = this.f1478g.iterator();
            while (it.hasNext()) {
                hkVar = (hk) ((WeakReference) it.next()).get();
                if (hkVar != null) {
                    hkVar.m1182b();
                }
            }
        }
        if (this.f1479h != null) {
            it = this.f1479h.iterator();
            while (it.hasNext()) {
                hkVar = (hk) ((WeakReference) it.next()).get();
                if (hkVar != null) {
                    hkVar.m1182b();
                }
            }
        }
    }

    private void m1204a() {
        hk hkVar;
        Iterator it = this.f1472a.f1292a.iterator();
        he heVar = null;
        while (it.hasNext()) {
            he heVar2 = (he) it.next();
            if (heVar2.f1369a == this.f1474c) {
                heVar = heVar2;
                break;
            }
            if (heVar2.f1369a != af.UNSPECIFIED) {
                heVar2 = heVar;
            }
            heVar = heVar2;
        }
        removeAllViews();
        if (this.f1478g != null) {
            it = this.f1478g.iterator();
            while (it.hasNext()) {
                hkVar = (hk) ((WeakReference) it.next()).get();
                if (hkVar != null) {
                    hkVar.m1183c();
                }
            }
            this.f1478g.clear();
        }
        if (this.f1479h != null) {
            it = this.f1479h.iterator();
            while (it.hasNext()) {
                hkVar = (hk) ((WeakReference) it.next()).get();
                if (hkVar != null) {
                    hkVar.m1183c();
                }
            }
            this.f1479h.clear();
        }
        if (heVar != null) {
            this.f1477f = heVar;
            Context context = getContext();
            Iterator it2 = heVar.f1371c.iterator();
            while (it2.hasNext()) {
                View hkVar2;
                View view;
                Bitmap bitmap;
                Drawable bitmapDrawable;
                BitmapDrawable bitmapDrawable2;
                hd hdVar = (hd) it2.next();
                View relativeLayout = new RelativeLayout(context);
                if (hdVar.f1366l.f1347c != null) {
                    hkVar2 = new hk(context);
                    hkVar2.setScaleType(ScaleType.FIT_XY);
                    hkVar2.m1181a(hdVar.f1366l.f1348d, hdVar.f1366l.f1347c);
                    if (this.f1478g == null) {
                        this.f1478g = new ArrayList();
                    }
                    this.f1478g.add(new WeakReference(hkVar2));
                } else {
                    hkVar2 = null;
                }
                if (hdVar.f1367m == null || hdVar.f1367m.f1347c == null) {
                    view = null;
                } else {
                    view = new hk(context);
                    view.setScaleType(ScaleType.FIT_XY);
                    view.m1181a(hdVar.f1367m.f1348d, hdVar.f1367m.f1347c);
                    if (this.f1479h == null) {
                        this.f1479h = new ArrayList();
                    }
                    this.f1479h.add(new WeakReference(view));
                }
                ViewGroup.LayoutParams layoutParams = new LayoutParams(0, 0);
                ViewGroup.LayoutParams layoutParams2 = new LayoutParams(-1, -1);
                Bitmap bitmap2 = hdVar.f1366l.f1346b;
                if (hdVar.f1367m != null) {
                    bitmap = hdVar.f1367m.f1346b;
                } else {
                    bitmap = null;
                }
                if (bitmap2 != null) {
                    bitmapDrawable = new BitmapDrawable(null, bitmap2);
                } else {
                    bitmapDrawable = null;
                }
                if (bitmap != null) {
                    bitmapDrawable2 = new BitmapDrawable(null, bitmap);
                } else {
                    bitmapDrawable2 = null;
                }
                if (bitmapDrawable != null) {
                    ag.m281a(relativeLayout, bitmapDrawable);
                }
                if (hkVar2 != null) {
                    relativeLayout.addView(hkVar2, layoutParams2);
                    hkVar2.m1180a();
                }
                if (view != null) {
                    relativeLayout.addView(view, layoutParams2);
                    view.setVisibility(4);
                }
                relativeLayout.setOnTouchListener(new OnTouchListener(this) {
                    final /* synthetic */ hs f1466e;

                    public final boolean onTouch(View v, MotionEvent event) {
                        boolean z = true;
                        if (event.getAction() == 0) {
                            if (!(view == null && bitmapDrawable2 == null)) {
                                if (hkVar2 != null) {
                                    hkVar2.m1182b();
                                    hkVar2.setVisibility(4);
                                }
                                ag.m281a(v, null);
                            }
                            if (bitmapDrawable2 != null) {
                                ag.m281a(v, bitmapDrawable2);
                            } else if (view != null) {
                                view.setVisibility(0);
                                view.m1180a();
                            }
                        } else if (event.getAction() == 1) {
                            float x = event.getX();
                            float y = event.getY();
                            if (x >= 0.0f && x < ((float) v.getWidth()) && y >= 0.0f && y < ((float) v.getHeight())) {
                                z = false;
                            }
                            if (z) {
                                if (bitmapDrawable != null) {
                                    ag.m281a(v, bitmapDrawable);
                                } else if (bitmapDrawable2 != null) {
                                    ag.m281a(v, null);
                                }
                            }
                            if (view != null) {
                                view.m1182b();
                                view.setVisibility(4);
                            }
                            if (!((view == null && bitmapDrawable2 == null) || hkVar2 == null || !z)) {
                                hkVar2.setVisibility(0);
                                hkVar2.m1180a();
                            }
                        }
                        return false;
                    }
                });
                final View view2 = relativeLayout;
                final hd hdVar2 = hdVar;
                relativeLayout.setOnClickListener(new OnClickListener(this) {
                    final /* synthetic */ hs f1471e;

                    public final void onClick(View v) {
                        if (view != null) {
                            view.m1182b();
                            view2.removeView(view);
                        }
                        if (hkVar2 != null) {
                            hkVar2.m1182b();
                            view2.removeView(hkVar2);
                        }
                        this.f1471e.f1473b.mo203a(hdVar2);
                    }
                });
                relativeLayout.setTag(hdVar);
                addView(relativeLayout, layoutParams);
            }
        }
    }
}
