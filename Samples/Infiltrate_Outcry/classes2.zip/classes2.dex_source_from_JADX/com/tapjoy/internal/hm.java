package com.tapjoy.internal;

import com.tapjoy.TapjoyConstants;
import java.util.Map;

public abstract class hm extends ce {
    public final String mo248b() {
        return "POST";
    }

    public final String mo249d() {
        return "application/json";
    }

    public Map mo250e() {
        Map e = super.mo250e();
        gd a = gd.m956a();
        e.put("sdk_ver", a.f1172m + "/Android");
        e.put(TapjoyConstants.TJC_API_KEY, a.f1171l);
        if (ga.f1141a) {
            e.put(TapjoyConstants.TJC_DEBUG, Boolean.valueOf(true));
        }
        return e;
    }

    protected Object mo251f() {
        try {
            return super.mo251f();
        } catch (Exception e) {
            new Object[1][0] = this;
            throw e;
        }
    }

    protected Object mo247a(bs bsVar) {
        bsVar.mo116s();
        return null;
    }
}
