package com.tapjoy.internal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.concurrent.ConcurrentHashMap;

public class fn extends Observable {
    public final List f1029b = new ArrayList();

    public class C0217a {
        public final String f1101a;
        public volatile Map f1102b = new ConcurrentHashMap();
        final /* synthetic */ fn f1103c;

        C0217a(fn fnVar, String str) {
            this.f1103c = fnVar;
            this.f1101a = str;
        }

        public final Object m896a(String str) {
            Map map = this.f1102b;
            return map != null ? map.get(str) : null;
        }
    }

    protected final C0217a m827a(String str) {
        C0217a c0217a = new C0217a(this, str);
        this.f1029b.add(c0217a);
        return c0217a;
    }

    protected void setChanged() {
        super.setChanged();
        notifyObservers();
    }

    public final boolean m829b(String str) {
        return m828a(str, false);
    }

    public final boolean m828a(String str, boolean z) {
        for (C0217a a : this.f1029b) {
            Object a2 = a.m896a(str);
            if (a2 != null) {
                if (a2 instanceof Boolean) {
                    return ((Boolean) a2).booleanValue();
                }
                if (!(a2 instanceof String)) {
                    continue;
                } else if ("true".equals(a2)) {
                    return true;
                } else {
                    if ("false".equals(a2)) {
                        return false;
                    }
                }
            }
        }
        return z;
    }

    public final long m830c(String str) {
        for (C0217a a : this.f1029b) {
            Object a2 = a.m896a(str);
            if (a2 != null) {
                if (a2 instanceof Number) {
                    return ((Number) a2).longValue();
                }
                if (a2 instanceof String) {
                    try {
                        return Long.parseLong((String) a2);
                    } catch (IllegalArgumentException e) {
                    }
                } else {
                    continue;
                }
            }
        }
        return 0;
    }

    private static long m826a(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).longValue();
        }
        if (obj instanceof String) {
            return Long.parseLong((String) obj);
        }
        throw new IllegalArgumentException();
    }

    public final fm m831d(String str) {
        for (C0217a a : this.f1029b) {
            Object a2 = a.m896a(str);
            if (a2 instanceof List) {
                List list = (List) a2;
                try {
                    double doubleValue;
                    long a3 = m826a(list.get(0));
                    long a4 = m826a(list.get(1));
                    long a5 = m826a(list.get(2));
                    a2 = list.get(3);
                    if (a2 instanceof Number) {
                        doubleValue = ((Number) a2).doubleValue();
                    } else if (a2 instanceof String) {
                        doubleValue = Double.parseDouble((String) a2);
                    } else {
                        throw new IllegalArgumentException();
                    }
                    return new fm(a3, a4, a5, doubleValue);
                } catch (RuntimeException e) {
                }
            }
        }
        return fm.f1095a;
    }
}
