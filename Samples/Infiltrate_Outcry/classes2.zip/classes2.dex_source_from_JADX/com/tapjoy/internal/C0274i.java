package com.tapjoy.internal;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.util.NoSuchElementException;

public final class C0274i extends ay implements bc, Closeable {
    private SQLiteDatabase f1505a;
    private final bi f1506b;
    private int f1507c;

    public C0274i(File file, bi biVar) {
        this.f1505a = SQLiteDatabase.openOrCreateDatabase(file, null);
        this.f1506b = biVar;
        if (this.f1505a.getVersion() != 1) {
            this.f1505a.beginTransaction();
            try {
                this.f1505a.execSQL("CREATE TABLE IF NOT EXISTS List(value BLOB)");
                this.f1505a.setVersion(1);
                this.f1505a.setTransactionSuccessful();
            } finally {
                this.f1505a.endTransaction();
            }
        }
        this.f1507c = m1265a();
    }

    protected final void finalize() {
        close();
        super.finalize();
    }

    public final void close() {
        if (this.f1505a != null) {
            this.f1505a.close();
            this.f1505a = null;
        }
    }

    private int m1265a() {
        Cursor cursor = null;
        int i = 0;
        try {
            cursor = this.f1505a.rawQuery("SELECT COUNT(1) FROM List", null);
            if (cursor.moveToNext()) {
                i = cursor.getInt(0);
            } else {
                C0274i.m1266a(cursor);
            }
            return i;
        } finally {
            C0274i.m1266a(cursor);
        }
    }

    public final int size() {
        return this.f1507c;
    }

    public final void clear() {
        this.f1505a.delete("List", "1", null);
        this.f1507c = 0;
    }

    public final boolean offer(Object element) {
        cs.m459a(element);
        Closeable byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            this.f1506b.mo235a(byteArrayOutputStream, element);
            byte[] toByteArray = byteArrayOutputStream.toByteArray();
            dc.m481a(byteArrayOutputStream);
            ContentValues contentValues = new ContentValues();
            contentValues.put("value", toByteArray);
            if (this.f1505a.insert("List", null, contentValues) == -1) {
                return false;
            }
            this.f1507c++;
            return true;
        } catch (Throwable e) {
            throw new IllegalArgumentException(e);
        } catch (Throwable th) {
            dc.m481a(byteArrayOutputStream);
        }
    }

    public final Object poll() {
        if (this.f1507c <= 0) {
            return null;
        }
        Object peek = peek();
        mo95b(1);
        return peek;
    }

    public final Object peek() {
        if (this.f1507c > 0) {
            return mo94a(0);
        }
        return null;
    }

    public final Object mo94a(int i) {
        Cursor cursor = null;
        if (i < 0 || i >= this.f1507c) {
            throw new IndexOutOfBoundsException();
        }
        try {
            cursor = this.f1505a.rawQuery("SELECT value FROM List ORDER BY rowid LIMIT " + i + ",1", null);
            if (cursor.moveToNext()) {
                Closeable byteArrayInputStream = new ByteArrayInputStream(cursor.getBlob(0));
                try {
                    Object b = this.f1506b.mo236b(byteArrayInputStream);
                    dc.m481a(byteArrayInputStream);
                    return b;
                } catch (Throwable e) {
                    throw new IllegalStateException(e);
                } catch (Throwable th) {
                    dc.m481a(byteArrayInputStream);
                }
            } else {
                throw new NoSuchElementException();
            }
        } finally {
            C0274i.m1266a(cursor);
        }
    }

    public final void mo95b(int i) {
        Throwable th;
        Cursor cursor = null;
        if (i <= 0 || i > this.f1507c) {
            throw new IndexOutOfBoundsException();
        } else if (i == this.f1507c) {
            clear();
        } else {
            try {
                Cursor rawQuery = this.f1505a.rawQuery("SELECT rowid FROM List ORDER BY rowid LIMIT " + (i - 1) + ",1", null);
                try {
                    if (rawQuery.moveToNext()) {
                        long j = rawQuery.getLong(0);
                        rawQuery.close();
                        int delete = this.f1505a.delete("List", "rowid <= " + j, null);
                        this.f1507c -= delete;
                        if (delete != i) {
                            throw new IllegalStateException("Try to delete " + i + ", but deleted " + delete);
                        }
                        C0274i.m1266a(null);
                        return;
                    }
                    throw new IllegalStateException();
                } catch (Throwable th2) {
                    th = th2;
                    cursor = rawQuery;
                    C0274i.m1266a(cursor);
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                C0274i.m1266a(cursor);
                throw th;
            }
        }
    }

    private static Cursor m1266a(Cursor cursor) {
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }
}
