package com.tapjoy.internal;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class gm {
    final C0282q f1235a = new C0282q(this.f1237c, "noMoreToday.date");
    public final C0282q f1236b = new C0282q(this.f1237c, "noMoreToday.actionIds");
    private final SharedPreferences f1237c;

    public gm(Context context) {
        this.f1237c = context.getApplicationContext().getSharedPreferences("fiverocks", 0);
        m1089b();
    }

    static String m1088a() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    public final void m1089b() {
        String a = this.f1235a.m1338a();
        if (a != null && !m1088a().equals(a)) {
            this.f1235a.m1339a(null);
            this.f1236b.m1339a(null);
        }
    }
}
