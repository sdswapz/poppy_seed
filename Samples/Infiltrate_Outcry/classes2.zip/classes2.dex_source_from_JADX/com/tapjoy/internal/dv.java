package com.tapjoy.internal;

import android.app.Activity;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.Build.VERSION;
import com.tapjoy.FiveRocksIntegration;
import com.tapjoy.TJAdUnit;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TJAwardCurrencyListener;
import com.tapjoy.TJConnectListener;
import com.tapjoy.TJCurrency;
import com.tapjoy.TJEarnedCurrencyListener;
import com.tapjoy.TJEventOptimizer;
import com.tapjoy.TJGetCurrencyBalanceListener;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TJPlacementManager;
import com.tapjoy.TJSetUserIDListener;
import com.tapjoy.TJSpendCurrencyListener;
import com.tapjoy.TJVideoListener;
import com.tapjoy.TapjoyAppSettings;
import com.tapjoy.TapjoyCache;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.TapjoyConnectFlag;
import com.tapjoy.TapjoyConstants;
import com.tapjoy.TapjoyErrorMessage;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.TapjoyException;
import com.tapjoy.TapjoyIntegrationException;
import com.tapjoy.TapjoyLog;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class dv extends du {
    private boolean f700b = false;
    private String f701c = "";
    private TJCurrency f702d = null;
    private TapjoyCache f703e = null;

    dv() {
    }

    public final String mo157b() {
        return "11.11.0";
    }

    public final void mo154a(boolean z) {
        TapjoyLog.setDebugEnabled(z);
    }

    public final boolean mo155a(Context context, String str) {
        return mo156a(context, str, null, null);
    }

    public synchronized boolean mo156a(final Context context, String str, Hashtable hashtable, final TJConnectListener tJConnectListener) {
        boolean z = false;
        synchronized (this) {
            if (hashtable != null) {
                Object obj = hashtable.get(TapjoyConnectFlag.ENABLE_LOGGING);
                if (obj != null) {
                    TapjoyLog.setDebugEnabled("true".equals(obj.toString()));
                }
            }
            TapjoyConnectCore.setSDKType(TapjoyConstants.TJC_SDK_TYPE_DEFAULT);
            if (context == null) {
                TapjoyLog.m250e("TapjoyAPI", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "The application context is NULL"));
                if (tJConnectListener != null) {
                    tJConnectListener.onConnectFailure();
                }
            } else {
                FiveRocksIntegration.m104a();
                try {
                    TapjoyAppSettings.init(context);
                    TapjoyConnectCore.requestTapjoyConnect(context, str, hashtable, new TJConnectListener(this) {
                        final /* synthetic */ dv f699c;

                        public final void onConnectSuccess() {
                            this.f699c.f702d = new TJCurrency(context);
                            this.f699c.f703e = new TapjoyCache(context);
                            try {
                                TJEventOptimizer.init(context);
                                this.f699c.a = true;
                                if (tJConnectListener != null) {
                                    tJConnectListener.onConnectSuccess();
                                }
                            } catch (InterruptedException e) {
                                onConnectFailure();
                            } catch (RuntimeException e2) {
                                TapjoyLog.m254w("TapjoyAPI", e2.getMessage());
                                onConnectFailure();
                            }
                        }

                        public final void onConnectFailure() {
                            if (tJConnectListener != null) {
                                tJConnectListener.onConnectFailure();
                            }
                        }
                    });
                    this.f700b = true;
                    if (VERSION.SDK_INT < 14) {
                        TapjoyLog.m252i("TapjoyAPI", "Automatic session tracking is not available on this device.");
                    } else {
                        if (hashtable != null) {
                            String valueOf = String.valueOf(hashtable.get(TapjoyConnectFlag.DISABLE_AUTOMATIC_SESSION_TRACKING));
                            if (valueOf != null && valueOf.equalsIgnoreCase("true")) {
                                z = true;
                            }
                        }
                        if (z) {
                            TapjoyLog.m252i("TapjoyAPI", "Automatic session tracking is disabled.");
                        } else {
                            eo.m778a(context);
                        }
                    }
                    z = true;
                } catch (TapjoyIntegrationException e) {
                    TapjoyLog.m250e("TapjoyAPI", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, e.getMessage()));
                    if (tJConnectListener != null) {
                        tJConnectListener.onConnectFailure();
                    }
                } catch (TapjoyException e2) {
                    TapjoyLog.m250e("TapjoyAPI", new TapjoyErrorMessage(ErrorType.SDK_ERROR, e2.getMessage()));
                    if (tJConnectListener != null) {
                        tJConnectListener.onConnectFailure();
                    }
                }
            }
        }
        return z;
    }

    public final TJPlacement mo130a(String str, TJPlacementListener tJPlacementListener) {
        return TJPlacementManager.m207a(str, "", "", tJPlacementListener);
    }

    public final void mo136a(Activity activity) {
        if (activity != null) {
            C0140d.m472a(activity);
        } else {
            TapjoyLog.m250e("TapjoyAPI", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Cannot set activity to NULL"));
        }
    }

    public final void mo131a(float f) {
        if (m653i("setCurrencyMultiplier")) {
            TapjoyConnectCore.getInstance().setCurrencyMultiplier(f);
        }
    }

    public final float mo163c() {
        if (m653i("getCurrencyMultiplier")) {
            return TapjoyConnectCore.getInstance().getCurrencyMultiplier();
        }
        return TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
    }

    public final void mo169e(String str) {
        if (m652h("actionComplete")) {
            TapjoyConnectCore.getInstance().actionComplete(str);
        }
    }

    public final void mo139a(TJGetCurrencyBalanceListener tJGetCurrencyBalanceListener) {
        if (this.f702d != null && m652h("getCurrencyBalance")) {
            this.f702d.getCurrencyBalance(tJGetCurrencyBalanceListener);
        }
    }

    public final void mo134a(int i, TJSpendCurrencyListener tJSpendCurrencyListener) {
        if (this.f702d != null && m652h("spendCurrency")) {
            this.f702d.spendCurrency(i, tJSpendCurrencyListener);
        }
    }

    public final void mo133a(int i, TJAwardCurrencyListener tJAwardCurrencyListener) {
        if (this.f702d != null && m652h("awardCurrency")) {
            this.f702d.awardCurrency(i, tJAwardCurrencyListener);
        }
    }

    public final void mo138a(TJEarnedCurrencyListener tJEarnedCurrencyListener) {
        if (this.f702d != null && m652h("setEarnedCurrencyListener")) {
            this.f702d.setEarnedCurrencyListener(tJEarnedCurrencyListener);
        }
    }

    public final void mo140a(TJVideoListener tJVideoListener) {
        if (m653i("setVideoListener")) {
            TJAdUnit.publisherVideoListener = tJVideoListener;
        }
    }

    public final void mo145a(String str, String str2, double d, String str3) {
        gd a = gd.m956a();
        if (a.m972b("trackPurchase")) {
            String a2 = fy.m921a(str, "trackPurchase", "productId");
            if (a2 != null) {
                String a3 = fy.m921a(str2, "trackPurchase", "currencyCode");
                if (a3 == null) {
                    return;
                }
                if (a3.length() != 3) {
                    ga.m937a("trackPurchase", "currencyCode", "invalid currency code");
                    return;
                }
                a.f1166g.m950a(a2, a3.toUpperCase(Locale.US), d, null, null, fy.m922b(str3));
                ga.m936a("trackPurchase called");
            }
        }
    }

    public final void mo147a(String str, String str2, String str3, String str4) {
        fr.m903a(str, str2, str3, str4);
    }

    public final void mo144a(String str, String str2) {
        fr.m903a(str, null, null, str2);
    }

    public final void mo141a(String str) {
        fr.m904a(null, str, null, null, 0);
    }

    public final void mo142a(String str, long j) {
        fr.m904a(null, str, null, null, j);
    }

    public final void mo146a(String str, String str2, long j) {
        fr.m904a(str, str2, null, null, j);
    }

    public final void mo161b(String str, String str2, String str3, String str4) {
        fr.m904a(str, str2, str3, str4, 0);
    }

    public final void mo148a(String str, String str2, String str3, String str4, long j) {
        fr.m904a(str, str2, str3, str4, j);
    }

    public final void mo149a(String str, String str2, String str3, String str4, String str5, long j) {
        fr.m905a(str, str2, str3, str4, str5, j, null, 0, null, 0);
    }

    public final void mo150a(String str, String str2, String str3, String str4, String str5, long j, String str6, long j2) {
        fr.m905a(str, str2, str3, str4, str5, j, str6, j2, null, 0);
    }

    public final void mo151a(String str, String str2, String str3, String str4, String str5, long j, String str6, long j2, String str7, long j3) {
        fr.m905a(str, str2, str3, str4, str5, j, str6, j2, str7, j3);
    }

    public final void mo166d() {
        if (m653i("startSession")) {
            if (VERSION.SDK_INT >= 14) {
                eo.m777a();
            }
            TapjoyConnectCore.getInstance().appResume();
            fr.m901a();
        }
    }

    public final void mo168e() {
        if (m653i("endSession")) {
            if (VERSION.SDK_INT >= 14) {
                eo.m777a();
            }
            gd.m956a().f1173n = false;
            TapjoyConnectCore.getInstance().appPause();
            fr.m906b();
        }
    }

    public final void mo159b(Activity activity) {
        if (VERSION.SDK_INT >= 14) {
            eo.m777a();
        }
        gd.m956a().f1173n = true;
        fr.m902a(activity);
    }

    public final void mo164c(Activity activity) {
        if (VERSION.SDK_INT >= 14) {
            eo.m777a();
        }
        fr.m907b(activity);
    }

    public final void mo143a(String str, TJSetUserIDListener tJSetUserIDListener) {
        if (m653i("setUserID")) {
            TapjoyConnectCore.setUserID(str, tJSetUserIDListener);
            gd a = gd.m956a();
            if (a.m974c("setUserId")) {
                a.f1165f.m1062b(fy.m920a(str));
            }
        } else if (tJSetUserIDListener != null) {
            tJSetUserIDListener.onSetUserIDFailure(this.f701c);
        }
    }

    public final void mo135a(int i, String str) {
        gd a = gd.m956a();
        if (a.m974c("setUserCohortVariable")) {
            int i2;
            if (i <= 0 || i > 5) {
                i2 = 0;
            } else {
                i2 = 1;
            }
            String str2 = "setCohortVariable: variableIndex is out of range";
            if (ga.f1141a && i2 == 0) {
                ga.m941b(str2);
            }
            if (i2 != 0) {
                ga.m938a("setUserCohortVariable({}, {}) called", Integer.valueOf(i), str);
                a.f1165f.m1055a(i, fy.m920a(str));
            }
        }
    }

    public final Set mo170f() {
        return gd.m956a().m973c();
    }

    public final void mo153a(Set set) {
        gd.m956a().m969a(set);
    }

    public final void mo173g() {
        gd.m956a().m969a(null);
    }

    public final void mo165c(String str) {
        if (!ct.m463c(str)) {
            gd a = gd.m956a();
            Set c = a.m973c();
            if (c.add(str)) {
                a.m969a(c);
            }
        }
    }

    public final void mo167d(String str) {
        if (!ct.m463c(str)) {
            gd a = gd.m956a();
            Set c = a.m973c();
            if (c.remove(str)) {
                a.m969a(c);
            }
        }
    }

    public final boolean mo174h() {
        gd a = gd.m956a();
        if (!a.m974c("isPushNotificationDisabled")) {
            return false;
        }
        ga.m938a("isPushNotificationDisabled = {}", Boolean.valueOf(a.f1165f.m1067f()));
        return a.f1165f.m1067f();
    }

    public final void mo162b(boolean z) {
        int i = 0;
        gd a = gd.m956a();
        if (a.m974c("setPushNotificationDisabled")) {
            Object[] objArr;
            Boolean valueOf;
            String str;
            Object[] objArr2;
            boolean a2 = a.f1165f.m1059a(z);
            if (a2) {
                objArr = new Object[1];
                valueOf = Boolean.valueOf(z);
                str = "setPushNotificationDisabled({}) called";
                objArr2 = objArr;
            } else {
                str = "setPushNotificationDisabled({}) called, but it is already {}";
                objArr2 = new Object[2];
                objArr2[0] = Boolean.valueOf(z);
                if (z) {
                    valueOf = "disabled";
                    i = 1;
                    objArr = objArr2;
                } else {
                    valueOf = String.ENABLED;
                    i = 1;
                    objArr = objArr2;
                }
            }
            objArr[i] = valueOf;
            ga.m938a(str, objArr2);
            if (a2 && a.f1170k && !ct.m463c(a.f1163d)) {
                String str2;
                if (a.f1174o != null) {
                    str2 = null;
                } else {
                    C0237r b = gf.m1039b(a.f1164e);
                    str2 = ct.m462b(b.f1199b.mo215b(b.f1198a));
                }
                a.m965a(str2);
            }
        }
    }

    public final boolean mo175i() {
        return this.a;
    }

    public final String mo172g(String str) {
        if (m652h("getSupportURL")) {
            return TapjoyConnectCore.getSupportURL(str);
        }
        return null;
    }

    private boolean m652h(String str) {
        if (this.a) {
            return true;
        }
        TapjoyLog.m254w("TapjoyAPI", "Can not call " + str + " because Tapjoy SDK has not successfully connected.");
        return false;
    }

    private boolean m653i(String str) {
        if (this.f700b) {
            return true;
        }
        this.f701c = "Can not call " + str + " because Tapjoy SDK is not initialized.";
        TapjoyLog.m250e("TapjoyAPI", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, this.f701c));
        return false;
    }

    public final void mo152a(String str, String str2, String str3, String str4, Map map) {
        gd a = gd.m956a();
        if (a.m972b("trackEvent") && !ct.m463c(str2)) {
            Map b = cx.m469b();
            if (map != null && map.size() > 0) {
                for (Entry entry : map.entrySet()) {
                    Object key = entry.getKey();
                    String str5;
                    if (key == null) {
                        String str6 = "trackEvent";
                        str5 = "key in values map";
                        if (ga.f1141a) {
                            ac.m268a("Tapjoy", "{}: {} must not be null", str6, str5);
                            return;
                        }
                        return;
                    } else if (key instanceof String) {
                        str5 = fy.m921a((String) key, "trackEvent", "key in values map");
                        if (str5 != null) {
                            Object value = entry.getValue();
                            if (value instanceof Number) {
                                b.put(str5, Long.valueOf(((Number) value).longValue()));
                            } else {
                                ga.m937a("trackEvent", "value in values map", "must be a long");
                                return;
                            }
                        }
                        return;
                    }
                }
            }
            a.f1166g.m952a(str, str2, str3, str4, b);
            ga.m938a("trackEvent category:{}, name:{}, p1:{}, p2:{}, values:{} called", str, str2, str3, str4, b);
        }
    }

    public final void mo132a(int i) {
        gd a = gd.m956a();
        if (a.m974c("setUserLevel")) {
            Integer valueOf;
            ga.m938a("setUserLevel({}) called", Integer.valueOf(i));
            gg ggVar = a.f1165f;
            if (i >= 0) {
                valueOf = Integer.valueOf(i);
            } else {
                valueOf = null;
            }
            ggVar.m1056a(valueOf);
        }
    }

    public final void mo158b(int i) {
        gd a = gd.m956a();
        if (a.m974c("setUserFriendCount")) {
            Integer valueOf;
            ga.m938a("setUserFriendCount({}) called", Integer.valueOf(i));
            gg ggVar = a.f1165f;
            if (i >= 0) {
                valueOf = Integer.valueOf(i);
            } else {
                valueOf = null;
            }
            ggVar.m1061b(valueOf);
        }
    }

    public final void mo160b(String str) {
        gd a = gd.m956a();
        if (a.m974c("setAppDataVersion")) {
            a.f1165f.m1057a(fy.m920a(str));
        }
    }

    public final void mo171f(String str) {
        gd a = gd.m956a();
        ga.m938a("setGcmSender({}) called", str);
        a.f1163d = ct.m461a(str);
        a.m970b();
    }

    public final void mo137a(GLSurfaceView gLSurfaceView) {
        gd.m956a();
        gd.m959a(gLSurfaceView);
    }
}
