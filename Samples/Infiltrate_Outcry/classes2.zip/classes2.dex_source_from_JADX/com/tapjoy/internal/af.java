package com.tapjoy.internal;

import android.content.Context;
import android.graphics.Point;
import android.os.Build.VERSION;
import android.view.Display;
import android.view.WindowManager;

public enum af {
    UNSPECIFIED,
    PORTRAIT,
    LANDSCAPE,
    SQUARE,
    NATURAL_PORTRAIT(PORTRAIT),
    RIGHT_LANDSCAPE(LANDSCAPE, NATURAL_PORTRAIT),
    REVERSE_PORTRAIT(PORTRAIT, NATURAL_PORTRAIT),
    LEFT_LANDSCAPE(LANDSCAPE, NATURAL_PORTRAIT),
    NATURAL_LANDSCAPE(LANDSCAPE),
    RIGHT_PORTRAIT(PORTRAIT, NATURAL_LANDSCAPE),
    REVERSE_LANDSCAPE(LANDSCAPE, NATURAL_LANDSCAPE),
    LEFT_PORTRAIT(PORTRAIT, NATURAL_LANDSCAPE),
    NATURAL_SQUARE(SQUARE),
    RIGHT_SQUARE(SQUARE, NATURAL_SQUARE),
    REVERSE_SQUARE(SQUARE, NATURAL_SQUARE),
    LEFT_SQUARE(SQUARE, NATURAL_SQUARE);
    
    private final af f474q;
    private final af f475r;

    private af(af afVar) {
        this.f474q = afVar;
        this.f475r = this;
    }

    private af(af afVar, af afVar2) {
        this.f474q = afVar;
        this.f475r = afVar2;
    }

    public final boolean m278a() {
        return this == PORTRAIT || this.f474q == PORTRAIT;
    }

    public final boolean m279b() {
        return this == LANDSCAPE || this.f474q == LANDSCAPE;
    }

    public final int m280c() {
        return this.f475r != null ? ordinal() - this.f475r.ordinal() : 0;
    }

    public static af m276a(Context context) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int rotation = defaultDisplay.getRotation();
        Point point = new Point();
        if (VERSION.SDK_INT >= 13) {
            defaultDisplay.getSize(point);
        } else {
            point.x = defaultDisplay.getWidth();
            point.y = defaultDisplay.getHeight();
        }
        if (point.x < point.y) {
            switch (rotation & 3) {
                case 1:
                    return RIGHT_PORTRAIT;
                case 2:
                    return REVERSE_PORTRAIT;
                case 3:
                    return LEFT_PORTRAIT;
                default:
                    return NATURAL_PORTRAIT;
            }
        } else if (point.x > point.y) {
            switch (rotation & 3) {
                case 1:
                    return RIGHT_LANDSCAPE;
                case 2:
                    return REVERSE_LANDSCAPE;
                case 3:
                    return LEFT_LANDSCAPE;
                default:
                    return NATURAL_LANDSCAPE;
            }
        } else {
            switch (rotation & 3) {
                case 1:
                    return RIGHT_SQUARE;
                case 2:
                    return REVERSE_SQUARE;
                case 3:
                    return LEFT_SQUARE;
                default:
                    return NATURAL_SQUARE;
            }
        }
    }

    public static af m277b(Context context) {
        switch (context.getResources().getConfiguration().orientation) {
            case 1:
                return PORTRAIT;
            case 2:
                return LANDSCAPE;
            default:
                return UNSPECIFIED;
        }
    }
}
