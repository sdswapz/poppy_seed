package com.tapjoy.internal;

import android.content.Context;
import android.content.Intent;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;
import com.tapjoy.TapjoyConstants;
import com.tapjoy.internal.dy.C0165a;
import java.io.File;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;

public final class gd {
    private static final gd f1156q;
    private static gd f1157r;
    private static Handler f1158w;
    private static File f1159x;
    public final gl f1160a = new gl(this);
    public gm f1161b;
    public boolean f1162c = false;
    public String f1163d = null;
    public Context f1164e;
    public gg f1165f;
    public gc f1166g;
    public gq f1167h;
    public gb f1168i;
    public String f1169j;
    public boolean f1170k;
    public String f1171l;
    public String f1172m;
    public boolean f1173n = false;
    public String f1174o;
    public ge f1175p = ge.m978a(null);
    private boolean f1176s = false;
    private boolean f1177t = false;
    private String f1178u;
    private String f1179v;

    static {
        gd gdVar = new gd();
        f1156q = gdVar;
        f1157r = gdVar;
    }

    public static gd m956a() {
        return f1157r;
    }

    private gd() {
    }

    final synchronized void m971b(Context context) {
        if (this.f1164e == null) {
            Context applicationContext = context.getApplicationContext();
            this.f1164e = applicationContext;
            fd.m836a().m838a(applicationContext);
            this.f1165f = gg.m1049a(applicationContext);
            File file = new File(m961c(applicationContext), "events2");
            if (this.f1168i == null) {
                this.f1168i = new gb(file);
            }
            this.f1166g = new gc(this.f1165f, this.f1168i);
            this.f1167h = new gq(this.f1166g);
            this.f1161b = new gm(applicationContext);
            fj.m871a(new fl(new File(m961c(applicationContext), "usages"), this.f1166g));
            gx gxVar = gx.f1309a;
            gxVar.f1310b = applicationContext.getApplicationContext();
            gxVar.f1311c = applicationContext.getSharedPreferences("tapjoyCacheDataMMF2E", 0);
            gxVar.f1312d = applicationContext.getSharedPreferences("tapjoyCacheDataMMF2U", 0);
            gxVar.m1125a();
        }
    }

    public final ee m963a(boolean z) {
        if (z) {
            this.f1165f.m1054a();
        }
        return this.f1165f.m1060b();
    }

    public final synchronized void m970b() {
        if (this.f1170k) {
            gf.m1039b(this.f1164e).mo230e(this.f1163d);
            m965a(null);
        }
    }

    public final synchronized void m965a(String str) {
        if (this.f1170k) {
            if (str == null && this.f1174o != null) {
                str = this.f1174o;
            }
            this.f1174o = null;
            if (str != null) {
                ga.m938a("GCM registration id of device {} updated for sender {}: {}", this.f1165f.m1060b().f849d.f829h, this.f1163d, str);
                new hp(r0, str).m442a(new ck(this) {
                    final /* synthetic */ gd f1155b;

                    public final /* synthetic */ void mo209a(cf cfVar, Object obj) {
                        C0237r b = gf.m1039b(this.f1155b.f1164e);
                        String str = str;
                        long currentTimeMillis = 0 != 0 ? System.currentTimeMillis() + 0 : 0;
                        if (str.equals(b.f1199b.mo215b(b.f1198a))) {
                            b.f1199b.mo218b(b.f1198a, true);
                            if (currentTimeMillis != 0) {
                                new Object[1][0] = new Timestamp(currentTimeMillis);
                            }
                            b.f1199b.mo212a(b.f1198a, currentTimeMillis);
                            return;
                        }
                        new Object[1][0] = str;
                    }

                    public final void mo208a(cf cfVar) {
                    }
                }, cf.f593a);
            }
        } else if (str != null) {
            this.f1174o = str;
        }
    }

    public static void m959a(GLSurfaceView gLSurfaceView) {
        if (ga.m939a((Object) gLSurfaceView, "setGLSurfaceView: The given GLSurfaceView was null")) {
            fv.m916a(gLSurfaceView);
        }
    }

    public final Set m973c() {
        if (m974c("getUserTags")) {
            return this.f1165f.m1066e();
        }
        return new HashSet();
    }

    public final void m969a(Set set) {
        if (m974c("setUserTags")) {
            if (!(set == null || set.isEmpty())) {
                Set hashSet = new HashSet();
                for (String str : set) {
                    String str2;
                    if (str2 != null) {
                        str2 = str2.trim();
                        if (!str2.isEmpty() && str2.length() <= 200) {
                            hashSet.add(str2);
                            if (hashSet.size() >= 200) {
                                break;
                            }
                        }
                    }
                }
                set = hashSet;
            }
            gg ggVar = this.f1165f;
            synchronized (ggVar) {
                if (set != null) {
                    if (!set.isEmpty()) {
                        ggVar.f1206c.f1267z.m1339a(Base64.encodeToString(ej.f905c.m521b(new ej(new ArrayList(set))), 2));
                        ggVar.f1205b.f907A.clear();
                        ggVar.f1205b.f907A.addAll(set);
                    }
                }
                ggVar.f1206c.f1267z.m1319c();
                ggVar.f1205b.f907A.clear();
            }
        }
    }

    public final synchronized void m964a(Context context, String str, String str2, String str3, String str4, String str5) {
        Object obj = 1;
        synchronized (this) {
            if (!this.f1170k) {
                boolean z;
                m971b(context);
                if (this.f1164e != null) {
                    z = true;
                } else {
                    z = false;
                }
                if (ga.m940a(z, "The given context was null")) {
                    Object obj2;
                    if (str4 != null && str4.length() == 24 && str4.matches("[0-9a-f]{24}")) {
                        obj2 = 1;
                    } else {
                        ga.m942b("Invalid App ID: {}", str4);
                        obj2 = null;
                    }
                    if (obj2 != null) {
                        if (str5 != null && str5.length() == 20 && str5.matches("[0-9A-Za-z\\-_]{20}")) {
                            obj2 = 1;
                        } else {
                            ga.m942b("Invalid App Key: {}", str5);
                            obj2 = null;
                        }
                        if (obj2 != null) {
                            this.f1171l = str;
                            this.f1172m = str2;
                            this.f1178u = str4;
                            this.f1179v = str5;
                            try {
                                URL url = new URL(str3);
                                ci cjVar = new cj("TapjoySDK" + " " + str2 + " (" + Build.MODEL + "; Android " + VERSION.RELEASE + "; " + Locale.getDefault() + ")", url);
                                cf.f594b = cjVar;
                                cf.f593a = Executors.newCachedThreadPool();
                                gb gbVar = this.f1168i;
                                gbVar.f1145b = cjVar;
                                gbVar.m946a();
                                new Object[1][0] = str3;
                                this.f1170k = true;
                                gh ghVar = new gh(m962d(this.f1164e));
                                if (ghVar.m1069b() == null) {
                                    obj = null;
                                }
                                if (obj == null && ghVar.m1068a()) {
                                    gc gcVar = this.f1166g;
                                    gcVar.m949a(gcVar.m948a(eb.APP, "install"));
                                }
                                gg ggVar = this.f1165f;
                                if (!(ct.m463c(str4) || str4.equals(ggVar.f1206c.f1241D.m1338a()))) {
                                    ggVar.f1206c.f1241D.m1339a(str4);
                                    ggVar.f1206c.m1092a(false);
                                }
                                m970b();
                            } catch (Throwable e) {
                                throw new IllegalArgumentException(e);
                            }
                        }
                    }
                }
            }
        }
    }

    public final boolean m972b(String str) {
        if ((this.f1170k || this.f1169j != null) && this.f1164e != null) {
            return true;
        }
        if (ga.f1141a) {
            ga.m941b(str + ": Should be called after initializing the SDK");
        }
        return false;
    }

    public final boolean m974c(String str) {
        if (this.f1164e != null) {
            return true;
        }
        if (ga.f1141a) {
            ga.m941b(str + ": Should be called after initializing the SDK");
        }
        return false;
    }

    public final boolean m975d() {
        return this.f1167h != null && this.f1167h.f1279b.get();
    }

    public final boolean m976e() {
        boolean z;
        gq gqVar = this.f1167h;
        if (gqVar.f1280c != null) {
            gqVar.f1280c.cancel(false);
            gqVar.f1280c = null;
        }
        if (gqVar.f1279b.compareAndSet(false, true)) {
            ga.m936a("New session started");
            gc gcVar = gqVar.f1278a;
            ef d = gcVar.f1149a.m1065d();
            gg ggVar = gcVar.f1149a;
            synchronized (ggVar) {
                int b = ggVar.f1206c.f1249h.m1329b() + 1;
                ggVar.f1206c.f1249h.m1327a(b);
                ggVar.f1205b.f914h = Integer.valueOf(b);
            }
            C0165a a = gcVar.m948a(eb.APP, "bootup");
            gcVar.f1151c = SystemClock.elapsedRealtime();
            if (d != null) {
                a.f743s = d;
            }
            gcVar.m949a(a);
            ev.f1015c.notifyObservers();
            z = true;
        } else {
            z = false;
        }
        if (!z) {
            return false;
        }
        gl glVar = this.f1160a;
        synchronized (glVar) {
            glVar.f1232b = null;
        }
        gx.f1309a.m1125a();
        return true;
    }

    final void m966a(Map map) {
        gc gcVar = this.f1166g;
        C0165a a = gcVar.m948a(eb.CAMPAIGN, "impression");
        if (map != null) {
            a.f742r = bm.m327a((Object) map);
        }
        gcVar.m949a(a);
    }

    final void m967a(Map map, long j) {
        gc gcVar = this.f1166g;
        C0165a a = gcVar.m948a(eb.CAMPAIGN, "view");
        a.f733i = Long.valueOf(j);
        if (map != null) {
            a.f742r = bm.m327a((Object) map);
        }
        gcVar.m949a(a);
    }

    final void m968a(Map map, String str) {
        gc gcVar = this.f1166g;
        C0165a a = gcVar.m948a(eb.CAMPAIGN, "click");
        Object linkedHashMap = new LinkedHashMap(map);
        linkedHashMap.put("region", str);
        a.f742r = bm.m327a(linkedHashMap);
        gcVar.m949a(a);
    }

    public static synchronized void m960a(Runnable runnable) {
        synchronized (gd.class) {
            if (f1158w == null) {
                f1158w = new Handler(Looper.getMainLooper());
            }
            f1158w.post(runnable);
        }
    }

    static synchronized File m961c(Context context) {
        File file;
        synchronized (gd.class) {
            if (f1159x == null) {
                f1159x = context.getDir("fiverocks", 0);
            }
            file = f1159x;
        }
        return file;
    }

    static File m962d(Context context) {
        return new File(m961c(context), "install");
    }

    public static String m958a(Context context, Intent intent) {
        String a = C0199f.m811a(intent);
        if (a != null) {
            gd gdVar = f1157r;
            gdVar.m971b(context);
            if (ct.m463c(gdVar.f1165f.m1063c()) || intent.getBooleanExtra("fiverocks:force", false)) {
                gg ggVar = gdVar.f1165f;
                synchronized (ggVar) {
                    ggVar.f1206c.f1245d.m1339a(a);
                    ggVar.f1205b.f910d = a;
                }
                if (a.length() > 0) {
                    gc gcVar = gdVar.f1166g;
                    gcVar.m949a(gcVar.m948a(eb.APP, TapjoyConstants.TJC_REFERRER));
                }
            }
        }
        return a;
    }

    public static gd m957a(Context context) {
        gd gdVar = f1157r;
        gdVar.m971b(context);
        return gdVar;
    }
}
