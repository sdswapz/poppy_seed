package com.tapjoy.internal;

public interface hx extends ig {
    void mo254a(long j);

    hy mo259b(long j);

    boolean mo260b();

    byte mo261c();

    String mo262c(long j);

    void mo265d(long j);

    int mo266e();

    long mo268f();
}
