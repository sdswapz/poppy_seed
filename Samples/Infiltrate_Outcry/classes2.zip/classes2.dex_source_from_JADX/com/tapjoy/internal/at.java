package com.tapjoy.internal;

public interface at {
    Object mo89a();

    void mo90a(Object obj);
}
