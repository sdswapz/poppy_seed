package com.tapjoy.internal;

import android.app.Activity;
import android.app.Application;
import java.util.Collections;
import java.util.Set;

public final class C0140d {
    private static Application f616a;
    private static int f617b;
    private static final cd f618c = new cd();
    private static final Set f619d = Collections.synchronizedSet(new bd());
    private static final cd f620e = new cd();

    public static boolean m475b() {
        return f617b > 0;
    }

    public static Activity m476c() {
        Activity activity = (Activity) f618c.m438a();
        if (activity != null) {
            return activity;
        }
        return (Activity) cw.m467a(f619d.iterator());
    }

    public static void m472a(Activity activity) {
        f618c.m439a(activity);
    }

    public static synchronized void m473a(Application application) {
        synchronized (C0140d.class) {
            if (f616a != application) {
                f616a = application;
            }
        }
    }

    public static void m474b(Activity activity) {
        f617b++;
        f618c.m439a(activity);
        f619d.add(activity);
    }

    public static void m477c(Activity activity) {
        f617b--;
        f618c.f592a = null;
        f619d.remove(activity);
        if (f617b < 0) {
            f617b = 0;
        }
    }

    public static Activity m471a() {
        Activity activity = (Activity) f620e.m438a();
        if (activity == null) {
            return C0140d.m476c();
        }
        return activity;
    }
}
