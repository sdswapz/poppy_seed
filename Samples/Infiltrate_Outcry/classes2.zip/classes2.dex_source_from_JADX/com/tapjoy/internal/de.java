package com.tapjoy.internal;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

public abstract class de implements dh {
    private final C0144a f634a = new C0144a();
    private final dg f635b = new dg();

    static final class C0144a extends AbstractQueuedSynchronizer {
        private Object f632a;
        private Throwable f633b;

        C0144a() {
        }

        protected final int tryAcquireShared(int ignored) {
            if (m503b()) {
                return 1;
            }
            return -1;
        }

        protected final boolean tryReleaseShared(int finalState) {
            setState(finalState);
            return true;
        }

        final Object m501a() {
            int state = getState();
            switch (state) {
                case 2:
                    if (this.f633b == null) {
                        return this.f632a;
                    }
                    throw new ExecutionException(this.f633b);
                case 4:
                    throw new CancellationException("Task was cancelled.");
                default:
                    throw new IllegalStateException("Error, synchronizer in invalid state: " + state);
            }
        }

        final boolean m503b() {
            return (getState() & 6) != 0;
        }

        final boolean m504c() {
            return getState() == 4;
        }

        final boolean m502a(Object obj, Throwable th, int i) {
            boolean compareAndSetState = compareAndSetState(0, 1);
            if (compareAndSetState) {
                this.f632a = obj;
                this.f633b = th;
                releaseShared(i);
            } else if (getState() == 1) {
                acquireShared(-1);
            }
            return compareAndSetState;
        }
    }

    public Object get(long timeout, TimeUnit unit) {
        C0144a c0144a = this.f634a;
        if (c0144a.tryAcquireSharedNanos(-1, unit.toNanos(timeout))) {
            return c0144a.m501a();
        }
        throw new TimeoutException("Timeout waiting for task.");
    }

    public Object get() {
        C0144a c0144a = this.f634a;
        c0144a.acquireSharedInterruptibly(-1);
        return c0144a.m501a();
    }

    public boolean isDone() {
        return this.f634a.m503b();
    }

    public boolean isCancelled() {
        return this.f634a.m504c();
    }

    public boolean cancel(boolean mayInterruptIfRunning) {
        if (!this.f634a.m502a(null, null, 4)) {
            return false;
        }
        this.f635b.m508a();
        return true;
    }

    protected final boolean m505a(Object obj) {
        boolean a = this.f634a.m502a(obj, null, 2);
        if (a) {
            this.f635b.m508a();
        }
        return a;
    }

    protected final boolean m506a(Throwable th) {
        boolean a = this.f634a.m502a(null, (Throwable) cs.m459a((Object) th), 2);
        if (a) {
            this.f635b.m508a();
        }
        if (!(th instanceof Error)) {
            return a;
        }
        throw ((Error) th);
    }
}
