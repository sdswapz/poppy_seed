package com.tapjoy.internal;

import android.os.SystemClock;

public final class el {
    public static final el f975a = new el(-1);
    public final long f976b;
    public long f977c;

    public el(long j) {
        this.f976b = j;
        this.f977c = SystemClock.elapsedRealtime();
    }

    public el() {
        this.f976b = 3600000;
        try {
            this.f977c = SystemClock.elapsedRealtime() - 3600000;
        } catch (NullPointerException e) {
            this.f977c = -1;
        }
    }

    public final boolean m769a() {
        try {
            return SystemClock.elapsedRealtime() - this.f977c > this.f976b;
        } catch (NullPointerException e) {
            return true;
        }
    }

    public final boolean m770a(long j) {
        try {
            return (SystemClock.elapsedRealtime() - this.f977c) + j > this.f976b;
        } catch (NullPointerException e) {
            return true;
        }
    }
}
