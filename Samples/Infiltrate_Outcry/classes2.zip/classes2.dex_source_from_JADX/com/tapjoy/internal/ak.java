package com.tapjoy.internal;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public final class ak extends Animation {
    private final boolean f488a;
    private final float f489b;
    private final float f490c;
    private final int f491d;
    private final float f492e;
    private final int f493f;
    private final float f494g;
    private float f495h;
    private float f496i;
    private Camera f497j;

    public ak(boolean z, float f, float f2, int i, float f3, int i2, float f4) {
        this.f488a = z;
        this.f489b = f;
        this.f490c = f2;
        this.f491d = i;
        this.f492e = f3;
        this.f493f = i2;
        this.f494g = f4;
    }

    public final void initialize(int width, int height, int parentWidth, int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
        this.f495h = resolveSize(this.f491d, this.f492e, width, parentWidth);
        this.f496i = resolveSize(this.f493f, this.f494g, height, parentHeight);
        this.f497j = new Camera();
    }

    protected final void applyTransformation(float interpolatedTime, Transformation t) {
        float f = this.f489b;
        f += (this.f490c - f) * interpolatedTime;
        Matrix matrix = t.getMatrix();
        Camera camera = this.f497j;
        camera.save();
        if (this.f488a) {
            camera.rotateX(f);
        } else {
            camera.rotateY(f);
        }
        camera.getMatrix(matrix);
        camera.restore();
        f = this.f495h;
        float f2 = this.f496i;
        matrix.preTranslate(-f, -f2);
        matrix.postTranslate(f, f2);
    }
}
