package com.tapjoy.internal;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public abstract class bs implements bp, bu {
    private HashMap f547a;

    public static abstract class C0132a {
        private static C0132a f546a;

        public static C0132a m347a() {
            C0132a c0132a = f546a;
            if (c0132a != null) {
                return c0132a;
            }
            c0132a = bt.f549a;
            f546a = c0132a;
            return c0132a;
        }

        public final bs m348a(InputStream inputStream) {
            return mo100a(new InputStreamReader(inputStream, cp.f605c));
        }

        public bs mo100a(Reader reader) {
            return mo101a(db.m480a(reader));
        }

        public bs mo101a(String str) {
            return m348a(new ByteArrayInputStream(str.getBytes(cp.f605c.name())));
        }
    }

    public static bs m365a(InputStream inputStream) {
        return C0132a.m347a().m348a(inputStream);
    }

    public static bs m367b(String str) {
        return C0132a.m347a().mo101a(str);
    }

    public final Object mo98a(String str) {
        return this.f547a != null ? this.f547a.get(str) : null;
    }

    public final void mo99a(String str, Object obj) {
        if (this.f547a == null) {
            this.f547a = new HashMap();
        }
        this.f547a.put(str, obj);
    }

    public final boolean m376a() {
        return mo108k() == bx.BEGIN_OBJECT;
    }

    private boolean m369t() {
        if (mo108k() != bx.NULL) {
            return false;
        }
        mo112o();
        return true;
    }

    public final String m377b() {
        if (m369t()) {
            return null;
        }
        return mo110m();
    }

    public final String m378c(String str) {
        return m369t() ? str : mo110m();
    }

    private Object m370u() {
        bx k = mo108k();
        switch (k) {
            case BEGIN_ARRAY:
                return m379c();
            case BEGIN_OBJECT:
                return m380d();
            case NULL:
                mo112o();
                return null;
            case BOOLEAN:
                return Boolean.valueOf(mo111n());
            case NUMBER:
                return new cn(mo110m());
            case STRING:
                return mo110m();
            default:
                throw new IllegalStateException("Expected a value but was " + k);
        }
    }

    public final List m379c() {
        List linkedList = new LinkedList();
        m366a(linkedList);
        return linkedList;
    }

    private void m366a(List list) {
        mo103f();
        while (mo107j()) {
            list.add(m370u());
        }
        mo104g();
    }

    public final Map m380d() {
        Map linkedHashMap = new LinkedHashMap();
        m375a(linkedHashMap);
        return linkedHashMap;
    }

    public final void m375a(Map map) {
        mo105h();
        while (mo107j()) {
            map.put(mo109l(), m370u());
        }
        mo106i();
    }

    public final Object m371a(bn bnVar) {
        if (m369t()) {
            return null;
        }
        return bnVar.mo97a(this);
    }

    public final void m374a(List list, bn bnVar) {
        mo103f();
        while (mo107j()) {
            list.add(bnVar.mo97a(this));
        }
        mo104g();
    }

    private static URI m368d(String str) {
        try {
            return new URI(str);
        } catch (Throwable e) {
            throw new ca(e);
        }
    }

    public final URL m381e() {
        URI uri = (URI) mo98a("BASE_URI");
        if (uri != null) {
            return uri.resolve(m368d(mo110m())).toURL();
        }
        return new URL(mo110m());
    }
}
