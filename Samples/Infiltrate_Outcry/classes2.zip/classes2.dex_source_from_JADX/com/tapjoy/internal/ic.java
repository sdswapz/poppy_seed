package com.tapjoy.internal;

final class ic {
    final byte[] f1514a;
    int f1515b;
    int f1516c;
    boolean f1517d;
    boolean f1518e;
    ic f1519f;
    ic f1520g;

    ic() {
        this.f1514a = new byte[8192];
        this.f1518e = true;
        this.f1517d = false;
    }

    ic(ic icVar) {
        this(icVar.f1514a, icVar.f1515b, icVar.f1516c);
        icVar.f1517d = true;
    }

    ic(byte[] bArr, int i, int i2) {
        this.f1514a = bArr;
        this.f1515b = i;
        this.f1516c = i2;
        this.f1518e = false;
        this.f1517d = true;
    }

    public final ic m1286a() {
        ic icVar = this.f1519f != this ? this.f1519f : null;
        this.f1520g.f1519f = this.f1519f;
        this.f1519f.f1520g = this.f1520g;
        this.f1519f = null;
        this.f1520g = null;
        return icVar;
    }

    public final ic m1287a(ic icVar) {
        icVar.f1520g = this;
        icVar.f1519f = this.f1519f;
        this.f1519f.f1520g = icVar;
        this.f1519f = icVar;
        return icVar;
    }

    public final void m1288a(ic icVar, int i) {
        if (icVar.f1518e) {
            if (icVar.f1516c + i > 8192) {
                if (icVar.f1517d) {
                    throw new IllegalArgumentException();
                } else if ((icVar.f1516c + i) - icVar.f1515b > 8192) {
                    throw new IllegalArgumentException();
                } else {
                    System.arraycopy(icVar.f1514a, icVar.f1515b, icVar.f1514a, 0, icVar.f1516c - icVar.f1515b);
                    icVar.f1516c -= icVar.f1515b;
                    icVar.f1515b = 0;
                }
            }
            System.arraycopy(this.f1514a, this.f1515b, icVar.f1514a, icVar.f1516c, i);
            icVar.f1516c += i;
            this.f1515b += i;
            return;
        }
        throw new IllegalArgumentException();
    }
}
