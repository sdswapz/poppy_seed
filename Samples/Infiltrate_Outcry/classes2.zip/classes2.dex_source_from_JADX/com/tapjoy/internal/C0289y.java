package com.tapjoy.internal;

import android.os.SystemClock;

public final class C0289y {
    private static String f1551a = "pool.ntp.org";
    private static long f1552b = 20000;
    private static volatile boolean f1553c = false;
    private static volatile String f1554d;
    private static volatile long f1555e;
    private static volatile long f1556f;
    private static volatile long f1557g;
    private static volatile long f1558h;
    private static volatile long f1559i;

    static {
        C0289y.m1350a(false, "System", System.currentTimeMillis(), SystemClock.elapsedRealtime(), Long.MAX_VALUE);
    }

    private static synchronized void m1350a(boolean z, String str, long j, long j2, long j3) {
        synchronized (C0289y.class) {
            f1553c = z;
            f1554d = str;
            f1555e = j;
            f1556f = j2;
            f1557g = j3;
            f1558h = f1555e - f1556f;
            f1559i = (SystemClock.elapsedRealtime() + f1558h) - System.currentTimeMillis();
        }
    }

    public static boolean m1351a() {
        String str = f1551a;
        long j = f1552b;
        fo foVar = new fo();
        if (!foVar.m899a(str, (int) j)) {
            return false;
        }
        C0289y.m1350a(true, "SNTP", foVar.f1104a, foVar.f1105b, foVar.f1106c / 2);
        return true;
    }

    public static long m1352b() {
        return SystemClock.elapsedRealtime() + f1558h;
    }

    public static long m1349a(long j) {
        return f1558h + j;
    }

    public static boolean m1353c() {
        return f1553c;
    }
}
