package com.tapjoy.internal;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public final class em {
    private static em f978a = new em();

    public static InputStream m771a(String str) {
        URLConnection openConnection = new URL(str).openConnection();
        openConnection.connect();
        return openConnection.getInputStream();
    }

    public static URLConnection m772a(URL url) {
        return url.openConnection();
    }
}
