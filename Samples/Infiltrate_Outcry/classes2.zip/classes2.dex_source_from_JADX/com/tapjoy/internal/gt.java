package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyConstants;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public final class gt {
    public static String m1113a(ed edVar) {
        bm b = new bm().m339c().m333a(TapjoyConstants.TJC_SDK_PLACEMENT).m338b(edVar.f841t).m333a("os_name").m338b(edVar.f832k).m333a("os_ver").m338b(edVar.f833l).m333a("device_id").m338b(edVar.f829h).m333a("device_maker").m338b(edVar.f830i).m333a("device_model").m338b(edVar.f831j).m333a(TapjoyConstants.TJC_PACKAGE_ID).m338b(edVar.f839r).m333a(TapjoyConstants.TJC_PACKAGE_SIGN).m338b(edVar.f840s).m333a("locale").m338b(edVar.f837p).m333a(TapjoyConstants.TJC_DEVICE_TIMEZONE).m338b(edVar.f838q);
        if (edVar.f834m != null) {
            b.m333a(TapjoyConstants.TJC_DEVICE_DISPLAY_DENSITY).m332a(edVar.f834m);
        }
        if (edVar.f835n != null) {
            b.m333a(TapjoyConstants.TJC_DEVICE_DISPLAY_WIDTH).m332a(edVar.f835n);
        }
        if (edVar.f836o != null) {
            b.m333a(TapjoyConstants.TJC_DEVICE_DISPLAY_HEIGHT).m332a(edVar.f836o);
        }
        if (edVar.f828g != null) {
            b.m333a("mac").m338b(edVar.f828g);
        }
        if (edVar.f842u != null) {
            b.m333a(TapjoyConstants.TJC_DEVICE_COUNTRY_SIM).m338b(edVar.f842u);
        }
        if (edVar.f843v != null) {
            b.m333a("country_net").m338b(edVar.f843v);
        }
        if (edVar.f844w != null) {
            b.m333a("imei").m338b(edVar.f844w);
        }
        return b.m340d().toString();
    }

    public static String m1109a(dx dxVar) {
        bm c = new bm().m339c();
        if (dxVar.f721e != null) {
            c.m333a(TapjoyConstants.TJC_PACKAGE_VERSION).m338b(dxVar.f721e);
        }
        if (dxVar.f722f != null) {
            c.m333a(TapjoyConstants.TJC_PACKAGE_REVISION).m332a(dxVar.f722f);
        }
        if (dxVar.f723g != null) {
            c.m333a("data_ver").m338b(dxVar.f723g);
        }
        if (dxVar.f724h != null) {
            c.m333a(TapjoyConstants.TJC_INSTALLER).m338b(dxVar.f724h);
        }
        if (dxVar.f725i != null) {
            c.m333a(TapjoyConstants.TJC_STORE).m338b(dxVar.f725i);
        }
        return c.m340d().toString();
    }

    public static String m1114a(ek ekVar) {
        return m1115a(ekVar, null);
    }

    private static String m1115a(ek ekVar, dy dyVar) {
        bm c = new bm().m339c();
        if (ekVar.f967s != null) {
            c.m333a(TapjoyConstants.TJC_INSTALLED).m332a(ekVar.f967s);
        }
        if (ekVar.f968t != null) {
            c.m333a(TapjoyConstants.TJC_REFERRER).m338b(ekVar.f968t);
        }
        if (ekVar.f955G != null) {
            c.m333a("idfa").m338b(ekVar.f955G);
            if (ekVar.f956H != null && ekVar.f956H.booleanValue()) {
                c.m333a("idfa_optout").m330a(1);
            }
        } else if (!(dyVar == null || dyVar.f778r == null || !gg.f1203a.equals(dyVar.f778r))) {
            String b = gr.m1104b();
            if (b != null) {
                c.m333a("idfa").m338b(b);
                if (gr.m1105c()) {
                    c.m333a("idfa_optout").m330a(1);
                }
            }
        }
        if (ekVar.f969u != null) {
            c.m333a(TapjoyConstants.TJC_USER_WEEKLY_FREQUENCY).m330a((long) Math.max(ekVar.f969u.intValue(), 1));
        }
        if (ekVar.f970v != null) {
            c.m333a(TapjoyConstants.TJC_USER_MONTHLY_FREQUENCY).m330a((long) Math.max(ekVar.f970v.intValue(), 1));
        }
        if (ekVar.f971w.size() > 0) {
            ArrayList arrayList = new ArrayList(ekVar.f971w.size());
            for (eh ehVar : ekVar.f971w) {
                if (ehVar.f900h != null) {
                    arrayList.add(ehVar.f898f);
                }
            }
            if (!arrayList.isEmpty()) {
                c.m333a("push").m329a();
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    c.m338b((String) it.next());
                }
                c.m337b();
            }
        }
        c.m333a("session").m339c();
        if (ekVar.f972x != null) {
            c.m333a("total_count").m332a(ekVar.f972x);
        }
        if (ekVar.f973y != null) {
            c.m333a("total_length").m332a(ekVar.f973y);
        }
        if (ekVar.f974z != null) {
            c.m333a("last_at").m332a(ekVar.f974z);
        }
        if (ekVar.f949A != null) {
            c.m333a("last_length").m332a(ekVar.f949A);
        }
        c.m340d();
        c.m333a("purchase").m339c();
        if (ekVar.f950B != null) {
            c.m333a("currency").m338b(ekVar.f950B);
        }
        if (ekVar.f951C != null) {
            c.m333a("total_count").m332a(ekVar.f951C);
        }
        if (ekVar.f952D != null) {
            c.m333a("total_price").m332a(ekVar.f952D);
        }
        if (ekVar.f953E != null) {
            c.m333a("last_at").m332a(ekVar.f953E);
        }
        if (ekVar.f954F != null) {
            c.m333a("last_price").m332a(ekVar.f954F);
        }
        c.m340d();
        if (ekVar.f957I != null) {
            c.m333a("user_id").m338b(ekVar.f957I);
        }
        if (ekVar.f958J != null) {
            c.m333a(TapjoyConstants.TJC_USER_LEVEL).m332a(ekVar.f958J);
        }
        if (ekVar.f959K != null) {
            c.m333a(TapjoyConstants.TJC_USER_FRIEND_COUNT).m332a(ekVar.f959K);
        }
        if (ekVar.f960L != null) {
            c.m333a(TapjoyConstants.TJC_USER_VARIABLE_1).m338b(ekVar.f960L);
        }
        if (ekVar.f961M != null) {
            c.m333a(TapjoyConstants.TJC_USER_VARIABLE_2).m338b(ekVar.f961M);
        }
        if (ekVar.f962N != null) {
            c.m333a(TapjoyConstants.TJC_USER_VARIABLE_3).m338b(ekVar.f962N);
        }
        if (ekVar.f963O != null) {
            c.m333a(TapjoyConstants.TJC_USER_VARIABLE_4).m338b(ekVar.f963O);
        }
        if (ekVar.f964P != null) {
            c.m333a(TapjoyConstants.TJC_USER_VARIABLE_5).m338b(ekVar.f964P);
        }
        if (ekVar.f965Q.size() > 0) {
            c.m333a("tags").m334a(ekVar.f965Q);
        }
        if (Boolean.TRUE.equals(ekVar.f966R)) {
            c.m333a("push_optout").m330a(1);
        }
        return c.m340d().toString();
    }

    private static String m1110a(dy dyVar, boolean z, boolean z2, boolean z3) {
        bm b;
        bm b2 = new bm().m339c().m333a("type").m338b(m1112a(dyVar.f774n)).m333a(String.USAGE_TRACKER_NAME).m338b(dyVar.f775o);
        b2.m333a("time");
        if (dyVar.f777q != null) {
            b2.m332a(dyVar.f776p);
            b2.m333a("systime").m332a(dyVar.f777q);
        } else if (!C0289y.m1353c() || dyVar.f778r == null || dyVar.f779s == null || !gg.f1203a.equals(dyVar.f778r)) {
            b2.m332a(dyVar.f776p);
        } else {
            b2.m330a(C0289y.m1349a(dyVar.f779s.longValue()));
            b2.m333a("systime").m332a(dyVar.f776p);
        }
        if (dyVar.f780t != null) {
            b2.m333a("duration").m332a(dyVar.f780t);
        }
        if (!(z || dyVar.f781u == null)) {
            b2.m333a(String.VIDEO_INFO).m331a(new br(m1113a(dyVar.f781u)));
        }
        if (!(z2 || dyVar.f782v == null)) {
            b2.m333a(TapjoyConstants.TJC_APP_PLACEMENT).m331a(new br(m1109a(dyVar.f782v)));
        }
        if (!(z3 || dyVar.f783w == null)) {
            b2.m333a("user").m331a(new br(m1115a(dyVar.f783w, dyVar)));
        }
        if (dyVar.f785y != null) {
            b2.m333a("event_seq").m332a(dyVar.f785y);
        }
        if (dyVar.f786z != null) {
            bm a = b2.m333a("event_prev");
            ea eaVar = dyVar.f786z;
            b = new bm().m339c().m333a("type").m338b(m1112a(eaVar.f796e)).m333a(String.USAGE_TRACKER_NAME).m338b(eaVar.f797f);
            if (eaVar.f798g != null) {
                b.m333a("category").m338b(eaVar.f798g);
            }
            a.m331a(new br(b.m340d().toString()));
        }
        if (dyVar.f762A != null) {
            a = b2.m333a("purchase");
            eg egVar = dyVar.f762A;
            b = new bm().m339c().m333a("product_id").m338b(egVar.f878h);
            if (egVar.f879i != null) {
                b.m333a("product_quantity").m332a(egVar.f879i);
            }
            if (egVar.f880j != null) {
                b.m333a("product_price").m332a(egVar.f880j);
            }
            if (egVar.f881k != null) {
                b.m333a("product_price_currency").m338b(egVar.f881k);
            }
            if (egVar.f889s != null) {
                b.m333a("currency_price").m338b(egVar.f889s);
            }
            if (egVar.f882l != null) {
                b.m333a("product_type").m338b(egVar.f882l);
            }
            if (egVar.f883m != null) {
                b.m333a("product_title").m338b(egVar.f883m);
            }
            if (egVar.f884n != null) {
                b.m333a("product_description").m338b(egVar.f884n);
            }
            if (egVar.f885o != null) {
                b.m333a("transaction_id").m338b(egVar.f885o);
            }
            if (egVar.f886p != null) {
                b.m333a("transaction_state").m332a(egVar.f886p);
            }
            if (egVar.f887q != null) {
                b.m333a("transaction_date").m332a(egVar.f887q);
            }
            if (egVar.f888r != null) {
                b.m333a("campaign_id").m338b(egVar.f888r);
            }
            if (egVar.f890t != null) {
                b.m333a("receipt").m338b(egVar.f890t);
            }
            if (egVar.f891u != null) {
                b.m333a("signature").m338b(egVar.f891u);
            }
            a.m331a(new br(b.m340d().toString()));
        }
        if (dyVar.f763B != null) {
            b2.m333a("exception").m338b(dyVar.f763B);
        }
        try {
            if (dyVar.f765D != null) {
                Map linkedHashMap = new LinkedHashMap();
                if (dyVar.f764C != null) {
                    bs.m367b(dyVar.f764C).m375a(linkedHashMap);
                }
                ef efVar = dyVar.f765D;
                if (efVar.f856d != null) {
                    linkedHashMap.put("fq7_change", efVar.f856d);
                }
                if (efVar.f857e != null) {
                    linkedHashMap.put("fq30_change", efVar.f857e);
                }
                if (efVar.f858f != null) {
                    linkedHashMap.put(TJAdUnitConstants.PARAM_PUSH_ID, efVar.f858f);
                }
                b2.m333a("meta").m335a(linkedHashMap);
            } else if (dyVar.f764C != null) {
                b2.m333a("meta").m331a(new br(dyVar.f764C));
            }
        } catch (IOException e) {
        }
        if (dyVar.f770I != null) {
            b2.m333a(String.USAGE_TRACKER_DIMENSIONS).m331a(new br(dyVar.f770I));
        }
        if (dyVar.f771J != null) {
            b2.m333a("count").m332a(dyVar.f771J);
        }
        if (dyVar.f772K != null) {
            b2.m333a("first_time").m332a(dyVar.f772K);
        }
        if (dyVar.f773L != null) {
            b2.m333a("last_time").m332a(dyVar.f773L);
        }
        if (dyVar.f766E != null) {
            b2.m333a("category").m338b(dyVar.f766E);
        }
        if (dyVar.f767F != null) {
            b2.m333a("p1").m338b(dyVar.f767F);
        }
        if (dyVar.f768G != null) {
            b2.m333a("p2").m338b(dyVar.f768G);
        }
        if (dyVar.f769H.size() > 0) {
            b2.m333a(String.USAGE_TRACKER_VALUES).m339c();
            for (ec ecVar : dyVar.f769H) {
                b2.m333a(ecVar.f805e).m332a(ecVar.f806f);
            }
            b2.m340d();
        }
        return b2.m340d().toString();
    }

    public static String m1111a(dz dzVar) {
        ek ekVar = null;
        bm a = new bm().m329a();
        dx dxVar = null;
        ed edVar = null;
        for (dy dyVar : dzVar.f789d) {
            ed edVar2;
            boolean z;
            dx dxVar2;
            boolean z2;
            ek ekVar2;
            boolean z3;
            if (edVar == null || !edVar.equals(dyVar.f781u)) {
                edVar2 = dyVar.f781u;
                z = false;
            } else {
                z = true;
                edVar2 = edVar;
            }
            if (dxVar == null || !dxVar.equals(dyVar.f782v)) {
                dxVar2 = dyVar.f782v;
                z2 = false;
            } else {
                z2 = true;
                dxVar2 = dxVar;
            }
            if (ekVar == null || !ekVar.equals(dyVar.f783w)) {
                ekVar2 = dyVar.f783w;
                z3 = false;
            } else {
                ekVar2 = ekVar;
                z3 = true;
            }
            a.m331a(new br(m1110a(dyVar, z, z2, z3)));
            ekVar = ekVar2;
            dxVar = dxVar2;
            edVar = edVar2;
        }
        return a.m337b().toString();
    }

    private static String m1112a(eb ebVar) {
        switch (ebVar) {
            case APP:
                return TapjoyConstants.TJC_APP_PLACEMENT;
            case CAMPAIGN:
                return "campaign";
            case CUSTOM:
                return "custom";
            case USAGES:
                return "usages";
            default:
                throw new RuntimeException();
        }
    }
}
