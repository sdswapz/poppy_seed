package com.tapjoy.internal;

import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyLog;
import com.tapjoy.internal.fj.C0215a;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

public class ep extends et {
    private static final String f990c = ep.class.getSimpleName();

    public ep(String str, String str2) {
        super(str, str2, "ad");
    }

    public final C0215a m788a(String str, JSONObject jSONObject) {
        return m782a(str, m786a(jSONObject), m787b(jSONObject));
    }

    public final C0215a m789b(String str, JSONObject jSONObject) {
        return m785b(str, m786a(jSONObject), m787b(jSONObject));
    }

    public static Map m786a(JSONObject jSONObject) {
        Map hashMap = new HashMap();
        if (jSONObject != null) {
            try {
                JSONObject jSONObject2 = jSONObject.getJSONObject(String.USAGE_TRACKER_DIMENSIONS);
                Iterator keys = jSONObject2.keys();
                while (keys.hasNext()) {
                    String str = (String) keys.next();
                    hashMap.put(str, jSONObject2.get(str));
                }
            } catch (JSONException e) {
                TapjoyLog.m249d(f990c, "Unable to getAdUnitDimensions. Invalid params: " + e);
            }
        }
        return hashMap;
    }

    public static Map m787b(JSONObject jSONObject) {
        Map hashMap = new HashMap();
        if (jSONObject != null) {
            try {
                JSONObject jSONObject2 = jSONObject.getJSONObject(String.USAGE_TRACKER_VALUES);
                Iterator keys = jSONObject2.keys();
                while (keys.hasNext()) {
                    String str = (String) keys.next();
                    hashMap.put(str, Long.valueOf(jSONObject2.getLong(str)));
                }
            } catch (JSONException e) {
                TapjoyLog.m249d(f990c, "Unable to getAdUnitValues. Invalid params: " + e);
            }
        }
        return hashMap;
    }
}
