package com.tapjoy.internal;

public final class cq {
    private final String f611a;

    public static final class C0137a {
        private final cq f609a;
        private final String f610b;

        private C0137a(cq cqVar, String str) {
            this.f609a = cqVar;
            this.f610b = (String) cs.m459a((Object) str);
        }
    }

    public cq(String str) {
        this.f611a = (String) cs.m459a((Object) str);
    }
}
