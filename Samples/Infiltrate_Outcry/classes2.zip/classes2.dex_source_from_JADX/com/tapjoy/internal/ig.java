package com.tapjoy.internal;

import java.io.Closeable;

public interface ig extends Closeable {
    long mo256b(hv hvVar, long j);

    void close();
}
