package com.tapjoy.internal;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public final class gh {
    private final File f1210a;

    public gh(File file) {
        this.f1210a = file;
    }

    public final synchronized boolean m1068a() {
        boolean z = false;
        synchronized (this) {
            if (m1069b() == null) {
                try {
                    bl.m324a(this.f1210a, UUID.randomUUID().toString());
                    if (m1069b() != null) {
                        z = true;
                    }
                } catch (IOException e) {
                    this.f1210a.delete();
                    throw e;
                } catch (IOException e2) {
                }
            }
        }
        return z;
    }

    final String m1069b() {
        if (this.f1210a.exists()) {
            try {
                String a = bl.m323a(this.f1210a, ap.f518c);
                if (a.length() > 0) {
                    return a;
                }
            } catch (IOException e) {
            }
        }
        return null;
    }
}
