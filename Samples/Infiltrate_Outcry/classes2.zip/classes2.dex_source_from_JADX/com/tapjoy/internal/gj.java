package com.tapjoy.internal;

public final class gj extends gk {
    public gj() {
        this.h = System.currentTimeMillis() + 60000;
    }

    public final boolean mo206b() {
        return false;
    }

    public final void mo204a() {
    }

    public final void mo205a(ge geVar, ez ezVar) {
        throw new UnsupportedOperationException();
    }
}
