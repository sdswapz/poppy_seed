package com.tapjoy.internal;

import java.io.StringWriter;
import java.io.Writer;
import java.util.Collection;
import java.util.Map;

public final class bm implements bq {
    private final StringWriter f539a = new StringWriter();
    private final by f540b = new by(this.f539a);

    public final String toString() {
        try {
            this.f540b.f586a.flush();
            return this.f539a.toString();
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final void mo96a(Writer writer) {
        try {
            this.f540b.f586a.flush();
            writer.write(this.f539a.toString());
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m329a() {
        try {
            this.f540b.m424a();
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m337b() {
        try {
            this.f540b.m432b();
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m339c() {
        try {
            this.f540b.m434c();
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m340d() {
        try {
            this.f540b.m435d();
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m333a(String str) {
        try {
            this.f540b.m429a(str);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m331a(bq bqVar) {
        try {
            this.f540b.m426a(bqVar);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m338b(String str) {
        try {
            this.f540b.m433b(str);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m330a(long j) {
        try {
            this.f540b.m425a(j);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m332a(Number number) {
        try {
            this.f540b.m427a(number);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    private bm m328b(Object obj) {
        try {
            this.f540b.m428a(obj);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m334a(Collection collection) {
        try {
            this.f540b.m430a(collection);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public final bm m335a(Map map) {
        try {
            this.f540b.m431a(map);
            return this;
        } catch (Throwable e) {
            throw cu.m464a(e);
        }
    }

    public static String m327a(Object obj) {
        return new bm().m328b(obj).toString();
    }
}
