package com.tapjoy.internal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public final class C0279m extends C0276o {
    private final int f1540c;

    public C0279m(SharedPreferences sharedPreferences, String str, int i) {
        super(sharedPreferences, str);
        this.f1540c = i;
    }

    public final Integer m1326a() {
        return Integer.valueOf(m1329b());
    }

    public final int m1329b() {
        return this.a.getInt(this.b, this.f1540c);
    }

    public final void m1328a(Integer num) {
        if (num != null) {
            m1327a(num.intValue());
        } else {
            m1319c();
        }
    }

    public final void m1327a(int i) {
        this.a.edit().putInt(this.b, i).commit();
    }

    public final Editor m1325a(Editor editor, int i) {
        return editor.putInt(this.b, i);
    }
}
