package com.tapjoy.internal;

public interface fs {
    void mo36a(String str);

    void mo37a(String str, fp fpVar);

    void mo38a(String str, String str2, fp fpVar);

    void mo39b(String str);

    void mo40c(String str);

    void mo41d(String str);
}
