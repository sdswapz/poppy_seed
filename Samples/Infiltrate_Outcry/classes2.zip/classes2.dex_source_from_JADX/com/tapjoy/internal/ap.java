package com.tapjoy.internal;

import java.nio.charset.Charset;

public final class ap {
    public static final Charset f516a = Charset.forName("US-ASCII");
    public static final Charset f517b = Charset.forName("ISO-8859-1");
    public static final Charset f518c = Charset.forName("UTF-8");
    public static final Charset f519d = Charset.forName("UTF-16BE");
    public static final Charset f520e = Charset.forName("UTF-16LE");
    public static final Charset f521f = Charset.forName("UTF-16");
}
