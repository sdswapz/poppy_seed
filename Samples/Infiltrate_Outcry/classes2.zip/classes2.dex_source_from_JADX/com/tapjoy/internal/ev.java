package com.tapjoy.internal;

import java.util.Observable;

public final class ev {
    public static final C0198a f1013a = new C0198a();
    public static final C0198a f1014b = new C0198a();
    public static final C0198a f1015c = new C0198a();
    public static final C0198a f1016d = new C0198a();
    public static final C0198a f1017e = new C0198a();

    public static class C0198a extends Observable {
        public final void notifyObservers() {
            setChanged();
            super.notifyObservers();
        }

        public final void notifyObservers(Object data) {
            setChanged();
            super.notifyObservers(data);
        }
    }
}
