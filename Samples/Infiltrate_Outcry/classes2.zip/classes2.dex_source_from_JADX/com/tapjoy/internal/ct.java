package com.tapjoy.internal;

public final class ct {
    public static String m461a(String str) {
        return str == null ? "" : str;
    }

    public static String m462b(String str) {
        return m463c(str) ? null : str;
    }

    public static boolean m463c(String str) {
        return str == null || str.length() == 0;
    }
}
