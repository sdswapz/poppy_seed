package com.tapjoy.internal;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import com.tapjoy.TapjoyLog;
import com.tapjoy.TapjoyUtil;
import java.util.HashSet;
import java.util.concurrent.CountDownLatch;

public final class eo {
    private static final eo f983a = new eo();
    private Application f984b;
    private ActivityLifecycleCallbacks f985c;
    private final HashSet f986d = new HashSet();

    public static void m778a(Context context) {
        if (VERSION.SDK_INT >= 14 && context != null) {
            eo eoVar = f983a;
            Context applicationContext = context.getApplicationContext();
            if (eoVar.f984b == null) {
                try {
                    if (applicationContext instanceof Application) {
                        eoVar.f984b = (Application) applicationContext;
                    } else {
                        final CountDownLatch countDownLatch = new CountDownLatch(1);
                        TapjoyUtil.runOnMainThread(new Runnable(eoVar) {
                            final /* synthetic */ eo f980b;

                            public final void run() {
                                try {
                                    this.f980b.f984b = ((Application) Class.forName("android.app.ActivityThread").getMethod("currentApplication", new Class[0]).invoke(null, null));
                                } catch (Throwable e) {
                                    TapjoyLog.m254w("Tapjoy.ActivityTracker", Log.getStackTraceString(e));
                                } finally {
                                    countDownLatch.countDown();
                                }
                            }
                        });
                        countDownLatch.await();
                    }
                } catch (Throwable e) {
                    TapjoyLog.m254w("Tapjoy.ActivityTracker", Log.getStackTraceString(e));
                }
                if (eoVar.f984b == null) {
                    return;
                }
            }
            synchronized (eoVar) {
                if (eoVar.f985c == null) {
                    Activity c = C0140d.m476c();
                    if (c != null) {
                        eoVar.f986d.add(m780b(c));
                    }
                    final HashSet hashSet = eoVar.f986d;
                    eoVar.f985c = new ActivityLifecycleCallbacks(eoVar) {
                        final /* synthetic */ eo f982b;

                        public final void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                        }

                        public final void onActivityStarted(Activity activity) {
                            hashSet.add(eo.m780b(activity));
                            if (hashSet.size() == 1) {
                                fr.m901a();
                            }
                            C0140d.m472a(activity);
                        }

                        public final void onActivityResumed(Activity activity) {
                        }

                        public final void onActivityPaused(Activity activity) {
                        }

                        public final void onActivityStopped(Activity activity) {
                            hashSet.remove(eo.m780b(activity));
                            if (hashSet.size() <= 0) {
                                fr.m906b();
                            }
                        }

                        public final void onActivitySaveInstanceState(Activity activity, Bundle outState) {
                        }

                        public final void onActivityDestroyed(Activity activity) {
                        }
                    };
                    eoVar.f984b.registerActivityLifecycleCallbacks(eoVar.f985c);
                    fr.m901a();
                }
            }
        }
    }

    public static void m777a() {
        if (VERSION.SDK_INT >= 14) {
            eo eoVar = f983a;
            if (eoVar.f984b != null) {
                synchronized (eoVar) {
                    if (eoVar.f985c != null) {
                        eoVar.f984b.unregisterActivityLifecycleCallbacks(eoVar.f985c);
                        eoVar.f985c = null;
                    }
                }
            }
        }
    }

    private static String m780b(Activity activity) {
        return activity.getClass().getName() + "@" + System.identityHashCode(activity);
    }
}
