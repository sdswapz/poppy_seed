package com.tapjoy.internal;

import android.content.Context;

public interface C0234t {
    String mo210a(Context context);

    void mo211a(Context context, int i);

    void mo212a(Context context, long j);

    void mo213a(Context context, String str);

    void mo214a(Context context, boolean z);

    String mo215b(Context context);

    void mo216b(Context context, int i);

    void mo217b(Context context, String str);

    void mo218b(Context context, boolean z);

    boolean mo219c(Context context);

    int mo220d(Context context);

    boolean mo221e(Context context);

    long mo222f(Context context);

    int mo223g(Context context);
}
