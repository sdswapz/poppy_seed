package com.tapjoy.internal;

import com.tapjoy.TJAwardCurrencyListener;

public class TJAwardCurrencyListenerNative implements TJAwardCurrencyListener {
    private final long f419a;

    private static native void onAwardCurrencyResponseFailureNative(long j, String str);

    private static native void onAwardCurrencyResponseNative(long j, String str, int i);

    private TJAwardCurrencyListenerNative(long nativeHandle) {
        if (nativeHandle == 0) {
            throw new IllegalArgumentException();
        }
        this.f419a = nativeHandle;
    }

    public void onAwardCurrencyResponse(String currencyName, int balance) {
        onAwardCurrencyResponseNative(this.f419a, currencyName, balance);
    }

    public void onAwardCurrencyResponseFailure(String error) {
        onAwardCurrencyResponseFailureNative(this.f419a, error);
    }

    @ew
    static Object create(long nativeHandle) {
        return new TJAwardCurrencyListenerNative(nativeHandle);
    }
}
