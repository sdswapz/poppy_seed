package com.tapjoy.internal;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.graphics.Rect;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;
import com.tapjoy.TapjoyCache;
import com.tapjoy.TapjoyConstants;
import com.tapjoy.internal.dx.C0163a;
import com.tapjoy.internal.ed.C0175a;
import com.tapjoy.internal.eh.C0183a;
import com.tapjoy.internal.ek.C0189a;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

public final class gg {
    public static final String f1203a = UUID.randomUUID().toString();
    private static gg f1204d;
    final C0189a f1205b = new C0189a();
    final gn f1206c;
    private final C0175a f1207e = new C0175a();
    private final C0163a f1208f = new C0163a();
    private final Context f1209g;

    class C02381 implements Runnable {
        final /* synthetic */ gg f1202a;

        C02381(gg ggVar) {
            this.f1202a = ggVar;
        }

        public final void run() {
            fh fhVar = new fh();
            boolean a = fhVar.m851a(this.f1202a.f1209g);
            synchronized (this.f1202a) {
                if (a) {
                    String a2 = ct.m461a(fhVar.f1071a);
                    boolean z = fhVar.f1072b;
                    String a3 = this.f1202a.f1206c.f1238A.m1338a();
                    this.f1202a.f1205b.f923q = a2;
                    this.f1202a.f1205b.f924r = Boolean.valueOf(z);
                    this.f1202a.f1206c.f1238A.m1339a(a2);
                    this.f1202a.f1206c.f1239B.m1321a(z);
                    gr.m1103a(a2, z);
                    if (!(ct.m463c(a3) || a2.equals(a3))) {
                        this.f1202a.f1206c.m1092a(false);
                    }
                } else {
                    this.f1202a.f1205b.f923q = null;
                    this.f1202a.f1205b.f924r = null;
                    this.f1202a.f1206c.f1238A.m1339a(null);
                    this.f1202a.f1206c.f1239B.m1321a(false);
                    gr.m1103a(null, false);
                }
            }
        }
    }

    public static synchronized gg m1049a(Context context) {
        gg ggVar;
        synchronized (gg.class) {
            if (f1204d == null) {
                f1204d = new gg(context, gn.m1090a(context));
            }
            ggVar = f1204d;
        }
        return ggVar;
    }

    private gg(Context context, gn gnVar) {
        Integer valueOf;
        gr.m1102a();
        Context applicationContext = context.getApplicationContext();
        this.f1209g = applicationContext;
        String string = Secure.getString(applicationContext.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        if ("9774d56d682e549c".equals(string)) {
            string = null;
        } else {
            string = ct.m462b(string);
        }
        if (string == null) {
            File a = C0286w.m1345a(applicationContext);
            string = aa.m264a(new File(gd.m961c(applicationContext), "deviceid"), a != null ? new File(a, ".io.5rocks") : null);
        }
        this.f1207e.f808d = string;
        string = ab.m265a(applicationContext);
        if (string != null) {
            this.f1207e.f807c = string.replace(":", "").toLowerCase(Locale.US);
        }
        PackageManager packageManager = applicationContext.getPackageManager();
        TelephonyManager telephonyManager = (TelephonyManager) applicationContext.getSystemService("phone");
        if (telephonyManager != null) {
            String simCountryIso = telephonyManager.getSimCountryIso();
            if (!ct.m463c(simCountryIso)) {
                this.f1207e.f821q = simCountryIso.toUpperCase(Locale.US);
            }
            simCountryIso = telephonyManager.getNetworkCountryIso();
            if (!ct.m463c(simCountryIso)) {
                this.f1207e.f822r = simCountryIso.toUpperCase(Locale.US);
            }
            if (fd.m837b().m829b("analytics_gather_imei") && packageManager.checkPermission("android.permission.READ_PHONE_STATE", applicationContext.getPackageName()) == 0) {
                try {
                    string = telephonyManager.getDeviceId();
                    if (!ct.m463c(string)) {
                        this.f1207e.f823s = string;
                    }
                } catch (SecurityException e) {
                } catch (RuntimeException e2) {
                }
            }
        }
        String packageName = applicationContext.getPackageName();
        this.f1207e.f818n = packageName;
        C0175a c0175a = this.f1207e;
        Signature[] e3 = ae.m275e(packageManager, packageName);
        if (e3 == null || e3.length <= 0) {
            string = null;
        } else {
            string = Base64.encodeToString(cm.m455a(e3[0].toByteArray()), 2);
        }
        c0175a.f819o = ct.m461a(string);
        this.f1208f.f714c = ae.m271a(packageManager, packageName);
        this.f1208f.f715d = Integer.valueOf(ae.m272b(packageManager, packageName));
        string = packageManager.getInstallerPackageName(packageName);
        if (!ct.m463c(string)) {
            this.f1208f.f717f = string;
        }
        string = m1050a(packageManager, packageName);
        if (!ct.m463c(string)) {
            this.f1208f.f718g = string;
        }
        m1054a();
        this.f1206c = gnVar;
        string = this.f1206c.f1244c.m1338a();
        if (string != null && string.length() > 0) {
            this.f1207e.f820p = string + " 11.11.0/Android";
        }
        string = this.f1206c.m1093b();
        if (string != null) {
            this.f1205b.f910d = string;
        }
        C0189a c0189a = this.f1205b;
        gn gnVar2 = this.f1206c;
        long j = gnVar2.f1243b.getLong("it", 0);
        if (j == 0) {
            applicationContext = gnVar2.f1242a;
            j = ae.m273c(applicationContext.getPackageManager(), applicationContext.getPackageName());
            if (j == 0) {
                j = gd.m962d(gnVar2.f1242a).lastModified();
                if (j == 0) {
                    Context context2 = gnVar2.f1242a;
                    j = new File(ae.m274d(context2.getPackageManager(), context2.getPackageName())).lastModified();
                    if (j == 0) {
                        j = System.currentTimeMillis();
                    }
                }
            }
            gnVar2.f1243b.edit().putLong("it", j).commit();
        }
        c0189a.f909c = Long.valueOf(j);
        int b = this.f1206c.f1247f.m1329b();
        this.f1205b.f911e = Integer.valueOf(m1047a(7, b));
        this.f1205b.f912f = Integer.valueOf(m1047a(30, b));
        b = this.f1206c.f1249h.m1329b();
        if (b > 0) {
            this.f1205b.f914h = Integer.valueOf(b);
        }
        j = this.f1206c.f1250i.m1330a();
        if (j > 0) {
            this.f1205b.f915i = Long.valueOf(j);
        }
        j = this.f1206c.f1251j.m1330a();
        if (j > 0) {
            this.f1205b.f916j = Long.valueOf(j);
        }
        j = this.f1206c.f1252k.m1330a();
        if (j > 0) {
            this.f1205b.f917k = Long.valueOf(j);
        }
        string = this.f1206c.f1253l.m1338a();
        if (string != null) {
            this.f1205b.f918l = string;
        }
        b = this.f1206c.f1254m.m1329b();
        if (b > 0) {
            this.f1205b.f919m = Integer.valueOf(b);
        }
        double a2 = this.f1206c.f1255n.m1322a();
        if (a2 != 0.0d) {
            this.f1205b.f920n = Double.valueOf(a2);
        }
        j = this.f1206c.f1256o.m1330a();
        if (j > 0) {
            this.f1205b.f921o = Long.valueOf(j);
        }
        a2 = this.f1206c.f1257p.m1322a();
        if (a2 != 0.0d) {
            this.f1205b.f922p = Double.valueOf(a2);
        }
        string = this.f1206c.f1248g.m1338a();
        if (string != null) {
            try {
                ei eiVar = (ei) ei.f902c.m517a(Base64.decode(string, 2));
                this.f1205b.f913g.clear();
                this.f1205b.f913g.addAll(eiVar.f903d);
            } catch (IllegalArgumentException e4) {
                this.f1206c.f1248g.m1319c();
            } catch (IOException e5) {
                this.f1206c.f1248g.m1319c();
            }
        }
        this.f1208f.f716e = this.f1206c.f1258q.m1338a();
        this.f1205b.f925s = this.f1206c.f1259r.m1338a();
        b = this.f1206c.f1260s.m1326a().intValue();
        C0189a c0189a2 = this.f1205b;
        if (b != -1) {
            valueOf = Integer.valueOf(b);
        } else {
            valueOf = null;
        }
        c0189a2.f926t = valueOf;
        b = this.f1206c.f1261t.m1326a().intValue();
        c0189a2 = this.f1205b;
        if (b != -1) {
            valueOf = Integer.valueOf(b);
        } else {
            valueOf = null;
        }
        c0189a2.f927u = valueOf;
        this.f1205b.f928v = this.f1206c.f1262u.m1338a();
        this.f1205b.f929w = this.f1206c.f1263v.m1338a();
        this.f1205b.f930x = this.f1206c.f1264w.m1338a();
        this.f1205b.f931y = this.f1206c.f1265x.m1338a();
        this.f1205b.f932z = this.f1206c.f1266y.m1338a();
        string = this.f1206c.f1267z.m1338a();
        if (string != null) {
            try {
                ej ejVar = (ej) ej.f905c.m517a(Base64.decode(string, 2));
                this.f1205b.f907A.clear();
                this.f1205b.f907A.addAll(ejVar.f906d);
            } catch (IllegalArgumentException e6) {
                this.f1206c.f1267z.m1319c();
            } catch (IOException e7) {
                this.f1206c.f1267z.m1319c();
            }
        }
        string = this.f1206c.f1238A.m1338a();
        boolean booleanValue = this.f1206c.f1239B.m1320a().booleanValue();
        if (string != null) {
            this.f1205b.f923q = string;
            this.f1205b.f924r = Boolean.valueOf(booleanValue);
        } else {
            this.f1205b.f923q = null;
            this.f1205b.f924r = null;
        }
        this.f1205b.f908B = this.f1206c.f1240C.m1320a();
        new Thread(new C02381(this)).start();
    }

    private static String m1050a(PackageManager packageManager, String str) {
        try {
            Bundle bundle = packageManager.getApplicationInfo(str, 128).metaData;
            if (bundle != null) {
                Object obj = bundle.get("com.tapjoy.appstore");
                if (obj != null) {
                    return obj.toString().trim();
                }
            }
        } catch (NameNotFoundException e) {
        }
        return null;
    }

    final void m1054a() {
        synchronized (this) {
            try {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ((WindowManager) this.f1209g.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
                Activity a = fv.m915a();
                if (a != null) {
                    Window window = a.getWindow();
                    if (window != null) {
                        int i = displayMetrics.heightPixels;
                        Rect rect = new Rect();
                        window.getDecorView().getWindowVisibleDisplayFrame(rect);
                        displayMetrics.heightPixels = i - rect.top;
                    }
                }
                this.f1207e.f813i = Integer.valueOf(displayMetrics.densityDpi);
                this.f1207e.f814j = Integer.valueOf(displayMetrics.widthPixels);
                this.f1207e.f815k = Integer.valueOf(displayMetrics.heightPixels);
            } catch (Exception e) {
            }
        }
    }

    public final ee m1060b() {
        ee eeVar;
        synchronized (this) {
            this.f1207e.f816l = Locale.getDefault().toString();
            this.f1207e.f817m = TimeZone.getDefault().getID();
            Object obj = null;
            long currentTimeMillis = System.currentTimeMillis() - 259200000;
            Iterator it = this.f1205b.f913g.iterator();
            while (it.hasNext()) {
                Object obj2;
                if (((eh) it.next()).f899g.longValue() <= currentTimeMillis) {
                    it.remove();
                    obj2 = 1;
                } else {
                    obj2 = obj;
                }
                obj = obj2;
            }
            if (obj != null) {
                m1053g();
            }
            eeVar = new ee(this.f1207e.m736b(), this.f1208f.m711b(), this.f1205b.m765b());
        }
        return eeVar;
    }

    final String m1063c() {
        String a;
        synchronized (this) {
            a = this.f1206c.f1245d.m1338a();
        }
        return a;
    }

    public final ef m1065d() {
        ef efVar = null;
        int i = 1;
        synchronized (this) {
            Calendar instance = Calendar.getInstance();
            int i2 = instance.get(5) + (((instance.get(1) * 10000) + (instance.get(2) * 100)) + 100);
            int intValue = this.f1206c.f1246e.m1326a().intValue();
            if (intValue != i2) {
                if (intValue == 0) {
                    this.f1205b.f911e = Integer.valueOf(1);
                    this.f1205b.f912f = Integer.valueOf(1);
                    efVar = new ef("fq7_0_1", "fq30_0_1", null);
                } else {
                    long timeInMillis;
                    int i3;
                    int intValue2 = this.f1206c.f1247f.m1326a().intValue();
                    int a = m1047a(7, intValue2);
                    int a2 = m1047a(30, intValue2);
                    Calendar instance2 = Calendar.getInstance();
                    instance2.set(intValue / 10000, ((intValue / 100) % 100) - 1, intValue % 100);
                    int signum = Integer.signum(instance.get(1) - instance2.get(1));
                    Calendar calendar;
                    switch (signum) {
                        case TapjoyCache.CACHE_LIMIT /*-1*/:
                            calendar = (Calendar) instance2.clone();
                            calendar.set(instance.get(1), instance.get(2), instance.get(5));
                            instance = calendar;
                            timeInMillis = instance2.getTimeInMillis();
                            break;
                        case 1:
                            calendar = (Calendar) instance.clone();
                            calendar.set(instance2.get(1), instance2.get(2), instance2.get(5));
                            long timeInMillis2 = instance.getTimeInMillis();
                            instance = calendar;
                            timeInMillis = timeInMillis2;
                            break;
                        default:
                            i3 = instance.get(6) - instance2.get(6);
                            break;
                    }
                    intValue = 0;
                    while (instance.getTimeInMillis() < timeInMillis) {
                        instance.add(5, 1);
                        intValue++;
                    }
                    i3 = signum > 0 ? intValue : -intValue;
                    if (Math.abs(i3) >= 30) {
                        i3 = 0;
                    } else if (i3 >= 0) {
                        i3 = intValue2 << i3;
                    } else {
                        i3 = intValue2 >> (-i3);
                    }
                    i3 |= 1;
                    int a3 = m1047a(7, i3);
                    intValue = m1047a(30, i3);
                    this.f1205b.f911e = Integer.valueOf(a3);
                    this.f1205b.f912f = Integer.valueOf(intValue);
                    int i4 = i3;
                    efVar = new ef("fq7_" + a + "_" + a3, "fq30_" + a2 + "_" + intValue, null);
                    i = i4;
                }
                this.f1206c.f1246e.m1327a(i2);
                this.f1206c.f1247f.m1327a(i);
            }
        }
        return efVar;
    }

    private static int m1047a(int i, int i2) {
        return Integer.bitCount(((1 << i) - 1) & i2);
    }

    final boolean m1058a(String str, long j, boolean z) {
        synchronized (this) {
            int size = this.f1205b.f913g.size();
            int i = 0;
            while (i < size) {
                eh ehVar = (eh) this.f1205b.f913g.get(i);
                if (!ehVar.f898f.equals(str)) {
                    i++;
                } else if (z) {
                    C0183a b = ehVar.m756b();
                    b.f893d = Long.valueOf(j);
                    this.f1205b.f913g.set(i, b.m752b());
                    return true;
                } else {
                    return false;
                }
            }
            this.f1205b.f913g.add(new eh(str, Long.valueOf(j)));
            m1053g();
            return true;
        }
    }

    private void m1053g() {
        this.f1206c.f1248g.m1339a(Base64.encodeToString(ei.f902c.m521b(new ei(this.f1205b.f913g)), 2));
    }

    public final boolean m1057a(String str) {
        boolean z = true;
        synchronized (this) {
            this.f1206c.f1258q.m1339a(str);
            if (str != null) {
                if (cr.m457a(this.f1208f.f716e, str)) {
                    z = false;
                }
                this.f1208f.f716e = str;
            } else {
                if (this.f1208f.f716e == null) {
                    z = false;
                }
                this.f1208f.f716e = null;
            }
        }
        return z;
    }

    public final boolean m1062b(String str) {
        boolean z;
        synchronized (this) {
            this.f1206c.f1259r.m1339a(str);
            z = !cr.m457a(this.f1205b.f925s, str);
            if (z) {
                this.f1205b.f925s = str;
            }
        }
        return z;
    }

    public final boolean m1056a(Integer num) {
        boolean z;
        synchronized (this) {
            this.f1206c.f1260s.m1328a(num);
            z = !cr.m457a(this.f1205b.f926t, num);
            if (z) {
                this.f1205b.f926t = num;
            }
        }
        return z;
    }

    public final boolean m1061b(Integer num) {
        boolean z;
        synchronized (this) {
            this.f1206c.f1261t.m1328a(num);
            z = !cr.m457a(this.f1205b.f927u, num);
            if (z) {
                this.f1205b.f927u = num;
            }
        }
        return z;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean m1055a(int r4, java.lang.String r5) {
        /*
        r3 = this;
        r1 = 1;
        r0 = 0;
        monitor-enter(r3);
        switch(r4) {
            case 1: goto L_0x0008;
            case 2: goto L_0x0024;
            case 3: goto L_0x003d;
            case 4: goto L_0x0056;
            case 5: goto L_0x006f;
            default: goto L_0x0006;
        };
    L_0x0006:
        monitor-exit(r3);	 Catch:{ all -> 0x0021 }
        return r0;
    L_0x0008:
        r2 = r3.f1206c;	 Catch:{ all -> 0x0021 }
        r2 = r2.f1262u;	 Catch:{ all -> 0x0021 }
        r2.m1339a(r5);	 Catch:{ all -> 0x0021 }
        r2 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r2 = r2.f928v;	 Catch:{ all -> 0x0021 }
        r2 = com.tapjoy.internal.cr.m457a(r2, r5);	 Catch:{ all -> 0x0021 }
        if (r2 != 0) goto L_0x001a;
    L_0x0019:
        r0 = r1;
    L_0x001a:
        if (r0 == 0) goto L_0x0006;
    L_0x001c:
        r1 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r1.f928v = r5;	 Catch:{ all -> 0x0021 }
        goto L_0x0006;
    L_0x0021:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0021 }
        throw r0;
    L_0x0024:
        r2 = r3.f1206c;	 Catch:{ all -> 0x0021 }
        r2 = r2.f1263v;	 Catch:{ all -> 0x0021 }
        r2.m1339a(r5);	 Catch:{ all -> 0x0021 }
        r2 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r2 = r2.f929w;	 Catch:{ all -> 0x0021 }
        r2 = com.tapjoy.internal.cr.m457a(r2, r5);	 Catch:{ all -> 0x0021 }
        if (r2 != 0) goto L_0x0036;
    L_0x0035:
        r0 = r1;
    L_0x0036:
        if (r0 == 0) goto L_0x0006;
    L_0x0038:
        r1 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r1.f929w = r5;	 Catch:{ all -> 0x0021 }
        goto L_0x0006;
    L_0x003d:
        r2 = r3.f1206c;	 Catch:{ all -> 0x0021 }
        r2 = r2.f1264w;	 Catch:{ all -> 0x0021 }
        r2.m1339a(r5);	 Catch:{ all -> 0x0021 }
        r2 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r2 = r2.f930x;	 Catch:{ all -> 0x0021 }
        r2 = com.tapjoy.internal.cr.m457a(r2, r5);	 Catch:{ all -> 0x0021 }
        if (r2 != 0) goto L_0x004f;
    L_0x004e:
        r0 = r1;
    L_0x004f:
        if (r0 == 0) goto L_0x0006;
    L_0x0051:
        r1 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r1.f930x = r5;	 Catch:{ all -> 0x0021 }
        goto L_0x0006;
    L_0x0056:
        r2 = r3.f1206c;	 Catch:{ all -> 0x0021 }
        r2 = r2.f1265x;	 Catch:{ all -> 0x0021 }
        r2.m1339a(r5);	 Catch:{ all -> 0x0021 }
        r2 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r2 = r2.f931y;	 Catch:{ all -> 0x0021 }
        r2 = com.tapjoy.internal.cr.m457a(r2, r5);	 Catch:{ all -> 0x0021 }
        if (r2 != 0) goto L_0x0068;
    L_0x0067:
        r0 = r1;
    L_0x0068:
        if (r0 == 0) goto L_0x0006;
    L_0x006a:
        r1 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r1.f931y = r5;	 Catch:{ all -> 0x0021 }
        goto L_0x0006;
    L_0x006f:
        r2 = r3.f1206c;	 Catch:{ all -> 0x0021 }
        r2 = r2.f1266y;	 Catch:{ all -> 0x0021 }
        r2.m1339a(r5);	 Catch:{ all -> 0x0021 }
        r2 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r2 = r2.f932z;	 Catch:{ all -> 0x0021 }
        r2 = com.tapjoy.internal.cr.m457a(r2, r5);	 Catch:{ all -> 0x0021 }
        if (r2 != 0) goto L_0x0081;
    L_0x0080:
        r0 = r1;
    L_0x0081:
        if (r0 == 0) goto L_0x0006;
    L_0x0083:
        r1 = r3.f1205b;	 Catch:{ all -> 0x0021 }
        r1.f932z = r5;	 Catch:{ all -> 0x0021 }
        goto L_0x0006;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tapjoy.internal.gg.a(int, java.lang.String):boolean");
    }

    public final Set m1066e() {
        Set hashSet;
        synchronized (this) {
            hashSet = new HashSet(this.f1205b.f907A);
        }
        return hashSet;
    }

    public final boolean m1064c(String str) {
        synchronized (this) {
            for (int size = this.f1205b.f913g.size() - 1; size >= 0; size--) {
                eh ehVar = (eh) this.f1205b.f913g.get(size);
                if (ehVar.f898f.equals(str)) {
                    C0183a b = ehVar.m756b();
                    b.f894e = Long.valueOf(System.currentTimeMillis());
                    this.f1205b.f913g.set(size, b.m752b());
                    m1053g();
                    return true;
                }
            }
            return false;
        }
    }

    public final boolean m1067f() {
        return ((Boolean) cr.m458b(this.f1205b.f908B, ek.f948r)).booleanValue();
    }

    public final boolean m1059a(boolean z) {
        boolean z2;
        synchronized (this) {
            this.f1206c.f1240C.m1321a(z);
            z2 = z != ((Boolean) cr.m458b(this.f1205b.f908B, ek.f948r)).booleanValue();
            this.f1205b.f908B = Boolean.valueOf(z);
        }
        return z2;
    }
}
