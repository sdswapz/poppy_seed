package com.tapjoy.internal;

import com.tapjoy.internal.hn.C0268a;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class gl implements ck {
    public final gd f1231a;
    Set f1232b = null;
    private final Map f1233c = Collections.synchronizedMap(new HashMap());
    private final Map f1234d = cx.m468a();

    public gl(gd gdVar) {
        this.f1231a = gdVar;
    }

    private void m1085a(cf cfVar, C0268a c0268a) {
        if (cfVar instanceof hn) {
            if (c0268a.f1442b != null) {
                Iterable iterable = c0268a.f1442b;
                synchronized (this) {
                    Set hashSet;
                    if (iterable instanceof Collection) {
                        hashSet = new HashSet(cv.m466a(iterable));
                    } else {
                        hashSet = cy.m470a(iterable.iterator());
                    }
                    this.f1232b = hashSet;
                }
            }
            hn hnVar = (hn) cfVar;
            String str = hnVar.f1443c;
            boolean z = hnVar.f1444d;
            this.f1234d.remove(str);
            if (!z) {
                this.f1233c.put(str, c0268a.f1441a);
            }
            gk gkVar = c0268a.f1441a;
            ge geVar = this.f1231a.f1175p;
            if (gkVar instanceof gj) {
                ga.m938a("No content for \"{}\"", str);
                geVar.mo36a(str);
                return;
            }
            ga.m938a("New content for \"{}\" is ready", str);
            if (z) {
                gkVar.mo205a(geVar, new ez());
                return;
            } else {
                geVar.mo39b(str);
                return;
            }
        }
        throw new IllegalStateException(cfVar.getClass().getName());
    }

    public final void mo208a(cf cfVar) {
        m1085a(cfVar, new C0268a(new gj(), null));
    }
}
