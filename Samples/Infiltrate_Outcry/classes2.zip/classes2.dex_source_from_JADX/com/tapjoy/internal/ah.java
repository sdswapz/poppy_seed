package com.tapjoy.internal;

import android.view.ViewGroup;
import java.util.Iterator;

public final class ah {

    static class C0122a implements Iterator {
        private final ViewGroup f477a;
        private int f478b;
        private int f479c = 0;

        public C0122a(ViewGroup viewGroup) {
            this.f477a = viewGroup;
            this.f478b = viewGroup.getChildCount();
        }

        public final boolean hasNext() {
            return this.f479c < this.f478b;
        }

        public final void remove() {
            this.f477a.removeViewAt(this.f479c - 1);
        }

        public final /* synthetic */ Object next() {
            ViewGroup viewGroup = this.f477a;
            int i = this.f479c;
            this.f479c = i + 1;
            return viewGroup.getChildAt(i);
        }
    }

    public static Iterable m282a(ViewGroup viewGroup) {
        final Iterator c0122a = new C0122a(viewGroup);
        return new Iterable() {
            public final Iterator iterator() {
                return c0122a;
            }
        };
    }
}
