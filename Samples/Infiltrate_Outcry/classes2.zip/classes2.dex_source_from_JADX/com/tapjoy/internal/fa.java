package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TJPlacementManager;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.internal.fc.C0201a;
import com.tapjoy.internal.go.C0244a;
import java.util.Observer;

public final class fa extends go {
    private final fc f1028b = new C02001(this);

    class C02001 extends fc {
        final /* synthetic */ fa f1025a;

        C02001(fa faVar) {
            this.f1025a = faVar;
        }

        protected final /* synthetic */ TJPlacement mo180a(Context context, TJPlacementListener tJPlacementListener, Object obj) {
            C0244a c0244a = (C0244a) obj;
            TJPlacement createPlacement = TJPlacementManager.createPlacement(TapjoyConnectCore.getContext(), c0244a.f1269b, false, tJPlacementListener);
            createPlacement.pushId = c0244a.f1268a;
            return createPlacement;
        }

        protected final /* synthetic */ C0201a mo185b(Object obj) {
            C0244a c0244a = (C0244a) obj;
            return new C0201a(this, c0244a, c0244a.f1271d);
        }

        protected final boolean mo182a() {
            return true;
        }

        protected final boolean mo184a(Observer observer) {
            if (TapjoyConnectCore.isViewOpen()) {
                TJPlacementManager.dismissContentShowing(true);
            }
            return super.mo184a(observer);
        }
    }

    static {
        go.m818a(new fa());
    }

    public static void m823a() {
    }

    private fa() {
    }

    protected final boolean mo187b() {
        return this.f1028b.f1005b != null;
    }

    protected final void mo186a(C0244a c0244a) {
        this.f1028b.m798c(c0244a);
    }
}
