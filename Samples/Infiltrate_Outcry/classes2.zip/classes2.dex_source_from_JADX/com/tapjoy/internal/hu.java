package com.tapjoy.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.tapjoy.TapjoyConnectCore;
import java.util.ArrayList;
import java.util.Iterator;

public final class hu extends RelativeLayout implements OnClickListener {
    private boolean f1483a;
    private float f1484b = TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER;
    private View f1485c;
    private View f1486d;
    private FrameLayout f1487e;
    private ImageView f1488f;
    private hr f1489g;
    private gy f1490h;
    private C0242a f1491i;

    public interface C0242a {
        void mo232a();

        void mo233a(gw gwVar);

        void mo234b();
    }

    public hu(Context context, gy gyVar, C0242a c0242a) {
        int i = 1;
        super(context);
        this.f1490h = gyVar;
        this.f1491i = c0242a;
        Context context2 = getContext();
        this.f1485c = new View(context2);
        this.f1485c.setId(1);
        LayoutParams layoutParams = new RelativeLayout.LayoutParams(0, 0);
        layoutParams.addRule(13);
        addView(this.f1485c, layoutParams);
        this.f1486d = new View(context2);
        layoutParams = new RelativeLayout.LayoutParams(0, 0);
        layoutParams.addRule(13);
        addView(this.f1486d, layoutParams);
        this.f1487e = new FrameLayout(context2);
        layoutParams = new RelativeLayout.LayoutParams(0, 0);
        layoutParams.addRule(13);
        addView(this.f1487e, layoutParams);
        this.f1488f = new ImageView(context2);
        this.f1488f.setOnClickListener(this);
        layoutParams = new RelativeLayout.LayoutParams(0, 0);
        layoutParams.addRule(7, this.f1485c.getId());
        layoutParams.addRule(6, this.f1485c.getId());
        addView(this.f1488f, layoutParams);
        if (this.f1490h.f1328m != null) {
            gz gzVar = this.f1490h.f1328m;
            if (gzVar.f1330a == null || (gzVar.f1331b == null && gzVar.f1332c == null)) {
                i = 0;
            }
            if (i != 0) {
                this.f1489g = new hr(context2);
                this.f1489g.setOnClickListener(this);
                LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(0, 0);
                layoutParams2.addRule(5, this.f1486d.getId());
                layoutParams2.addRule(8, this.f1486d.getId());
                addView(this.f1489g, layoutParams2);
            }
        }
        this.f1488f.setImageBitmap(gyVar.f1318c.f1346b);
        if (this.f1489g != null && gyVar.f1328m != null && gyVar.f1328m.f1330a != null) {
            this.f1489g.setImageBitmap(gyVar.f1328m.f1330a.f1346b);
        }
    }

    public final void setLandscape(boolean landscape) {
        Bitmap bitmap;
        Bitmap bitmap2;
        ArrayList arrayList;
        this.f1483a = landscape;
        if (landscape) {
            bitmap = this.f1490h.f1317b.f1346b;
            bitmap2 = this.f1490h.f1321f.f1346b;
            arrayList = this.f1490h.f1325j;
        } else {
            bitmap = this.f1490h.f1316a.f1346b;
            bitmap2 = this.f1490h.f1320e.f1346b;
            arrayList = this.f1490h.f1324i;
        }
        ag.m281a(this.f1485c, new BitmapDrawable(null, bitmap));
        ag.m281a(this.f1486d, new BitmapDrawable(null, bitmap2));
        if (this.f1487e.getChildCount() > 0) {
            this.f1487e.removeAllViews();
        }
        Context context = getContext();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            gw gwVar = (gw) it.next();
            View view = new View(context);
            view.setTag(gwVar);
            view.setOnClickListener(this);
            this.f1487e.addView(view, new FrameLayout.LayoutParams(0, 0, 51));
        }
    }

    protected final void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i = 15;
        int i2 = 0;
        int size = MeasureSpec.getSize(widthMeasureSpec);
        int size2 = MeasureSpec.getSize(heightMeasureSpec);
        if (this.f1483a) {
            this.f1484b = Math.min(((float) size) / 480.0f, ((float) size2) / 320.0f);
        } else {
            this.f1484b = Math.min(((float) size) / 320.0f, ((float) size2) / 480.0f);
        }
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.f1485c.getLayoutParams();
        layoutParams.width = m1205a(this.f1483a ? 480 : 320);
        layoutParams.height = m1205a(this.f1483a ? 320 : 480);
        layoutParams = (RelativeLayout.LayoutParams) this.f1486d.getLayoutParams();
        layoutParams.width = m1205a(this.f1483a ? 448 : 290);
        layoutParams.height = m1205a(this.f1483a ? 290 : 448);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.f1487e.getLayoutParams();
        layoutParams2.width = layoutParams.width;
        layoutParams2.height = layoutParams.height;
        for (View view : ah.m282a(this.f1487e)) {
            FrameLayout.LayoutParams layoutParams3 = (FrameLayout.LayoutParams) view.getLayoutParams();
            Rect rect = ((gw) view.getTag()).f1296a;
            layoutParams3.width = m1205a(rect.width());
            layoutParams3.height = m1205a(rect.height());
            layoutParams3.leftMargin = m1205a(rect.left);
            layoutParams3.topMargin = m1205a(rect.top);
        }
        size2 = m1205a(0);
        this.f1488f.setPadding(size2, size2, size2, size2);
        layoutParams = (RelativeLayout.LayoutParams) this.f1488f.getLayoutParams();
        layoutParams.width = m1205a(30);
        layoutParams.height = layoutParams.width;
        layoutParams.rightMargin = (-size2) + m1205a(this.f1490h.f1319d.x);
        layoutParams.topMargin = (-size2) + m1205a(this.f1490h.f1319d.y);
        if (this.f1489g != null) {
            int a = m1205a(this.f1483a ? 16 : 15);
            if (!this.f1483a) {
                i = 16;
            }
            int a2 = m1205a(i);
            this.f1489g.setPadding(size2, size2, size2, size2);
            layoutParams = (RelativeLayout.LayoutParams) this.f1489g.getLayoutParams();
            layoutParams.width = m1205a(26);
            layoutParams.height = layoutParams.width;
            if (this.f1490h.f1328m != null) {
                Point point;
                gz gzVar;
                if (this.f1483a) {
                    gzVar = this.f1490h.f1328m;
                    if (gzVar.f1331b == null) {
                        point = gzVar.f1332c;
                    } else {
                        point = gzVar.f1331b;
                    }
                } else {
                    gzVar = this.f1490h.f1328m;
                    if (gzVar.f1332c == null) {
                        point = gzVar.f1331b;
                    } else {
                        point = gzVar.f1332c;
                    }
                }
                if (point != null) {
                    i2 = point.x;
                    size2 = point.y;
                    layoutParams.leftMargin = m1205a(i2) + a;
                    layoutParams.topMargin = m1205a(size2) + a2;
                }
            }
            size2 = 0;
            layoutParams.leftMargin = m1205a(i2) + a;
            layoutParams.topMargin = m1205a(size2) + a2;
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    private int m1205a(int i) {
        return (int) (((float) i) * this.f1484b);
    }

    protected final void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
    }

    public final void onClick(View v) {
        if (v == this.f1488f) {
            this.f1491i.mo232a();
        } else if (v != null && v == this.f1489g) {
            hr hrVar = this.f1489g;
            hrVar.f1456a = !hrVar.f1456a;
            hrVar.m1202a();
            hrVar.invalidate();
            this.f1491i.mo234b();
        } else if (v.getTag() instanceof gw) {
            this.f1491i.mo233a((gw) v.getTag());
        }
    }
}
