package com.tapjoy.internal;

import android.graphics.Bitmap;
import java.io.InputStream;
import java.net.ContentHandler;
import java.net.URLConnection;

public final class C0283u extends ContentHandler {
    public static final C0283u f1543a = new C0283u();

    public final /* synthetic */ Object getContent(URLConnection uRLConnection) {
        return C0283u.m1341a(uRLConnection);
    }

    private C0283u() {
    }

    private static Bitmap m1341a(URLConnection uRLConnection) {
        InputStream inputStream = uRLConnection.getInputStream();
        try {
            Bitmap a = C0285v.f1546a.m1342a(inputStream);
            return a;
        } finally {
            inputStream.close();
        }
    }

    public static Bitmap m1340a(InputStream inputStream) {
        try {
            Bitmap a = C0285v.f1546a.m1342a(inputStream);
            return a;
        } finally {
            inputStream.close();
        }
    }
}
