package com.tapjoy.internal;

public interface ax extends as {
}
