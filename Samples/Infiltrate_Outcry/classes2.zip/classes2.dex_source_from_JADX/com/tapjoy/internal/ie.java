package com.tapjoy.internal;

import java.util.Arrays;

final class ie extends hy {
    final transient byte[][] f1523f;
    final transient int[] f1524g;

    ie(hv hvVar, int i) {
        int i2 = 0;
        super(null);
        ii.m1305a(hvVar.f1494b, 0, (long) i);
        ic icVar = hvVar.f1493a;
        int i3 = 0;
        int i4 = 0;
        while (i4 < i) {
            if (icVar.f1516c == icVar.f1515b) {
                throw new AssertionError("s.limit == s.pos");
            }
            i4 += icVar.f1516c - icVar.f1515b;
            i3++;
            icVar = icVar.f1519f;
        }
        this.f1523f = new byte[i3][];
        this.f1524g = new int[(i3 * 2)];
        ic icVar2 = hvVar.f1493a;
        i4 = 0;
        while (i2 < i) {
            this.f1523f[i4] = icVar2.f1514a;
            int i5 = (icVar2.f1516c - icVar2.f1515b) + i2;
            if (i5 > i) {
                i5 = i;
            }
            this.f1524g[i4] = i5;
            this.f1524g[this.f1523f.length + i4] = icVar2.f1515b;
            icVar2.f1517d = true;
            i4++;
            icVar2 = icVar2.f1519f;
            i2 = i5;
        }
    }

    public final String mo273a() {
        return m1292e().mo273a();
    }

    public final String mo276b() {
        return m1292e().mo276b();
    }

    public final hy mo272a(int i, int i2) {
        return m1292e().mo272a(i, i2);
    }

    public final byte mo271a(int i) {
        ii.m1305a((long) this.f1524g[this.f1523f.length - 1], (long) i, 1);
        int b = m1291b(i);
        return this.f1523f[b][(i - (b == 0 ? 0 : this.f1524g[b - 1])) + this.f1524g[this.f1523f.length + b]];
    }

    private int m1291b(int i) {
        int binarySearch = Arrays.binarySearch(this.f1524g, 0, this.f1523f.length, i + 1);
        return binarySearch >= 0 ? binarySearch : binarySearch ^ -1;
    }

    public final int mo277c() {
        return this.f1524g[this.f1523f.length - 1];
    }

    public final byte[] mo278d() {
        int i = 0;
        Object obj = new byte[this.f1524g[this.f1523f.length - 1]];
        int length = this.f1523f.length;
        int i2 = 0;
        while (i < length) {
            int i3 = this.f1524g[length + i];
            int i4 = this.f1524g[i];
            System.arraycopy(this.f1523f[i], i3, obj, i2, i4 - i2);
            i++;
            i2 = i4;
        }
        return obj;
    }

    final void mo274a(hv hvVar) {
        int i = 0;
        int length = this.f1523f.length;
        int i2 = 0;
        while (i < length) {
            int i3 = this.f1524g[length + i];
            int i4 = this.f1524g[i];
            ic icVar = new ic(this.f1523f[i], i3, (i3 + i4) - i2);
            if (hvVar.f1493a == null) {
                icVar.f1520g = icVar;
                icVar.f1519f = icVar;
                hvVar.f1493a = icVar;
            } else {
                hvVar.f1493a.f1520g.m1287a(icVar);
            }
            i++;
            i2 = i4;
        }
        hvVar.f1494b = ((long) i2) + hvVar.f1494b;
    }

    public final boolean mo275a(int i, byte[] bArr, int i2, int i3) {
        if (i < 0 || i > mo277c() - i3 || i2 < 0 || i2 > bArr.length - i3) {
            return false;
        }
        int b = m1291b(i);
        while (i3 > 0) {
            int i4 = b == 0 ? 0 : this.f1524g[b - 1];
            int min = Math.min(i3, ((this.f1524g[b] - i4) + i4) - i);
            if (!ii.m1307a(this.f1523f[b], (i - i4) + this.f1524g[this.f1523f.length + b], bArr, i2, min)) {
                return false;
            }
            i += min;
            i2 += min;
            i3 -= min;
            b++;
        }
        return true;
    }

    private hy m1292e() {
        return new hy(mo278d());
    }

    public final boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof hy) || ((hy) o).mo277c() != mo277c()) {
            return false;
        }
        boolean z;
        hy hyVar = (hy) o;
        int c = mo277c();
        if (mo277c() - c < 0) {
            z = false;
        } else {
            int i = c;
            int i2 = 0;
            int i3 = 0;
            c = m1291b(0);
            while (i > 0) {
                int i4 = c == 0 ? 0 : this.f1524g[c - 1];
                int min = Math.min(i, ((this.f1524g[c] - i4) + i4) - i3);
                if (!hyVar.mo275a(i2, this.f1523f[c], (i3 - i4) + this.f1524g[this.f1523f.length + c], min)) {
                    z = false;
                    break;
                }
                i3 += min;
                i2 += min;
                i -= min;
                c++;
            }
            z = true;
        }
        if (z) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.d;
        if (i == 0) {
            i = 1;
            int length = this.f1523f.length;
            int i2 = 0;
            int i3 = 0;
            while (i2 < length) {
                byte[] bArr = this.f1523f[i2];
                int i4 = this.f1524g[length + i2];
                int i5 = this.f1524g[i2];
                i3 = (i5 - i3) + i4;
                int i6 = i4;
                i4 = i;
                for (i = i6; i < i3; i++) {
                    i4 = (i4 * 31) + bArr[i];
                }
                i2++;
                i3 = i5;
                i = i4;
            }
            this.d = i;
        }
        return i;
    }

    public final String toString() {
        return m1292e().toString();
    }
}
