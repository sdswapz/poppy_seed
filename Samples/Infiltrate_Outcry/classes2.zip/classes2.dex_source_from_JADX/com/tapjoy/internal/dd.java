package com.tapjoy.internal;

import com.tapjoy.internal.di.C0147a;
import java.util.concurrent.Executor;
import java.util.logging.Logger;

public abstract class dd implements di {
    private static final Logger f630a = Logger.getLogger(dd.class.getName());
    private final di f631b = new C01421(this);

    class C01421 extends df {
        final /* synthetic */ dd f628a;

        class C01411 implements Runnable {
            final /* synthetic */ C01421 f622a;

            C01411(C01421 c01421) {
                this.f622a = c01421;
            }

            public final void run() {
                try {
                    Object obj;
                    this.f622a.f628a.mo188a();
                    this.f622a.m488c();
                    if (this.f622a.mo121f() == C0147a.RUNNING) {
                        obj = 1;
                    } else {
                        obj = null;
                    }
                    if (obj != null) {
                        this.f622a.f628a.mo189b();
                    }
                    this.f622a.f628a.mo190c();
                    this.f622a.m489d();
                } catch (Throwable th) {
                    this.f622a.m486a(th);
                    RuntimeException a = cu.m464a(th);
                }
            }
        }

        C01421(dd ddVar) {
            this.f628a = ddVar;
        }

        protected final void mo122a() {
            new C01432(this.f628a).execute(new C01411(this));
        }

        protected final void mo123b() {
            this.f628a.mo191d();
        }
    }

    class C01432 implements Executor {
        final /* synthetic */ dd f629a;

        C01432(dd ddVar) {
            this.f629a = ddVar;
        }

        public final void execute(Runnable command) {
            new Thread(command, this.f629a.getClass().getSimpleName()).start();
        }
    }

    public abstract void mo189b();

    public void mo188a() {
    }

    public void mo190c() {
    }

    public void mo191d() {
    }

    public String toString() {
        return getClass().getSimpleName() + " [" + mo121f() + "]";
    }

    public final dh mo120e() {
        return this.f631b.mo120e();
    }

    public final C0147a mo121f() {
        return this.f631b.mo121f();
    }
}
