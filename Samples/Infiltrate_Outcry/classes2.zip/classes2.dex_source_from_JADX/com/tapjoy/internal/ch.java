package com.tapjoy.internal;

public final class ch implements Runnable {
    private final cf f597a;
    private final ck f598b;

    protected ch(cf cfVar, ck ckVar) {
        this.f597a = cfVar;
        this.f598b = ckVar;
    }

    public final void run() {
        try {
            Object f = this.f597a.mo251f();
            if (this.f598b != null && !(this.f598b instanceof cl)) {
                this.f598b.mo209a(this.f597a, f);
            }
        } catch (Throwable th) {
            if (this.f598b != null && !(this.f598b instanceof cl)) {
                this.f598b.mo208a(this.f597a);
            }
        }
    }
}
