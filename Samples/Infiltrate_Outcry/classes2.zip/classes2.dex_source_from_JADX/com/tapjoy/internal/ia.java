package com.tapjoy.internal;

final class ia implements hw {
    public final hv f1508a = new hv();
    public final C0271if f1509b;
    boolean f1510c;

    ia(C0271if c0271if) {
        if (c0271if == null) {
            throw new IllegalArgumentException("sink == null");
        }
        this.f1509b = c0271if;
    }

    public final void mo255a(hv hvVar, long j) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.mo255a(hvVar, j);
        m1269b();
    }

    public final hw mo257b(hy hyVar) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.m1225a(hyVar);
        return m1269b();
    }

    public final hw mo258b(String str) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.m1226a(str);
        return m1269b();
    }

    public final hw mo267e(int i) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.m1224a(i);
        return m1269b();
    }

    public final hw mo264d(int i) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.m1232b(i);
        return m1269b();
    }

    public final hw mo269f(long j) {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        this.f1508a.m1244e(j);
        return m1269b();
    }

    private hw m1269b() {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        hv hvVar = this.f1508a;
        long j = hvVar.f1494b;
        if (j == 0) {
            j = 0;
        } else {
            ic icVar = hvVar.f1493a.f1520g;
            if (icVar.f1516c < 8192 && icVar.f1518e) {
                j -= (long) (icVar.f1516c - icVar.f1515b);
            }
        }
        if (j > 0) {
            this.f1509b.mo255a(this.f1508a, j);
        }
        return this;
    }

    public final hw mo253a() {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        long j = this.f1508a.f1494b;
        if (j > 0) {
            this.f1509b.mo255a(this.f1508a, j);
        }
        return this;
    }

    public final void flush() {
        if (this.f1510c) {
            throw new IllegalStateException("closed");
        }
        if (this.f1508a.f1494b > 0) {
            this.f1509b.mo255a(this.f1508a, this.f1508a.f1494b);
        }
        this.f1509b.flush();
    }

    public final void close() {
        if (!this.f1510c) {
            Throwable th = null;
            try {
                if (this.f1508a.f1494b > 0) {
                    this.f1509b.mo255a(this.f1508a, this.f1508a.f1494b);
                }
            } catch (Throwable th2) {
                th = th2;
            }
            try {
                this.f1509b.close();
            } catch (Throwable th3) {
                if (th == null) {
                    th = th3;
                }
            }
            this.f1510c = true;
            if (th != null) {
                ii.m1306a(th);
            }
        }
    }

    public final String toString() {
        return "buffer(" + this.f1509b + ")";
    }
}
