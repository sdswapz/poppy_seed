package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJConnectListener;
import java.util.Hashtable;

final class dw extends dv {
    private final fe f713b = new C01621(this);

    class C01621 extends fe {
        final /* synthetic */ dw f712a;

        C01621(dw dwVar) {
            this.f712a = dwVar;
        }

        protected final boolean mo176a(Context context, String str, Hashtable hashtable, TJConnectListener tJConnectListener) {
            return super.mo156a(context, str, hashtable, tJConnectListener);
        }
    }

    dw() {
    }

    public final boolean mo156a(Context context, String str, Hashtable hashtable, TJConnectListener tJConnectListener) {
        return this.f713b.m707b(context, str, hashtable, tJConnectListener);
    }
}
