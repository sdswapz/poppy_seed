package com.tapjoy.internal;

final class ha extends gs implements ft {
    public static final bn f1340a = new C02581();
    private final String f1341b;
    private final String f1342c;

    static class C02581 implements bn {
        C02581() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            String str = "";
            String str2 = "";
            bsVar.mo105h();
            while (bsVar.mo107j()) {
                String l = bsVar.mo109l();
                if ("campaign_id".equals(l)) {
                    str = bsVar.m378c("");
                } else if ("product_id".equals(l)) {
                    str2 = bsVar.m378c("");
                } else {
                    bsVar.mo116s();
                }
            }
            bsVar.mo106i();
            return new ha(str, str2);
        }
    }

    ha(String str, String str2) {
        this.f1341b = str;
        this.f1342c = str2;
    }

    public final String mo238a() {
        return this.f1341b;
    }

    public final String mo239b() {
        return this.f1342c;
    }
}
