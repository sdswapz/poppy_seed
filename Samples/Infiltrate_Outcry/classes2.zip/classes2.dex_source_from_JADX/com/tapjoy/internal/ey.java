package com.tapjoy.internal;

public final class ey extends et {
    public final ep f1019c;

    public ey(String str, String str2, ep epVar) {
        super(str, str2, "mm");
        m783a("content_card", "n2e");
        this.f1019c = epVar;
    }
}
