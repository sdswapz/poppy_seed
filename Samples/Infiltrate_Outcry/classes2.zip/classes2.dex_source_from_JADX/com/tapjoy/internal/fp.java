package com.tapjoy.internal;

public interface fp {
    void mo237a(fq fqVar);
}
