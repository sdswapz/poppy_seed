package com.tapjoy.internal;

import android.content.Context;
import android.content.Intent;

public abstract class C0236s {
    public abstract void mo224a(int i);

    public abstract void mo225a(Context context, String str);

    public abstract boolean mo226a(Context context, Intent intent);

    public abstract void mo227b(String str);

    public boolean mo228c(String str) {
        return true;
    }

    public boolean mo229d(String str) {
        return false;
    }
}
