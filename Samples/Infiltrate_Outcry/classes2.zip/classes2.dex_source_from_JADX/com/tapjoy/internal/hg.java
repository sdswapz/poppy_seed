package com.tapjoy.internal;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.os.Build.VERSION;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class hg {
    private static final String f1374d = hg.class.getSimpleName();
    int f1375a;
    int f1376b;
    hi f1377c;
    private int[] f1378e;
    private final int[] f1379f;
    private ByteBuffer f1380g;
    private byte[] f1381h;
    private byte[] f1382i;
    private int f1383j;
    private int f1384k;
    private hj f1385l;
    private short[] f1386m;
    private byte[] f1387n;
    private byte[] f1388o;
    private byte[] f1389p;
    private int[] f1390q;
    private C0263a f1391r;
    private Bitmap f1392s;
    private boolean f1393t;
    private int f1394u;
    private int f1395v;
    private int f1396w;
    private int f1397x;
    private boolean f1398y;

    interface C0263a {
        Bitmap mo244a(int i, int i2, Config config);

        byte[] mo245a(int i);

        int[] mo246b(int i);
    }

    hg(C0263a c0263a, hi hiVar, ByteBuffer byteBuffer) {
        this(c0263a, hiVar, byteBuffer, (byte) 0);
    }

    private hg(C0263a c0263a, hi hiVar, ByteBuffer byteBuffer, byte b) {
        this(c0263a);
        m1156b(hiVar, byteBuffer);
    }

    private hg(C0263a c0263a) {
        this.f1379f = new int[256];
        this.f1383j = 0;
        this.f1384k = 0;
        this.f1391r = c0263a;
        this.f1377c = new hi();
    }

    hg() {
        this(new hl());
    }

    final synchronized Bitmap m1161a() {
        Bitmap bitmap;
        if (this.f1377c.f1412c <= 0 || this.f1375a < 0) {
            Object[] objArr = new Object[]{Integer.valueOf(this.f1377c.f1412c), Integer.valueOf(this.f1375a)};
            this.f1394u = 1;
        }
        if (this.f1394u == 1 || this.f1394u == 2) {
            new Object[1][0] = Integer.valueOf(this.f1394u);
            bitmap = null;
        } else {
            hh hhVar;
            this.f1394u = 0;
            hh hhVar2 = (hh) this.f1377c.f1414e.get(this.f1375a);
            int i = this.f1375a - 1;
            if (i >= 0) {
                hhVar = (hh) this.f1377c.f1414e.get(i);
            } else {
                hhVar = null;
            }
            this.f1378e = hhVar2.f1409k != null ? hhVar2.f1409k : this.f1377c.f1410a;
            if (this.f1378e == null) {
                new Object[1][0] = Integer.valueOf(this.f1375a);
                this.f1394u = 1;
                bitmap = null;
            } else {
                int i2;
                int i3;
                int i4;
                int i5;
                int i6;
                int i7;
                if (hhVar2.f1404f) {
                    System.arraycopy(this.f1378e, 0, this.f1379f, 0, this.f1378e.length);
                    this.f1378e = this.f1379f;
                    this.f1378e[hhVar2.f1406h] = 0;
                }
                int[] iArr = this.f1390q;
                if (hhVar == null) {
                    Arrays.fill(iArr, 0);
                }
                if (hhVar != null && hhVar.f1405g > 0) {
                    if (hhVar.f1405g == 2) {
                        i2 = 0;
                        if (!hhVar2.f1404f) {
                            i2 = this.f1377c.f1421l;
                            if (hhVar2.f1409k != null && this.f1377c.f1419j == hhVar2.f1406h) {
                                i2 = 0;
                            }
                        } else if (this.f1375a == 0) {
                            this.f1398y = true;
                        }
                        m1154a(iArr, hhVar, i2);
                    } else if (hhVar.f1405g == 3) {
                        if (this.f1392s == null) {
                            m1154a(iArr, hhVar, 0);
                        } else {
                            i3 = hhVar.f1400b / this.f1395v;
                            i4 = hhVar.f1399a / this.f1395v;
                            this.f1392s.getPixels(iArr, (this.f1397x * i3) + i4, this.f1397x, i4, i3, hhVar.f1401c / this.f1395v, hhVar.f1402d / this.f1395v);
                        }
                    }
                }
                this.f1383j = 0;
                this.f1384k = 0;
                if (hhVar2 != null) {
                    this.f1380g.position(hhVar2.f1408j);
                }
                if (hhVar2 == null) {
                    i5 = this.f1377c.f1415f * this.f1377c.f1416g;
                } else {
                    i5 = hhVar2.f1401c * hhVar2.f1402d;
                }
                if (this.f1389p == null || this.f1389p.length < i5) {
                    this.f1389p = this.f1391r.mo245a(i5);
                }
                if (this.f1386m == null) {
                    this.f1386m = new short[4096];
                }
                if (this.f1387n == null) {
                    this.f1387n = new byte[4096];
                }
                if (this.f1388o == null) {
                    this.f1388o = new byte[4097];
                }
                int c = m1157c();
                int i8 = 1 << c;
                int i9 = i8 + 1;
                int i10 = i8 + 2;
                int i11 = -1;
                i2 = c + 1;
                int i12 = (1 << i2) - 1;
                for (i4 = 0; i4 < i8; i4++) {
                    this.f1386m[i4] = (short) 0;
                    this.f1387n[i4] = (byte) i4;
                }
                int i13 = 0;
                int i14 = 0;
                int i15 = 0;
                int i16 = 0;
                int i17 = 0;
                i3 = i12;
                int i18 = i10;
                i12 = 0;
                i10 = 0;
                i4 = i2;
                i2 = 0;
                while (i13 < i5) {
                    if (i10 == 0) {
                        i10 = m1158d();
                        if (i10 <= 0) {
                            this.f1394u = 3;
                            break;
                        }
                        i6 = 0;
                        i7 = i10;
                    } else {
                        i6 = i12;
                        i7 = i10;
                    }
                    i12 = ((this.f1381h[i6] & 255) << i17) + i16;
                    i10 = i17 + 8;
                    i16 = i6 + 1;
                    i17 = i7 - 1;
                    i7 = i10;
                    i10 = i18;
                    i18 = i15;
                    int i19 = i2;
                    i2 = i4;
                    i4 = i19;
                    int i20 = i3;
                    i3 = i12;
                    i12 = i20;
                    while (i7 >= i2) {
                        i15 = i3 & i12;
                        i6 = i3 >> i2;
                        i7 -= i2;
                        if (i15 != i8) {
                            if (i15 <= i10) {
                                if (i15 == i9) {
                                    i15 = i18;
                                    i3 = i12;
                                    i12 = i16;
                                    i18 = i10;
                                    i10 = i17;
                                    i16 = i6;
                                    i17 = i7;
                                    i19 = i4;
                                    i4 = i2;
                                    i2 = i19;
                                    break;
                                } else if (i11 == -1) {
                                    i3 = i14 + 1;
                                    this.f1388o[i14] = this.f1387n[i15];
                                    i14 = i3;
                                    i18 = i15;
                                    i11 = i15;
                                    i3 = i6;
                                } else {
                                    if (i15 >= i10) {
                                        i3 = i14 + 1;
                                        this.f1388o[i14] = (byte) i18;
                                        i14 = i3;
                                        i18 = i11;
                                    } else {
                                        i18 = i15;
                                    }
                                    while (i18 >= i8) {
                                        i3 = i14 + 1;
                                        this.f1388o[i14] = this.f1387n[i18];
                                        short s = this.f1386m[i18];
                                        i14 = i3;
                                    }
                                    i18 = this.f1387n[i18] & 255;
                                    i3 = i14 + 1;
                                    this.f1388o[i14] = (byte) i18;
                                    if (i10 < 4096) {
                                        this.f1386m[i10] = (short) i11;
                                        this.f1387n[i10] = (byte) i18;
                                        i10++;
                                        if ((i10 & i12) == 0 && i10 < 4096) {
                                            i2++;
                                            i12 += i10;
                                        }
                                    }
                                    i14 = i13;
                                    i13 = i3;
                                    while (i13 > 0) {
                                        i3 = i4 + 1;
                                        i13--;
                                        this.f1389p[i4] = this.f1388o[i13];
                                        i14++;
                                        i4 = i3;
                                    }
                                    i3 = i6;
                                    i11 = i15;
                                    i19 = i14;
                                    i14 = i13;
                                    i13 = i19;
                                }
                            } else {
                                this.f1394u = 3;
                                i15 = i18;
                                i3 = i12;
                                i12 = i16;
                                i18 = i10;
                                i10 = i17;
                                i16 = i6;
                                i17 = i7;
                                i19 = i4;
                                i4 = i2;
                                i2 = i19;
                                break;
                            }
                        }
                        i2 = c + 1;
                        i12 = (1 << i2) - 1;
                        i10 = i8 + 2;
                        i3 = i6;
                        i11 = -1;
                    }
                    i15 = i18;
                    i18 = i10;
                    i10 = i17;
                    i17 = i7;
                    i19 = i4;
                    i4 = i2;
                    i2 = i19;
                    i20 = i3;
                    i3 = i12;
                    i12 = i16;
                    i16 = i20;
                }
                while (i2 < i5) {
                    this.f1389p[i2] = (byte) 0;
                    i2++;
                }
                i5 = hhVar2.f1402d / this.f1395v;
                c = hhVar2.f1400b / this.f1395v;
                i8 = hhVar2.f1401c / this.f1395v;
                i9 = hhVar2.f1399a / this.f1395v;
                i4 = 1;
                i10 = 8;
                i12 = 0;
                Object obj = this.f1375a == 0 ? 1 : null;
                i18 = 0;
                while (i18 < i5) {
                    if (hhVar2.f1403e) {
                        if (i12 >= i5) {
                            i4++;
                            switch (i4) {
                                case 2:
                                    i12 = 4;
                                    break;
                                case 3:
                                    i12 = 2;
                                    i10 = 4;
                                    break;
                                case 4:
                                    i12 = 1;
                                    i10 = 2;
                                    break;
                            }
                        }
                        i11 = i12 + i10;
                        i15 = i10;
                        i6 = i4;
                    } else {
                        i11 = i12;
                        i15 = i10;
                        i6 = i4;
                        i12 = i18;
                    }
                    i12 += c;
                    if (i12 < this.f1396w) {
                        i4 = i12 * this.f1397x;
                        i10 = i4 + i9;
                        i12 = i10 + i8;
                        if (this.f1397x + i4 < i12) {
                            i14 = this.f1397x + i4;
                        } else {
                            i14 = i12;
                        }
                        i12 = (this.f1395v * i18) * hhVar2.f1401c;
                        int i21 = i12 + ((i14 - i10) * this.f1395v);
                        i7 = i12;
                        for (i16 = i10; i16 < i14; i16++) {
                            if (this.f1395v == 1) {
                                i12 = this.f1378e[this.f1389p[i7] & 255];
                            } else {
                                int i22;
                                int i23 = hhVar2.f1401c;
                                i13 = 0;
                                i3 = 0;
                                i4 = 0;
                                i10 = 0;
                                i12 = 0;
                                i17 = i7;
                                while (i17 < this.f1395v + i7 && i17 < this.f1389p.length && i17 < i21) {
                                    i22 = this.f1378e[this.f1389p[i17] & 255];
                                    if (i22 != 0) {
                                        i13 += (i22 >> 24) & 255;
                                        i3 += (i22 >> 16) & 255;
                                        i4 += (i22 >> 8) & 255;
                                        i10 += i22 & 255;
                                        i12++;
                                    }
                                    i17++;
                                }
                                i17 = i7 + i23;
                                while (i17 < (i7 + i23) + this.f1395v && i17 < this.f1389p.length && i17 < i21) {
                                    i22 = this.f1378e[this.f1389p[i17] & 255];
                                    if (i22 != 0) {
                                        i13 += (i22 >> 24) & 255;
                                        i3 += (i22 >> 16) & 255;
                                        i4 += (i22 >> 8) & 255;
                                        i10 += i22 & 255;
                                        i12++;
                                    }
                                    i17++;
                                }
                                if (i12 == 0) {
                                    i12 = 0;
                                } else {
                                    i12 = (i10 / i12) | (((i4 / i12) << 8) | (((i3 / i12) << 16) | ((i13 / i12) << 24)));
                                }
                            }
                            if (i12 != 0) {
                                iArr[i16] = i12;
                            } else if (!(this.f1398y || obj == null)) {
                                this.f1398y = true;
                            }
                            i7 = this.f1395v + i7;
                        }
                    }
                    i18++;
                    i12 = i11;
                    i10 = i15;
                    i4 = i6;
                }
                if (this.f1393t && (hhVar2.f1405g == 0 || hhVar2.f1405g == 1)) {
                    if (this.f1392s == null) {
                        this.f1392s = m1159e();
                    }
                    this.f1392s.setPixels(iArr, 0, this.f1397x, 0, 0, this.f1397x, this.f1396w);
                }
                bitmap = m1159e();
                bitmap.setPixels(iArr, 0, this.f1397x, 0, 0, this.f1397x, this.f1396w);
            }
        }
        return bitmap;
    }

    private synchronized void m1153a(hi hiVar, byte[] bArr) {
        m1152a(hiVar, ByteBuffer.wrap(bArr));
    }

    private synchronized void m1152a(hi hiVar, ByteBuffer byteBuffer) {
        m1156b(hiVar, byteBuffer);
    }

    private synchronized void m1156b(hi hiVar, ByteBuffer byteBuffer) {
        int highestOneBit = Integer.highestOneBit(1);
        this.f1394u = 0;
        this.f1377c = hiVar;
        this.f1398y = false;
        this.f1375a = -1;
        this.f1376b = 0;
        this.f1380g = byteBuffer.asReadOnlyBuffer();
        this.f1380g.position(0);
        this.f1380g.order(ByteOrder.LITTLE_ENDIAN);
        this.f1393t = false;
        for (hh hhVar : hiVar.f1414e) {
            if (hhVar.f1405g == 3) {
                this.f1393t = true;
                break;
            }
        }
        this.f1395v = highestOneBit;
        this.f1397x = hiVar.f1415f / highestOneBit;
        this.f1396w = hiVar.f1416g / highestOneBit;
        this.f1389p = this.f1391r.mo245a(hiVar.f1415f * hiVar.f1416g);
        this.f1390q = this.f1391r.mo246b(this.f1397x * this.f1396w);
    }

    final synchronized int m1160a(byte[] bArr) {
        if (this.f1385l == null) {
            this.f1385l = new hj();
        }
        this.f1377c = this.f1385l.m1171a(bArr).m1170a();
        if (bArr != null) {
            m1153a(this.f1377c, bArr);
        }
        return this.f1394u;
    }

    private void m1154a(int[] iArr, hh hhVar, int i) {
        int i2 = hhVar.f1401c / this.f1395v;
        int i3 = hhVar.f1399a / this.f1395v;
        int i4 = ((hhVar.f1400b / this.f1395v) * this.f1397x) + i3;
        i3 = i4 + ((hhVar.f1402d / this.f1395v) * this.f1397x);
        while (i4 < i3) {
            int i5 = i4 + i2;
            for (int i6 = i4; i6 < i5; i6++) {
                iArr[i6] = i;
            }
            i4 += this.f1397x;
        }
    }

    private void m1155b() {
        if (this.f1383j <= this.f1384k) {
            if (this.f1382i == null) {
                this.f1382i = this.f1391r.mo245a(16384);
            }
            this.f1384k = 0;
            this.f1383j = Math.min(this.f1380g.remaining(), 16384);
            this.f1380g.get(this.f1382i, 0, this.f1383j);
        }
    }

    private int m1157c() {
        try {
            m1155b();
            byte[] bArr = this.f1382i;
            int i = this.f1384k;
            this.f1384k = i + 1;
            return bArr[i] & 255;
        } catch (Exception e) {
            this.f1394u = 1;
            return 0;
        }
    }

    private int m1158d() {
        int c = m1157c();
        if (c > 0) {
            try {
                if (this.f1381h == null) {
                    this.f1381h = this.f1391r.mo245a(255);
                }
                int i = this.f1383j - this.f1384k;
                if (i >= c) {
                    System.arraycopy(this.f1382i, this.f1384k, this.f1381h, 0, c);
                    this.f1384k += c;
                } else if (this.f1380g.remaining() + i >= c) {
                    System.arraycopy(this.f1382i, this.f1384k, this.f1381h, 0, i);
                    this.f1384k = this.f1383j;
                    m1155b();
                    int i2 = c - i;
                    System.arraycopy(this.f1382i, 0, this.f1381h, i, i2);
                    this.f1384k += i2;
                } else {
                    this.f1394u = 1;
                }
            } catch (Exception e) {
                new Object[1][0] = e;
                this.f1394u = 1;
            }
        }
        return c;
    }

    private Bitmap m1159e() {
        Bitmap a = this.f1391r.mo244a(this.f1397x, this.f1396w, this.f1398y ? Config.ARGB_4444 : Config.RGB_565);
        if (VERSION.SDK_INT >= 12) {
            a.setHasAlpha(true);
        }
        return a;
    }
}
