package com.tapjoy.internal;

import java.util.HashSet;
import java.util.Iterator;

public final class cy {
    public static HashSet m470a(Iterator it) {
        HashSet hashSet = new HashSet();
        while (it.hasNext()) {
            hashSet.add(it.next());
        }
        return hashSet;
    }
}
