package com.tapjoy.internal;

public interface ft extends fp {
    String mo238a();

    String mo239b();
}
