package com.tapjoy.internal;

import java.io.IOException;

public final class bz extends IOException {
    public bz(String str) {
        super(str);
    }
}
