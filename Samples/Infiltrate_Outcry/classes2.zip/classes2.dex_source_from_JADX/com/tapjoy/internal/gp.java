package com.tapjoy.internal;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;

public final class gp implements Flushable {
    final Object f1273a = this;
    bc f1274b;
    private final File f1275c;

    class C02451 implements bi {
        final /* synthetic */ gp f1272a;

        C02451(gp gpVar) {
            this.f1272a = gpVar;
        }

        public final /* bridge */ /* synthetic */ void mo235a(OutputStream outputStream, Object obj) {
            dy.f751c.m520a(outputStream, (dy) obj);
        }

        public final /* synthetic */ Object mo236b(InputStream inputStream) {
            return (dy) dy.f751c.m516a(inputStream);
        }
    }

    public gp(File file) {
        this.f1275c = file;
        try {
            this.f1274b = az.m309a(new C0274i(file, new C02451(this)));
        } catch (Exception e) {
            m1096a();
        }
    }

    final void m1096a() {
        this.f1275c.delete();
        if (this.f1274b instanceof Closeable) {
            try {
                ((Closeable) this.f1274b).close();
            } catch (Exception e) {
            }
        }
        this.f1274b = new ba(new LinkedList());
    }

    public final void flush() {
        synchronized (this.f1273a) {
            if (this.f1274b instanceof Flushable) {
                try {
                    ((Flushable) this.f1274b).flush();
                } catch (Exception e) {
                    m1096a();
                }
            }
        }
    }

    public final int m1098b() {
        int size;
        synchronized (this.f1273a) {
            try {
                size = this.f1274b.size();
            } catch (Exception e) {
                m1096a();
                size = 0;
            }
        }
        return size;
    }

    public final boolean m1100c() {
        boolean isEmpty;
        synchronized (this.f1273a) {
            try {
                isEmpty = this.f1274b.isEmpty();
            } catch (Exception e) {
                m1096a();
                isEmpty = true;
            }
        }
        return isEmpty;
    }

    public final void m1097a(int i) {
        synchronized (this.f1273a) {
            try {
                this.f1274b.mo95b(i);
            } catch (Exception e) {
                m1096a();
            }
        }
    }

    public final dy m1099b(int i) {
        dy dyVar;
        synchronized (this.f1273a) {
            try {
                dyVar = (dy) this.f1274b.mo94a(i);
            } catch (Exception e) {
                m1096a();
                dyVar = null;
            }
        }
        return dyVar;
    }
}
