package com.tapjoy.internal;

import android.os.SystemClock;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public abstract class fj {
    static Set f1078a = null;
    private static final ThreadLocal f1079b = new C02141();
    private static fj f1080c;
    private static volatile boolean f1081d = false;

    static class C02141 extends ThreadLocal {
        C02141() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new HashMap();
        }
    }

    public static final class C0215a {
        final String f1074a;
        private final TreeMap f1075b = new TreeMap();
        private final Map f1076c = new HashMap();
        private volatile long f1077d;

        C0215a(String str) {
            this.f1074a = str;
        }

        public final C0215a m861a() {
            try {
                this.f1077d = SystemClock.elapsedRealtime();
            } catch (NullPointerException e) {
                this.f1077d = -1;
            }
            return this;
        }

        public final C0215a m866b() {
            long j = this.f1077d;
            if (j != -1) {
                try {
                    m863a("spent_time", SystemClock.elapsedRealtime() - j);
                } catch (NullPointerException e) {
                }
            }
            return this;
        }

        public final C0215a m864a(String str, Object obj) {
            this.f1075b.put(str, obj);
            return this;
        }

        public final C0215a m865a(Map map) {
            if (map != null) {
                this.f1075b.putAll(map);
            }
            return this;
        }

        public final C0215a m862a(String str) {
            this.f1075b.put("failure", str);
            return this;
        }

        public final C0215a m867b(String str) {
            this.f1075b.put("misuse", str);
            return this;
        }

        public final C0215a m863a(String str, long j) {
            this.f1076c.put(str, Long.valueOf(j));
            return this;
        }

        public final C0215a m868b(Map map) {
            if (map != null) {
                this.f1076c.putAll(map);
            }
            return this;
        }

        public final void m869c() {
            String a;
            Map map = null;
            String str = this.f1074a;
            if (this.f1075b.size() > 0) {
                a = bm.m327a(this.f1075b);
            } else {
                a = null;
            }
            if (this.f1076c.size() > 0) {
                map = this.f1076c;
            }
            fj.m878b(str, a, map);
        }
    }

    protected abstract void mo197a();

    protected abstract void mo198a(long j);

    protected abstract void mo199a(long j, String str, String str2, Map map);

    public static void m871a(fl flVar) {
        if (f1080c == null) {
            f1080c = flVar;
            if (f1081d) {
                flVar.mo198a(C0289y.m1352b());
            }
        }
    }

    public static void m876a(boolean z) {
        if (f1081d != z) {
            f1081d = z;
            if (f1080c == null) {
                return;
            }
            if (z) {
                f1080c.mo198a(C0289y.m1352b());
            } else {
                f1080c.mo197a();
            }
        }
    }

    public static void m875a(Collection collection) {
        if (collection == null || collection.isEmpty()) {
            f1078a = null;
        } else {
            f1078a = new HashSet(collection);
        }
    }

    private static void m878b(String str, String str2, Map map) {
        Set set = f1078a;
        if ((set == null || !set.contains(str)) && f1081d && f1080c != null) {
            f1080c.mo199a(C0289y.m1352b(), str, str2, map);
        }
    }

    public static void m874a(String str, TreeMap treeMap, Map map) {
        m878b(str, treeMap != null ? bm.m327a((Object) treeMap) : null, map);
    }

    public static C0215a m870a(String str) {
        C0215a a = new C0215a(str).m861a();
        ((Map) f1079b.get()).put(str, a);
        return a;
    }

    public static C0215a m877b(String str) {
        C0215a c0215a = (C0215a) ((Map) f1079b.get()).remove(str);
        return c0215a != null ? c0215a.m866b() : new C0215a(str);
    }

    public static C0215a m879c(String str) {
        return (C0215a) ((Map) f1079b.get()).get(str);
    }

    public static C0215a m880d(String str) {
        return (C0215a) ((Map) f1079b.get()).remove(str);
    }

    public static void m872a(String str, C0215a c0215a) {
        if (c0215a == null) {
            new Object[1][0] = str;
        } else if (str.equals(c0215a.f1074a)) {
            ((Map) f1079b.get()).put(str, c0215a);
        } else {
            Object[] objArr = new Object[]{str, c0215a.f1074a};
        }
    }

    public static C0215a m881e(String str) {
        return new C0215a(str);
    }
}
