package com.tapjoy.internal;

public final class al {
    public boolean f498a = false;
    public float f499b = 0.0f;
    private float f500c = 0.0f;
    private int f501d = 1;
    private float f502e = 0.5f;
    private int f503f = 1;
    private float f504g = 0.5f;

    public final ak m288a() {
        return new ak(this.f498a, this.f499b, this.f500c, this.f501d, this.f502e, this.f503f, this.f504g);
    }
}
