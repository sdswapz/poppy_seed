package com.tapjoy.internal;

import java.io.Closeable;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class by implements Closeable {
    final Writer f586a;
    private final List f587b = new ArrayList();
    private String f588c;
    private String f589d;
    private boolean f590e;

    public by(Writer writer) {
        this.f587b.add(bv.EMPTY_DOCUMENT);
        this.f589d = ":";
        if (writer == null) {
            throw new NullPointerException("out == null");
        }
        this.f586a = writer;
    }

    public final by m424a() {
        return m416a(bv.EMPTY_ARRAY, "[");
    }

    public final by m432b() {
        return m415a(bv.EMPTY_ARRAY, bv.NONEMPTY_ARRAY, "]");
    }

    public final by m434c() {
        return m416a(bv.EMPTY_OBJECT, "{");
    }

    public final by m435d() {
        return m415a(bv.EMPTY_OBJECT, bv.NONEMPTY_OBJECT, "}");
    }

    private by m416a(bv bvVar, String str) {
        m419a(true);
        this.f587b.add(bvVar);
        this.f586a.write(str);
        return this;
    }

    private by m415a(bv bvVar, bv bvVar2, String str) {
        bv e = m421e();
        if (e == bvVar2 || e == bvVar) {
            this.f587b.remove(this.f587b.size() - 1);
            if (e == bvVar2) {
                m423g();
            }
            this.f586a.write(str);
            return this;
        }
        throw new IllegalStateException("Nesting problem: " + this.f587b);
    }

    private bv m421e() {
        return (bv) this.f587b.get(this.f587b.size() - 1);
    }

    private void m418a(bv bvVar) {
        this.f587b.set(this.f587b.size() - 1, bvVar);
    }

    public final by m429a(String str) {
        if (str == null) {
            throw new NullPointerException("name == null");
        }
        bv e = m421e();
        if (e == bv.NONEMPTY_OBJECT) {
            this.f586a.write(44);
        } else if (e != bv.EMPTY_OBJECT) {
            throw new IllegalStateException("Nesting problem: " + this.f587b);
        }
        m423g();
        m418a(bv.DANGLING_NAME);
        m420c(str);
        return this;
    }

    public final by m433b(String str) {
        if (str == null) {
            return m422f();
        }
        m419a(false);
        m420c(str);
        return this;
    }

    private by m422f() {
        m419a(false);
        this.f586a.write("null");
        return this;
    }

    public final by m425a(long j) {
        m419a(false);
        this.f586a.write(Long.toString(j));
        return this;
    }

    public final by m427a(Number number) {
        if (number == null) {
            return m422f();
        }
        CharSequence obj = number.toString();
        if (this.f590e || !(obj.equals("-Infinity") || obj.equals("Infinity") || obj.equals("NaN"))) {
            m419a(false);
            this.f586a.append(obj);
            return this;
        }
        throw new IllegalArgumentException("Numeric values must be finite, but was " + number);
    }

    public final void close() {
        this.f586a.close();
        if (m421e() != bv.NONEMPTY_DOCUMENT) {
            throw new IOException("Incomplete document");
        }
    }

    private void m420c(String str) {
        this.f586a.write("\"");
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char charAt = str.charAt(i);
            switch (charAt) {
                case '\b':
                    this.f586a.write("\\b");
                    continue;
                case '\t':
                    this.f586a.write("\\t");
                    continue;
                case '\n':
                    this.f586a.write("\\n");
                    continue;
                case '\f':
                    this.f586a.write("\\f");
                    continue;
                case '\r':
                    this.f586a.write("\\r");
                    continue;
                case '\"':
                case '\\':
                    this.f586a.write(92);
                    break;
                case ' ':
                case ' ':
                    this.f586a.write(String.format("\\u%04x", new Object[]{Integer.valueOf(charAt)}));
                    continue;
                default:
                    if (charAt <= '\u001f') {
                        this.f586a.write(String.format("\\u%04x", new Object[]{Integer.valueOf(charAt)}));
                        continue;
                    }
                    break;
            }
            this.f586a.write(charAt);
        }
        this.f586a.write("\"");
    }

    private void m423g() {
        if (this.f588c != null) {
            this.f586a.write("\n");
            for (int i = 1; i < this.f587b.size(); i++) {
                this.f586a.write(this.f588c);
            }
        }
    }

    private void m419a(boolean z) {
        switch (m421e()) {
            case EMPTY_DOCUMENT:
                if (this.f590e || z) {
                    m418a(bv.NONEMPTY_DOCUMENT);
                    return;
                }
                throw new IllegalStateException("JSON must start with an array or an object.");
            case EMPTY_ARRAY:
                m418a(bv.NONEMPTY_ARRAY);
                m423g();
                return;
            case NONEMPTY_ARRAY:
                this.f586a.append(',');
                m423g();
                return;
            case DANGLING_NAME:
                this.f586a.append(this.f589d);
                m418a(bv.NONEMPTY_OBJECT);
                return;
            case NONEMPTY_DOCUMENT:
                throw new IllegalStateException("JSON must have only one top-level value.");
            default:
                throw new IllegalStateException("Nesting problem: " + this.f587b);
        }
    }

    public final by m428a(Object obj) {
        if (obj == null) {
            return m422f();
        }
        if (obj instanceof bw) {
            if (this.f587b.size() == this.f587b.size()) {
                return this;
            }
            throw new IllegalStateException(obj.getClass().getName() + ".writeToJson(JsonWriter) wrote incomplete value");
        } else if (obj instanceof Boolean) {
            boolean booleanValue = ((Boolean) obj).booleanValue();
            m419a(false);
            this.f586a.write(booleanValue ? "true" : "false");
            return this;
        } else if (obj instanceof Number) {
            if (obj instanceof Long) {
                return m425a(((Number) obj).longValue());
            }
            if (!(obj instanceof Double)) {
                return m427a((Number) obj);
            }
            double doubleValue = ((Number) obj).doubleValue();
            if (this.f590e || !(Double.isNaN(doubleValue) || Double.isInfinite(doubleValue))) {
                m419a(false);
                this.f586a.append(Double.toString(doubleValue));
                return this;
            }
            throw new IllegalArgumentException("Numeric values must be finite, but was " + doubleValue);
        } else if (obj instanceof String) {
            return m433b((String) obj);
        } else {
            if (obj instanceof bq) {
                return m426a((bq) obj);
            }
            if (obj instanceof Collection) {
                return m430a((Collection) obj);
            }
            if (obj instanceof Map) {
                return m431a((Map) obj);
            }
            if (obj instanceof Date) {
                Date date = (Date) obj;
                if (date == null) {
                    return m422f();
                }
                return m433b(C0292z.m1354a(date));
            } else if (obj instanceof Object[]) {
                return m417a((Object[]) obj);
            } else {
                throw new IllegalArgumentException("Unknown type: " + obj.getClass().getName());
            }
        }
    }

    private by m417a(Object[] objArr) {
        if (objArr == null) {
            return m422f();
        }
        m424a();
        for (Object a : objArr) {
            m428a(a);
        }
        m432b();
        return this;
    }

    public final by m426a(bq bqVar) {
        m419a(false);
        bqVar.mo96a(this.f586a);
        return this;
    }

    public final by m430a(Collection collection) {
        if (collection == null) {
            return m422f();
        }
        m424a();
        for (Object a : collection) {
            m428a(a);
        }
        m432b();
        return this;
    }

    public final by m431a(Map map) {
        if (map == null) {
            return m422f();
        }
        m434c();
        for (Entry entry : map.entrySet()) {
            m429a(String.valueOf(entry.getKey()));
            m428a(entry.getValue());
        }
        m435d();
        return this;
    }
}
