package com.tapjoy.internal;

import com.tapjoy.internal.dl.C0149a;

public final class eh extends dl {
    public static final dn f895c = new C0184b();
    public static final Long f896d = Long.valueOf(0);
    public static final Long f897e = Long.valueOf(0);
    public final String f898f;
    public final Long f899g;
    public final Long f900h;

    public static final class C0183a extends C0149a {
        public String f892c;
        public Long f893d;
        public Long f894e;

        public final eh m752b() {
            if (this.f892c != null && this.f893d != null) {
                return new eh(this.f892c, this.f893d, this.f894e, super.m529a());
            }
            throw ds.m599a(this.f892c, "id", this.f893d, "received");
        }
    }

    static final class C0184b extends dn {
        public final /* synthetic */ int mo125a(Object obj) {
            eh ehVar = (eh) obj;
            return ((ehVar.f900h != null ? dn.f655i.mo128a(3, ehVar.f900h) : 0) + (dn.f655i.mo128a(2, ehVar.f899g) + dn.f662p.mo128a(1, ehVar.f898f))) + ehVar.m530a().mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            eh ehVar = (eh) obj;
            dn.f662p.mo129a(dpVar, 1, ehVar.f898f);
            dn.f655i.mo129a(dpVar, 2, ehVar.f899g);
            if (ehVar.f900h != null) {
                dn.f655i.mo129a(dpVar, 3, ehVar.f900h);
            }
            dpVar.m593a(ehVar.m530a());
        }

        C0184b() {
            super(dk.LENGTH_DELIMITED, eh.class);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            C0183a c0183a = new C0183a();
            long a = c0160do.m579a();
            while (true) {
                int b = c0160do.m581b();
                if (b != -1) {
                    switch (b) {
                        case 1:
                            c0183a.f892c = (String) dn.f662p.mo126a(c0160do);
                            break;
                        case 2:
                            c0183a.f893d = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        case 3:
                            c0183a.f894e = (Long) dn.f655i.mo126a(c0160do);
                            break;
                        default:
                            dk c = c0160do.m582c();
                            c0183a.m527a(b, c, c.m526a().mo126a(c0160do));
                            break;
                    }
                }
                c0160do.m580a(a);
                return c0183a.m752b();
            }
        }
    }

    public eh(String str, Long l) {
        this(str, l, null, hy.f1496b);
    }

    public eh(String str, Long l, Long l2, hy hyVar) {
        super(f895c, hyVar);
        this.f898f = str;
        this.f899g = l;
        this.f900h = l2;
    }

    public final C0183a m756b() {
        C0183a c0183a = new C0183a();
        c0183a.f892c = this.f898f;
        c0183a.f893d = this.f899g;
        c0183a.f894e = this.f900h;
        c0183a.m528a(m530a());
        return c0183a;
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof eh)) {
            return false;
        }
        eh ehVar = (eh) other;
        if (m530a().equals(ehVar.m530a()) && this.f898f.equals(ehVar.f898f) && this.f899g.equals(ehVar.f899g) && ds.m602a(this.f900h, ehVar.f900h)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f677b;
        if (i != 0) {
            return i;
        }
        i = (this.f900h != null ? this.f900h.hashCode() : 0) + (((((m530a().hashCode() * 37) + this.f898f.hashCode()) * 37) + this.f899g.hashCode()) * 37);
        this.f677b = i;
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(", id=").append(this.f898f);
        stringBuilder.append(", received=").append(this.f899g);
        if (this.f900h != null) {
            stringBuilder.append(", clicked=").append(this.f900h);
        }
        return stringBuilder.replace(0, 2, "Push{").append('}').toString();
    }
}
