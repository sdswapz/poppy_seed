package com.tapjoy.internal;

public interface fu extends fp {
    String mo240a();

    String mo241b();

    int mo242c();

    String mo243d();
}
