package com.tapjoy.internal;

import com.tapjoy.internal.cq.C0137a;
import java.util.HashMap;
import java.util.LinkedHashMap;

public final class cx {
    static final C0137a f615a = new C0137a("=");

    public static HashMap m468a() {
        return new HashMap();
    }

    public static LinkedHashMap m469b() {
        return new LinkedHashMap();
    }
}
