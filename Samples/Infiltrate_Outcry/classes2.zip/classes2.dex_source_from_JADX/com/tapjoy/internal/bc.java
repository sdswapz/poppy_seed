package com.tapjoy.internal;

import java.util.Queue;

public interface bc extends Queue {
    Object mo94a(int i);

    void mo95b(int i);
}
