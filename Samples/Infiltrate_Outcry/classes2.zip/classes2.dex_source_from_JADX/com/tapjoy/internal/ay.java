package com.tapjoy.internal;

import java.util.AbstractQueue;
import java.util.Iterator;

public abstract class ay extends AbstractQueue implements bc {

    class C01261 implements Iterator {
        final /* synthetic */ ay f527a;
        private int f528b = 0;

        C01261(ay ayVar) {
            this.f527a = ayVar;
        }

        public final boolean hasNext() {
            return this.f528b < this.f527a.size();
        }

        public final Object next() {
            ay ayVar = this.f527a;
            int i = this.f528b;
            this.f528b = i + 1;
            return ayVar.mo94a(i);
        }

        public final void remove() {
            if (this.f528b == 1) {
                this.f527a.mo95b(1);
                this.f528b = 0;
                return;
            }
            throw new UnsupportedOperationException("For the first element only");
        }
    }

    public Iterator iterator() {
        return new C01261(this);
    }
}
