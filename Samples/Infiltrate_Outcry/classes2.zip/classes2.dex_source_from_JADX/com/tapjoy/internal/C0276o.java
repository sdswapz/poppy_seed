package com.tapjoy.internal;

import android.content.SharedPreferences;

public abstract class C0276o {
    protected SharedPreferences f1536a;
    protected String f1537b;

    public C0276o(SharedPreferences sharedPreferences, String str) {
        this.f1536a = sharedPreferences;
        this.f1537b = str;
    }

    public final void m1319c() {
        this.f1536a.edit().remove(this.f1537b).commit();
    }
}
