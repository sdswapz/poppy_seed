package com.tapjoy.internal;

public final class aq {
    public static boolean m292a(CharSequence charSequence) {
        return charSequence == null || charSequence.length() == 0;
    }
}
