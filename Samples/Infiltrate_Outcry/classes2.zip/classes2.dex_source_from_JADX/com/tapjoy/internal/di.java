package com.tapjoy.internal;

public interface di {

    public enum C0147a {
        NEW,
        STARTING,
        RUNNING,
        STOPPING,
        TERMINATED,
        FAILED
    }

    dh mo120e();

    C0147a mo121f();
}
