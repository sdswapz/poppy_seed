package com.tapjoy.internal;

import android.graphics.Bitmap;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.internal.au.C0125a;
import com.tapjoy.internal.gx.C02532;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public final class hb {
    public static final bn f1343e = new C02591();
    private static final as f1344f;
    public URL f1345a;
    public Bitmap f1346b;
    public byte[] f1347c;
    public hi f1348d;

    static class C02591 implements bn {
        C02591() {
        }

        public final /* synthetic */ Object mo97a(bs bsVar) {
            return new hb(bsVar);
        }
    }

    static {
        as awVar = new aw();
        if (!(awVar instanceof ax)) {
            Object c0125a = new C0125a((av) awVar);
        }
        f1344f = awVar;
    }

    public hb(URL url) {
        this.f1345a = url;
    }

    public final boolean m1138a() {
        return (this.f1346b == null && this.f1347c == null) ? false : true;
    }

    public final void m1139b() {
        Closeable fileInputStream;
        Throwable th;
        boolean a = fd.m837b().m828a("mm_external_cache_enabled", true);
        boolean z = !a;
        if (z) {
            this.f1346b = (Bitmap) f1344f.mo91a(this.f1345a);
            if (this.f1346b != null) {
                return;
            }
        }
        if (a) {
            File a2 = gx.f1309a.m1124a(this.f1345a);
            if (a2 != null) {
                Closeable closeable = null;
                try {
                    fileInputStream = new FileInputStream(a2);
                    try {
                        m1137a(fileInputStream);
                        dc.m481a(fileInputStream);
                    } catch (IOException e) {
                        dc.m481a(fileInputStream);
                        if (this.f1346b != null) {
                        }
                        if (z) {
                            return;
                        }
                        return;
                    } catch (Throwable th2) {
                        Throwable th3 = th2;
                        closeable = fileInputStream;
                        th = th3;
                        dc.m481a(closeable);
                        throw th;
                    }
                } catch (IOException e2) {
                    fileInputStream = null;
                    dc.m481a(fileInputStream);
                    if (this.f1346b != null) {
                    }
                    if (z) {
                        return;
                    }
                    return;
                } catch (Throwable th4) {
                    th = th4;
                    dc.m481a(closeable);
                    throw th;
                }
                if (this.f1346b != null && this.f1347c == null) {
                    a2.delete();
                } else if (z && this.f1346b != null) {
                    f1344f.mo92a(this.f1345a, this.f1346b);
                    return;
                } else {
                    return;
                }
            }
        }
        URLConnection a3 = em.m772a(this.f1345a);
        long j = 0;
        String headerField = a3.getHeaderField("Cache-Control");
        if (!ct.m463c(headerField)) {
            String[] split = headerField.split(",");
            int length = split.length;
            int i = 0;
            while (i < length) {
                String trim = split[i].trim();
                if (trim.startsWith("max-age=")) {
                    try {
                        j = Long.parseLong(trim.substring(8));
                        break;
                    } catch (NumberFormatException e3) {
                    }
                } else {
                    i++;
                }
            }
        }
        fileInputStream = a3.getInputStream();
        InputStream a4 = m1137a(fileInputStream);
        dc.m481a(fileInputStream);
        gx gxVar = gx.f1309a;
        if (gx.m1119a(j) && a && !(this.f1346b == null && this.f1347c == null)) {
            gx gxVar2 = gx.f1309a;
            URL url = this.f1345a;
            if (gxVar2.f1310b != null) {
                gxVar2.f1313e.submit(new C02532(gxVar2, url, a4, j));
            }
        }
        if (z && this.f1346b != null) {
            f1344f.mo92a(this.f1345a, this.f1346b);
        }
    }

    private ByteArrayInputStream m1137a(InputStream inputStream) {
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        da.m478a(inputStream, byteArrayOutputStream);
        byteArrayOutputStream.close();
        byte[] toByteArray = byteArrayOutputStream.toByteArray();
        InputStream byteArrayInputStream = new ByteArrayInputStream(toByteArray);
        hj hjVar = new hj();
        hjVar.m1171a(toByteArray);
        hi a = hjVar.m1170a();
        if (a.f1411b == 0) {
            this.f1347c = toByteArray;
            this.f1348d = a;
        } else {
            C0283u c0283u = C0283u.f1543a;
            this.f1346b = C0283u.m1340a(byteArrayInputStream);
            byteArrayInputStream.reset();
        }
        return byteArrayInputStream;
    }

    hb(bs bsVar) {
        Object obj;
        if (bsVar.mo108k() == bx.STRING) {
            obj = 1;
        } else {
            obj = null;
        }
        if (obj != null) {
            this.f1345a = bsVar.m381e();
            return;
        }
        bsVar.mo105h();
        String l = bsVar.mo109l();
        while (bsVar.mo107j()) {
            if (String.URL.equals(l)) {
                this.f1345a = bsVar.m381e();
            } else {
                bsVar.mo116s();
            }
        }
        bsVar.mo106i();
    }
}
