package com.tapjoy.internal;

import java.util.Iterator;
import java.util.LinkedHashMap;

public final class aw extends av {
    private final LinkedHashMap f525a = new LinkedHashMap(0, 0.75f, true);
    private int f526b = 10;

    private void m304a() {
        int size = this.f525a.size() - this.f526b;
        if (size > 0) {
            Iterator it = this.f525a.entrySet().iterator();
            while (size > 0 && it.hasNext()) {
                size--;
                it.next();
                it.remove();
            }
        }
    }

    public final void mo92a(Object obj, Object obj2) {
        super.mo92a(obj, obj2);
        m304a();
    }

    protected final at mo93a(Object obj, boolean z) {
        ar arVar = (ar) this.f525a.get(obj);
        if (arVar != null || !z) {
            return arVar;
        }
        at arVar2 = new ar(obj);
        this.f525a.put(obj, arVar2);
        m304a();
        return arVar2;
    }
}
