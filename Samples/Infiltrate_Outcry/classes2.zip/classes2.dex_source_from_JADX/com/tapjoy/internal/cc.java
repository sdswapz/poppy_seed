package com.tapjoy.internal;

import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;

public final class cc extends ReferenceQueue {
    public final cb m437a() {
        return (cb) super.poll();
    }

    public final /* bridge */ /* synthetic */ Reference poll() {
        return (cb) super.poll();
    }
}
