package com.tapjoy.internal;

import com.tapjoy.TapjoyLog;
import com.tapjoy.internal.fj.C0215a;
import java.util.HashMap;
import java.util.Map;

public abstract class et {
    private static final String f987c = et.class.getSimpleName();
    public final Map f988a = new HashMap();
    public final Map f989b = new HashMap();

    protected et(String str, String str2, String str3) {
        this.f988a.put("placement", str);
        this.f988a.put("placement_type", str2);
        this.f988a.put("content_type", str3);
    }

    protected final C0215a m782a(String str, Map map, Map map2) {
        C0215a b = fj.m881e(str).m861a().m865a(this.f988a).m865a(map).m868b(map2);
        this.f989b.put(str, b);
        return b;
    }

    public final void m783a(String str, Object obj) {
        this.f988a.put(str, obj);
    }

    public final C0215a m781a() {
        return m782a("Content.rendered", null, null);
    }

    public final C0215a m784b() {
        return m785b("Content.rendered", null, null);
    }

    protected final C0215a m785b(String str, Map map, Map map2) {
        C0215a c0215a;
        if (aq.m292a(str)) {
            c0215a = null;
        } else {
            c0215a = (C0215a) this.f989b.remove(str);
        }
        if (c0215a == null) {
            TapjoyLog.m251e(f987c, "Error when calling endTrackingEvent -- " + str + " tracking has not been started.");
        } else {
            c0215a.m865a(this.f988a).m865a(map).m868b(map2).m866b().m869c();
        }
        return c0215a;
    }
}
