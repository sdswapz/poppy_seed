package com.tapjoy.internal;

public final class fy {
    public static String m920a(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        String trim = str.trim();
        return (trim == null || trim.length() == 0) ? null : trim;
    }

    public static String m922b(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        String trim = str.trim();
        if (trim.length() != 0) {
            return trim;
        }
        return null;
    }

    public static String m921a(String str, String str2, String str3) {
        if (str == null) {
            ga.m937a(str2, str3, "must not be null");
            return null;
        } else if (str.length() == 0) {
            ga.m937a(str2, str3, "must not be empty");
            return null;
        } else {
            String trim = str.trim();
            if (trim.length() != 0) {
                return trim;
            }
            ga.m937a(str2, str3, "must not be blank");
            return null;
        }
    }
}
