package com.tapjoy.internal;

public interface bi extends bj, bk {
}
