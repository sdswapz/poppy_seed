package com.tapjoy.internal;

import android.content.Context;
import com.tapjoy.TJPlacement;
import com.tapjoy.TJPlacementListener;
import com.tapjoy.TJPlacementManager;
import com.tapjoy.internal.ev.C0198a;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

public final class es extends fx implements Observer {
    private final Map f1008b = new HashMap();
    private final el f1009c = new el();
    private boolean f1010d;
    private final fc f1011e = new C01961(this);

    class C01961 extends fc {
        final /* synthetic */ es f1006a;

        C01961(es esVar) {
            this.f1006a = esVar;
        }

        protected final boolean mo182a() {
            return super.mo182a() && !go.m820c();
        }

        protected final /* bridge */ /* synthetic */ String mo181a(Object obj) {
            return "AppLaunch";
        }

        protected final /* synthetic */ TJPlacement mo180a(Context context, TJPlacementListener tJPlacementListener, Object obj) {
            return TJPlacementManager.createPlacement(context, "AppLaunch", true, tJPlacementListener);
        }
    }

    static {
        fx.f1007a = new es();
    }

    public static void m804a() {
    }

    private es() {
    }

    public final void update(Observable observable, Object data) {
        C0198a c0198a = ev.f1016d;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected final void mo183a(android.app.Activity r7) {
        /*
        r6 = this;
        r2 = 1;
        r1 = 0;
        if (r7 == 0) goto L_0x000e;
    L_0x0004:
        r3 = r7.getTaskId();
        r0 = -1;
        if (r3 != r0) goto L_0x0023;
    L_0x000b:
        r0 = r1;
    L_0x000c:
        if (r0 != 0) goto L_0x001a;
    L_0x000e:
        r0 = r6.f1010d;
        if (r0 != 0) goto L_0x0020;
    L_0x0012:
        r0 = r6.f1009c;
        r0 = r0.m769a();
        if (r0 == 0) goto L_0x0020;
    L_0x001a:
        r0 = r6.f1011e;
        r1 = 0;
        r0.m798c(r1);
    L_0x0020:
        r6.f1010d = r2;
        return;
    L_0x0023:
        r4 = r7.getIntent();
        if (r4 == 0) goto L_0x0046;
    L_0x0029:
        r0 = r4.getCategories();
        if (r0 == 0) goto L_0x0048;
    L_0x002f:
        r5 = "android.intent.category.LAUNCHER";
        r0 = r0.contains(r5);
        if (r0 == 0) goto L_0x0048;
    L_0x0037:
        r0 = "android.intent.action.MAIN";
        r5 = r4.getAction();
        r0 = r0.equals(r5);
        if (r0 == 0) goto L_0x0048;
    L_0x0043:
        r0 = r2;
    L_0x0044:
        if (r0 != 0) goto L_0x004a;
    L_0x0046:
        r0 = r1;
        goto L_0x000c;
    L_0x0048:
        r0 = r1;
        goto L_0x0044;
    L_0x004a:
        r0 = r4.getComponent();
        if (r0 != 0) goto L_0x0052;
    L_0x0050:
        r0 = r1;
        goto L_0x000c;
    L_0x0052:
        r0 = r0.getClassName();
        r4 = r6.f1008b;
        r5 = java.lang.Integer.valueOf(r3);
        r0 = r4.put(r0, r5);
        r0 = (java.lang.Integer) r0;
        if (r0 == 0) goto L_0x006c;
    L_0x0064:
        r0 = r0.intValue();
        if (r0 != r3) goto L_0x006c;
    L_0x006a:
        r0 = r1;
        goto L_0x000c;
    L_0x006c:
        r0 = r2;
        goto L_0x000c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tapjoy.internal.es.a(android.app.Activity):void");
    }
}
