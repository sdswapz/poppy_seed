package com.tapjoy.internal;

enum bv {
    EMPTY_ARRAY,
    NONEMPTY_ARRAY,
    EMPTY_OBJECT,
    DANGLING_NAME,
    NONEMPTY_OBJECT,
    EMPTY_DOCUMENT,
    NONEMPTY_DOCUMENT,
    CLOSED
}
