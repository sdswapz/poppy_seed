package com.tapjoy.internal;

import java.io.Closeable;
import java.io.Flushable;
import java.util.LinkedList;

public final class az extends ay implements bc, Closeable, Flushable {
    private final bc f529a;
    private final LinkedList f530b = new LinkedList();
    private final LinkedList f531c = new LinkedList();
    private int f532d;
    private boolean f533e;

    public static az m309a(bc bcVar) {
        return new az(bcVar);
    }

    private az(bc bcVar) {
        this.f529a = bcVar;
        this.f532d = bcVar.size();
        this.f533e = this.f532d == 0;
    }

    protected final void finalize() {
        close();
        super.finalize();
    }

    public final void close() {
        try {
            flush();
        } finally {
            if (this.f529a instanceof Closeable) {
                ((Closeable) this.f529a).close();
            }
        }
    }

    public final void flush() {
        if (!this.f531c.isEmpty()) {
            this.f529a.addAll(this.f531c);
            if (this.f533e) {
                this.f530b.addAll(this.f531c);
            }
            this.f531c.clear();
        }
    }

    public final int size() {
        return this.f532d;
    }

    public final boolean offer(Object e) {
        this.f531c.add(e);
        this.f532d++;
        return true;
    }

    public final Object poll() {
        if (this.f532d <= 0) {
            return null;
        }
        Object remove;
        if (!this.f530b.isEmpty()) {
            remove = this.f530b.remove();
            this.f529a.mo95b(1);
        } else if (this.f533e) {
            remove = this.f531c.remove();
        } else {
            remove = this.f529a.remove();
            if (this.f532d == this.f531c.size() + 1) {
                this.f533e = true;
            }
        }
        this.f532d--;
        return remove;
    }

    public final Object peek() {
        if (this.f532d <= 0) {
            return null;
        }
        if (!this.f530b.isEmpty()) {
            return this.f530b.element();
        }
        if (this.f533e) {
            return this.f531c.element();
        }
        Object peek = this.f529a.peek();
        this.f530b.add(peek);
        if (this.f532d != this.f530b.size() + this.f531c.size()) {
            return peek;
        }
        this.f533e = true;
        return peek;
    }

    public final Object mo94a(int i) {
        if (i < 0 || i >= this.f532d) {
            throw new IndexOutOfBoundsException();
        }
        int size = this.f530b.size();
        if (i < size) {
            return this.f530b.get(i);
        }
        if (this.f533e) {
            return this.f531c.get(i - size);
        }
        if (i >= this.f529a.size()) {
            return this.f531c.get(i - this.f529a.size());
        }
        int i2 = size;
        Object obj = null;
        int i3 = i2;
        while (i3 <= i) {
            Object a = this.f529a.mo94a(i3);
            this.f530b.add(a);
            i3++;
            obj = a;
        }
        if ((i + 1) + this.f531c.size() != this.f532d) {
            return obj;
        }
        this.f533e = true;
        return obj;
    }

    public final void mo95b(int i) {
        if (i <= 0 || i > this.f532d) {
            throw new IndexOutOfBoundsException();
        }
        if (i <= this.f530b.size()) {
            bb.m315a(this.f530b, i);
            this.f529a.mo95b(i);
        } else {
            this.f530b.clear();
            int size = (this.f531c.size() + i) - this.f532d;
            if (size < 0) {
                this.f529a.mo95b(i);
            } else {
                this.f529a.clear();
                this.f533e = true;
                if (size > 0) {
                    bb.m315a(this.f531c, size);
                }
            }
        }
        this.f532d -= i;
    }
}
