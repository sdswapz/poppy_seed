package com.tapjoy.internal;

public interface bf {
    boolean mo201a(Runnable runnable);
}
