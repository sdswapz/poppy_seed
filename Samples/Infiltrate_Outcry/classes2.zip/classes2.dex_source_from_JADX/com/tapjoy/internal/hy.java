package com.tapjoy.internal;

import java.io.Serializable;
import java.util.Arrays;

public class hy implements Serializable, Comparable {
    static final char[] f1495a = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
    public static final hy f1496b = new hy((byte[]) new byte[0].clone());
    final byte[] f1497c;
    transient int f1498d;
    transient String f1499e;

    public /* synthetic */ int compareTo(Object obj) {
        hy hyVar = (hy) obj;
        int c = mo277c();
        int c2 = hyVar.mo277c();
        int min = Math.min(c, c2);
        int i = 0;
        while (i < min) {
            int a = mo271a(i) & 255;
            int a2 = hyVar.mo271a(i) & 255;
            if (a == a2) {
                i++;
            } else if (a < a2) {
                return -1;
            } else {
                return 1;
            }
        }
        if (c == c2) {
            return 0;
        }
        return c >= c2 ? 1 : -1;
    }

    public hy(byte[] bArr) {
        this.f1497c = bArr;
    }

    public String mo273a() {
        String str = this.f1499e;
        if (str != null) {
            return str;
        }
        str = new String(this.f1497c, ii.f1528a);
        this.f1499e = str;
        return str;
    }

    public String mo276b() {
        int i = 0;
        char[] cArr = new char[(this.f1497c.length * 2)];
        byte[] bArr = this.f1497c;
        int length = bArr.length;
        int i2 = 0;
        while (i < length) {
            byte b = bArr[i];
            int i3 = i2 + 1;
            cArr[i2] = f1495a[(b >> 4) & 15];
            i2 = i3 + 1;
            cArr[i3] = f1495a[b & 15];
            i++;
        }
        return new String(cArr);
    }

    public hy mo272a(int i, int i2) {
        if (i < 0) {
            throw new IllegalArgumentException("beginIndex < 0");
        } else if (i2 > this.f1497c.length) {
            throw new IllegalArgumentException("endIndex > length(" + this.f1497c.length + ")");
        } else {
            int i3 = i2 - i;
            if (i3 < 0) {
                throw new IllegalArgumentException("endIndex < beginIndex");
            } else if (i == 0 && i2 == this.f1497c.length) {
                return this;
            } else {
                Object obj = new byte[i3];
                System.arraycopy(this.f1497c, i, obj, 0, i3);
                this(obj);
                return this;
            }
        }
    }

    public byte mo271a(int i) {
        return this.f1497c[i];
    }

    public int mo277c() {
        return this.f1497c.length;
    }

    public byte[] mo278d() {
        return (byte[]) this.f1497c.clone();
    }

    void mo274a(hv hvVar) {
        hvVar.m1227a(this.f1497c, 0, this.f1497c.length);
    }

    public boolean mo275a(int i, byte[] bArr, int i2, int i3) {
        return i >= 0 && i <= this.f1497c.length - i3 && i2 >= 0 && i2 <= bArr.length - i3 && ii.m1307a(this.f1497c, i, bArr, i2, i3);
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        return (o instanceof hy) && ((hy) o).mo277c() == this.f1497c.length && ((hy) o).mo275a(0, this.f1497c, 0, this.f1497c.length);
    }

    public int hashCode() {
        int i = this.f1498d;
        if (i != 0) {
            return i;
        }
        i = Arrays.hashCode(this.f1497c);
        this.f1498d = i;
        return i;
    }

    public String toString() {
        if (this.f1497c.length == 0) {
            return "[size=0]";
        }
        String a = mo273a();
        int length = a.length();
        int i = 0;
        int i2 = 0;
        while (i2 < length) {
            if (i != 64) {
                int codePointAt = a.codePointAt(i2);
                if ((Character.isISOControl(codePointAt) && codePointAt != 10 && codePointAt != 13) || codePointAt == 65533) {
                    i2 = -1;
                    break;
                }
                i++;
                i2 += Character.charCount(codePointAt);
            } else {
                break;
            }
        }
        i2 = a.length();
        if (i2 != -1) {
            String replace = a.substring(0, i2).replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
            return i2 < a.length() ? "[size=" + this.f1497c.length + " text=" + replace + "…]" : "[text=" + replace + "]";
        } else if (this.f1497c.length <= 64) {
            return "[hex=" + mo276b() + "]";
        } else {
            return "[size=" + this.f1497c.length + " hex=" + mo272a(0, 64).mo276b() + "…]";
        }
    }
}
