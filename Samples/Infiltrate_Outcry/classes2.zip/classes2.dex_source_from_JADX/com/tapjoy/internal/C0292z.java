package com.tapjoy.internal;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class C0292z {
    private static final ThreadLocal f1560a = new C02901();
    private static final ThreadLocal f1561b = new C02912();

    static class C02901 extends ThreadLocal {
        C02901() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ssZ");
        }
    }

    static class C02912 extends ThreadLocal {
        C02912() {
        }

        protected final /* synthetic */ Object initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");
        }
    }

    public static String m1354a(Date date) {
        return ((DateFormat) f1560a.get()).format(date);
    }
}
