package com.tapjoy.internal;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class fl extends fk {
    private final ThreadPoolExecutor f1094b = new ThreadPoolExecutor(0, 1, 1, TimeUnit.SECONDS, new LinkedBlockingQueue());

    class C0216a implements Runnable {
        final /* synthetic */ fl f1088a;
        private int f1089b;
        private long f1090c;
        private String f1091d;
        private String f1092e;
        private Map f1093f;

        C0216a(fl flVar, int i, long j, String str, String str2, Map map) {
            this.f1088a = flVar;
            this.f1089b = i;
            this.f1090c = j;
            this.f1091d = str;
            this.f1092e = str2;
            this.f1093f = map;
        }

        public final void run() {
            try {
                switch (this.f1089b) {
                    case 1:
                        super.mo198a(this.f1090c);
                        return;
                    case 2:
                        super.mo197a();
                        return;
                    case 3:
                        super.mo199a(this.f1090c, this.f1091d, this.f1092e, this.f1093f);
                        return;
                    default:
                        return;
                }
            } catch (Throwable th) {
                super.mo197a();
            }
            super.mo197a();
        }
    }

    public fl(File file, gc gcVar) {
        super(file, gcVar);
    }

    protected final void finalize() {
        try {
            this.f1094b.shutdown();
            this.f1094b.awaitTermination(1, TimeUnit.SECONDS);
        } finally {
            super.finalize();
        }
    }

    protected final void mo198a(long j) {
        try {
            this.f1094b.execute(new C0216a(this, 1, j, null, null, null));
        } catch (Throwable th) {
        }
    }

    protected final void mo197a() {
        try {
            this.f1094b.execute(new C0216a(this, 2, 0, null, null, null));
        } catch (Throwable th) {
        }
    }

    protected final void mo199a(long j, String str, String str2, Map map) {
        try {
            this.f1094b.execute(new C0216a(this, 3, j, str, str2, map != null ? new HashMap(map) : null));
        } catch (Throwable th) {
        }
    }
}
