package com.tapjoy.internal;

public interface ck {
    void mo208a(cf cfVar);

    void mo209a(cf cfVar, Object obj);
}
