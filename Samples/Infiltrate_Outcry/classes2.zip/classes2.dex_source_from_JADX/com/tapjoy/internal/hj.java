package com.tapjoy.internal;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public final class hj {
    private final byte[] f1423a = new byte[256];
    private ByteBuffer f1424b;
    private hi f1425c;
    private int f1426d = 0;

    public final hj m1171a(byte[] bArr) {
        if (bArr != null) {
            ByteBuffer wrap = ByteBuffer.wrap(bArr);
            this.f1424b = null;
            Arrays.fill(this.f1423a, (byte) 0);
            this.f1425c = new hi();
            this.f1426d = 0;
            this.f1424b = wrap.asReadOnlyBuffer();
            this.f1424b.position(0);
            this.f1424b.order(ByteOrder.LITTLE_ENDIAN);
        } else {
            this.f1424b = null;
            this.f1425c.f1411b = 2;
        }
        return this;
    }

    public final hi m1170a() {
        if (this.f1424b == null) {
            throw new IllegalStateException("You must call setData() before parseHeader()");
        } else if (m1169h()) {
            return this.f1425c;
        } else {
            m1165d();
            if (!m1169h()) {
                m1163b();
                if (this.f1425c.f1412c < 0) {
                    this.f1425c.f1411b = 1;
                }
            }
            return this.f1425c;
        }
    }

    private void m1163b() {
        int i = 0;
        while (i == 0 && !m1169h() && this.f1425c.f1412c <= Integer.MAX_VALUE) {
            int g;
            switch (m1168g()) {
                case 33:
                    switch (m1168g()) {
                        case 1:
                            m1166e();
                            break;
                        case 249:
                            boolean z;
                            this.f1425c.f1413d = new hh();
                            m1168g();
                            g = m1168g();
                            this.f1425c.f1413d.f1405g = (g & 28) >> 2;
                            if (this.f1425c.f1413d.f1405g == 0) {
                                this.f1425c.f1413d.f1405g = 1;
                            }
                            hh hhVar = this.f1425c.f1413d;
                            if ((g & 1) != 0) {
                                z = true;
                            } else {
                                z = false;
                            }
                            hhVar.f1404f = z;
                            g = this.f1424b.getShort();
                            if (g < 2) {
                                g = 10;
                            }
                            this.f1425c.f1413d.f1407i = g * 10;
                            this.f1425c.f1413d.f1406h = m1168g();
                            m1168g();
                            break;
                        case 254:
                            m1166e();
                            break;
                        case 255:
                            m1167f();
                            String str = "";
                            for (g = 0; g < 11; g++) {
                                str = str + ((char) this.f1423a[g]);
                            }
                            if (!str.equals("NETSCAPE2.0")) {
                                m1166e();
                                break;
                            } else {
                                m1164c();
                                break;
                            }
                        default:
                            m1166e();
                            break;
                    }
                case 44:
                    boolean z2;
                    if (this.f1425c.f1413d == null) {
                        this.f1425c.f1413d = new hh();
                    }
                    this.f1425c.f1413d.f1399a = this.f1424b.getShort();
                    this.f1425c.f1413d.f1400b = this.f1424b.getShort();
                    this.f1425c.f1413d.f1401c = this.f1424b.getShort();
                    this.f1425c.f1413d.f1402d = this.f1424b.getShort();
                    int g2 = m1168g();
                    g = (g2 & 128) != 0 ? 1 : 0;
                    int pow = (int) Math.pow(2.0d, (double) ((g2 & 7) + 1));
                    hh hhVar2 = this.f1425c.f1413d;
                    if ((g2 & 64) != 0) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    hhVar2.f1403e = z2;
                    if (g != 0) {
                        this.f1425c.f1413d.f1409k = m1162a(pow);
                    } else {
                        this.f1425c.f1413d.f1409k = null;
                    }
                    this.f1425c.f1413d.f1408j = this.f1424b.position();
                    m1168g();
                    m1166e();
                    if (!m1169h()) {
                        hi hiVar = this.f1425c;
                        hiVar.f1412c++;
                        this.f1425c.f1414e.add(this.f1425c.f1413d);
                        break;
                    }
                    break;
                case 59:
                    i = 1;
                    break;
                default:
                    this.f1425c.f1411b = 1;
                    break;
            }
        }
    }

    private void m1164c() {
        do {
            m1167f();
            if (this.f1423a[0] == (byte) 1) {
                this.f1425c.f1422m = (this.f1423a[1] & 255) | ((this.f1423a[2] & 255) << 8);
                if (this.f1425c.f1422m == 0) {
                    this.f1425c.f1422m = -1;
                }
            }
            if (this.f1426d <= 0) {
                return;
            }
        } while (!m1169h());
    }

    private void m1165d() {
        int i;
        boolean z = true;
        String str = "";
        for (i = 0; i < 6; i++) {
            str = str + ((char) m1168g());
        }
        if (str.startsWith("GIF")) {
            this.f1425c.f1415f = this.f1424b.getShort();
            this.f1425c.f1416g = this.f1424b.getShort();
            i = m1168g();
            hi hiVar = this.f1425c;
            if ((i & 128) == 0) {
                z = false;
            }
            hiVar.f1417h = z;
            this.f1425c.f1418i = 2 << (i & 7);
            this.f1425c.f1419j = m1168g();
            this.f1425c.f1420k = m1168g();
            if (this.f1425c.f1417h && !m1169h()) {
                this.f1425c.f1410a = m1162a(this.f1425c.f1418i);
                this.f1425c.f1421l = this.f1425c.f1410a[this.f1425c.f1419j];
                return;
            }
            return;
        }
        this.f1425c.f1411b = 1;
    }

    private int[] m1162a(int i) {
        int[] iArr;
        BufferUnderflowException e;
        byte[] bArr = new byte[(i * 3)];
        try {
            this.f1424b.get(bArr);
            iArr = new int[256];
            int i2 = 0;
            int i3 = 0;
            while (i3 < i) {
                int i4 = i2 + 1;
                try {
                    int i5 = bArr[i2] & 255;
                    int i6 = i4 + 1;
                    int i7 = bArr[i4] & 255;
                    i2 = i6 + 1;
                    i4 = i3 + 1;
                    iArr[i3] = (((i5 << 16) | -16777216) | (i7 << 8)) | (bArr[i6] & 255);
                    i3 = i4;
                } catch (BufferUnderflowException e2) {
                    e = e2;
                }
            }
        } catch (BufferUnderflowException e3) {
            BufferUnderflowException bufferUnderflowException = e3;
            iArr = null;
            e = bufferUnderflowException;
            new Object[1][0] = e;
            this.f1425c.f1411b = 1;
            return iArr;
        }
        return iArr;
    }

    private void m1166e() {
        int g;
        do {
            try {
                g = m1168g();
                this.f1424b.position(this.f1424b.position() + g);
            } catch (IllegalArgumentException e) {
                return;
            }
        } while (g > 0);
    }

    private int m1167f() {
        this.f1426d = m1168g();
        if (this.f1426d <= 0) {
            return 0;
        }
        int i = 0;
        int i2 = 0;
        while (i2 < this.f1426d) {
            try {
                i = this.f1426d - i2;
                this.f1424b.get(this.f1423a, i2, i);
                i2 += i;
            } catch (Exception e) {
                Object[] objArr = new Object[]{Integer.valueOf(i2), Integer.valueOf(i), Integer.valueOf(this.f1426d), e};
                this.f1425c.f1411b = 1;
                return i2;
            }
        }
        return i2;
    }

    private int m1168g() {
        int i = 0;
        try {
            return this.f1424b.get() & 255;
        } catch (Exception e) {
            this.f1425c.f1411b = 1;
            return i;
        }
    }

    private boolean m1169h() {
        return this.f1425c.f1411b != 0;
    }
}
