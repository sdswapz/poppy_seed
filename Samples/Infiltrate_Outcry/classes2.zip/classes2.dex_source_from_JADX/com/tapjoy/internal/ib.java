package com.tapjoy.internal;

import java.io.EOFException;

final class ib implements hx {
    public final hv f1511a = new hv();
    public final ig f1512b;
    boolean f1513c;

    ib(ig igVar) {
        if (igVar == null) {
            throw new IllegalArgumentException("source == null");
        }
        this.f1512b = igVar;
    }

    public final long mo256b(hv hvVar, long j) {
        if (hvVar == null) {
            throw new IllegalArgumentException("sink == null");
        } else if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j);
        } else if (this.f1513c) {
            throw new IllegalStateException("closed");
        } else if (this.f1511a.f1494b == 0 && this.f1512b.mo256b(this.f1511a, 8192) == -1) {
            return -1;
        } else {
            return this.f1511a.mo256b(hvVar, Math.min(j, this.f1511a.f1494b));
        }
    }

    public final boolean mo260b() {
        if (!this.f1513c) {
            return this.f1511a.mo260b() && this.f1512b.mo256b(this.f1511a, 8192) == -1;
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public final byte mo261c() {
        mo254a(1);
        return this.f1511a.mo261c();
    }

    public final hy mo259b(long j) {
        mo254a(j);
        return this.f1511a.mo259b(j);
    }

    public final String mo262c(long j) {
        mo254a(j);
        return this.f1511a.mo262c(j);
    }

    public final int mo266e() {
        mo254a(4);
        return ii.m1303a(this.f1511a.m1240d());
    }

    public final long mo268f() {
        mo254a(8);
        return this.f1511a.mo268f();
    }

    public final void mo265d(long j) {
        if (this.f1513c) {
            throw new IllegalStateException("closed");
        }
        while (j > 0) {
            if (this.f1511a.f1494b == 0 && this.f1512b.mo256b(this.f1511a, 8192) == -1) {
                throw new EOFException();
            }
            long min = Math.min(j, this.f1511a.f1494b);
            this.f1511a.mo265d(min);
            j -= min;
        }
    }

    public final void close() {
        if (!this.f1513c) {
            this.f1513c = true;
            this.f1512b.close();
            hv hvVar = this.f1511a;
            try {
                hvVar.mo265d(hvVar.f1494b);
            } catch (EOFException e) {
                throw new AssertionError(e);
            }
        }
    }

    public final String toString() {
        return "buffer(" + this.f1512b + ")";
    }

    public final void mo254a(long j) {
        if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j);
        } else if (this.f1513c) {
            throw new IllegalStateException("closed");
        } else {
            Object obj;
            while (this.f1511a.f1494b < j) {
                if (this.f1512b.mo256b(this.f1511a, 8192) == -1) {
                    obj = null;
                    break;
                }
            }
            obj = 1;
            if (obj == null) {
                throw new EOFException();
            }
        }
    }
}
