package com.tapjoy.internal;

import android.app.Activity;

public abstract class fx {
    protected static fx f1007a;

    public abstract void mo183a(Activity activity);

    public static void m802b(Activity activity) {
        if (f1007a != null) {
            f1007a.mo183a(activity);
        }
    }
}
