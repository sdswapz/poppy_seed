package com.tapjoy.internal;

public interface ci {
    Object mo119a(cf cfVar);
}
