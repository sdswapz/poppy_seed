package com.tapjoy.internal;

import android.content.SharedPreferences.Editor;
import android.os.SystemClock;
import com.tapjoy.internal.dy.C0165a;
import com.tapjoy.internal.gb.C02251;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class gq {
    final gc f1278a;
    final AtomicBoolean f1279b = new AtomicBoolean();
    ScheduledFuture f1280c;
    private final Runnable f1281d = new C02461(this);
    private final Runnable f1282e = new C02472(this);

    class C02461 implements Runnable {
        final /* synthetic */ gq f1276a;

        C02461(gq gqVar) {
            this.f1276a = gqVar;
        }

        public final void run() {
            if (this.f1276a.f1279b.compareAndSet(true, false)) {
                ga.m936a("The session ended");
                gc gcVar = this.f1276a.f1278a;
                long elapsedRealtime = SystemClock.elapsedRealtime() - gcVar.f1151c;
                gg ggVar = gcVar.f1149a;
                synchronized (ggVar) {
                    long a = ggVar.f1206c.f1250i.m1330a() + elapsedRealtime;
                    ggVar.f1206c.f1250i.m1333a(a);
                    ggVar.f1205b.f915i = Long.valueOf(a);
                }
                C0165a a2 = gcVar.m948a(eb.APP, "session");
                a2.f733i = Long.valueOf(elapsedRealtime);
                gcVar.m949a(a2);
                gcVar.f1151c = 0;
                gg ggVar2 = gcVar.f1149a;
                long longValue = a2.f729e.longValue();
                synchronized (ggVar2) {
                    Editor a3 = ggVar2.f1206c.m1091a();
                    ggVar2.f1206c.f1251j.m1332a(a3, longValue);
                    ggVar2.f1206c.f1252k.m1332a(a3, elapsedRealtime);
                    a3.commit();
                    ggVar2.f1205b.f916j = Long.valueOf(longValue);
                    ggVar2.f1205b.f917k = Long.valueOf(elapsedRealtime);
                }
                gb gbVar = gcVar.f1150b;
                if (gbVar.f1145b != null) {
                    gbVar.m946a();
                    new C02251(gbVar).run();
                }
                gbVar.f1144a.flush();
                ev.f1016d.notifyObservers();
            }
        }
    }

    class C02472 implements Runnable {
        final /* synthetic */ gq f1277a;

        C02472(gq gqVar) {
            this.f1277a = gqVar;
        }

        public final void run() {
        }
    }

    gq(gc gcVar) {
        this.f1278a = gcVar;
    }

    public final void m1101a() {
        if (!this.f1279b.get()) {
            return;
        }
        if (!Boolean.FALSE.booleanValue()) {
            this.f1281d.run();
        } else if (this.f1280c == null || this.f1280c.cancel(false)) {
            this.f1280c = gr.f1283a.schedule(this.f1281d, 3000, TimeUnit.MILLISECONDS);
        }
    }
}
