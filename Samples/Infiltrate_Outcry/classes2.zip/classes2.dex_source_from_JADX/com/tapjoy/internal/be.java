package com.tapjoy.internal;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public final class be extends AbstractMap {
    private final HashMap f537a = new HashMap();
    private final cc f538b = new cc();

    public final int size() {
        m318b();
        return this.f537a.size();
    }

    public final void clear() {
        this.f537a.clear();
        do {
        } while (this.f538b.m437a() != null);
    }

    public final boolean containsKey(Object key) {
        m318b();
        return this.f537a.containsKey(key);
    }

    public final boolean containsValue(Object value) {
        m318b();
        for (cb cbVar : this.f537a.values()) {
            if (value.equals(cbVar.get())) {
                return true;
            }
        }
        return false;
    }

    public final Object get(Object key) {
        m318b();
        return m317a((cb) this.f537a.get(key));
    }

    public final Object put(Object key, Object value) {
        m318b();
        return m317a((cb) this.f537a.put(key, new cb(key, value, this.f538b)));
    }

    public final Object remove(Object key) {
        m318b();
        return m317a((cb) this.f537a.remove(key));
    }

    private static Object m317a(cb cbVar) {
        return cbVar != null ? cbVar.get() : null;
    }

    public final Set entrySet() {
        m318b();
        throw new UnsupportedOperationException();
    }

    public final Set keySet() {
        m318b();
        return this.f537a.keySet();
    }

    public final Collection values() {
        m318b();
        throw new UnsupportedOperationException();
    }

    public final boolean equals(Object object) {
        m318b();
        throw new UnsupportedOperationException();
    }

    public final int hashCode() {
        m318b();
        throw new UnsupportedOperationException();
    }

    public final String toString() {
        m318b();
        throw new UnsupportedOperationException();
    }

    private void m318b() {
        while (true) {
            cb a = this.f538b.m437a();
            if (a != null) {
                this.f537a.remove(a.f591a);
            } else {
                return;
            }
        }
    }

    public static be m316a() {
        return new be();
    }
}
