package com.tapjoy.internal;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;

public abstract class dn {
    public static final dn f649c = new dn(dk.VARINT, Boolean.class) {
        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            int d = c0160do.m583d();
            if (d == 0) {
                return Boolean.FALSE;
            }
            if (d == 1) {
                return Boolean.TRUE;
            }
            throw new IOException(String.format("Invalid boolean value 0x%02x", new Object[]{Integer.valueOf(d)}));
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            int i;
            if (((Boolean) obj).booleanValue()) {
                i = 1;
            } else {
                i = 0;
            }
            dpVar.m594c(i);
        }
    };
    public static final dn f650d = new dn(dk.VARINT, Integer.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            int intValue = ((Integer) obj).intValue();
            if (intValue >= 0) {
                return dp.m588a(intValue);
            }
            return 10;
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            int intValue = ((Integer) obj).intValue();
            if (intValue >= 0) {
                dpVar.m594c(intValue);
            } else {
                dpVar.m595c((long) intValue);
            }
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Integer.valueOf(c0160do.m583d());
        }
    };
    public static final dn f651e = new dn(dk.VARINT, Integer.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return dp.m588a(((Integer) obj).intValue());
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m594c(((Integer) obj).intValue());
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Integer.valueOf(c0160do.m583d());
        }
    };
    public static final dn f652f = new dn(dk.VARINT, Integer.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return dp.m588a(dp.m591b(((Integer) obj).intValue()));
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m594c(dp.m591b(((Integer) obj).intValue()));
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            int d = c0160do.m583d();
            return Integer.valueOf((-(d & 1)) ^ (d >>> 1));
        }
    };
    public static final dn f653g;
    public static final dn f654h;
    public static final dn f655i = new dn(dk.VARINT, Long.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return dp.m590a(((Long) obj).longValue());
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m595c(((Long) obj).longValue());
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Long.valueOf(c0160do.m584e());
        }
    };
    public static final dn f656j = new dn(dk.VARINT, Long.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return dp.m590a(((Long) obj).longValue());
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m595c(((Long) obj).longValue());
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Long.valueOf(c0160do.m584e());
        }
    };
    public static final dn f657k = new dn(dk.VARINT, Long.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return dp.m590a(dp.m592b(((Long) obj).longValue()));
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m595c(dp.m592b(((Long) obj).longValue()));
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            long e = c0160do.m584e();
            return Long.valueOf((-(e & 1)) ^ (e >>> 1));
        }
    };
    public static final dn f658l;
    public static final dn f659m;
    public static final dn f660n = new dn(dk.FIXED32, Float.class) {
        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m596d(Float.floatToIntBits(((Float) obj).floatValue()));
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Float.valueOf(Float.intBitsToFloat(c0160do.m585f()));
        }
    };
    public static final dn f661o = new dn(dk.FIXED64, Double.class) {
        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m597d(Double.doubleToLongBits(((Double) obj).doubleValue()));
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return Double.valueOf(Double.longBitsToDouble(c0160do.m586g()));
        }
    };
    public static final dn f662p = new dn(dk.LENGTH_DELIMITED, String.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            int i = 0;
            String str = (String) obj;
            int length = str.length();
            int i2 = 0;
            while (i < length) {
                char charAt = str.charAt(i);
                if (charAt >= '') {
                    if (charAt < 'ࠀ') {
                        i2 += 2;
                    } else if (charAt < '?' || charAt > '?') {
                        i2 += 3;
                    } else if (charAt <= '?' && i + 1 < length && str.charAt(i + 1) >= '?' && str.charAt(i + 1) <= '?') {
                        i2 += 4;
                        i++;
                    }
                    i++;
                }
                i2++;
                i++;
            }
            return i2;
        }

        public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.f690a.mo258b((String) obj);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return c0160do.f682a.mo262c(c0160do.m587h());
        }
    };
    public static final dn f663q = new dn(dk.LENGTH_DELIMITED, hy.class) {
        public final /* synthetic */ int mo125a(Object obj) {
            return ((hy) obj).mo277c();
        }

        public final /* bridge */ /* synthetic */ void mo127a(dp dpVar, Object obj) {
            dpVar.m593a((hy) obj);
        }

        public final /* synthetic */ Object mo126a(C0160do c0160do) {
            return c0160do.f682a.mo259b(c0160do.m587h());
        }
    };
    final Class f664a;
    dn f665b;
    private final dk f666r;

    public static final class C0159a extends IllegalArgumentException {
        public final int f681a;

        C0159a(int i, Class cls) {
            super("Unknown enum tag " + i + " for " + cls.getCanonicalName());
            this.f681a = i;
        }
    }

    public abstract int mo125a(Object obj);

    public abstract Object mo126a(C0160do c0160do);

    public abstract void mo127a(dp dpVar, Object obj);

    public dn(dk dkVar, Class cls) {
        this.f666r = dkVar;
        this.f664a = cls;
    }

    public int mo128a(int i, Object obj) {
        int a = mo125a(obj);
        if (this.f666r == dk.LENGTH_DELIMITED) {
            a += dp.m588a(a);
        }
        return a + dp.m588a(dp.m589a(i, dk.VARINT));
    }

    public void mo129a(dp dpVar, int i, Object obj) {
        dpVar.m594c(dp.m589a(i, this.f666r));
        if (this.f666r == dk.LENGTH_DELIMITED) {
            dpVar.m594c(mo125a(obj));
        }
        mo127a(dpVar, obj);
    }

    private void m510a(hw hwVar, Object obj) {
        dm.m531a(obj, "value == null");
        dm.m531a(hwVar, "sink == null");
        mo127a(new dp(hwVar), obj);
    }

    public final byte[] m521b(Object obj) {
        dm.m531a(obj, "value == null");
        hw hvVar = new hv();
        try {
            m510a(hvVar, obj);
            return hvVar.m1248g();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }

    public final void m520a(OutputStream outputStream, Object obj) {
        dm.m531a(obj, "value == null");
        dm.m531a(outputStream, "stream == null");
        hw a = hz.m1260a(hz.m1262a(outputStream));
        m510a(a, obj);
        a.mo253a();
    }

    public final Object m517a(byte[] bArr) {
        dm.m531a(bArr, "bytes == null");
        hv hvVar = new hv();
        if (bArr != null) {
            return m509a(hvVar.m1227a(bArr, 0, bArr.length));
        }
        throw new IllegalArgumentException("source == null");
    }

    public final Object m516a(InputStream inputStream) {
        dm.m531a(inputStream, "stream == null");
        return m509a(hz.m1261a(hz.m1263a(inputStream)));
    }

    private Object m509a(hx hxVar) {
        dm.m531a(hxVar, "source == null");
        return mo126a(new C0160do(hxVar));
    }

    public static String m511c(Object obj) {
        return obj.toString();
    }

    static {
        dn anonymousClass10 = new dn(dk.FIXED32, Integer.class) {
            public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
                dpVar.m596d(((Integer) obj).intValue());
            }

            public final /* synthetic */ Object mo126a(C0160do c0160do) {
                return Integer.valueOf(c0160do.m585f());
            }
        };
        f653g = anonymousClass10;
        f654h = anonymousClass10;
        anonymousClass10 = new dn(dk.FIXED64, Long.class) {
            public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
                dpVar.m597d(((Long) obj).longValue());
            }

            public final /* synthetic */ Object mo126a(C0160do c0160do) {
                return Long.valueOf(c0160do.m586g());
            }
        };
        f658l = anonymousClass10;
        f659m = anonymousClass10;
    }

    public final dn m514a() {
        dn dnVar = this.f665b;
        if (dnVar != null) {
            return dnVar;
        }
        dnVar = new dn(this, this.f666r, List.class) {
            final /* synthetic */ dn f680r;

            public final /* synthetic */ int mo128a(int i, Object obj) {
                int i2 = 0;
                List list = (List) obj;
                int i3 = 0;
                while (i2 < list.size()) {
                    i3 += this.f680r.mo128a(i, list.get(i2));
                    i2++;
                }
                return i3;
            }

            public final /* synthetic */ void mo129a(dp dpVar, int i, Object obj) {
                List list = (List) obj;
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    this.f680r.mo129a(dpVar, i, list.get(i2));
                }
            }

            public final /* synthetic */ Object mo126a(C0160do c0160do) {
                return Collections.singletonList(this.f680r.mo126a(c0160do));
            }

            public final /* synthetic */ void mo127a(dp dpVar, Object obj) {
                throw new UnsupportedOperationException("Repeated values can only be encoded with a tag.");
            }

            public final /* synthetic */ int mo125a(Object obj) {
                throw new UnsupportedOperationException("Repeated values can only be sized with a tag.");
            }
        };
        this.f665b = dnVar;
        return dnVar;
    }
}
