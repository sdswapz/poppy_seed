package com.tapjoy.internal;

public final class ar implements at {
    public final Object f522a;
    protected Object f523b = null;

    public ar(Object obj) {
        this.f522a = obj;
    }

    public final Object mo89a() {
        return this.f523b;
    }

    public final void mo90a(Object obj) {
        this.f523b = obj;
    }
}
