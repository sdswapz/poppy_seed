package com.tapjoy.internal;

public interface hw extends C0271if {
    hw mo253a();

    hw mo257b(hy hyVar);

    hw mo258b(String str);

    hw mo264d(int i);

    hw mo267e(int i);

    hw mo269f(long j);
}
