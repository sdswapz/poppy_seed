package com.tapjoy.internal;

import java.io.Closeable;
import java.io.Flushable;

public interface C0271if extends Closeable, Flushable {
    void mo255a(hv hvVar, long j);

    void close();

    void flush();
}
