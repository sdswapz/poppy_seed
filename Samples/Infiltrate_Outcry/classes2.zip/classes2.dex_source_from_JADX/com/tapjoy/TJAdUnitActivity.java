package com.tapjoy;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.ep;
import com.tapjoy.internal.fr;
import com.tapjoy.internal.gd;

public class TJAdUnitActivity extends Activity implements OnClickListener {
    private static TJAdUnitActivity f149b;
    private final Handler f150a = new Handler(Looper.getMainLooper());
    private TJAdUnit f151c;
    private TJPlacementData f152d;
    private C0072a f153e;
    private TJAdUnitSaveStateData f154f = new TJAdUnitSaveStateData();
    private RelativeLayout f155g = null;
    private TJCloseButton f156h;
    private ProgressBar f157i;
    private boolean f158j = false;

    class C00701 implements Runnable {
        final /* synthetic */ TJAdUnitActivity f146a;

        C00701(TJAdUnitActivity tJAdUnitActivity) {
            this.f146a = tJAdUnitActivity;
        }

        public final void run() {
            if (this.f146a.f151c.getCloseRequested()) {
                TapjoyLog.m249d("TJAdUnitActivity", "Did not receive callback from content. Closing ad.");
                this.f146a.finish();
            }
        }
    }

    class C00712 implements DialogInterface.OnClickListener {
        final /* synthetic */ TJAdUnitActivity f147a;

        C00712(TJAdUnitActivity tJAdUnitActivity) {
            this.f147a = tJAdUnitActivity;
        }

        public final void onClick(DialogInterface dialog, int which) {
            this.f147a.handleClose();
            dialog.cancel();
        }
    }

    class C0072a extends BroadcastReceiver {
        final /* synthetic */ TJAdUnitActivity f148a;

        private C0072a(TJAdUnitActivity tJAdUnitActivity) {
            this.f148a = tJAdUnitActivity;
        }

        public final void onReceive(Context context, Intent intent) {
            if (intent.getBooleanExtra("noConnectivity", false)) {
                TapjoyLog.m252i("TJAdUnitActivity", "Network connectivity lost during ad unit activity");
                this.f148a.showErrorDialog();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        TapjoyLog.m249d("TJAdUnitActivity", "TJAdUnitActivity onCreate: " + savedInstanceState);
        super.onCreate(savedInstanceState);
        f149b = this;
        if (savedInstanceState != null) {
            this.f154f = (TJAdUnitSaveStateData) savedInstanceState.getSerializable("ad_unit_bundle");
            if (this.f154f != null && this.f154f.isVideoComplete) {
                TapjoyLog.m249d("TJAdUnitActivity", "finishing TJAdUnitActivity");
                finish();
                return;
            }
        }
        Bundle extras = getIntent().getExtras();
        if (extras == null || extras.getSerializable(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA) == null) {
            TapjoyLog.m250e("TJAdUnitActivity", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Failed to launch AdUnit Activity"));
            finish();
            return;
        }
        this.f152d = (TJPlacementData) extras.getSerializable(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA);
        if (this.f152d.getContentViewId() != null) {
            TapjoyConnectCore.viewWillOpen(this.f152d.getContentViewId(), 1);
        }
        if (TJPlacementManager.m205a(this.f152d.getKey()) != null) {
            this.f151c = TJPlacementManager.m205a(this.f152d.getKey()).getAdUnit();
        } else {
            this.f151c = new TJAdUnit();
            this.f151c.setAdContentTracker(new ep(this.f152d.getPlacementName(), this.f152d.getPlacementType()));
        }
        if (!this.f151c.hasCalledLoad()) {
            TapjoyLog.m249d("TJAdUnitActivity", "No content loaded for ad unit -- loading now");
            this.f151c.load(this.f152d, false, this);
        }
        this.f151c.setAdUnitActivity(this);
        if (VERSION.SDK_INT < 11) {
            setTheme(16973829);
        } else {
            requestWindowFeature(1);
            getWindow().setFlags(1024, 1024);
            getWindow().setFlags(16777216, 16777216);
        }
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        if (!TapjoyConnectCore.isUnitTestMode()) {
            this.f153e = new C0072a();
            registerReceiver(this.f153e, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }
        LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        this.f155g = new RelativeLayout(this);
        this.f155g.setLayoutParams(layoutParams);
        this.f155g.setBackgroundColor(0);
        View backgroundWebView = this.f151c.getBackgroundWebView();
        backgroundWebView.setLayoutParams(layoutParams);
        if (backgroundWebView.getParent() != null) {
            ((ViewGroup) backgroundWebView.getParent()).removeView(backgroundWebView);
        }
        View webView = this.f151c.getWebView();
        webView.setLayoutParams(layoutParams);
        if (webView.getParent() != null) {
            ((ViewGroup) webView.getParent()).removeView(webView);
        }
        View videoView = this.f151c.getVideoView();
        LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams2.addRule(13);
        videoView.setLayoutParams(layoutParams2);
        if (videoView.getParent() != null) {
            ((ViewGroup) videoView.getParent()).removeView(videoView);
        }
        this.f155g.addView(backgroundWebView);
        this.f155g.addView(videoView);
        this.f155g.addView(webView);
        this.f157i = new ProgressBar(this, null, 16842874);
        if (this.f152d.hasProgressSpinner()) {
            setProgressSpinnerVisibility(true);
        } else {
            setProgressSpinnerVisibility(false);
        }
        layoutParams2 = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams2.addRule(13);
        this.f157i.setLayoutParams(layoutParams2);
        this.f155g.addView(this.f157i);
        if (!this.f151c.getWebView().isMraid()) {
            this.f156h = new TJCloseButton(this);
            this.f156h.setOnClickListener(this);
            this.f155g.addView(this.f156h);
        }
        setContentView(this.f155g);
        this.f151c.setVisible(true);
        TJCorePlacement a = TJPlacementManager.m205a(this.f152d.getKey());
        if (a != null) {
            a.m195e();
        }
    }

    public void setCloseButtonVisibility(boolean visibility) {
        if (visibility) {
            this.f156h.setVisibility(0);
        } else {
            this.f156h.setVisibility(4);
        }
    }

    public void setCloseButtonClickable(boolean clickable) {
        this.f156h.setClickableRequested(clickable);
    }

    public void setProgressSpinnerVisibility(boolean visibility) {
        if (visibility) {
            this.f157i.setVisibility(0);
        } else {
            this.f157i.setVisibility(4);
        }
    }

    public void onBackPressed() {
        handleClose();
    }

    public void handleClose() {
        handleClose(false);
    }

    public void handleClose(boolean shouldForceClose) {
        if (!this.f151c.getCloseRequested()) {
            TapjoyLog.m249d("TJAdUnitActivity", String.CLOSE_REQUESTED);
            this.f151c.closeRequested(shouldForceClose);
            this.f150a.postDelayed(new C00701(this), 1000);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        f149b = null;
        TapjoyLog.m249d("TJAdUnitActivity", "onDestroy");
        if (this.f151c != null) {
            this.f151c.destroy();
        }
        if (!(this.f153e == null || TapjoyConnectCore.isUnitTestMode())) {
            unregisterReceiver(this.f153e);
        }
        if (this.f152d != null && this.f152d.isBaseActivity()) {
            if (this.f152d.getContentViewId() != null) {
                TapjoyConnectCore.viewDidClose(this.f152d.getContentViewId());
            }
            TJCorePlacement a = TJPlacementManager.m205a(this.f152d.getKey());
            if (a != null) {
                a.m194d();
            }
        }
    }

    protected void onResume() {
        TapjoyLog.m249d("TJAdUnitActivity", "onResume");
        super.onResume();
        if (this.f151c.isLockedOrientation()) {
            setRequestedOrientation(this.f151c.getOrientation());
        }
        this.f151c.resume(this.f154f);
    }

    protected void onStart() {
        super.onStart();
        TapjoyLog.m249d("TJAdUnitActivity", "onStart");
        if (gd.m956a().f1173n) {
            this.f158j = true;
            fr.m902a(this);
        }
        if (!this.f152d.isBaseActivity()) {
            setResult(-1, getIntent());
        }
    }

    protected void onPause() {
        super.onPause();
        TapjoyLog.m249d("TJAdUnitActivity", "onPause");
        this.f151c.pause();
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        TapjoyLog.m249d("TJAdUnitActivity", "onSaveInstanceState");
        this.f154f.seekTime = this.f151c.getVideoSeekTime();
        this.f154f.isVideoComplete = this.f151c.isVideoComplete();
        outState.putSerializable("ad_unit_bundle", this.f154f);
    }

    protected void onStop() {
        if (this.f158j) {
            this.f158j = false;
            fr.m907b(this);
        }
        super.onStop();
        TapjoyLog.m249d("TJAdUnitActivity", "onStop");
    }

    public void showErrorDialog() {
        if (!isFinishing()) {
            new Builder(this).setMessage("An error occured. Please try again later.").setPositiveButton("OK", new C00712(this)).create().show();
        }
    }

    public void onClick(View v) {
        handleClose();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == TJAdUnitConstants.MRAID_REQUEST_CODE && data != null && data.hasExtra(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA) && this.f151c != null) {
            TJPlacementData tJPlacementData = (TJPlacementData) data.getSerializableExtra(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA);
            this.f151c.invokeBridgeCallback(tJPlacementData.getCallbackID(), Boolean.TRUE);
        }
    }

    static void m142a() {
        TJAdUnitActivity tJAdUnitActivity = f149b;
        if (tJAdUnitActivity != null) {
            tJAdUnitActivity.handleClose(true);
        }
    }
}
