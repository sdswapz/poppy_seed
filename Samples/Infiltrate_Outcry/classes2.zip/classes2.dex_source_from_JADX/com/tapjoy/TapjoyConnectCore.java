package com.tapjoy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.C0289y;
import com.tapjoy.internal.bm;
import com.tapjoy.internal.bs;
import com.tapjoy.internal.ct;
import com.tapjoy.internal.dc;
import com.tapjoy.internal.dx;
import com.tapjoy.internal.ed;
import com.tapjoy.internal.ee;
import com.tapjoy.internal.ek;
import com.tapjoy.internal.er;
import com.tapjoy.internal.er.C0195a;
import com.tapjoy.internal.ev;
import com.tapjoy.internal.fd;
import com.tapjoy.internal.gd;
import com.tapjoy.mediation.TJMediationNetwork;
import com.tapjoy.mediation.TJMediationSettings;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import org.w3c.dom.Document;

public class TapjoyConnectCore {
    private static int f345A = 1;
    private static float f346B = DEFAULT_CURRENCY_MULTIPLIER;
    private static int f347C = 1;
    private static String f348D = "";
    public static final float DEFAULT_CURRENCY_MULTIPLIER = 1.0f;
    private static boolean f349E = false;
    private static String f350F = "";
    private static String f351G = "";
    private static String f352H = "";
    private static String f353I = "";
    private static String f354J = "";
    private static String f355K = "";
    private static String f356L = "";
    private static String f357M = "";
    private static String f358N = "";
    private static String f359O = "";
    private static String f360P = TapjoyConstants.TJC_PLUGIN_NATIVE;
    private static String f361Q = "";
    private static String f362R = "";
    private static float f363S = DEFAULT_CURRENCY_MULTIPLIER;
    private static boolean f364T = false;
    private static String f365U = "";
    private static String f366V = "";
    private static String f367W = "";
    private static String f368X = "";
    private static String f369Y = null;
    protected static int f370a = 0;
    private static Integer aA;
    private static Integer aB;
    private static Integer aC;
    private static Long aD;
    private static Long aE;
    private static Long aF;
    private static String aG;
    private static Integer aH;
    private static Double aI;
    private static Double aJ;
    private static Long aK;
    private static Integer aL;
    private static Integer aM;
    private static Integer aN;
    private static String aO;
    private static String aP;
    private static String aQ;
    private static long ab = 0;
    private static boolean ad;
    private static PackageManager ae;
    private static Hashtable ag = TapjoyConnectFlag.CONNECT_FLAG_DEFAULTS;
    private static String ah = "";
    private static Map ai = new ConcurrentHashMap();
    private static String aj;
    private static String ak;
    private static String al;
    private static String am;
    private static Integer an;
    private static String ao;
    private static String ap;
    private static Long aq;
    private static String ar;
    private static Integer as;
    private static Integer at;
    private static String au;
    private static String av;
    private static String aw;
    private static String ax;
    private static String ay;
    private static Set az;
    protected static int f371b = 0;
    protected static String f372c = "";
    protected static boolean f373d;
    protected static String f374e = "";
    protected static String f375f = "";
    private static Context f376g = null;
    private static String f377h = null;
    private static TapjoyConnectCore f378i = null;
    private static TapjoyURLConnection f379j = null;
    private static TJConnectListener f380k = null;
    private static TJSetUserIDListener f381l = null;
    private static Vector f382m = new Vector(Arrays.asList(TapjoyConstants.dependencyClassNames));
    private static String f383n = "";
    private static String f384o = "";
    private static String f385p = "";
    private static String f386q = "";
    private static String f387r = "";
    private static String f388s = "";
    private static String f389t = "";
    private static String f390u = "";
    private static String f391v = "";
    private static String f392w = "";
    private static String f393x = "";
    private static String f394y = "";
    private static String f395z = "";
    private long f396Z = 0;
    private boolean aa = false;
    private boolean ac = false;
    private TapjoyGpsHelper af;

    class C01031 implements Runnable {
        final /* synthetic */ TapjoyConnectCore f340a;

        C01031(TapjoyConnectCore tapjoyConnectCore) {
            this.f340a = tapjoyConnectCore;
        }

        public final void run() {
            this.f340a.af.loadAdvertisingId();
            if (this.f340a.af.isGooglePlayServicesAvailable() && this.f340a.af.isGooglePlayManifestConfigured()) {
                TapjoyConnectCore.f371b = this.f340a.af.getDeviceGooglePlayServicesVersion();
                TapjoyConnectCore.f370a = this.f340a.af.getPackagedGooglePlayServicesVersion();
            }
            if (this.f340a.af.isAdIdAvailable()) {
                TapjoyConnectCore.f373d = this.f340a.af.isAdTrackingEnabled();
                TapjoyConnectCore.f372c = this.f340a.af.getAdvertisingId();
            }
            if (TapjoyConnectCore.m241m()) {
                TapjoyLog.m252i("TapjoyConnect", "Disabling persistent IDs. Do this only if you are not using Tapjoy to manage currency.");
            }
            this.f340a.completeConnectCall();
        }
    }

    static class C01042 implements Runnable {
        C01042() {
        }

        public final void run() {
            TapjoyLog.m252i("TapjoyConnect", "Setting userID to " + TapjoyConnectCore.f348D);
            TapjoyHttpURLResponse responseFromURL = TapjoyConnectCore.f379j.getResponseFromURL(TapjoyConnectCore.getHostURL() + TapjoyConstants.TJC_USER_ID_URL_PATH, TapjoyConnectCore.getURLParams());
            boolean z = false;
            if (responseFromURL.response != null) {
                z = TapjoyConnectCore.m222a(responseFromURL.response);
            }
            TapjoyConnectCore.m220a(z);
        }
    }

    public class PPAThread implements Runnable {
        final /* synthetic */ TapjoyConnectCore f343a;
        private Map f344b;

        public PPAThread(TapjoyConnectCore this$0, Map urlParams) {
            this.f343a = this$0;
            this.f344b = urlParams;
        }

        public void run() {
            TapjoyHttpURLResponse responseFromURL = TapjoyConnectCore.f379j.getResponseFromURL(TapjoyConnectCore.getHostURL() + TapjoyConstants.TJC_CONNECT_URL_PATH, null, null, this.f344b);
            if (responseFromURL.response != null) {
                TapjoyConnectCore.m229c(responseFromURL.response);
            }
        }
    }

    static /* synthetic */ boolean m222a(String str) {
        Document buildDocument = TapjoyUtil.buildDocument(str);
        if (buildDocument != null) {
            String nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("PackageNames"));
            if (nodeTrimValue != null && nodeTrimValue.length() > 0) {
                List vector = new Vector();
                int i = 0;
                while (true) {
                    int indexOf = nodeTrimValue.indexOf(44, i);
                    if (indexOf == -1) {
                        break;
                    }
                    TapjoyLog.m249d("TapjoyConnect", "parse: " + nodeTrimValue.substring(i, indexOf).trim());
                    vector.add(nodeTrimValue.substring(i, indexOf).trim());
                    i = indexOf + 1;
                }
                TapjoyLog.m249d("TapjoyConnect", "parse: " + nodeTrimValue.substring(i).trim());
                vector.add(nodeTrimValue.substring(i).trim());
                m218a(vector);
            }
            String nodeTrimValue2 = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Success"));
            if (nodeTrimValue2 == null || !nodeTrimValue2.equals("true")) {
                return false;
            }
        }
        return true;
    }

    public static TapjoyConnectCore getInstance() {
        return f378i;
    }

    public static void requestTapjoyConnect(Context applicationContext, String apiKey) {
        requestTapjoyConnect(applicationContext, apiKey, null);
    }

    public static void requestTapjoyConnect(Context applicationContext, String apiKey, Hashtable flags) {
        requestTapjoyConnect(applicationContext, apiKey, flags, null);
    }

    public static void requestTapjoyConnect(Context applicationContext, String apiKey, Hashtable flags, TJConnectListener tapjoyConnectListener) {
        try {
            er erVar = new er(apiKey);
            if (erVar.f999a != C0195a.SDK_ANDROID) {
                throw new IllegalArgumentException("The given API key was not for Android.");
            }
            f377h = apiKey;
            f392w = erVar.f1000b;
            f358N = erVar.f1001c;
            f359O = erVar.f1002d;
            gd.m957a(applicationContext).f1169j = apiKey;
            if (flags != null) {
                ag.putAll(flags);
                fd.m837b().m832a(flags);
            }
            f380k = tapjoyConnectListener;
            f378i = new TapjoyConnectCore(applicationContext);
        } catch (IllegalArgumentException e) {
            throw new TapjoyIntegrationException(e.getMessage());
        }
    }

    public TapjoyConnectCore(Context applicationContext) {
        f376g = applicationContext;
        fd.m836a().m838a(applicationContext);
        f379j = new TapjoyURLConnection();
        ae = f376g.getPackageManager();
        this.af = new TapjoyGpsHelper(f376g);
        try {
            String networkOperator;
            boolean z;
            if (ag == null) {
                ag = new Hashtable();
            }
            m237i();
            int identifier = f376g.getResources().getIdentifier("raw/tapjoy_config", null, f376g.getPackageName());
            Properties properties = new Properties();
            try {
                properties.load(f376g.getResources().openRawResource(identifier));
                m219a(properties);
            } catch (Exception e) {
            }
            if (getConnectFlagValue("unit_test_mode") == "") {
                m238j();
            }
            String string = Secure.getString(f376g.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
            f383n = string;
            if (string != null) {
                f383n = f383n.toLowerCase();
            }
            f393x = ae.getPackageInfo(f376g.getPackageName(), 0).versionName;
            f390u = TapjoyConstants.TJC_DEVICE_PLATFORM_TYPE;
            f350F = TapjoyConstants.TJC_DEVICE_PLATFORM_TYPE;
            f388s = Build.MODEL;
            f389t = Build.MANUFACTURER;
            f391v = VERSION.RELEASE;
            f394y = "11.11.0";
            f395z = TapjoyConstants.TJC_BRIDGE_VERSION_NUMBER;
            try {
                if (VERSION.SDK_INT > 3) {
                    TapjoyDisplayMetricsUtil tapjoyDisplayMetricsUtil = new TapjoyDisplayMetricsUtil(f376g);
                    f345A = tapjoyDisplayMetricsUtil.getScreenDensityDPI();
                    f346B = tapjoyDisplayMetricsUtil.getScreenDensityScale();
                    f347C = tapjoyDisplayMetricsUtil.getScreenLayoutSize();
                }
            } catch (Exception e2) {
                TapjoyLog.m251e("TapjoyConnect", "Error getting screen density/dimensions/layout: " + e2.toString());
            }
            if (m233e("android.permission.ACCESS_WIFI_STATE")) {
                try {
                    WifiManager wifiManager = (WifiManager) f376g.getSystemService(TapjoyConstants.TJC_CONNECTION_TYPE_WIFI);
                    if (wifiManager != null) {
                        WifiInfo connectionInfo = wifiManager.getConnectionInfo();
                        if (connectionInfo != null) {
                            string = connectionInfo.getMacAddress();
                            f386q = string;
                            if (string != null) {
                                f386q = f386q.replace(":", "").toLowerCase();
                            }
                        }
                    }
                } catch (Exception e22) {
                    TapjoyLog.m251e("TapjoyConnect", "Error getting device mac address: " + e22.toString());
                }
            } else {
                TapjoyLog.m249d("TapjoyConnect", "*** ignore macAddress");
            }
            TelephonyManager telephonyManager = (TelephonyManager) f376g.getSystemService("phone");
            if (telephonyManager != null) {
                f351G = telephonyManager.getNetworkOperatorName();
                f352H = telephonyManager.getNetworkCountryIso();
                networkOperator = telephonyManager.getNetworkOperator();
                if (networkOperator != null && (networkOperator.length() == 5 || networkOperator.length() == 6)) {
                    f353I = networkOperator.substring(0, 3);
                    f354J = networkOperator.substring(3);
                }
                if (m233e("android.permission.READ_PHONE_STATE")) {
                    try {
                        if (getConnectFlagValue(TapjoyConnectFlag.DEBUG_DEVICE_ID) == null || getConnectFlagValue(TapjoyConnectFlag.DEBUG_DEVICE_ID).length() <= 0) {
                            f385p = telephonyManager.getDeviceId();
                        } else {
                            f385p = getConnectFlagValue(TapjoyConnectFlag.DEBUG_DEVICE_ID);
                        }
                        TapjoyLog.m249d("TapjoyConnect", "deviceID: " + f385p);
                        if (f385p == null) {
                            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Device ID is NULL"));
                            z = false;
                        } else if (f385p.length() == 0 || f385p.equals("000000000000000") || f385p.equals("0")) {
                            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Device ID is empty or an emulator"));
                            z = false;
                        } else {
                            f385p = f385p.toLowerCase(Locale.getDefault());
                            z = true;
                        }
                        TapjoyLog.m252i("TapjoyConnect", "ANDROID SDK VERSION: " + VERSION.SDK_INT);
                        if (VERSION.SDK_INT >= 9) {
                            TapjoyLog.m249d("TapjoyConnect", "TRYING TO GET SERIAL OF 2.3+ DEVICE...");
                            networkOperator = getSerial();
                            if (!z) {
                                f385p = networkOperator;
                            }
                            if (f385p == null) {
                                TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Device serial number is NULL"));
                            } else if (f385p.length() == 0 || f385p.equals("000000000000000") || f385p.equals("0") || f385p.equals("unknown")) {
                                TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Device serial number is empty or an emulator"));
                            } else {
                                f385p = f385p.toLowerCase(Locale.getDefault());
                            }
                        }
                    } catch (Exception e222) {
                        TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Cannot get deviceID -- " + e222.toString()));
                        f385p = null;
                    }
                } else {
                    TapjoyLog.m249d("TapjoyConnect", "*** ignore deviceID");
                }
            }
            SharedPreferences sharedPreferences = f376g.getSharedPreferences(TapjoyConstants.TJC_PREFERENCE, 0);
            networkOperator = sharedPreferences.getString(TapjoyConstants.PREF_INSTALL_ID, "");
            f387r = networkOperator;
            if (networkOperator == null || f387r.length() == 0) {
                try {
                    f387r = TapjoyUtil.SHA256(UUID.randomUUID().toString() + System.currentTimeMillis());
                    Editor edit = sharedPreferences.edit();
                    edit.putString(TapjoyConstants.PREF_INSTALL_ID, f387r);
                    edit.commit();
                } catch (Exception e2222) {
                    TapjoyLog.m251e("TapjoyConnect", "Error generating install id: " + e2222.toString());
                }
            }
            try {
                f349E = m223a("android.hardware.location", "android.permission.ACCESS_FINE_LOCATION");
            } catch (Exception e22222) {
                TapjoyLog.m251e("TapjoyConnect", "Error trying to detect capabilities on devicee: " + e22222.toString());
            }
            if (getConnectFlagValue(TapjoyConnectFlag.STORE_NAME) != null && getConnectFlagValue(TapjoyConnectFlag.STORE_NAME).length() > 0) {
                f357M = getConnectFlagValue(TapjoyConnectFlag.STORE_NAME);
                if (!new ArrayList(Arrays.asList(TapjoyConnectFlag.STORE_ARRAY)).contains(f357M)) {
                    TapjoyLog.m254w("TapjoyConnect", "Warning -- undefined STORE_NAME: " + f357M);
                }
            }
            try {
                string = f357M;
                Intent intent = new Intent("android.intent.action.VIEW");
                if (string.length() <= 0) {
                    intent.setData(Uri.parse("market://details"));
                    if (ae.queryIntentActivities(intent, 0).size() > 0) {
                        z = true;
                    }
                    z = false;
                } else if (string.equals(TapjoyConnectFlag.STORE_GFAN)) {
                    z = m231d("com.mappn.gfan");
                } else {
                    if (string.equals(TapjoyConnectFlag.STORE_SKT)) {
                        z = m231d("com.skt.skaf.TSCINSTALL");
                    }
                    z = false;
                }
                f364T = z;
            } catch (Exception e222222) {
                TapjoyLog.m251e("TapjoyConnect", "Error trying to detect store intent on devicee: " + e222222.toString());
            }
            m235g();
            if (getConnectFlagValue(TapjoyConnectFlag.DISABLE_PERSISTENT_IDS) != null && getConnectFlagValue(TapjoyConnectFlag.DISABLE_PERSISTENT_IDS).length() > 0) {
                f375f = getConnectFlagValue(TapjoyConnectFlag.DISABLE_PERSISTENT_IDS);
            }
            if (getConnectFlagValue(TapjoyConnectFlag.DISABLE_ADVERTISING_ID_CHECK) != null && getConnectFlagValue(TapjoyConnectFlag.DISABLE_ADVERTISING_ID_CHECK).length() > 0) {
                f374e = getConnectFlagValue(TapjoyConnectFlag.DISABLE_ADVERTISING_ID_CHECK);
            }
            if (getConnectFlagValue(TapjoyConnectFlag.USER_ID) != null && getConnectFlagValue(TapjoyConnectFlag.USER_ID).length() > 0) {
                TapjoyLog.m252i("TapjoyConnect", "Setting userID to: " + getConnectFlagValue(TapjoyConnectFlag.USER_ID));
                setUserID(getConnectFlagValue(TapjoyConnectFlag.USER_ID), null);
            }
            f362R = TapjoyUtil.getRedirectDomain(getConnectFlagValue(TapjoyConnectFlag.SERVICE_URL));
            String str = "TapjoyConnect";
            StringBuilder append = new StringBuilder("deviceID: ").append(f385p);
            string = (getConnectFlagValue(TapjoyConnectFlag.DEBUG_DEVICE_ID) == null || getConnectFlagValue(TapjoyConnectFlag.DEBUG_DEVICE_ID).length() <= 0) ? "" : " *debug_device_id*";
            TapjoyLog.m249d(str, append.append(string).toString());
            if (ag != null) {
                m236h();
            }
            callConnect();
            this.ac = true;
        } catch (NameNotFoundException e3) {
            throw new TapjoyException(e3.getMessage());
        } catch (TapjoyIntegrationException e4) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, e4.getMessage()));
            m230d();
            ev.f1014b.notifyObservers(Boolean.FALSE);
        } catch (TapjoyException e5) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, e5.getMessage()));
            m230d();
            ev.f1014b.notifyObservers(Boolean.FALSE);
        }
    }

    private static void m230d() {
        if (!ct.m463c(f359O)) {
            gd.m956a().m964a(f376g, f377h, "11.11.0", TapjoyConfig.TJC_ANALYTICS_SERVICE_URL, f359O, f358N);
        }
        if (f380k != null) {
            f380k.onConnectFailure();
        }
    }

    public void callConnect() {
        fetchAdvertisingID();
    }

    public void fetchAdvertisingID() {
        new Thread(new C01031(this)).start();
    }

    public void appPause() {
        this.aa = true;
    }

    public void appResume() {
        if (this.aa) {
            m242n();
            this.aa = false;
        }
    }

    public static Map getURLParams() {
        Map genericURLParams = getGenericURLParams();
        genericURLParams.putAll(getTimeStampAndVerifierParams());
        return genericURLParams;
    }

    public static Map getGenericURLParams() {
        Map e = m232e();
        TapjoyUtil.safePut(e, TapjoyConstants.TJC_APP_ID, f392w, true);
        return e;
    }

    private static Map m232e() {
        Map hashMap = new HashMap();
        Map hashMap2 = new HashMap();
        Map hashMap3 = new HashMap();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PLUGIN, f360P, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_SDK_TYPE, f361Q, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_APP_ID, f392w, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_LIBRARY_VERSION, f394y, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_LIBRARY_REVISION, TapjoyRevision.GIT_REVISION, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_BRIDGE_VERSION, f395z, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_APP_VERSION_NAME, f393x, true);
        hashMap2.putAll(hashMap3);
        hashMap3 = new HashMap();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_NAME, f388s, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PLATFORM, f350F, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_OS_VERSION_NAME, f391v, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_MANUFACTURER, f389t, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_TYPE_NAME, f390u, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_SCREEN_LAYOUT_SIZE, f347C, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_LOCATION, String.valueOf(f349E), true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_STORE_NAME, f357M, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_STORE_VIEW, String.valueOf(f364T), true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_CARRIER_NAME, f351G, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_CARRIER_COUNTRY_CODE, f352H, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_MOBILE_NETWORK_CODE, f354J, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_MOBILE_COUNTRY_CODE, f353I, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_COUNTRY_CODE, Locale.getDefault().getCountry(), true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_LANGUAGE, Locale.getDefault().getLanguage(), true);
        f355K = getConnectionType();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_CONNECTION_TYPE, f355K, true);
        f356L = getConnectionSubType();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_CONNECTION_SUBTYPE, f356L, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_SCREEN_DENSITY, f345A, true);
        hashMap2.putAll(hashMap3);
        hashMap3 = new HashMap();
        if (m240l()) {
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_ADVERTISING_ID, f372c, true);
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_AD_TRACKING_ENABLED, String.valueOf(f373d), true);
        }
        if (!m241m()) {
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_ANDROID_ID, f383n, true);
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_ID_NAME, f385p, true);
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_MAC_ADDRESS, f386q, true);
        }
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_INSTALL_ID, f387r, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_USER_ID, f348D, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_ADVERTISING_ID_CHECK_DISABLED, f374e, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PERSISTENT_ID_DISABLED, f375f, true);
        if (f370a != 0) {
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGED_GOOGLE_PLAY_SERVICES_VERSION, Integer.toString(f370a), true);
        }
        if (f371b != 0) {
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_GOOGLE_PLAY_SERVICES_VERSION, Integer.toString(f371b), true);
        }
        if (f384o == null || f384o.length() == 0 || System.currentTimeMillis() - ab > TapjoyConstants.SESSION_ID_INACTIVITY_TIME) {
            f384o = m242n();
        } else {
            ab = System.currentTimeMillis();
        }
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_SESSION_ID, f384o, true);
        hashMap2.putAll(hashMap3);
        hashMap3 = new HashMap();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_APP_GROUP_ID, f365U, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_STORE, f366V, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_ANALYTICS_API_KEY, f367W, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_MANAGED_DEVICE_ID, f368X, true);
        hashMap2.putAll(hashMap3);
        if (!(TapjoyCache.getInstance() == null || TapjoyCache.getInstance().getCachedOfferIDs() == null || TapjoyCache.getInstance().getCachedOfferIDs().length() <= 0)) {
            TapjoyUtil.safePut(hashMap2, TapjoyConstants.TJC_CACHED_OFFERS, TapjoyCache.getInstance().getCachedOfferIDs(), true);
        }
        TapjoyUtil.safePut(hashMap2, TapjoyConstants.TJC_CURRENCY_MULTIPLIER, Float.toString(f363S), true);
        hashMap.putAll(hashMap2);
        hashMap2 = new HashMap();
        m235g();
        hashMap3 = new HashMap();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_ANALYTICS_ID, aj, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGE_ID, ak, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGE_SIGN, al, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_DISPLAY_DENSITY, aL);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_DISPLAY_WIDTH, aM);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_DISPLAY_HEIGHT, aN);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_COUNTRY_SIM, aO, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_DEVICE_TIMEZONE, aP, true);
        hashMap2.putAll(hashMap3);
        hashMap3 = new HashMap();
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGE_VERSION, am, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGE_REVISION, an);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_PACKAGE_DATA_VERSION, ao, true);
        TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_INSTALLER, ap, true);
        if (ct.m463c(f357M)) {
            TapjoyUtil.safePut(hashMap3, TapjoyConstants.TJC_STORE_NAME, aQ, true);
        }
        hashMap2.putAll(hashMap3);
        hashMap2.putAll(m234f());
        hashMap.putAll(hashMap2);
        return hashMap;
    }

    public static Map getTimeStampAndVerifierParams() {
        long currentTimeMillis = System.currentTimeMillis() / 1000;
        String a = m216a(currentTimeMillis);
        Map hashMap = new HashMap();
        TapjoyUtil.safePut(hashMap, "timestamp", String.valueOf(currentTimeMillis), true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_VERIFIER, a, true);
        return hashMap;
    }

    private static Map m234f() {
        Map hashMap = new HashMap();
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_INSTALLED, aq);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_REFERRER, ar, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_LEVEL, as);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_FRIEND_COUNT, at);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_VARIABLE_1, au, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_VARIABLE_2, av, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_VARIABLE_3, aw, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_VARIABLE_4, ax, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_VARIABLE_5, ay, true);
        int i = 0;
        for (String safePut : az) {
            int i2 = i + 1;
            TapjoyUtil.safePut(hashMap, "user_tags[" + i + "]", safePut, true);
            i = i2;
        }
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_WEEKLY_FREQUENCY, aA);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_USER_MONTHLY_FREQUENCY, aB);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_SESSION_TOTAL_COUNT, aC);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_SESSION_TOTAL_LENGTH, aD);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_SESSION_LAST_AT, aE);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_SESSION_LAST_LENGTH, aF);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_PURCHASE_CURRENCY, aG, true);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_PURCHASE_TOTAL_COUNT, aH);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_PURCHASE_TOTAL_PRICE, aI);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_PURCHASE_LAST_PRICE, aJ);
        TapjoyUtil.safePut(hashMap, TapjoyConstants.TJC_PURCHASE_LAST_AT, aK);
        return hashMap;
    }

    private static void m235g() {
        ee a = gd.m957a(f376g).m963a(true);
        ed edVar = a.f849d;
        aj = edVar.f829h;
        ak = edVar.f839r;
        al = edVar.f840s;
        aL = edVar.f834m;
        aM = edVar.f835n;
        aN = edVar.f836o;
        aO = edVar.f842u;
        aP = edVar.f838q;
        dx dxVar = a.f850e;
        am = dxVar.f721e;
        an = dxVar.f722f;
        ao = dxVar.f723g;
        ap = dxVar.f724h;
        aQ = dxVar.f725i;
        ek ekVar = a.f851f;
        aq = ekVar.f967s;
        ar = ekVar.f968t;
        as = ekVar.f958J;
        at = ekVar.f959K;
        au = ekVar.f960L;
        av = ekVar.f961M;
        aw = ekVar.f962N;
        ax = ekVar.f963O;
        ay = ekVar.f964P;
        az = new HashSet(ekVar.f965Q);
        aA = ekVar.f969u;
        aB = ekVar.f970v;
        aC = ekVar.f972x;
        aD = ekVar.f973y;
        aE = ekVar.f974z;
        aF = ekVar.f949A;
        aG = ekVar.f950B;
        aH = ekVar.f951C;
        aI = ekVar.f952D;
        aJ = ekVar.f954F;
        aK = ekVar.f953E;
    }

    private static void m236h() {
        TapjoyLog.m252i("TapjoyConnect", "Connect Flags:");
        TapjoyLog.m252i("TapjoyConnect", "--------------------");
        for (Entry entry : ag.entrySet()) {
            TapjoyLog.m252i("TapjoyConnect", "key: " + ((String) entry.getKey()) + ", value: " + Uri.encode(entry.getValue().toString()));
        }
        TapjoyLog.m252i("TapjoyConnect", "hostURL: [" + getConnectFlagValue(TapjoyConnectFlag.SERVICE_URL) + "]");
        TapjoyLog.m252i("TapjoyConnect", "redirectDomain: [" + f362R + "]");
        TapjoyLog.m252i("TapjoyConnect", "--------------------");
    }

    private static void m237i() {
        try {
            if (ae != null) {
                ApplicationInfo applicationInfo = ae.getApplicationInfo(f376g.getPackageName(), 128);
                if (applicationInfo == null || applicationInfo.metaData == null) {
                    TapjoyLog.m249d("TapjoyConnect", "No metadata present.");
                    return;
                }
                for (String str : TapjoyConnectFlag.FLAG_ARRAY) {
                    String string = applicationInfo.metaData.getString("tapjoy." + str);
                    if (string != null) {
                        TapjoyLog.m249d("TapjoyConnect", "Found manifest flag: " + str + ", " + string);
                        m226b(str, string);
                    }
                }
                TapjoyLog.m249d("TapjoyConnect", "Metadata successfully loaded");
            }
        } catch (Exception e) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error reading manifest meta-data -- " + e.toString()));
        }
    }

    private static void m219a(Properties properties) {
        Enumeration keys = properties.keys();
        while (keys.hasMoreElements()) {
            try {
                String str = (String) keys.nextElement();
                m226b(str, (String) properties.get(str));
            } catch (ClassCastException e) {
                TapjoyLog.m251e("TapjoyConnect", "Error parsing configuration properties in tapjoy_config.txt");
            }
        }
    }

    private void m238j() {
        String copyTextFromJarIntoString;
        int indexOf;
        try {
            List<ActivityInfo> asList = Arrays.asList(ae.getPackageInfo(f376g.getPackageName(), 1).activities);
            if (asList != null) {
                for (ActivityInfo activityInfo : asList) {
                    if (f382m.contains(activityInfo.name)) {
                        indexOf = f382m.indexOf(activityInfo.name);
                        Class.forName((String) f382m.get(indexOf));
                        Vector vector = new Vector();
                        if ((activityInfo.configChanges & 128) != 128) {
                            vector.add(String.ORIENTATION);
                        }
                        if ((activityInfo.configChanges & 32) != 32) {
                            vector.add("keyboardHidden");
                        }
                        if (vector.size() == 0) {
                            if (VERSION.SDK_INT >= 13 && (activityInfo.configChanges & 1024) != 1024) {
                                TapjoyLog.m254w("TapjoyConnect", "WARNING -- screenSize property is not specified in manifest configChanges for " + ((String) f382m.get(indexOf)));
                            }
                            if (VERSION.SDK_INT < 11 || !activityInfo.name.equals("com.tapjoy.TJAdUnitActivity") || (activityInfo.flags & 512) == 512) {
                                f382m.remove(indexOf);
                            } else {
                                throw new TapjoyIntegrationException("'hardwareAccelerated' property not specified in manifest for " + ((String) f382m.get(indexOf)));
                            }
                        } else if (vector.size() == 1) {
                            throw new TapjoyIntegrationException(vector.toString() + " property is not specified in manifest configChanges for " + ((String) f382m.get(indexOf)));
                        } else {
                            throw new TapjoyIntegrationException(vector.toString() + " properties are not specified in manifest configChanges for " + ((String) f382m.get(indexOf)));
                        }
                    }
                }
            }
            if (f382m.size() == 0) {
                m239k();
                try {
                    try {
                        Class.forName("com.tapjoy.TJAdUnitJSBridge").getMethod(String.CLOSE_REQUESTED, new Class[]{Boolean.class});
                        String str = (String) TapjoyUtil.getResource("mraid.js");
                        if (str == null) {
                            copyTextFromJarIntoString = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", f376g);
                        } else {
                            copyTextFromJarIntoString = str;
                        }
                        if (copyTextFromJarIntoString == null) {
                            try {
                                InputStream openRawResource = f376g.getResources().openRawResource(f376g.getResources().getIdentifier("mraid", "raw", f376g.getPackageName()));
                                byte[] bArr = new byte[openRawResource.available()];
                                openRawResource.read(bArr);
                                str = new String(bArr);
                                try {
                                    TapjoyUtil.setResource("mraid.js", str);
                                } catch (Exception e) {
                                }
                            } catch (Exception e2) {
                                str = copyTextFromJarIntoString;
                            }
                        } else {
                            str = copyTextFromJarIntoString;
                        }
                        if (str == null) {
                            throw new TapjoyIntegrationException("ClassNotFoundException: mraid.js was not found.");
                        } else if (getConnectFlagValue(TapjoyConnectFlag.DISABLE_ADVERTISING_ID_CHECK) == null || !getConnectFlagValue(TapjoyConnectFlag.DISABLE_ADVERTISING_ID_CHECK).equals("true")) {
                            this.af.checkGooglePlayIntegration();
                        } else {
                            TapjoyLog.m252i("TapjoyConnect", "Skipping integration check for Google Play Services and Advertising ID. Do this only if you do not have access to Google Play Services.");
                        }
                    } catch (NoSuchMethodException e3) {
                        throw new TapjoyIntegrationException("Try configuring Proguard or other code obfuscators to ignore com.tapjoy classes. Visit http://dev.tapjoy.comfor more information.");
                    }
                } catch (ClassNotFoundException e4) {
                    throw new TapjoyIntegrationException("ClassNotFoundException: com.tapjoy.TJAdUnitJSBridge was not found.");
                }
            } else if (f382m.size() == 1) {
                throw new TapjoyIntegrationException("Missing " + f382m.size() + " dependency class in manifest: " + f382m.toString());
            } else {
                throw new TapjoyIntegrationException("Missing " + f382m.size() + " dependency classes in manifest: " + f382m.toString());
            }
        } catch (ClassNotFoundException e5) {
            throw new TapjoyIntegrationException("[ClassNotFoundException] Could not find dependency class " + ((String) f382m.get(indexOf)));
        } catch (NameNotFoundException e6) {
            throw new TapjoyIntegrationException("NameNotFoundException: Could not find package.");
        }
    }

    private static void m239k() {
        int i = 0;
        Vector vector = new Vector();
        for (String str : TapjoyConstants.dependencyPermissions) {
            if (!m233e(str)) {
                vector.add(str);
            }
        }
        if (vector.size() == 0) {
            Vector vector2 = new Vector();
            String[] strArr = TapjoyConstants.optionalPermissions;
            int length = strArr.length;
            while (i < length) {
                String str2 = strArr[i];
                if (!m233e(str2)) {
                    vector2.add(str2);
                }
                i++;
            }
            if (vector2.size() == 0) {
                return;
            }
            if (vector2.size() == 1) {
                TapjoyLog.m254w("TapjoyConnect", "WARNING -- " + vector2.toString() + " permission was not found in manifest. The exclusion of this permission could cause problems.");
            } else {
                TapjoyLog.m254w("TapjoyConnect", "WARNING -- " + vector2.toString() + " permissions were not found in manifest. The exclusion of these permissions could cause problems.");
            }
        } else if (vector.size() == 1) {
            throw new TapjoyIntegrationException("Missing 1 permission in manifest: " + vector.toString());
        } else {
            throw new TapjoyIntegrationException("Missing " + vector.size() + " permissions in manifest: " + vector.toString());
        }
    }

    private static boolean m240l() {
        return f372c != null && f372c.length() > 0;
    }

    private static boolean m241m() {
        return m240l() && getConnectFlagValue(TapjoyConnectFlag.DISABLE_PERSISTENT_IDS) != null && getConnectFlagValue(TapjoyConnectFlag.DISABLE_PERSISTENT_IDS).equals("true");
    }

    private static boolean m224a(String str, boolean z) {
        IOException e;
        Throwable th;
        RuntimeException e2;
        Closeable closeable = null;
        Closeable b;
        try {
            b = bs.m367b(str);
            try {
                Map d = b.m380d();
                String a = ct.m461a((String) d.get(TapjoyConstants.TJC_APP_GROUP_ID));
                String a2 = ct.m461a((String) d.get(TapjoyConstants.TJC_STORE));
                String a3 = ct.m461a((String) d.get(TapjoyConstants.TJC_ANALYTICS_API_KEY));
                String a4 = ct.m461a((String) d.get(TapjoyConstants.TJC_MANAGED_DEVICE_ID));
                String a5 = ct.m461a((String) d.get(TapjoyConstants.TJC_PACKAGE_NAMES));
                Object obj = d.get("cache_max_age");
                er erVar = new er(a3);
                if (erVar.f999a != C0195a.RPC_ANALYTICS) {
                    throw new IOException("Invalid analytics_api_key");
                }
                String str2 = erVar.f1000b;
                if (str2.regionMatches(13, "-8000-8000-", 0, 11)) {
                    String str3;
                    String stringBuffer = new StringBuffer().append(str2.substring(0, 8)).append(str2.substring(24, 30)).append(str2.substring(9, 13)).append(str2.substring(30)).toString();
                    String str4 = erVar.f1001c;
                    if (a == null) {
                        str3 = stringBuffer;
                    } else {
                        str3 = a;
                    }
                    gd.m956a().m964a(f376g, a3, "11.11.0", TapjoyConfig.TJC_ANALYTICS_SERVICE_URL, stringBuffer, str4);
                    f365U = str3;
                    f366V = a2;
                    f367W = a3;
                    f368X = a4;
                    List arrayList = new ArrayList();
                    if (a5 != null) {
                        for (String trim : a5.split(",")) {
                            String trim2 = trim2.trim();
                            if (trim2.length() > 0) {
                                arrayList.add(trim2);
                            }
                        }
                    }
                    if (!arrayList.isEmpty()) {
                        m218a(arrayList);
                    }
                    b.close();
                    if (!z) {
                        try {
                            long parseLong;
                            if (obj instanceof String) {
                                try {
                                    parseLong = Long.parseLong(((String) obj).trim());
                                } catch (NumberFormatException e3) {
                                    parseLong = 0;
                                }
                            } else {
                                if (obj instanceof Number) {
                                    try {
                                        parseLong = ((Number) obj).longValue();
                                    } catch (NumberFormatException e4) {
                                    }
                                }
                                parseLong = 0;
                            }
                            if (parseLong <= 0) {
                                TapjoyAppSettings.getInstance().removeConnectResult();
                            } else {
                                TapjoyAppSettings.getInstance().saveConnectResultAndParams(str, m245q(), (parseLong * 1000) + C0289y.m1352b());
                            }
                            fd a6 = fd.m836a();
                            Object obj2 = d.get(TapjoyConstants.PREF_SERVER_PROVIDED_CONFIGURATIONS);
                            if (obj2 instanceof Map) {
                                try {
                                    a6.f1044a.m833a((Map) obj2);
                                    a6.m839c().edit().putString(TapjoyConstants.PREF_SERVER_PROVIDED_CONFIGURATIONS, bm.m327a(obj2)).apply();
                                } catch (Exception e5) {
                                }
                            } else if (obj2 == null) {
                                a6.f1044a.m833a(null);
                                a6.m839c().edit().remove(TapjoyConstants.PREF_SERVER_PROVIDED_CONFIGURATIONS).apply();
                            }
                        } catch (IOException e6) {
                            e = e6;
                            closeable = null;
                            try {
                                TapjoyLog.m253v("TapjoyConnect", e.getMessage());
                                dc.m481a(closeable);
                                return false;
                            } catch (Throwable th2) {
                                th = th2;
                                b = closeable;
                                dc.m481a(b);
                                throw th;
                            }
                        } catch (RuntimeException e7) {
                            e2 = e7;
                            b = null;
                            try {
                                TapjoyLog.m253v("TapjoyConnect", e2.getMessage());
                                dc.m481a(b);
                                return false;
                            } catch (Throwable th3) {
                                th = th3;
                                dc.m481a(b);
                                throw th;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                            b = null;
                            dc.m481a(b);
                            throw th;
                        }
                    }
                    dc.m481a(null);
                    return true;
                }
                throw new IllegalArgumentException("The given UUID did not come from 5Rocks.");
            } catch (IOException e8) {
                e = e8;
                closeable = b;
                TapjoyLog.m253v("TapjoyConnect", e.getMessage());
                dc.m481a(closeable);
                return false;
            } catch (RuntimeException e9) {
                e2 = e9;
                TapjoyLog.m253v("TapjoyConnect", e2.getMessage());
                dc.m481a(b);
                return false;
            }
        } catch (IOException e10) {
            e = e10;
            TapjoyLog.m253v("TapjoyConnect", e.getMessage());
            dc.m481a(closeable);
            return false;
        } catch (RuntimeException e11) {
            e2 = e11;
            b = null;
            TapjoyLog.m253v("TapjoyConnect", e2.getMessage());
            dc.m481a(b);
            return false;
        } catch (Throwable th5) {
            th = th5;
            b = null;
            dc.m481a(b);
            throw th;
        }
    }

    private static synchronized void m218a(List list) {
        synchronized (TapjoyConnectCore.class) {
            ah = "";
            for (ApplicationInfo applicationInfo : ae.getInstalledApplications(0)) {
                if ((applicationInfo.flags & 1) != 1 && list.contains(applicationInfo.packageName)) {
                    TapjoyLog.m249d("TapjoyConnect", "MATCH: installed packageName: " + applicationInfo.packageName);
                    if (ah.length() > 0) {
                        ah += ",";
                    }
                    ah += applicationInfo.packageName;
                }
            }
        }
    }

    private static boolean m229c(String str) {
        Closeable b;
        IOException e;
        Throwable th;
        RuntimeException e2;
        try {
            b = bs.m367b(str);
            try {
                if (b.m376a()) {
                    b.mo116s();
                    TapjoyLog.m249d("TapjoyConnect", "Successfully sent completed Pay-Per-Action to Tapjoy server.");
                    b.close();
                    dc.m481a(null);
                    return true;
                }
                b.close();
                dc.m481a(null);
                TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Completed Pay-Per-Action call failed."));
                return false;
            } catch (IOException e3) {
                e = e3;
                try {
                    TapjoyLog.m253v("TapjoyConnect", e.getMessage());
                    dc.m481a(b);
                    TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Completed Pay-Per-Action call failed."));
                    return false;
                } catch (Throwable th2) {
                    th = th2;
                    dc.m481a(b);
                    throw th;
                }
            } catch (RuntimeException e4) {
                e2 = e4;
                TapjoyLog.m253v("TapjoyConnect", e2.getMessage());
                dc.m481a(b);
                TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Completed Pay-Per-Action call failed."));
                return false;
            }
        } catch (IOException e5) {
            e = e5;
            b = null;
            TapjoyLog.m253v("TapjoyConnect", e.getMessage());
            dc.m481a(b);
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Completed Pay-Per-Action call failed."));
            return false;
        } catch (RuntimeException e6) {
            e2 = e6;
            b = null;
            TapjoyLog.m253v("TapjoyConnect", e2.getMessage());
            dc.m481a(b);
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Completed Pay-Per-Action call failed."));
            return false;
        } catch (Throwable th3) {
            th = th3;
            b = null;
            dc.m481a(b);
            throw th;
        }
    }

    public void release() {
        f378i = null;
        f379j = null;
        TapjoyLog.m249d("TapjoyConnect", "Releasing core static instance.");
    }

    public static String getAppID() {
        return f392w;
    }

    public static String getDeviceID() {
        return f385p;
    }

    public static String getUserID() {
        return f348D;
    }

    public static String getHostURL() {
        return getConnectFlagValue(TapjoyConnectFlag.SERVICE_URL);
    }

    public static String getPlacementURL() {
        return getConnectFlagValue(TapjoyConnectFlag.PLACEMENT_URL);
    }

    public static String getConnectURL() {
        return TapjoyConfig.TJC_CONNECT_SERVICE_URL;
    }

    public static String getRedirectDomain() {
        return f362R;
    }

    public static String getCarrierName() {
        return f351G;
    }

    public String getSerial() {
        String obj;
        Exception e;
        try {
            Field declaredField = Class.forName("android.os.Build").getDeclaredField("SERIAL");
            if (!declaredField.isAccessible()) {
                declaredField.setAccessible(true);
            }
            obj = declaredField.get(Build.class).toString();
            try {
                TapjoyLog.m249d("TapjoyConnect", "serial: " + obj);
            } catch (Exception e2) {
                e = e2;
                TapjoyLog.m251e("TapjoyConnect", e.toString());
                return obj;
            }
        } catch (Exception e3) {
            Exception exception = e3;
            obj = null;
            e = exception;
            TapjoyLog.m251e("TapjoyConnect", e.toString());
            return obj;
        }
        return obj;
    }

    public static String getConnectionType() {
        String str = "";
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) f376g.getSystemService("connectivity");
            if (!(connectivityManager == null || connectivityManager.getActiveNetworkInfo() == null)) {
                switch (connectivityManager.getActiveNetworkInfo().getType()) {
                    case 1:
                    case 6:
                        str = TapjoyConstants.TJC_CONNECTION_TYPE_WIFI;
                        break;
                    default:
                        str = TapjoyConstants.TJC_CONNECTION_TYPE_MOBILE;
                        break;
                }
                TapjoyLog.m249d("TapjoyConnect", "connectivity: " + connectivityManager.getActiveNetworkInfo().getType());
                TapjoyLog.m249d("TapjoyConnect", "connection_type: " + str);
            }
            return str;
        } catch (Exception e) {
            Exception exception = e;
            String str2 = str;
            TapjoyLog.m251e("TapjoyConnect", "getConnectionType error: " + exception.toString());
            return str2;
        }
    }

    public static String getConnectionSubType() {
        String subtypeName;
        Exception e;
        String str = "";
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) f376g.getSystemService("connectivity");
            if (connectivityManager == null) {
                return str;
            }
            subtypeName = connectivityManager.getActiveNetworkInfo().getSubtypeName();
            try {
                TapjoyLog.m249d("TapjoyConnect", "connection_sub_type: " + subtypeName);
                return subtypeName;
            } catch (Exception e2) {
                e = e2;
            }
        } catch (Exception e3) {
            Exception exception = e3;
            subtypeName = str;
            e = exception;
            TapjoyLog.m251e("TapjoyConnect", "getConnectionSubType error: " + e.toString());
            return subtypeName;
        }
    }

    private static boolean m231d(String str) {
        for (ApplicationInfo applicationInfo : ae.getInstalledApplications(0)) {
            if (applicationInfo.packageName.startsWith(str)) {
                return true;
            }
        }
        return false;
    }

    private static boolean m223a(String str, String str2) {
        FeatureInfo[] systemAvailableFeatures = ae.getSystemAvailableFeatures();
        int length = systemAvailableFeatures.length;
        int i = 0;
        while (i < length) {
            if (!systemAvailableFeatures[i].name.matches(str)) {
                i++;
            } else if (ae.checkPermission(str2, f376g.getPackageName()) == 0) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    private static String m242n() {
        String SHA256;
        Exception e;
        TapjoyLog.m252i("TapjoyConnect", "generating sessionID...");
        try {
            SHA256 = TapjoyUtil.SHA256((System.currentTimeMillis() / 1000) + f392w + f385p);
            try {
                ab = System.currentTimeMillis();
            } catch (Exception e2) {
                e = e2;
                TapjoyLog.m251e("TapjoyConnect", "unable to generate session id: " + e.toString());
                return SHA256;
            }
        } catch (Exception e3) {
            Exception exception = e3;
            SHA256 = null;
            e = exception;
            TapjoyLog.m251e("TapjoyConnect", "unable to generate session id: " + e.toString());
            return SHA256;
        }
        return SHA256;
    }

    public static Context getContext() {
        return f376g;
    }

    private static String m243o() {
        Object obj = 1;
        if (m241m()) {
            return f372c;
        }
        Object obj2;
        if (f385p == null || f385p.length() <= 0) {
            obj2 = null;
        } else {
            obj2 = 1;
        }
        if (obj2 != null) {
            return f385p;
        }
        if (f386q == null || f386q.length() <= 0) {
            obj2 = null;
        } else {
            obj2 = 1;
        }
        if (obj2 != null) {
            return f386q;
        }
        if (m240l()) {
            return f372c;
        }
        if (f383n == null || f383n.length() <= 0) {
            obj = null;
        }
        if (obj != null) {
            return f383n;
        }
        TapjoyLog.m251e("TapjoyConnect", "Error -- no valid device identifier");
        return null;
    }

    private static String m216a(long j) {
        String str = "";
        try {
            str = TapjoyUtil.SHA256(f392w + ":" + m243o() + ":" + j + ":" + f358N);
        } catch (Exception e) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error in computing verifier value -- " + e.toString()));
        }
        return str;
    }

    public static String getAwardCurrencyVerifier(long time, int amount, String guid) {
        String str = "";
        try {
            str = TapjoyUtil.SHA256(f392w + ":" + m243o() + ":" + time + ":" + f358N + ":" + amount + ":" + guid);
        } catch (Exception e) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error in computing awardCurrencyVerifier -- " + e.toString()));
        }
        return str;
    }

    private static String m217a(long j, String str) {
        String str2 = "";
        try {
            str2 = TapjoyUtil.SHA256(f392w + ":" + m243o() + ":" + j + ":" + f358N + ":" + str);
        } catch (Exception e) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error in computing packageNamesVerifier -- " + e.toString()));
        }
        return str2;
    }

    public boolean isInitialized() {
        return this.ac;
    }

    public static void setPlugin(String name) {
        f360P = name;
    }

    public static void setSDKType(String name) {
        f361Q = name;
    }

    public static void setUserID(String id, TJSetUserIDListener listener) {
        f348D = id;
        f381l = listener;
        TapjoyLog.m249d("TapjoyConnect", "URL parameters: " + getURLParams());
        new Thread(new C01042()).start();
    }

    public static void viewDidClose(String contentViewId) {
        TapjoyLog.m249d("TapjoyConnect", "viewDidClose: " + contentViewId);
        ai.remove(contentViewId);
        ev.f1017e.notifyObservers();
    }

    public static void viewWillOpen(String contentViewId, int viewType) {
        TapjoyLog.m249d("TapjoyConnect", "viewWillOpen: " + contentViewId);
        ai.put(contentViewId, Integer.valueOf(viewType));
    }

    public static boolean isViewOpen() {
        TapjoyLog.m249d("TapjoyConnect", "isViewOpen: " + ai.size());
        return !ai.isEmpty();
    }

    public static boolean isFullScreenViewOpen() {
        for (Integer intValue : ai.values()) {
            switch (intValue.intValue()) {
                case 1:
                case 2:
                    return true;
                default:
            }
        }
        return false;
    }

    public static void setViewShowing(boolean showing) {
        if (showing) {
            ai.put("", Integer.valueOf(1));
        } else {
            ai.clear();
        }
    }

    private static void m226b(String str, String str2) {
        if ((str.equals(TapjoyConnectFlag.SERVICE_URL) || str.equals(TapjoyConnectFlag.PLACEMENT_URL)) && !str2.endsWith("/")) {
            str2 = str2 + "/";
        }
        ag.put(str, str2);
    }

    private static boolean m233e(String str) {
        if (ae.checkPermission(str, f376g.getPackageName()) != 0) {
            return false;
        }
        return true;
    }

    public void actionComplete(String actionID) {
        TapjoyLog.m252i("TapjoyConnect", "actionComplete: " + actionID);
        Map e = m232e();
        TapjoyUtil.safePut(e, TapjoyConstants.TJC_APP_ID, actionID, true);
        e.putAll(getTimeStampAndVerifierParams());
        TapjoyLog.m249d("TapjoyConnect", "PPA URL parameters: " + e);
        new Thread(new PPAThread(this, e)).start();
    }

    public void completeConnectCall() {
        boolean z;
        TapjoyHttpURLResponse responseFromURL;
        TapjoyLog.m249d("TapjoyConnect", "starting connect call...");
        String str = TapjoyConfig.TJC_CONNECT_SERVICE_URL;
        if (getHostURL() != TapjoyConfig.TJC_SERVICE_URL) {
            str = getHostURL();
        }
        if (!isConnected()) {
            String connectResult = TapjoyAppSettings.getInstance().getConnectResult(m245q(), C0289y.m1352b());
            if (connectResult != null && m224a(connectResult, true)) {
                TapjoyLog.m252i("TapjoyConnect", "Connect using stored connect result");
                ad = true;
                m244p();
                if (f380k != null) {
                    f380k.onConnectSuccess();
                }
                ev.f1013a.notifyObservers();
                z = true;
                responseFromURL = f379j.getResponseFromURL(str + TapjoyConstants.TJC_CONNECT_URL_PATH, null, null, getURLParams());
                if (responseFromURL == null && responseFromURL.statusCode == 200) {
                    if (m224a(responseFromURL.response, false)) {
                        TapjoyLog.m252i("TapjoyConnect", "Successfully connected to Tapjoy");
                        ad = true;
                        m244p();
                        for (Entry entry : getGenericURLParams().entrySet()) {
                            TapjoyLog.m249d("TapjoyConnect", ((String) entry.getKey()) + ": " + ((String) entry.getValue()));
                        }
                        if (!z) {
                            if (f380k != null) {
                                f380k.onConnectSuccess();
                            }
                            ev.f1013a.notifyObservers();
                        }
                        ev.f1014b.notifyObservers(Boolean.TRUE);
                    } else {
                        if (!z) {
                            m230d();
                        }
                        ev.f1014b.notifyObservers(Boolean.FALSE);
                    }
                    if (ah.length() > 0) {
                        Map genericURLParams = getGenericURLParams();
                        TapjoyUtil.safePut(genericURLParams, TapjoyConstants.TJC_PACKAGE_NAMES, ah, true);
                        long currentTimeMillis = System.currentTimeMillis() / 1000;
                        String a = m217a(currentTimeMillis, ah);
                        TapjoyUtil.safePut(genericURLParams, "timestamp", String.valueOf(currentTimeMillis), true);
                        TapjoyUtil.safePut(genericURLParams, TapjoyConstants.TJC_VERIFIER, a, true);
                        responseFromURL = new TapjoyURLConnection().getResponseFromURL(getHostURL() + TapjoyConstants.TJC_SDK_LESS_CONNECT, genericURLParams);
                        if (responseFromURL != null && responseFromURL.statusCode == 200) {
                            TapjoyLog.m249d("TapjoyConnect", "Successfully pinged sdkless api.");
                            return;
                        }
                        return;
                    }
                    return;
                }
                if (!z) {
                    m230d();
                }
                ev.f1014b.notifyObservers(Boolean.FALSE);
            }
        }
        z = false;
        responseFromURL = f379j.getResponseFromURL(str + TapjoyConstants.TJC_CONNECT_URL_PATH, null, null, getURLParams());
        if (responseFromURL == null) {
        }
        if (z) {
            m230d();
        }
        ev.f1014b.notifyObservers(Boolean.FALSE);
    }

    private void m244p() {
        TapjoyLog.m249d("TapjoyConnect", "Initializing mediation params");
        try {
            ArrayList arrayList = (ArrayList) ag.get(TapjoyConnectFlag.MEDIATION_CONFIGS);
            if (arrayList != null) {
                TapjoyLog.m252i("TapjoyConnect", "Initializing mediation partners with configs");
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    final TJMediationNetwork tJMediationNetwork = (TJMediationNetwork) it.next();
                    new Thread(this) {
                        final /* synthetic */ TapjoyConnectCore f342b;

                        public final void run() {
                            if (tJMediationNetwork != null) {
                                tJMediationNetwork.init();
                            } else {
                                TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Failed to cast mediation connect flag into TJMediationNetwork type! Make sure to pass in an ArrayList<TJMediationNetwork> type as your mediation configs."));
                            }
                        }
                    }.run();
                }
            }
        } catch (ClassCastException e) {
            TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Invalid type! Make sure to pass in an ArrayList<TJMediationNetwork> type as your mediation configs."));
        }
        String connectFlagValue = getConnectFlagValue(TapjoyConnectFlag.MEDIATION_TIMEOUT);
        if (connectFlagValue != null && !connectFlagValue.isEmpty()) {
            TJMediationSettings.getInstance().setTimeout(connectFlagValue);
            TapjoyLog.m252i("TapjoyConnect", "Setting mediation timeout to " + connectFlagValue + "s");
        }
    }

    public void setCurrencyMultiplier(float multiplier) {
        TapjoyLog.m252i("TapjoyConnect", "setVirtualCurrencyMultiplier: " + multiplier);
        f363S = multiplier;
    }

    public float getCurrencyMultiplier() {
        return f363S;
    }

    public static String getConnectFlagValue(String key) {
        String str = "";
        if (ag == null || ag.get(key) == null) {
            return str;
        }
        return ag.get(key).toString();
    }

    public static String getSecretKey() {
        return f358N;
    }

    public static String getAndroidID() {
        return f383n;
    }

    public static String getSha1MacAddress() {
        String str = null;
        try {
            str = TapjoyUtil.SHA1(f386q);
        } catch (Exception e) {
            TapjoyLog.m251e("TapjoyConnect", "Error generating sha1 of macAddress: " + e.toString());
        }
        return str;
    }

    public static String getMacAddress() {
        return f386q;
    }

    public static float getDeviceScreenDensityScale() {
        return f346B;
    }

    public static String getSupportURL(String currencyId) {
        if (currencyId == null) {
            currencyId = f392w;
        }
        return getHostURL() + "support_requests/new?currency_id=" + currencyId + "&app_id=" + f392w + "&udid=" + f368X + "&language_code=" + Locale.getDefault().getLanguage();
    }

    public static boolean isConnected() {
        return ad;
    }

    public static boolean isUnitTestMode() {
        return getConnectFlagValue("unit_test_mode") == "true";
    }

    private static String m245q() {
        String str = f392w + f393x + f394y + f372c + f385p + f387r;
        try {
            str = TapjoyUtil.SHA1(str);
        } catch (Exception e) {
        }
        return str;
    }

    static /* synthetic */ void m220a(boolean z) {
        if (z) {
            TapjoyLog.m252i("TapjoyConnect", "Set userID is successful");
            if (f381l != null) {
                f381l.onSetUserIDSuccess();
                return;
            }
            return;
        }
        String str = "Failed to set userID";
        TapjoyLog.m250e("TapjoyConnect", new TapjoyErrorMessage(ErrorType.SDK_ERROR, str));
        if (f381l != null) {
            f381l.onSetUserIDFailure(str);
        }
    }
}
