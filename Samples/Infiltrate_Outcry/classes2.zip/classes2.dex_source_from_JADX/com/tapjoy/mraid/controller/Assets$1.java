package com.tapjoy.mraid.controller;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class Assets$1 implements OnClickListener {
    final /* synthetic */ String f1577a;
    final /* synthetic */ Assets f1578b;

    Assets$1(Assets assets, String str) {
        this.f1578b = assets;
        this.f1577a = str;
    }

    public final void onClick(DialogInterface dialog, int id) {
        this.f1578b.storePicture(this.f1577a);
    }
}
