package com.tapjoy.mraid.controller;

import android.content.Context;
import com.tapjoy.TJAdUnitConstants;
import com.tapjoy.TapjoyLog;
import com.tapjoy.mraid.listener.Accel;
import com.tapjoy.mraid.view.MraidView;

public class MraidSensor extends Abstract {
    final int f1587c = TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT;
    private Accel f1588d;
    private float f1589e = 0.0f;
    private float f1590f = 0.0f;
    private float f1591g = 0.0f;

    public MraidSensor(MraidView adView, Context context) {
        super(adView, context);
        this.f1588d = new Accel(context, this);
    }

    public void startTiltListener() {
        this.f1588d.startTrackingTilt();
    }

    public void startShakeListener() {
        this.f1588d.startTrackingShake();
    }

    public void stopTiltListener() {
        this.f1588d.stopTrackingTilt();
    }

    public void stopShakeListener() {
        this.f1588d.stopTrackingShake();
    }

    public void startHeadingListener() {
        this.f1588d.startTrackingHeading();
    }

    public void stopHeadingListener() {
        this.f1588d.stopTrackingHeading();
    }

    public void onShake() {
        this.a.injectMraidJavaScript("mraid.gotShake()");
    }

    public void onTilt(float x, float y, float z) {
        this.f1589e = x;
        this.f1590f = y;
        this.f1591g = z;
        String str = "window.mraidview.fireChangeEvent({ tilt: " + getTilt() + "})";
        TapjoyLog.m249d("MRAID Sensor", str);
        this.a.injectMraidJavaScript(str);
    }

    public String getTilt() {
        String str = "{ x : \"" + this.f1589e + "\", y : \"" + this.f1590f + "\", z : \"" + this.f1591g + "\"}";
        TapjoyLog.m249d("MRAID Sensor", "getTilt: " + str);
        return str;
    }

    public void onHeadingChange(float f) {
        String str = "window.mraidview.fireChangeEvent({ heading: " + ((int) (((double) f) * 57.29577951308232d)) + "});";
        TapjoyLog.m249d("MRAID Sensor", str);
        this.a.injectMraidJavaScript(str);
    }

    public float getHeading() {
        TapjoyLog.m249d("MRAID Sensor", "getHeading: " + this.f1588d.getHeading());
        return this.f1588d.getHeading();
    }

    public void stopAllListeners() {
        this.f1588d.stopAllListeners();
    }
}
