package com.tapjoy.mraid.controller;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import com.tapjoy.TJAdUnitConstants;
import com.tapjoy.TapjoyConnectCore;
import com.tapjoy.TapjoyLog;
import com.tapjoy.mraid.listener.Loc;
import com.tapjoy.mraid.view.MraidView;

public class MraidLocation extends Abstract {
    final int f1580c = TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT;
    private LocationManager f1581d;
    private boolean f1582e = false;
    private Loc f1583f;
    private Loc f1584g;
    private int f1585h;
    private boolean f1586i = false;

    public MraidLocation(MraidView adView, Context context) {
        super(adView, context);
        try {
            this.f1581d = (LocationManager) context.getSystemService("location");
            if (!TapjoyConnectCore.isUnitTestMode()) {
                if (this.f1581d.getProvider("gps") != null) {
                    this.f1583f = new Loc(context, TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT, this, "gps");
                }
                if (this.f1581d.getProvider("network") != null) {
                    this.f1584g = new Loc(context, TJAdUnitConstants.CUSTOM_CLOSE_TIMEOUT, this, "network");
                }
                this.f1582e = true;
            }
        } catch (SecurityException e) {
        }
    }

    public void allowLocationServices(boolean flag) {
        this.f1586i = flag;
    }

    public boolean allowLocationServices() {
        return this.f1586i;
    }

    private static String m1357a(Location location) {
        return "{ lat: " + location.getLatitude() + ", lon: " + location.getLongitude() + ", acc: " + location.getAccuracy() + "}";
    }

    public String getLocation() {
        TapjoyLog.m249d("MRAID Location", "getLocation: hasPermission: " + this.f1582e);
        if (!this.f1582e) {
            return null;
        }
        Location location = null;
        for (String lastKnownLocation : this.f1581d.getProviders(true)) {
            location = this.f1581d.getLastKnownLocation(lastKnownLocation);
            if (location != null) {
                break;
            }
        }
        TapjoyLog.m249d("MRAID Location", "getLocation: " + location);
        if (location != null) {
            return m1357a(location);
        }
        return null;
    }

    public void startLocationListener() {
        if (this.f1585h == 0) {
            if (this.f1584g != null) {
                this.f1584g.start();
            }
            if (this.f1583f != null) {
                this.f1583f.start();
            }
        }
        this.f1585h++;
    }

    public void stopLocationListener() {
        this.f1585h--;
        if (this.f1585h == 0) {
            if (this.f1584g != null) {
                this.f1584g.stop();
            }
            if (this.f1583f != null) {
                this.f1583f.stop();
            }
        }
    }

    public void success(Location loc) {
        String str = "window.mraidview.fireChangeEvent({ location: " + m1357a(loc) + "})";
        TapjoyLog.m249d("MRAID Location", str);
        this.a.injectMraidJavaScript(str);
    }

    public void fail() {
        TapjoyLog.m251e("MRAID Location", "Location can't be determined");
        this.a.injectMraidJavaScript("window.mraidview.fireErrorEvent(\"Location cannot be identified\", \"OrmmaLocationController\")");
    }

    public void stopAllListeners() {
        this.f1585h = 0;
        try {
            this.f1583f.stop();
        } catch (Exception e) {
        }
        try {
            this.f1584g.stop();
        } catch (Exception e2) {
        }
    }
}
