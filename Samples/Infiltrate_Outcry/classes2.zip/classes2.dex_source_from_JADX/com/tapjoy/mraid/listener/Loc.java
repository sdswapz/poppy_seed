package com.tapjoy.mraid.listener;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import com.tapjoy.mraid.controller.MraidLocation;

public class Loc implements LocationListener {
    MraidLocation f1613a;
    private LocationManager f1614b;
    private String f1615c;

    public Loc(Context c, int interval, MraidLocation ormmaLocationController, String provider) {
        this.f1613a = ormmaLocationController;
        this.f1614b = (LocationManager) c.getSystemService("location");
        this.f1615c = provider;
    }

    public void onProviderDisabled(String provider) {
        this.f1613a.fail();
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
        if (status == 0) {
            this.f1613a.fail();
        }
    }

    public void onLocationChanged(Location location) {
        this.f1613a.success(location);
    }

    public void stop() {
        this.f1614b.removeUpdates(this);
    }

    public void onProviderEnabled(String provider) {
    }

    public void start() {
        this.f1614b.requestLocationUpdates(this.f1615c, 0, 0.0f, this);
    }
}
