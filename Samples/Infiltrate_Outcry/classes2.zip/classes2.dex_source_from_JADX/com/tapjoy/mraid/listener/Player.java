package com.tapjoy.mraid.listener;

public interface Player {
    void onComplete();

    void onError();

    void onPrepared();
}
