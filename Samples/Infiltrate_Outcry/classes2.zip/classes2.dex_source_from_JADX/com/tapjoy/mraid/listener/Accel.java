package com.tapjoy.mraid.listener;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.tapjoy.mraid.controller.MraidSensor;
import java.util.List;

public class Accel implements SensorEventListener {
    MraidSensor f1597a;
    int f1598b = 0;
    int f1599c = 0;
    int f1600d = 0;
    private SensorManager f1601e;
    private int f1602f = 3;
    private long f1603g;
    private int f1604h;
    private long f1605i;
    private long f1606j;
    private float[] f1607k;
    private float[] f1608l = new float[]{0.0f, 0.0f, 0.0f};
    private boolean f1609m;
    private boolean f1610n;
    private float[] f1611o = new float[]{0.0f, 0.0f, 0.0f};
    private float[] f1612p = new float[]{-1.0f, -1.0f, -1.0f};

    public Accel(Context ctx, MraidSensor sensorController) {
        this.f1597a = sensorController;
        this.f1601e = (SensorManager) ctx.getSystemService("sensor");
    }

    public void setSensorDelay(int delay) {
        this.f1602f = delay;
        if (this.f1598b > 0 || this.f1599c > 0) {
            stop();
            m1358a();
        }
    }

    public void startTrackingTilt() {
        if (this.f1598b == 0) {
            m1358a();
        }
        this.f1598b++;
    }

    public void stopTrackingTilt() {
        if (this.f1598b > 0) {
            int i = this.f1598b - 1;
            this.f1598b = i;
            if (i == 0) {
                stop();
            }
        }
    }

    public void startTrackingShake() {
        if (this.f1599c == 0) {
            setSensorDelay(1);
            m1358a();
        }
        this.f1599c++;
    }

    public void stopTrackingShake() {
        if (this.f1599c > 0) {
            int i = this.f1599c - 1;
            this.f1599c = i;
            if (i == 0) {
                setSensorDelay(3);
                stop();
            }
        }
    }

    public void startTrackingHeading() {
        if (this.f1600d == 0) {
            List sensorList = this.f1601e.getSensorList(2);
            if (sensorList.size() > 0) {
                this.f1601e.registerListener(this, (Sensor) sensorList.get(0), this.f1602f);
                m1358a();
            }
        }
        this.f1600d++;
    }

    public void stopTrackingHeading() {
        if (this.f1600d > 0) {
            int i = this.f1600d - 1;
            this.f1600d = i;
            if (i == 0) {
                stop();
            }
        }
    }

    private void m1358a() {
        List sensorList = this.f1601e.getSensorList(1);
        if (sensorList.size() > 0) {
            this.f1601e.registerListener(this, (Sensor) sensorList.get(0), this.f1602f);
        }
    }

    public void stop() {
        if (this.f1600d == 0 && this.f1599c == 0 && this.f1598b == 0) {
            this.f1601e.unregisterListener(this);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case 1:
                this.f1611o = this.f1608l;
                this.f1608l = (float[]) event.values.clone();
                this.f1610n = true;
                break;
            case 2:
                this.f1607k = (float[]) event.values.clone();
                this.f1609m = true;
                break;
        }
        if (this.f1607k != null && this.f1608l != null && this.f1610n && this.f1609m) {
            this.f1610n = false;
            this.f1609m = false;
            float[] fArr = new float[9];
            SensorManager.getRotationMatrix(fArr, new float[9], this.f1608l, this.f1607k);
            this.f1612p = new float[3];
            SensorManager.getOrientation(fArr, this.f1612p);
            this.f1597a.onHeadingChange(this.f1612p[0]);
        }
        if (event.sensor.getType() == 1) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.f1603g > 500) {
                this.f1604h = 0;
            }
            if (currentTimeMillis - this.f1605i > 100) {
                if ((Math.abs(((((this.f1608l[0] + this.f1608l[1]) + this.f1608l[2]) - this.f1611o[0]) - this.f1611o[1]) - this.f1611o[2]) / ((float) (currentTimeMillis - this.f1605i))) * 10000.0f > 1000.0f) {
                    int i = this.f1604h + 1;
                    this.f1604h = i;
                    if (i >= 2 && currentTimeMillis - this.f1606j > 2000) {
                        this.f1606j = currentTimeMillis;
                        this.f1604h = 0;
                        this.f1597a.onShake();
                    }
                    this.f1603g = currentTimeMillis;
                }
                this.f1605i = currentTimeMillis;
                this.f1597a.onTilt(this.f1608l[0], this.f1608l[1], this.f1608l[2]);
            }
        }
    }

    public float getHeading() {
        return this.f1612p[0];
    }

    public void stopAllListeners() {
        this.f1598b = 0;
        this.f1599c = 0;
        this.f1600d = 0;
        try {
            stop();
        } catch (Exception e) {
        }
    }
}
