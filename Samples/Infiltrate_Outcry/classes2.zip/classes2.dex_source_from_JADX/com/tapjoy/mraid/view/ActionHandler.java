package com.tapjoy.mraid.view;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.RelativeLayout;
import com.tapjoy.mraid.controller.Abstract;
import com.tapjoy.mraid.controller.Abstract.Dimensions;
import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
import com.tapjoy.mraid.listener.Player;
import com.tapjoy.mraid.util.MraidPlayer;
import com.tapjoy.mraid.util.Utils;
import com.tapjoy.mraid.view.MraidView.Action;
import java.util.HashMap;
import java.util.Map.Entry;

public class ActionHandler extends Activity {
    private HashMap f1635a = new HashMap();
    private RelativeLayout f1636b;

    class C02971 implements Player {
        final /* synthetic */ ActionHandler f1633a;

        C02971(ActionHandler actionHandler) {
            this.f1633a = actionHandler;
        }

        public final void onPrepared() {
        }

        public final void onError() {
            this.f1633a.finish();
        }

        public final void onComplete() {
            this.f1633a.finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        Bundle extras = getIntent().getExtras();
        this.f1636b = new RelativeLayout(this);
        this.f1636b.setLayoutParams(new LayoutParams(-1, -1));
        this.f1636b.setBackgroundColor(-16777216);
        setContentView(this.f1636b);
        String string = extras.getString(MraidView.ACTION_KEY);
        if (string != null) {
            Action valueOf = Action.valueOf(string);
            switch (valueOf) {
                case PLAY_AUDIO:
                    m1362a(extras, valueOf).playAudio();
                    return;
                case PLAY_VIDEO:
                    m1362a(extras, valueOf).playVideo();
                    return;
                default:
                    return;
            }
        }
    }

    private MraidPlayer m1362a(Bundle bundle, Action action) {
        LayoutParams layoutParams;
        PlayerProperties playerProperties = (PlayerProperties) bundle.getParcelable(MraidView.PLAYER_PROPERTIES);
        Dimensions dimensions = (Dimensions) bundle.getParcelable(MraidView.DIMENSIONS);
        View mraidPlayer = new MraidPlayer(this);
        mraidPlayer.setPlayData(playerProperties, Utils.getData(MraidView.EXPAND_URL, bundle));
        if (playerProperties.inline || !playerProperties.startStyle.equals(Abstract.FULL_SCREEN)) {
            layoutParams = new RelativeLayout.LayoutParams(dimensions.width, dimensions.height);
            layoutParams.topMargin = dimensions.f1574y;
            layoutParams.leftMargin = dimensions.f1573x;
        } else {
            getWindow().setFlags(1024, 1024);
            getWindow().setFlags(16777216, 16777216);
            layoutParams = new RelativeLayout.LayoutParams(-1, -1);
            layoutParams.addRule(13);
        }
        mraidPlayer.setLayoutParams(layoutParams);
        this.f1636b.addView(mraidPlayer);
        this.f1635a.put(action, mraidPlayer);
        mraidPlayer.setListener(new C02971(this));
        return mraidPlayer;
    }

    protected void onStop() {
        for (Entry entry : this.f1635a.entrySet()) {
            switch ((Action) entry.getKey()) {
                case PLAY_AUDIO:
                case PLAY_VIDEO:
                    ((MraidPlayer) entry.getValue()).releasePlayer();
                    break;
                default:
                    break;
            }
        }
        super.onStop();
    }
}
