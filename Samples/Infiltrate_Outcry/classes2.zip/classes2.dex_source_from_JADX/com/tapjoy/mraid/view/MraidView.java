package com.tapjoy.mraid.view;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.CustomViewCallback;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyCache;
import com.tapjoy.TapjoyCachedAssetData;
import com.tapjoy.TapjoyErrorMessage;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.TapjoyHttpURLResponse;
import com.tapjoy.TapjoyLog;
import com.tapjoy.TapjoyURLConnection;
import com.tapjoy.TapjoyUtil;
import com.tapjoy.mraid.controller.Abstract;
import com.tapjoy.mraid.controller.Abstract.Dimensions;
import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
import com.tapjoy.mraid.controller.Utility;
import com.tapjoy.mraid.listener.MraidViewListener;
import com.tapjoy.mraid.listener.Player;
import com.tapjoy.mraid.util.MraidPlayer;
import com.tapjoy.mraid.util.Utils;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.regex.Pattern;

public class MraidView extends BasicWebView implements OnGlobalLayoutListener {
    public static final String ACTION_KEY = "action";
    public static final String DIMENSIONS = "expand_dimensions";
    public static final String EXPAND_URL = "expand_url";
    public static final int MRAID_ID = 102;
    public static final String PLAYER_PROPERTIES = "player_properties";
    private static int[] f1667c = new int[]{16843039, 16843040};
    private static final String[] f1668d = new String[]{".mp4", ".3gp", ".mpg"};
    private static MraidPlayer f1669s;
    private VideoView f1670A;
    private CustomViewCallback f1671B;
    private ProgressBar f1672C;
    private Handler f1673D = new C03072(this);
    private boolean f1674E;
    WebViewClient f1675a = new C03083(this);
    WebChromeClient f1676b = new C03124(this);
    private customCloseState f1677e = customCloseState.UNKNOWN;
    private boolean f1678f = false;
    private boolean f1679g;
    private Utility f1680h;
    private float f1681i;
    private int f1682j;
    private boolean f1683k;
    private int f1684l;
    private int f1685m;
    private int f1686n;
    private int f1687o;
    private PLACEMENT_TYPE f1688p;
    private VIEW_STATE f1689q = VIEW_STATE.DEFAULT;
    private MraidViewListener f1690r;
    private int f1691t = 0;
    private int f1692u = 0;
    private Thread f1693v = null;
    private boolean f1694w = false;
    private int f1695x;
    private Context f1696y;
    private RelativeLayout f1697z;

    class C03072 extends Handler {
        final /* synthetic */ MraidView f1646a;

        C03072(MraidView mraidView) {
            this.f1646a = mraidView;
        }

        public final void handleMessage(Message msg) {
            Bundle data = msg.getData();
            String string;
            switch (msg.what) {
                case 1001:
                    switch (this.f1646a.f1689q) {
                        case DEFAULT:
                            if (this.f1646a.f1688p != PLACEMENT_TYPE.INLINE) {
                                MraidView.m1384f(this.f1646a);
                                break;
                            }
                            break;
                        default:
                            break;
                    }
                case 1003:
                    this.f1646a.injectMraidJavaScript("window.mraidview.fireChangeEvent({ state: 'default' });");
                    this.f1646a.setVisibility(0);
                    break;
                case 1006:
                    this.f1646a.f1689q = VIEW_STATE.LEFT_BEHIND;
                    break;
                case 1007:
                    this.f1646a.playVideoImpl(data);
                    break;
                case 1008:
                    this.f1646a.playAudioImpl(data);
                    break;
                case 1009:
                    string = data.getString(String.MESSAGE);
                    this.f1646a.injectMraidJavaScript("window.mraidview.fireErrorEvent(\"" + string + "\", \"" + data.getString(MraidView.ACTION_KEY) + "\")");
                    break;
                case 1010:
                    MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f1646a.getLayoutParams();
                    if (marginLayoutParams != null) {
                        this.f1646a.removeCloseImageButton();
                        marginLayoutParams.height = data.getInt("resize_height", marginLayoutParams.height);
                        marginLayoutParams.width = data.getInt("resize_width", marginLayoutParams.width);
                        string = "window.mraidview.fireChangeEvent({ state: '" + this.f1646a.getState() + "', size: { width: " + ((int) (((float) marginLayoutParams.width) / this.f1646a.f1681i)) + ", height: " + ((int) (((float) marginLayoutParams.height) / this.f1646a.f1681i)) + "}});";
                        TapjoyLog.m249d("MRAIDView", "resize: injection: " + string);
                        this.f1646a.injectMraidJavaScript(string);
                        this.f1646a.requestLayout();
                        MraidView.m1381c(this.f1646a, data.getString("resize_customClosePostition"));
                        if (this.f1646a.f1688p != PLACEMENT_TYPE.INLINE && this.f1646a.f1677e == customCloseState.OPEN) {
                            this.f1646a.showCloseImageButton();
                        }
                    }
                    if (this.f1646a.f1690r != null) {
                        this.f1646a.f1690r.onResize();
                        break;
                    }
                    break;
            }
            super.handleMessage(msg);
        }
    }

    class C03083 extends WebViewClient {
        final /* synthetic */ MraidView f1647a;

        C03083(MraidView mraidView) {
            this.f1647a = mraidView;
        }

        public final void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (this.f1647a.f1690r != null) {
                this.f1647a.f1690r.onPageStarted(view, url, favicon);
            }
        }

        public final void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (this.f1647a.f1690r != null) {
                this.f1647a.f1690r.onReceivedError(view, errorCode, description, failingUrl);
            }
            TapjoyLog.m249d("MRAIDView", "error:" + description);
            super.onReceivedError(view, errorCode, description, failingUrl);
        }

        public final void onPageFinished(WebView view, String url) {
            if (this.f1647a.f1690r != null) {
                this.f1647a.f1690r.onPageFinished(view, url);
            }
            this.f1647a.f1684l = (int) (((float) this.f1647a.getHeight()) / this.f1647a.f1681i);
            this.f1647a.f1685m = (int) (((float) this.f1647a.getWidth()) / this.f1647a.f1681i);
            this.f1647a.f1680h.init(this.f1647a.f1681i);
            this.f1647a.createCloseImageButton();
            if (this.f1647a.f1688p == PLACEMENT_TYPE.INLINE) {
                this.f1647a.removeCloseImageButton();
            }
        }

        public final boolean shouldOverrideUrlLoading(WebView view, String url) {
            TapjoyLog.m249d("MRAIDView", "shouldOverrideUrlLoading: " + url);
            if (this.f1647a.f1690r != null && this.f1647a.f1690r.shouldOverrideUrlLoading(view, url)) {
                return true;
            }
            Uri parse = Uri.parse(url);
            Intent intent;
            try {
                if (url.startsWith("mraid")) {
                    return super.shouldOverrideUrlLoading(view, url);
                }
                if (url.startsWith("tel:")) {
                    intent = new Intent("android.intent.action.DIAL", Uri.parse(url));
                    intent.addFlags(268435456);
                    this.f1647a.getContext().startActivity(intent);
                    return true;
                } else if (url.startsWith("mailto:")) {
                    intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                    intent.addFlags(268435456);
                    this.f1647a.getContext().startActivity(intent);
                    return true;
                } else {
                    intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    intent.setData(parse);
                    intent.addFlags(268435456);
                    this.f1647a.getContext().startActivity(intent);
                    return true;
                }
            } catch (Exception e) {
                try {
                    intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    intent.setData(parse);
                    intent.addFlags(268435456);
                    this.f1647a.getContext().startActivity(intent);
                    return true;
                } catch (Exception e2) {
                    return false;
                }
            }
        }

        public final WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            if (TapjoyCache.getInstance() != null) {
                TapjoyCachedAssetData cachedDataForURL = TapjoyCache.getInstance().getCachedDataForURL(url);
                if (cachedDataForURL == null) {
                    TapjoyLog.m249d("MRAIDView", "No cached data for " + url);
                } else {
                    WebResourceResponse a = MraidView.m1377b(cachedDataForURL);
                    if (a != null) {
                        TapjoyLog.m249d("MRAIDView", "Reading request for " + url + " from cache -- localPath: " + cachedDataForURL.getLocalFilePath());
                        return a;
                    }
                }
            }
            return super.shouldInterceptRequest(view, url);
        }

        public final void onLoadResource(WebView view, String url) {
        }
    }

    class C03124 extends WebChromeClient {
        final /* synthetic */ MraidView f1651a;

        class C03091 implements OnPreparedListener {
            final /* synthetic */ C03124 f1648a;

            C03091(C03124 c03124) {
                this.f1648a = c03124;
            }

            public final void onPrepared(MediaPlayer mp) {
                TapjoyLog.m252i("MRAIDView", "** ON PREPARED **");
                TapjoyLog.m252i("MRAIDView", "isPlaying: " + mp.isPlaying());
                if (!mp.isPlaying()) {
                    mp.start();
                }
            }
        }

        class C03102 implements OnCompletionListener {
            final /* synthetic */ C03124 f1649a;

            C03102(C03124 c03124) {
                this.f1649a = c03124;
            }

            public final void onCompletion(MediaPlayer mp) {
                TapjoyLog.m252i("MRAIDView", "** ON COMPLETION **");
                this.f1649a.f1651a.videoViewCleanup();
            }
        }

        class C03113 implements OnErrorListener {
            final /* synthetic */ C03124 f1650a;

            C03113(C03124 c03124) {
                this.f1650a = c03124;
            }

            public final boolean onError(MediaPlayer mp, int what, int extra) {
                TapjoyLog.m252i("MRAIDView", "** ON ERROR **");
                this.f1650a.f1651a.videoViewCleanup();
                return false;
            }
        }

        C03124(MraidView mraidView) {
            this.f1651a = mraidView;
        }

        public final boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            TapjoyLog.m249d("MRAIDView", message);
            return false;
        }

        public final void onCloseWindow(WebView w) {
            super.onCloseWindow(w);
            MraidView.m1384f(this.f1651a);
        }

        public final void onShowCustomView(View view, CustomViewCallback callback) {
            TapjoyLog.m249d("MRAIDView", "-- onShowCustomView --");
            super.onShowCustomView(view, callback);
            this.f1651a.f1671B = callback;
            if (view instanceof FrameLayout) {
                FrameLayout frameLayout = (FrameLayout) view;
                if ((frameLayout.getFocusedChild() instanceof VideoView) && (this.f1651a.f1696y instanceof Activity)) {
                    Activity activity = (Activity) this.f1651a.f1696y;
                    this.f1651a.f1670A = (VideoView) frameLayout.getFocusedChild();
                    frameLayout.removeView(this.f1651a.f1670A);
                    if (this.f1651a.f1697z == null) {
                        this.f1651a.f1697z = new RelativeLayout(this.f1651a.f1696y);
                        this.f1651a.f1697z.setLayoutParams(new LayoutParams(-1, -1));
                        this.f1651a.f1697z.setBackgroundColor(-16777216);
                    }
                    LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
                    layoutParams.addRule(13);
                    this.f1651a.f1670A.setLayoutParams(layoutParams);
                    this.f1651a.f1672C = new ProgressBar(this.f1651a.f1696y, null, 16842874);
                    this.f1651a.f1672C.setVisibility(0);
                    layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                    layoutParams.addRule(13);
                    this.f1651a.f1672C.setLayoutParams(layoutParams);
                    this.f1651a.f1697z.addView(this.f1651a.f1670A);
                    this.f1651a.f1697z.addView(this.f1651a.f1672C);
                    activity.getWindow().addContentView(this.f1651a.f1697z, new LayoutParams(-1, -1));
                    new Thread(new C0319c(this.f1651a)).start();
                    this.f1651a.setVisibility(8);
                    this.f1651a.f1670A.setOnPreparedListener(new C03091(this));
                    this.f1651a.f1670A.setOnCompletionListener(new C03102(this));
                    this.f1651a.f1670A.setOnErrorListener(new C03113(this));
                    this.f1651a.f1670A.start();
                }
            }
        }

        public final void onHideCustomView() {
            super.onHideCustomView();
        }

        public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            if (this.f1651a.f1690r != null) {
                return this.f1651a.f1690r.onConsoleMessage(consoleMessage);
            }
            return super.onConsoleMessage(consoleMessage);
        }
    }

    class C03135 implements Player {
        final /* synthetic */ MraidView f1652a;

        C03135(MraidView mraidView) {
            this.f1652a = mraidView;
        }

        public final void onPrepared() {
        }

        public final void onError() {
            onComplete();
        }

        public final void onComplete() {
            FrameLayout frameLayout = (FrameLayout) this.f1652a.getRootView().findViewById(101);
            ((ViewGroup) frameLayout.getParent()).removeView(frameLayout);
            this.f1652a.setVisibility(0);
        }
    }

    public enum Action {
        PLAY_AUDIO,
        PLAY_VIDEO
    }

    public enum PLACEMENT_TYPE {
        INLINE,
        INTERSTITIAL
    }

    public enum VIEW_STATE {
        DEFAULT,
        LEFT_BEHIND,
        OPENED
    }

    class C0315a extends AsyncTask {
        TapjoyHttpURLResponse f1657a;
        TapjoyURLConnection f1658b;
        String f1659c;
        final /* synthetic */ MraidView f1660d;

        private C0315a(MraidView mraidView) {
            this.f1660d = mraidView;
        }

        protected final /* synthetic */ Object doInBackground(Object[] objArr) {
            return m1365a((String[]) objArr);
        }

        private Void m1365a(String... strArr) {
            this.f1659c = strArr[0];
            try {
                this.f1658b = new TapjoyURLConnection();
                this.f1657a = this.f1658b.getResponseFromURL(this.f1659c);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected final /* synthetic */ void onPostExecute(Object obj) {
            try {
                if (this.f1657a.statusCode == 0 || this.f1657a.response == null) {
                    TapjoyLog.m250e("MRAIDView", new TapjoyErrorMessage(ErrorType.NETWORK_ERROR, "Connection not properly established"));
                    if (this.f1660d.f1690r != null) {
                        this.f1660d.f1690r.onReceivedError(this.f1660d, 0, "Connection not properly established", this.f1659c);
                    }
                } else if (this.f1657a.statusCode != 302 || this.f1657a.redirectURL == null || this.f1657a.redirectURL.length() <= 0) {
                    this.f1660d.loadDataWithBaseURL(this.f1659c, this.f1657a.response, "text/html", "utf-8", this.f1659c);
                } else {
                    TapjoyLog.m252i("MRAIDView", "302 redirectURL detected: " + this.f1657a.redirectURL);
                    this.f1660d.loadUrlStandard(this.f1657a.redirectURL);
                }
            } catch (Exception e) {
                TapjoyLog.m254w("MRAIDView", "error in loadURL " + e);
                e.printStackTrace();
            }
        }
    }

    class C0316b implements Runnable {
        final /* synthetic */ MraidView f1661a;

        public C0316b(MraidView mraidView) {
            this.f1661a = mraidView;
        }

        public final void run() {
            while (!this.f1661a.f1694w) {
                try {
                    Thread.sleep(250);
                    MraidView.m1391m(this.f1661a);
                } catch (Exception e) {
                }
            }
        }
    }

    class C0319c implements Runnable {
        final /* synthetic */ MraidView f1665a;

        class C03171 implements Runnable {
            final /* synthetic */ C0319c f1662a;

            C03171(C0319c c0319c) {
                this.f1662a = c0319c;
            }

            public final void run() {
                if (this.f1662a.f1665a.f1672C != null) {
                    this.f1662a.f1665a.f1672C.setVisibility(8);
                }
                new Thread(new C0318a(this.f1662a)).start();
            }
        }

        class C0318a implements Runnable {
            final /* synthetic */ C0319c f1663a;
            private boolean f1664b = false;

            public C0318a(C0319c c0319c) {
                this.f1663a = c0319c;
            }

            public final void run() {
                while (this.f1663a.f1665a.f1670A != null) {
                    try {
                        Thread.sleep(100);
                        if (this.f1664b != this.f1663a.f1665a.f1670A.isPlaying()) {
                            this.f1664b = this.f1663a.f1665a.f1670A.isPlaying();
                            this.f1663a.f1665a.loadUrl("javascript:try{Tapjoy.AdUnit.dispatchEvent('" + (this.f1664b ? "videoplay" : "videopause") + "')}catch(e){}");
                        }
                    } catch (Exception e) {
                    }
                }
            }
        }

        public C0319c(MraidView mraidView) {
            this.f1665a = mraidView;
        }

        public final void run() {
            int i = 0;
            while (this.f1665a.f1670A != null && !this.f1665a.f1670A.isPlaying()) {
                try {
                    Thread.sleep(50);
                    i += 50;
                    if (i >= 10000) {
                        break;
                    }
                } catch (Exception e) {
                }
            }
            ((Activity) this.f1665a.f1696y).runOnUiThread(new C03171(this));
        }
    }

    public enum customCloseState {
        HIDDEN,
        OPEN,
        UNKNOWN
    }

    public MraidView(Context context, MraidViewListener listener) {
        super(context);
        setListener(listener);
        this.f1696y = context;
        initialize();
    }

    public void setListener(MraidViewListener listener) {
        this.f1690r = listener;
    }

    public void removeListener() {
        this.f1690r = null;
    }

    public MraidView(Context context) {
        super(context);
        this.f1696y = context;
        initialize();
    }

    public void setPlacementType(PLACEMENT_TYPE type) {
        if (type.equals(PLACEMENT_TYPE.INLINE) || type.equals(PLACEMENT_TYPE.INTERSTITIAL)) {
            this.f1688p = type;
        } else {
            TapjoyLog.m249d("MRAIDView", "Incorrect placement type.");
        }
        if (!type.equals(PLACEMENT_TYPE.INLINE)) {
            return;
        }
        if (this.f1693v == null || !this.f1693v.isAlive()) {
            this.f1693v = new Thread(new C0316b(this));
            this.f1693v.start();
        }
    }

    public PLACEMENT_TYPE getPlacementType() {
        return this.f1688p;
    }

    public void createCloseImageButton() {
        injectMraidJavaScript("window.mraidview.createCss();");
        TapjoyLog.m249d("MRAIDView", "Creating close button.");
    }

    public void removeCloseImageButton() {
        injectMraidJavaScript("document.getElementById(\"closeButton\").style.visibility=\"hidden\";");
        TapjoyLog.m249d("MRAIDView", "Removing close button.");
        this.f1677e = customCloseState.HIDDEN;
    }

    public void showCloseImageButton() {
        injectMraidJavaScript("document.getElementById(\"closeButton\").style.visibility=\"visible\";");
        TapjoyLog.m249d("MRAIDView", "Showing close button.");
        this.f1677e = customCloseState.OPEN;
    }

    public customCloseState getCloseButtonState() {
        return this.f1677e;
    }

    public boolean isMraid() {
        return this.f1678f;
    }

    public void setMaxSize(int w, int h) {
        this.f1680h.setMaxSize(w, h);
    }

    public void injectMraidJavaScript(String str) {
        if (str != null && this.f1678f) {
            loadUrl("javascript:" + str);
        }
    }

    public void loadUrl(final String url) {
        ((Activity) this.f1696y).runOnUiThread(new Runnable(this) {
            final /* synthetic */ MraidView f1645b;

            public final void run() {
                if (!URLUtil.isValidUrl(url)) {
                    this.f1645b.loadDataWithBaseURL(null, "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\"><html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\"><title>Connection not Established</title></head><h2>Connection Not Properly Established</h2><body></body></html>", "text/html", "utf-8", null);
                } else if (!url.startsWith("javascript:")) {
                    new C0315a().execute(new String[]{url});
                } else if (VERSION.SDK_INT >= 19) {
                    try {
                        super.evaluateJavascript(url.replaceFirst("javascript:", ""), null);
                    } catch (Exception e) {
                        TapjoyLog.m251e("MRAIDView", "Exception in evaluateJavascript. Device not supported. " + e.toString());
                    }
                } else {
                    super.loadUrl(url);
                }
            }
        });
    }

    public void loadUrlStandard(String url) {
        super.loadUrl(url);
    }

    public boolean hasMraidTag(String html) {
        return Pattern.compile("<\\s*script[^>]+mraid\\.js").matcher(html).find();
    }

    public void loadDataWithBaseURL(String baseUrl, String data, String mimeType, String encoding, String historyUrl) {
        if (data != null) {
            StringBuffer stringBuffer = new StringBuffer();
            int indexOf = data.indexOf("<html>");
            this.f1678f = false;
            int indexOf2 = data.indexOf("mraid.js");
            if (indexOf2 <= 0 || !hasMraidTag(data)) {
                stringBuffer.append(data);
            } else {
                this.f1678f = true;
                int i = indexOf2;
                while (i >= 0) {
                    if (data.substring(i, i + 7).equals("<script")) {
                        break;
                    }
                    i--;
                }
                i = indexOf2;
                int i2 = 0;
                while (i2 < data.length()) {
                    if (data.substring(indexOf2 + i2, (indexOf2 + i2) + 2).equalsIgnoreCase("/>")) {
                        indexOf2 = (indexOf2 + i2) + 2;
                        break;
                    } else if (data.substring(indexOf2 + i2, (indexOf2 + i2) + 9).equalsIgnoreCase("</script>")) {
                        indexOf2 = (indexOf2 + i2) + 9;
                        break;
                    } else {
                        i2++;
                    }
                }
                String str;
                if (indexOf < 0) {
                    TapjoyLog.m249d("MRAIDView", "wrapping fragment");
                    stringBuffer.append("<html>");
                    stringBuffer.append("<head>");
                    stringBuffer.append("<meta name='viewport' content='user-scalable=no initial-scale=1.0' />");
                    stringBuffer.append("<title>Advertisement</title>");
                    stringBuffer.append("</head>");
                    stringBuffer.append("<body style=\"margin:0; padding:0; overflow:hidden; background-color:transparent;\">");
                    stringBuffer.append("<div align=\"center\"> ");
                    stringBuffer.append(data.substring(0, i));
                    stringBuffer.append("<script type=text/javascript>");
                    str = (String) TapjoyUtil.getResource("mraid.js");
                    if (str == null) {
                        str = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", getContext());
                    }
                    stringBuffer.append(str);
                    stringBuffer.append("</script>");
                    stringBuffer.append(data.substring(indexOf2));
                } else {
                    indexOf2 = data.indexOf("<head>");
                    if (indexOf2 != -1) {
                        str = (String) TapjoyUtil.getResource("mraid.js");
                        if (str == null) {
                            str = TapjoyUtil.copyTextFromJarIntoString("js/mraid.js", getContext());
                        }
                        stringBuffer.append(data.substring(0, indexOf2 + 6));
                        stringBuffer.append("<script type='text/javascript'>");
                        stringBuffer.append(str);
                        stringBuffer.append("</script>");
                        stringBuffer.append(data.substring(indexOf2 + 6));
                    }
                }
                TapjoyLog.m249d("MRAIDView", "injected js/mraid.js");
            }
            super.loadDataWithBaseURL(baseUrl, stringBuffer.toString(), mimeType, encoding, historyUrl);
        }
    }

    public void clearView() {
        reset();
        super.clearView();
    }

    public void reset() {
        invalidate();
        this.f1680h.deleteOldAds();
        this.f1680h.stopAllListeners();
        LayoutParams layoutParams = getLayoutParams();
        if (this.f1674E) {
            layoutParams.height = this.f1686n;
            layoutParams.width = this.f1687o;
        }
        setVisibility(0);
        requestLayout();
    }

    public MraidView(Context context, AttributeSet set) {
        super(context, set);
        initialize();
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(set, f1667c);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(0, -1);
        int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(1, -1);
        if (dimensionPixelSize > 0 && dimensionPixelSize2 > 0) {
            this.f1680h.setMaxSize(dimensionPixelSize, dimensionPixelSize2);
        }
        obtainStyledAttributes.recycle();
    }

    private static WebResourceResponse m1377b(TapjoyCachedAssetData tapjoyCachedAssetData) {
        if (tapjoyCachedAssetData == null) {
            return null;
        }
        try {
            return new WebResourceResponse(tapjoyCachedAssetData.getMimeType(), "UTF-8", new FileInputStream(tapjoyCachedAssetData.getLocalFilePath()));
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    public boolean videoPlaying() {
        return this.f1670A != null;
    }

    public void videoViewCleanup() {
        if (this.f1697z != null) {
            ((ViewGroup) this.f1697z.getParent()).removeView(this.f1697z);
            this.f1697z.setVisibility(8);
            this.f1697z = null;
        }
        try {
            if (this.f1670A != null) {
                this.f1670A.stopPlayback();
            }
            if (this.f1671B != null) {
                this.f1671B.onCustomViewHidden();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.f1670A = null;
        this.f1671B = null;
        if (this != null) {
            setVisibility(0);
        }
        loadUrl("javascript:try{Tapjoy.AdUnit.dispatchEvent('videoend')}catch(e){}");
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void initialize() {
        setPlacementType(PLACEMENT_TYPE.INTERSTITIAL);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
        this.f1681i = displayMetrics.density;
        this.f1679g = false;
        this.f1680h = new Utility(this, getContext());
        addJavascriptInterface(this.f1680h, "MRAIDUtilityControllerBridge");
        setWebViewClient(this.f1675a);
        setWebChromeClient(this.f1676b);
        this.f1682j = getContentViewHeight();
        if (getViewTreeObserver() != null) {
            getViewTreeObserver().addOnGlobalLayoutListener(this);
        }
        WindowManager windowManager = (WindowManager) getContext().getSystemService("window");
        this.f1691t = windowManager.getDefaultDisplay().getWidth();
        this.f1692u = windowManager.getDefaultDisplay().getHeight();
        if (getContext() instanceof Activity) {
            this.f1695x = ((Activity) getContext()).getRequestedOrientation();
        }
    }

    public void addJavascriptObject(Object obj, String name) {
        addJavascriptInterface(obj, name);
    }

    private int getContentViewHeight() {
        View findViewById = getRootView().findViewById(16908290);
        if (findViewById != null) {
            return findViewById.getHeight();
        }
        return -1;
    }

    public VIEW_STATE getViewState() {
        return this.f1689q;
    }

    public String getState() {
        return this.f1689q.toString().toLowerCase();
    }

    public void resizeOrientation(int width, int height, String customClosePosition, boolean allowOffScreen) {
        this.f1691t = width;
        this.f1692u = height;
        TapjoyLog.m249d("MRAIDView", "resizeOrientation to dimensions: " + width + "x" + height);
        Message obtainMessage = this.f1673D.obtainMessage(1010);
        Bundle bundle = new Bundle();
        bundle.putInt("resize_width", width);
        bundle.putInt("resize_height", height);
        bundle.putBoolean("resize_allowOffScreen", allowOffScreen);
        bundle.putString("resize_customClosePostition", customClosePosition);
        obtainMessage.setData(bundle);
        this.f1673D.sendMessage(obtainMessage);
    }

    public void close() {
        this.f1673D.sendEmptyMessage(1001);
    }

    public void show() {
        this.f1673D.sendEmptyMessage(1003);
    }

    public ConnectivityManager getConnectivityManager() {
        return (ConnectivityManager) getContext().getSystemService("connectivity");
    }

    public void open(String url, boolean back, boolean forward, boolean refresh) {
        boolean z;
        String str = null;
        if (m1375a(url)) {
            str = url;
            z = true;
        } else {
            TapjoyHttpURLResponse redirectFromURL = new TapjoyURLConnection().getRedirectFromURL(url);
            TapjoyLog.m252i("MRAIDView", "redirect: " + redirectFromURL.redirectURL + ", " + redirectFromURL.statusCode);
            if (redirectFromURL == null || redirectFromURL.redirectURL == null || redirectFromURL.redirectURL.length() <= 0 || !m1375a(redirectFromURL.redirectURL)) {
                z = false;
            } else {
                str = redirectFromURL.redirectURL;
                z = true;
            }
        }
        if (z) {
            Dimensions dimensions = new Dimensions();
            dimensions.f1573x = 0;
            dimensions.f1574y = 0;
            dimensions.width = getWidth();
            dimensions.height = getHeight();
            playVideo(str, false, true, true, false, dimensions, Abstract.FULL_SCREEN, Abstract.EXIT);
            return;
        }
        TapjoyLog.m249d("MRAIDView", "Mraid Browser open:" + url);
        Intent intent = new Intent(getContext(), Browser.class);
        intent.putExtra(Browser.URL_EXTRA, url);
        intent.putExtra(Browser.SHOW_BACK_EXTRA, back);
        intent.putExtra(Browser.SHOW_FORWARD_EXTRA, forward);
        intent.putExtra(Browser.SHOW_REFRESH_EXTRA, refresh);
        intent.addFlags(268435456);
        getContext().startActivity(intent);
    }

    private static boolean m1375a(String str) {
        for (String endsWith : f1668d) {
            if (str.endsWith(endsWith)) {
                return true;
            }
        }
        return false;
    }

    public void setOrientationProperties(boolean allowOrientationChange, String forceOrientation) {
        int i;
        if (allowOrientationChange) {
            i = -1;
        } else {
            i = forceOrientation.equals(String.LANDSCAPE) ? 0 : 1;
        }
        ((Activity) getContext()).setRequestedOrientation(i);
    }

    public void openMap(String POI, boolean fullscreen) {
        TapjoyLog.m249d("MRAIDView", "Opening Map Url " + POI);
        POI = Utils.convert(POI.trim());
        if (fullscreen) {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(POI));
                intent.setFlags(268435456);
                getContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void playAudioImpl(Bundle data) {
        PlayerProperties playerProperties = (PlayerProperties) data.getParcelable(PLAYER_PROPERTIES);
        String string = data.getString(EXPAND_URL);
        View player = getPlayer();
        player.setPlayData(playerProperties, string);
        player.setLayoutParams(new LayoutParams(1, 1));
        ((ViewGroup) getParent()).addView(player);
        player.playAudio();
    }

    public void playAudio(String url, boolean autoPlay, boolean controls, boolean loop, boolean position, String startStyle, String stopStyle) {
        Object playerProperties = new PlayerProperties();
        playerProperties.setProperties(false, autoPlay, controls, position, loop, startStyle, stopStyle);
        Bundle bundle = new Bundle();
        bundle.putString(ACTION_KEY, Action.PLAY_AUDIO.toString());
        bundle.putString(EXPAND_URL, url);
        bundle.putParcelable(PLAYER_PROPERTIES, playerProperties);
        if (playerProperties.isFullScreen()) {
            try {
                Intent intent = new Intent(getContext(), ActionHandler.class);
                intent.putExtras(bundle);
                getContext().startActivity(intent);
                return;
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
                return;
            }
        }
        Message obtainMessage = this.f1673D.obtainMessage(1008);
        obtainMessage.setData(bundle);
        this.f1673D.sendMessage(obtainMessage);
    }

    public void playVideoImpl(Bundle data) {
        PlayerProperties playerProperties = (PlayerProperties) data.getParcelable(PLAYER_PROPERTIES);
        Dimensions dimensions = (Dimensions) data.getParcelable(DIMENSIONS);
        String string = data.getString(EXPAND_URL);
        View player = getPlayer();
        player.setPlayData(playerProperties, string);
        LayoutParams layoutParams = new FrameLayout.LayoutParams(dimensions.width, dimensions.height);
        layoutParams.topMargin = dimensions.f1573x;
        layoutParams.leftMargin = dimensions.f1574y;
        player.setLayoutParams(layoutParams);
        View frameLayout = new FrameLayout(getContext());
        frameLayout.setId(101);
        frameLayout.setPadding(dimensions.f1573x, dimensions.f1574y, 0, 0);
        ((FrameLayout) getRootView().findViewById(16908290)).addView(frameLayout, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(player);
        setVisibility(4);
        player.setListener(new C03135(this));
        player.playVideo();
    }

    public void playVideo(String url, boolean audioMuted, boolean autoPlay, boolean controls, boolean loop, Dimensions d, String startStyle, String stopStyle) {
        Message obtainMessage = this.f1673D.obtainMessage(1007);
        Object playerProperties = new PlayerProperties();
        playerProperties.setProperties(audioMuted, autoPlay, controls, false, loop, startStyle, stopStyle);
        Bundle bundle = new Bundle();
        bundle.putString(EXPAND_URL, url);
        bundle.putString(ACTION_KEY, Action.PLAY_VIDEO.toString());
        bundle.putParcelable(PLAYER_PROPERTIES, playerProperties);
        if (d != null) {
            bundle.putParcelable(DIMENSIONS, d);
        }
        if (playerProperties.isFullScreen()) {
            try {
                Intent intent = new Intent(getContext(), ActionHandler.class);
                intent.putExtras(bundle);
                intent.setFlags(268435456);
                getContext().startActivity(intent);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        } else if (d != null) {
            obtainMessage.setData(bundle);
            this.f1673D.sendMessage(obtainMessage);
        }
    }

    public boolean isPageFinished() {
        return this.f1679g;
    }

    public void onGlobalLayout() {
        boolean z = this.f1683k;
        if (!this.f1683k && this.f1682j >= 0 && getContentViewHeight() >= 0 && this.f1682j != getContentViewHeight()) {
            z = true;
            injectMraidJavaScript("window.mraidview.fireChangeEvent({ keyboardState: true});");
        }
        if (this.f1683k && this.f1682j >= 0 && getContentViewHeight() >= 0 && this.f1682j == getContentViewHeight()) {
            z = false;
            injectMraidJavaScript("window.mraidview.fireChangeEvent({ keyboardState: false});");
        }
        if (this.f1682j < 0) {
            this.f1682j = getContentViewHeight();
        }
        this.f1683k = z;
    }

    public String getSize() {
        return "{ width: " + ((int) Math.ceil((double) (((float) getWidth()) / this.f1681i))) + ", height: " + ((int) Math.ceil((double) (((float) getHeight()) / this.f1681i))) + "}";
    }

    protected void onAttachedToWindow() {
        if (!this.f1674E) {
            LayoutParams layoutParams = getLayoutParams();
            this.f1686n = layoutParams.height;
            this.f1687o = layoutParams.width;
            this.f1674E = true;
        }
        this.f1694w = false;
        if (this.f1693v == null || !this.f1693v.isAlive()) {
            this.f1693v = new Thread(new C0316b(this));
            this.f1693v.start();
        }
        super.onAttachedToWindow();
    }

    public WebBackForwardList saveState(Bundle outState) {
        return super.saveState(outState);
    }

    public WebBackForwardList restoreState(Bundle savedInstanceState) {
        return super.restoreState(savedInstanceState);
    }

    public void raiseError(String strMsg, String action) {
        Message obtainMessage = this.f1673D.obtainMessage(1009);
        Bundle bundle = new Bundle();
        bundle.putString(String.MESSAGE, strMsg);
        bundle.putString(ACTION_KEY, action);
        obtainMessage.setData(bundle);
        this.f1673D.sendMessage(obtainMessage);
    }

    protected void onDetachedFromWindow() {
        this.f1694w = true;
        this.f1680h.stopAllListeners();
        try {
            if (this.f1670A != null) {
                this.f1670A.stopPlayback();
            }
            if (this.f1671B != null) {
                this.f1671B.onCustomViewHidden();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDetachedFromWindow();
    }

    MraidPlayer getPlayer() {
        if (f1669s != null) {
            f1669s.releasePlayer();
        }
        MraidPlayer mraidPlayer = new MraidPlayer(getContext());
        f1669s = mraidPlayer;
        return mraidPlayer;
    }

    public void setContext(Context context) {
        this.f1696y = context;
    }

    static /* synthetic */ void m1381c(MraidView mraidView, String str) {
        if (str != null) {
            String str2 = null;
            if (str.equals("top-right")) {
                str2 = "document.getElementById(\"closeButton\").style.right = 1;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = mraid.getSize().width -36";
            } else if (str.equals("top-center")) {
                str2 = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 - 18;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = mraid.getSize().width/2 -18";
            } else if (str.equals("top-left")) {
                str2 = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36;document.getElementById(\"closeButton\").style.top = 1;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.left = 1";
            } else if (str.equals("center")) {
                str2 = "document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 - 18;document.getElementById(\"closeButton\").style.top = mraid.getSize().height/2 -18;document.getElementById(\"closeButton\").style.bottom = mraid.getSize().height/2 -18;document.getElementById(\"closeButton\").style.left = mraid.getSize().width/2 -18";
            } else if (str.equals("bottom-right")) {
                str2 = "document.getElementById(\"closeButton\").style.right = 1;document.getElementById(\"closeButton\").style.top = mraid.getSize().height -36;document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.left = mraid.getSize().width -36";
            } else if (str.equals("bottom-left")) {
                str2 = "document.getElementById(\"closeButton\").style.left = 1;document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36;document.getElementById(\"closeButton\").style.top = mraid.getSize().height-36;";
            } else if (str.equals("bottom-center")) {
                str2 = "document.getElementById(\"closeButton\").style.bottom = 1;document.getElementById(\"closeButton\").style.right = mraid.getSize().width -36document.getElementById(\"closeButton\").style.right = mraid.getSize().width/2 -18;document.getElementById(\"closeButton\").style.top = mraid.getSize().height-36;";
            }
            if (str2 != null) {
                mraidView.injectMraidJavaScript(str2);
            } else {
                TapjoyLog.m249d("MRAIDView", "Reposition of close button failed.");
            }
        }
    }

    static /* synthetic */ void m1384f(MraidView mraidView) {
        try {
            if (mraidView.f1690r != null) {
                mraidView.f1690r.onClose();
            }
            ((ViewGroup) mraidView.getParent()).removeView(mraidView);
        } catch (Exception e) {
        }
    }

    static /* synthetic */ void m1391m(MraidView mraidView) {
        WindowManager windowManager = (WindowManager) mraidView.getContext().getSystemService("window");
        int width = windowManager.getDefaultDisplay().getWidth();
        int height = windowManager.getDefaultDisplay().getHeight();
        if (!(width == mraidView.f1691t && height == mraidView.f1692u) && mraidView.getPlacementType() == PLACEMENT_TYPE.INTERSTITIAL) {
            mraidView.resizeOrientation(width, height, "top-right", true);
        }
    }
}
