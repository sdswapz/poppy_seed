package com.tapjoy.mraid.util;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.tapjoy.TapjoyLog;
import com.tapjoy.mraid.controller.Abstract.PlayerProperties;
import com.tapjoy.mraid.listener.Player;

public class MraidPlayer extends VideoView implements OnCompletionListener, OnErrorListener, OnPreparedListener {
    private static String f1618h = "Loading. Please Wait..";
    private static String f1619i = "MRAID Player";
    private PlayerProperties f1620a;
    private AudioManager f1621b = ((AudioManager) getContext().getSystemService("audio"));
    private Player f1622c;
    private int f1623d;
    private String f1624e;
    private RelativeLayout f1625f;
    private ImageButton f1626g;
    private boolean f1627j;

    public MraidPlayer(Context context) {
        super(context);
    }

    public void setPlayData(PlayerProperties properties, String url) {
        this.f1627j = false;
        this.f1620a = properties;
        this.f1624e = url;
    }

    public void playAudio() {
        m1359a();
    }

    public ImageButton getCloseImageButton() {
        return this.f1626g;
    }

    private void m1359a() {
        this.f1624e = this.f1624e.trim();
        this.f1624e = Utils.convert(this.f1624e);
        if (this.f1624e != null || this.f1622c == null) {
            setVideoURI(Uri.parse(this.f1624e));
            TapjoyLog.m249d("player", Uri.parse(this.f1624e).toString());
            if (this.f1620a.showControl()) {
                MediaController mediaController = new MediaController(getContext());
                setMediaController(mediaController);
                mediaController.setAnchorView(this);
            }
            setOnCompletionListener(this);
            setOnErrorListener(this);
            setOnPreparedListener(this);
            if (!(this.f1620a.inline || this.f1620a.inline)) {
                this.f1625f = new RelativeLayout(getContext());
                this.f1625f.setLayoutParams(getLayoutParams());
                View textView = new TextView(getContext());
                textView.setText(f1618h);
                textView.setTextColor(-1);
                LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
                layoutParams.addRule(13);
                this.f1625f.addView(textView, layoutParams);
                ((ViewGroup) getParent()).addView(this.f1625f);
            }
            if (this.f1620a.isAutoPlay()) {
                start();
                return;
            }
            return;
        }
        m1360b();
        this.f1622c.onError();
    }

    public void playVideo() {
        if (this.f1620a.doMute()) {
            this.f1623d = this.f1621b.getStreamVolume(3);
            this.f1621b.setStreamVolume(3, 0, 4);
        }
        m1359a();
    }

    public void setListener(Player listener) {
        this.f1622c = listener;
    }

    public void onCompletion(MediaPlayer mp) {
        if (this.f1620a.doLoop()) {
            start();
        } else if (this.f1620a.exitOnComplete() || this.f1620a.inline) {
            releasePlayer();
        }
    }

    public boolean onError(MediaPlayer mp, int what, int extra) {
        TapjoyLog.m252i(f1619i, "Player error : " + what);
        m1361c();
        m1360b();
        if (this.f1622c != null) {
            this.f1622c.onError();
        }
        return false;
    }

    public void onPrepared(MediaPlayer mp) {
        m1361c();
        if (this.f1622c != null) {
            this.f1622c.onPrepared();
        }
    }

    private void m1360b() {
        ViewGroup viewGroup = (ViewGroup) getParent();
        if (viewGroup != null) {
            viewGroup.removeAllViews();
        }
    }

    public void releasePlayer() {
        if (!this.f1627j) {
            this.f1627j = true;
            stopPlayback();
            m1360b();
            if (this.f1620a != null && this.f1620a.doMute()) {
                this.f1621b.setStreamVolume(3, this.f1623d, 4);
            }
            if (this.f1622c != null) {
                this.f1622c.onComplete();
            }
        }
    }

    private void m1361c() {
        if (this.f1625f != null) {
            ((ViewGroup) getParent()).removeView(this.f1625f);
        }
    }
}
