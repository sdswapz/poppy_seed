package com.tapjoy.mraid.util;

public enum TransitionStringEnum {
    DEFAULT("default"),
    DISSOLVE("dissolve"),
    FADE("fade"),
    ROLL("roll"),
    SLIDE("slide"),
    ZOOM("zoom"),
    NONE("none");
    
    private String f1632a;

    private TransitionStringEnum(String text) {
        this.f1632a = text;
    }

    public final String getText() {
        return this.f1632a;
    }

    public static TransitionStringEnum fromString(String text) {
        if (text != null) {
            for (TransitionStringEnum transitionStringEnum : values()) {
                if (text.equalsIgnoreCase(transitionStringEnum.f1632a)) {
                    return transitionStringEnum;
                }
            }
        }
        return null;
    }
}
