package com.tapjoy.mraid.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.tapjoy.mraid.controller.Network;

public class NetworkBroadcastReceiver extends BroadcastReceiver {
    private Network f1630a;

    public NetworkBroadcastReceiver(Network mraidNetworkController) {
        this.f1630a = mraidNetworkController;
    }

    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            this.f1630a.onConnectionChanged();
        }
    }
}
