package com.tapjoy.mraid.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.tapjoy.mraid.controller.Display;

public class ConfigBroadcastReceiver extends BroadcastReceiver {
    private Display f1616a;
    private int f1617b = this.f1616a.getOrientation();

    public ConfigBroadcastReceiver(Display mraidDisplayController) {
        this.f1616a = mraidDisplayController;
    }

    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.CONFIGURATION_CHANGED")) {
            int orientation = this.f1616a.getOrientation();
            if (orientation != this.f1617b) {
                this.f1617b = orientation;
                this.f1616a.onOrientationChanged(this.f1617b);
            }
        }
    }
}
