package com.tapjoy;

import android.content.Context;
import android.os.Looper;
import com.tapjoy.internal.C0288x;
import com.tapjoy.internal.be;
import com.tapjoy.internal.ct;
import com.tapjoy.internal.fz;
import com.tapjoy.internal.fz.C02201;
import com.tapjoy.internal.gi;

public class TJPlacementManager {
    private static final be f303a = be.m316a();
    private static int f304b = 0;
    private static int f305c = 0;
    private static int f306d = 3;
    private static int f307e = 3;

    public static TJPlacement createPlacement(Context context, String placementName, boolean initiatedBySdk, TJPlacementListener listener) {
        TJCorePlacement a = m206a(placementName, null, null, initiatedBySdk);
        a.f252j = initiatedBySdk;
        a.f245c.setPlacementType(TapjoyConstants.TJC_SDK_PLACEMENT);
        a.setContext(context);
        return new TJPlacement(a, listener);
    }

    public static TJPlacement m207a(String str, String str2, String str3, TJPlacementListener tJPlacementListener) {
        TJPlacement tJPlacement;
        synchronized (f303a) {
            tJPlacement = new TJPlacement(m206a(str, str2, str3, false), tJPlacementListener);
        }
        return tJPlacement;
    }

    static TJCorePlacement m205a(String str) {
        TJCorePlacement tJCorePlacement;
        synchronized (f303a) {
            tJCorePlacement = (TJCorePlacement) f303a.get(str);
        }
        return tJCorePlacement;
    }

    public static void setCachedPlacementLimit(int limit) {
        f306d = limit;
    }

    public static void setPreRenderedPlacementLimit(int limit) {
        f307e = limit;
    }

    public static int getCachedPlacementLimit() {
        return f306d;
    }

    public static int getPreRenderedPlacementLimit() {
        return f307e;
    }

    public static int getCachedPlacementCount() {
        return f304b;
    }

    public static int getPreRenderedPlacementCount() {
        return f305c;
    }

    public static boolean canCachePlacement() {
        return getCachedPlacementCount() < getCachedPlacementLimit();
    }

    public static boolean canPreRenderPlacement() {
        return getPreRenderedPlacementCount() < getPreRenderedPlacementLimit();
    }

    public static void incrementPlacementCacheCount() {
        int i = f304b + 1;
        f304b = i;
        if (i > f306d) {
            f304b = f306d;
        }
        printPlacementCacheInformation();
    }

    public static void decrementPlacementCacheCount() {
        int i = f304b - 1;
        f304b = i;
        if (i < 0) {
            f304b = 0;
        }
        printPlacementCacheInformation();
    }

    public static void incrementPlacementPreRenderCount() {
        int i = f305c + 1;
        f305c = i;
        if (i > f307e) {
            f305c = f307e;
        }
    }

    public static void decrementPlacementPreRenderCount() {
        int i = f305c - 1;
        f305c = i;
        if (i < 0) {
            f305c = 0;
        }
    }

    public static void printPlacementCacheInformation() {
        TapjoyLog.m252i("TJPlacementManager", "Space available in placement cache: " + f304b + " out of " + f306d);
    }

    public static void printPlacementPreRenderInformation() {
        TapjoyLog.m252i("TJPlacementManager", "Space available for placement pre-render: " + f305c + " out of " + f307e);
    }

    public static void dismissContentShowing(boolean dismissAd) {
        if (dismissAd) {
            TJAdUnitActivity.m142a();
        }
        gi giVar = gi.f1222a;
        if (giVar != null) {
            giVar.m1081c();
        }
        fz fzVar = fz.f1121a;
        if (fzVar != null) {
            Object obj;
            Runnable c02201 = new C02201(fzVar);
            Looper mainLooper = Looper.getMainLooper();
            if (mainLooper == null || mainLooper.getThread() != Thread.currentThread()) {
                obj = null;
            } else {
                obj = 1;
            }
            if (obj != null) {
                c02201.run();
            } else {
                C0288x.m1347a().post(c02201);
            }
        }
    }

    static TJCorePlacement m206a(String str, String str2, String str3, boolean z) {
        TJCorePlacement a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(z ? "!SYSTEM!" : "");
        stringBuilder.append(!ct.m463c(str) ? str : "");
        if (ct.m463c(str2)) {
            str2 = "";
        }
        stringBuilder.append(str2);
        if (ct.m463c(str3)) {
            str3 = "";
        }
        stringBuilder.append(str3);
        String stringBuilder2 = stringBuilder.toString();
        TapjoyLog.m249d("TJPlacementManager", "TJCorePlacement key=" + stringBuilder2);
        synchronized (f303a) {
            a = m205a(stringBuilder2);
            if (a == null) {
                a = new TJCorePlacement(str, stringBuilder2);
                f303a.put(stringBuilder2, a);
                TapjoyLog.m249d("TJPlacementManager", "Created TJCorePlacement with GUID: " + a.f246d);
            }
        }
        return a;
    }
}
