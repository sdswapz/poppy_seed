package com.tapjoy;

import com.tapjoy.internal.be;
import com.tapjoy.internal.fp;
import com.tapjoy.internal.fq;
import com.tapjoy.internal.fs;
import com.tapjoy.internal.gd;
import com.tapjoy.internal.ge;

public class FiveRocksIntegration {
    private static be f91a = new be();

    static class C00581 implements fs {
        C00581() {
        }

        public final void mo36a(String str) {
        }

        public final void mo39b(String str) {
            synchronized (FiveRocksIntegration.f91a) {
                TJPlacement tJPlacement = (TJPlacement) FiveRocksIntegration.f91a.get(str);
            }
            if (tJPlacement != null && tJPlacement.a != null) {
                tJPlacement.a.onContentReady(tJPlacement);
            }
        }

        public final void mo40c(String str) {
            synchronized (FiveRocksIntegration.f91a) {
                TJPlacement tJPlacement = (TJPlacement) FiveRocksIntegration.f91a.get(str);
            }
            if (tJPlacement != null && tJPlacement.a != null) {
                tJPlacement.a.onContentShow(tJPlacement);
            }
        }

        public final void mo41d(String str) {
        }

        public final void mo37a(String str, fp fpVar) {
            if (fpVar != null) {
                fpVar.mo237a(m97e(str));
            }
        }

        public final void mo38a(String str, String str2, fp fpVar) {
            if (fpVar != null) {
                fpVar.mo237a(m97e(str));
            }
            synchronized (FiveRocksIntegration.f91a) {
                TJPlacement tJPlacement = (TJPlacement) FiveRocksIntegration.f91a.get(str);
            }
            if (tJPlacement != null) {
                TapjoyConnectCore.viewDidClose(str2);
                if (tJPlacement.a != null) {
                    tJPlacement.a.onContentDismiss(tJPlacement);
                }
            }
        }

        private fq m97e(final String str) {
            return new fq(this) {
                final /* synthetic */ C00581 f90b;

                public final void mo34a(final String str, String str2) {
                    synchronized (FiveRocksIntegration.f91a) {
                        TJPlacement tJPlacement = (TJPlacement) FiveRocksIntegration.f91a.get(str);
                    }
                    if (tJPlacement != null && tJPlacement.a != null) {
                        tJPlacement.a.onPurchaseRequest(tJPlacement, new TJActionRequest(this) {
                            final /* synthetic */ C00571 f85b;

                            public final String getRequestId() {
                                return str;
                            }

                            public final String getToken() {
                                return null;
                            }

                            public final void completed() {
                            }

                            public final void cancelled() {
                            }
                        }, str2);
                    }
                }

                public final void mo35a(final String str, String str2, int i, final String str3) {
                    synchronized (FiveRocksIntegration.f91a) {
                        TJPlacement tJPlacement = (TJPlacement) FiveRocksIntegration.f91a.get(str);
                    }
                    if (tJPlacement != null && tJPlacement.a != null) {
                        tJPlacement.a.onRewardRequest(tJPlacement, new TJActionRequest(this) {
                            final /* synthetic */ C00571 f88c;

                            public final String getRequestId() {
                                return str;
                            }

                            public final String getToken() {
                                return str3;
                            }

                            public final void completed() {
                            }

                            public final void cancelled() {
                            }
                        }, str2, i);
                    }
                }
            };
        }
    }

    public static void addPlacementCallback(String placement, TJPlacement p) {
        synchronized (f91a) {
            f91a.put(placement, p);
        }
    }

    public static void m104a() {
        gd a = gd.m956a();
        if (!a.f1162c) {
            a.f1162c = true;
        }
        fs c00581 = new C00581();
        gd.m956a().f1175p = ge.m978a(c00581);
    }
}
