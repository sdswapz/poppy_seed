package com.tapjoy;

public class TJVideoStatus {
    public static final int STATUS_MEDIA_STORAGE_UNAVAILABLE = 1;
    public static final int STATUS_NETWORK_ERROR_ON_INIT_VIDEOS = 2;
    public static final int STATUS_UNABLE_TO_PLAY_VIDEO = 3;
}
