package com.tapjoy;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import java.lang.reflect.Method;

public class TapjoyAdIdClient {
    private Context f310a;
    private String f311b;
    private boolean f312c;

    public TapjoyAdIdClient(Context context) {
        this.f310a = context;
    }

    public boolean setupAdIdInfo() {
        try {
            boolean z;
            Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(this.f310a);
            this.f311b = advertisingIdInfo.getId();
            if (advertisingIdInfo.isLimitAdTrackingEnabled()) {
                z = false;
            } else {
                z = true;
            }
            this.f312c = z;
            return true;
        } catch (Exception e) {
            return false;
        } catch (Error e2) {
            return false;
        }
    }

    public boolean setupAdIdInfoReflection() {
        try {
            Class cls = Class.forName("com.google.android.gms.ads.identifier.AdvertisingIdClient");
            Method method = cls.getMethod("getAdvertisingIdInfo", new Class[]{Context.class});
            TapjoyLog.m249d("TapjoyAdIdClient", "Found method: " + method);
            Object invoke = method.invoke(cls, new Object[]{this.f310a});
            Method method2 = invoke.getClass().getMethod("isLimitAdTrackingEnabled", new Class[0]);
            Method method3 = invoke.getClass().getMethod("getId", new Class[0]);
            this.f312c = !((Boolean) method2.invoke(invoke, new Object[0])).booleanValue();
            this.f311b = (String) method3.invoke(invoke, new Object[0]);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getAdvertisingId() {
        return this.f311b;
    }

    public boolean isAdTrackingEnabled() {
        return this.f312c;
    }
}
