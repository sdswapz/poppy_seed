package com.tapjoy;

import org.json.JSONObject;

public interface TJWebViewJSInterfaceListener {
    void onDispatchMethod(String str, JSONObject jSONObject);
}
