package com.tapjoy;

public interface TJConnectListener {
    void onConnectFailure();

    void onConnectSuccess();
}
