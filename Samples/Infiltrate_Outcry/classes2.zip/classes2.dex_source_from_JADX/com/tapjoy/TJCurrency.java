package com.tapjoy;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.eu;
import java.util.Map;
import java.util.UUID;
import org.w3c.dom.Document;

public class TJCurrency {
    private static TJGetCurrencyBalanceListener f272d;
    private static TJSpendCurrencyListener f273e;
    private static TJAwardCurrencyListener f274f;
    private static TJEarnedCurrencyListener f275g;
    String f276a = null;
    int f277b = 0;
    Context f278c;

    class C00961 implements Runnable {
        final /* synthetic */ TJCurrency f269a;

        C00961(TJCurrency tJCurrency) {
            this.f269a = tJCurrency;
        }

        public final void run() {
            this.f269a.m197a(new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + TapjoyConstants.TJC_GET_CURRENCY_BALANCE_URL_PATH, TapjoyConnectCore.getURLParams()));
        }
    }

    class C00972 implements Runnable {
        final /* synthetic */ TJCurrency f270a;

        C00972(TJCurrency tJCurrency) {
            this.f270a = tJCurrency;
        }

        public final void run() {
            Map uRLParams = TapjoyConnectCore.getURLParams();
            TapjoyUtil.safePut(uRLParams, TapjoyConstants.TJC_CURRENCY, this.f270a.f276a, true);
            this.f270a.m199b(new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + TapjoyConstants.TJC_SPEND_CURRENCY_URL_PATH, uRLParams));
        }
    }

    class C00983 implements Runnable {
        final /* synthetic */ TJCurrency f271a;

        C00983(TJCurrency tJCurrency) {
            this.f271a = tJCurrency;
        }

        public final void run() {
            String uuid = UUID.randomUUID().toString();
            long currentTimeMillis = System.currentTimeMillis() / 1000;
            Map genericURLParams = TapjoyConnectCore.getGenericURLParams();
            TapjoyUtil.safePut(genericURLParams, TapjoyConstants.TJC_CURRENCY, String.valueOf(this.f271a.f277b), true);
            TapjoyUtil.safePut(genericURLParams, TapjoyConstants.TJC_GUID, uuid, true);
            TapjoyUtil.safePut(genericURLParams, "timestamp", String.valueOf(currentTimeMillis), true);
            TapjoyUtil.safePut(genericURLParams, TapjoyConstants.TJC_VERIFIER, TapjoyConnectCore.getAwardCurrencyVerifier(currentTimeMillis, this.f271a.f277b, uuid), true);
            this.f271a.m201c(new TapjoyURLConnection().getResponseFromURL(TapjoyConnectCore.getHostURL() + TapjoyConstants.TJC_AWARD_CURRENCY_URL_PATH, genericURLParams));
        }
    }

    public TJCurrency(Context applicationContext) {
        this.f278c = applicationContext;
    }

    public void saveCurrencyBalance(int balance) {
        Editor edit = this.f278c.getSharedPreferences(TapjoyConstants.TJC_PREFERENCE, 0).edit();
        edit.putInt(TapjoyConstants.PREF_LAST_CURRENCY_BALANCE, balance);
        edit.commit();
    }

    public int getLocalCurrencyBalance() {
        return this.f278c.getSharedPreferences(TapjoyConstants.TJC_PREFERENCE, 0).getInt(TapjoyConstants.PREF_LAST_CURRENCY_BALANCE, -9999);
    }

    public void getCurrencyBalance(TJGetCurrencyBalanceListener listener) {
        f272d = listener;
        new Thread(new C00961(this)).start();
    }

    public void spendCurrency(int amount, TJSpendCurrencyListener listener) {
        if (amount < 0) {
            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Amount must be a positive number for the spendCurrency API"));
            return;
        }
        this.f276a = String.valueOf(amount);
        f273e = listener;
        new Thread(new C00972(this)).start();
    }

    public void awardCurrency(int amount, TJAwardCurrencyListener listener) {
        if (amount < 0) {
            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Amount must be a positive number for the awardCurrency API"));
            return;
        }
        this.f277b = amount;
        f274f = listener;
        new Thread(new C00983(this)).start();
    }

    public void setEarnedCurrencyListener(TJEarnedCurrencyListener listener) {
        f275g = listener;
    }

    private synchronized void m197a(TapjoyHttpURLResponse tapjoyHttpURLResponse) {
        if (tapjoyHttpURLResponse.response != null) {
            Document buildDocument = TapjoyUtil.buildDocument(tapjoyHttpURLResponse.response);
            if (buildDocument != null) {
                String nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Success"));
                if (nodeTrimValue == null || !nodeTrimValue.equals("true")) {
                    TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "getCurrencyBalance response is invalid -- missing <Success> tag."));
                } else {
                    nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("TapPoints"));
                    String nodeTrimValue2 = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("CurrencyName"));
                    if (nodeTrimValue == null || nodeTrimValue2 == null) {
                        TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "getCurrencyBalance response is invalid -- missing tags."));
                    } else {
                        try {
                            int parseInt = Integer.parseInt(nodeTrimValue);
                            int localCurrencyBalance = getLocalCurrencyBalance();
                            if (!(f275g == null || localCurrencyBalance == -9999 || parseInt <= localCurrencyBalance)) {
                                TapjoyLog.m252i("TJCurrency", "earned: " + (parseInt - localCurrencyBalance));
                                f275g.onEarnedCurrency(nodeTrimValue2, parseInt - localCurrencyBalance);
                            }
                            saveCurrencyBalance(parseInt);
                            if (f272d != null) {
                                f272d.onGetCurrencyBalanceResponse(nodeTrimValue2, parseInt);
                            }
                        } catch (Exception e) {
                            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "Error parsing XML and calling listener: " + e.toString()));
                        }
                    }
                }
            }
            if (f272d != null) {
                f272d.onGetCurrencyBalanceResponseFailure("Failed to get currency balance");
            }
        } else {
            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "getCurrencyBalance response is NULL"));
            if (f272d != null) {
                f272d.onGetCurrencyBalanceResponseFailure("Failed to get currency balance");
            }
        }
    }

    private synchronized void m199b(TapjoyHttpURLResponse tapjoyHttpURLResponse) {
        String str = "Failed to spend currency";
        if (tapjoyHttpURLResponse.response != null) {
            Document buildDocument = TapjoyUtil.buildDocument(tapjoyHttpURLResponse.response);
            if (buildDocument != null) {
                String nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Success"));
                if (nodeTrimValue == null || !nodeTrimValue.equals("true")) {
                    if (nodeTrimValue != null) {
                        if (nodeTrimValue.endsWith("false")) {
                            str = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Message"));
                            TapjoyLog.m252i("TJCurrency", str);
                            if ("BalanceTooLowError".equals(TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("MessageCode")))) {
                                eu.m808a();
                            }
                        }
                    }
                    TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "spendCurrency response is invalid -- missing <Success> tag."));
                } else {
                    nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("TapPoints"));
                    String nodeTrimValue2 = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("CurrencyName"));
                    if (nodeTrimValue == null || nodeTrimValue2 == null) {
                        TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "spendCurrency response is invalid -- missing tags."));
                    } else {
                        int parseInt = Integer.parseInt(nodeTrimValue);
                        saveCurrencyBalance(parseInt);
                        if (f273e != null) {
                            f273e.onSpendCurrencyResponse(nodeTrimValue2, parseInt);
                        }
                    }
                }
            }
            if (f273e != null) {
                f273e.onSpendCurrencyResponseFailure(str);
            }
        } else {
            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "spendCurrency response is NULL"));
            if (f273e != null) {
                f273e.onSpendCurrencyResponseFailure(str);
            }
        }
    }

    private synchronized void m201c(TapjoyHttpURLResponse tapjoyHttpURLResponse) {
        String str = "Failed to award currency";
        if (tapjoyHttpURLResponse.response != null) {
            Document buildDocument = TapjoyUtil.buildDocument(tapjoyHttpURLResponse.response);
            if (buildDocument != null) {
                String nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Success"));
                if (nodeTrimValue == null || !nodeTrimValue.equals("true")) {
                    if (nodeTrimValue != null) {
                        if (nodeTrimValue.endsWith("false")) {
                            str = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("Message"));
                            TapjoyLog.m252i("TJCurrency", str);
                        }
                    }
                    TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "awardCurrency response is invalid -- missing <Success> tag."));
                } else {
                    nodeTrimValue = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("TapPoints"));
                    String nodeTrimValue2 = TapjoyUtil.getNodeTrimValue(buildDocument.getElementsByTagName("CurrencyName"));
                    if (nodeTrimValue == null || nodeTrimValue2 == null) {
                        TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "awardCurrency response is invalid -- missing tags."));
                    } else {
                        int parseInt = Integer.parseInt(nodeTrimValue);
                        saveCurrencyBalance(parseInt);
                        if (f274f != null) {
                            f274f.onAwardCurrencyResponse(nodeTrimValue2, parseInt);
                        }
                    }
                }
            }
            if (f274f != null) {
                f274f.onAwardCurrencyResponseFailure(str);
            }
        } else {
            TapjoyLog.m250e("TJCurrency", new TapjoyErrorMessage(ErrorType.SERVER_ERROR, "awardCurrency response is NULL"));
            if (f274f != null) {
                f274f.onAwardCurrencyResponseFailure(str);
            }
        }
    }
}
