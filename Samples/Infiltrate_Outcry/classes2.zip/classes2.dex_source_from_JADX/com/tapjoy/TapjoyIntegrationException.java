package com.tapjoy;

public class TapjoyIntegrationException extends TapjoyException {
    public TapjoyIntegrationException(String message) {
        super(message);
    }
}
