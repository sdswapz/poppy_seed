package com.tapjoy;

import android.annotation.TargetApi;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.WebView;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.ga;
import com.tapjoy.internal.gd;

public class TapjoyLog {
    private static final String f411a = TapjoyLog.class.getSimpleName();
    private static int f412b = 6;
    private static int f413c = 4;
    private static int f414d = 2;
    private static boolean f415e = false;
    private static int f416f = f412b;

    static class C01071 implements Runnable {
        C01071() {
        }

        public final void run() {
            TapjoyLog.m249d(TapjoyLog.f411a, "Enabling WebView debugging");
            WebView.setWebContentsDebuggingEnabled(true);
        }
    }

    public static void setDebugEnabled(boolean enable) {
        boolean z;
        f415e = enable;
        gd a = gd.m956a();
        if (ga.f1141a != enable) {
            ga.f1141a = enable;
            if (enable) {
                ga.m936a("The debug mode has been enabled");
            } else {
                ga.m936a("The debug mode has been disabled");
            }
            z = true;
        } else {
            z = false;
        }
        if (z && enable && a.f1170k) {
            a.f1168i.m946a();
        }
        if (f415e) {
            m248a(TapjoyConstants.LOG_LEVEL_DEBUG_ON, false);
        } else {
            m248a(TapjoyConstants.LOG_LEVEL_DEBUG_OFF, false);
        }
    }

    public static void setInternalLogging(boolean isInternalLogging) {
        if (isInternalLogging) {
            m248a(TapjoyConstants.LOG_LEVEL_INTERNAL, true);
        }
    }

    @TargetApi(19)
    static void m248a(String str, boolean z) {
        if (z || TapjoyAppSettings.getInstance() == null || TapjoyAppSettings.getInstance().f314a == null) {
            if (str.equals(TapjoyConstants.LOG_LEVEL_INTERNAL)) {
                f416f = f414d;
                if (VERSION.SDK_INT >= 19) {
                    new Handler(Looper.getMainLooper()).post(new C01071());
                }
            } else if (str.equals(TapjoyConstants.LOG_LEVEL_DEBUG_ON)) {
                f416f = f413c;
            } else if (str.equals(TapjoyConstants.LOG_LEVEL_DEBUG_OFF)) {
                f416f = f412b;
            } else {
                m249d(f411a, "unrecognized loggingLevel: " + str);
                f416f = f412b;
            }
            m249d(f411a, "logThreshold=" + f416f);
            return;
        }
        m249d(f411a, "setLoggingLevel -- log setting already persisted");
    }

    public static boolean isLoggingEnabled() {
        return f415e;
    }

    public static void m252i(String tag, String msg) {
        m247a(4, tag, msg);
    }

    public static void m251e(String tag, String msg) {
        m250e(tag, new TapjoyErrorMessage(ErrorType.INTERNAL_ERROR, msg));
    }

    public static void m250e(String tag, TapjoyErrorMessage error) {
        if (error == null) {
            return;
        }
        if (f416f == f414d || error.getType() != ErrorType.INTERNAL_ERROR) {
            m247a(6, tag, error.toString());
        }
    }

    public static void m254w(String tag, String msg) {
        m247a(5, tag, msg);
    }

    public static void m249d(String tag, String msg) {
        m247a(3, tag, msg);
    }

    public static void m253v(String tag, String msg) {
        m247a(2, tag, msg);
    }

    private static void m247a(int i, String str, String str2) {
        String str3 = f411a + ":" + str;
        if (f416f > i) {
            return;
        }
        if (str2.length() > 4096) {
            for (int i2 = 0; i2 <= str2.length() / 4096; i2++) {
                int i3 = i2 * 4096;
                int i4 = (i2 + 1) * 4096;
                if (i4 > str2.length()) {
                    i4 = str2.length();
                }
                Log.println(i, str3, str2.substring(i3, i4));
            }
            return;
        }
        Log.println(i, str3, str2);
    }
}
