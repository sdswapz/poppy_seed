package com.tapjoy;

public class TapjoyConfig {
    public static final String TJC_ANALYTICS_SERVICE_URL = "https://rpc.tapjoy.com/";
    public static final String TJC_CONNECT_SERVICE_URL = "https://connect.tapjoy.com/";
    public static final String TJC_PLACEMENT_SERVICE_URL = "https://placements.tapjoy.com/";
    public static final String TJC_SERVICE_URL = "https://ws.tapjoyads.com/";
}
