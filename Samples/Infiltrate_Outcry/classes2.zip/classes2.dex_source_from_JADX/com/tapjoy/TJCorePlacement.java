package com.tapjoy;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import com.tapjoy.TJAdUnit.TJAdUnitVideoListener;
import com.tapjoy.TJAdUnit.TJAdUnitWebViewListener;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.C0140d;
import com.tapjoy.internal.C0289y;
import com.tapjoy.internal.cg;
import com.tapjoy.internal.ct;
import com.tapjoy.internal.ee;
import com.tapjoy.internal.el;
import com.tapjoy.internal.ep;
import com.tapjoy.internal.et;
import com.tapjoy.internal.ex;
import com.tapjoy.internal.ey;
import com.tapjoy.internal.ez;
import com.tapjoy.internal.fd;
import com.tapjoy.internal.fj;
import com.tapjoy.internal.fj.C0215a;
import com.tapjoy.internal.fm;
import com.tapjoy.internal.fw;
import com.tapjoy.internal.fz;
import com.tapjoy.internal.ga;
import com.tapjoy.internal.gd;
import com.tapjoy.internal.gi;
import com.tapjoy.internal.gk;
import com.tapjoy.internal.gl;
import com.tapjoy.internal.gm;
import com.tapjoy.internal.hn;
import com.tapjoy.internal.hn.C0268a;
import com.tapjoy.mediation.TJCustomPlacement;
import com.tapjoy.mediation.TJCustomPlacementListener;
import com.tapjoy.mediation.TJMediatedPlacementData;
import com.tapjoy.mediation.TJMediationSettings;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TJCorePlacement implements TJCustomPlacementListener {
    static final String f240a = TJCorePlacement.class.getSimpleName();
    private Runnable f241A;
    private TJAdUnitWebViewListener f242B = new C00861(this);
    private TJAdUnitVideoListener f243C = new C00894(this);
    Context f244b = C0140d.m476c();
    TJPlacementData f245c;
    String f246d;
    long f247e;
    final ez f248f = new ez();
    TJAdUnit f249g;
    boolean f250h = false;
    gk f251i = null;
    boolean f252j;
    volatile boolean f253k = false;
    volatile boolean f254l = false;
    volatile boolean f255m = false;
    TJCustomPlacement f256n;
    String f257o;
    String f258p;
    String f259q;
    String f260r;
    private Map f261s = new HashMap();
    private Map f262t;
    private ep f263u;
    private boolean f264v = false;
    private hn f265w = null;
    private volatile boolean f266x = false;
    private TJMediatedPlacementData f267y;
    private Handler f268z;

    class C00861 implements TJAdUnitWebViewListener {
        final /* synthetic */ TJCorePlacement f221a;

        C00861(TJCorePlacement tJCorePlacement) {
            this.f221a = tJCorePlacement;
        }

        public final void onContentReady() {
            this.f221a.m193c();
        }

        public final void onClosed() {
            if (this.f221a.f250h) {
                TJPlacementManager.decrementPlacementCacheCount();
                this.f221a.f250h = false;
            }
            if (this.f221a.f264v) {
                TJPlacementManager.decrementPlacementPreRenderCount();
                this.f221a.f264v = false;
            }
        }
    }

    class C00894 implements TJAdUnitVideoListener {
        final /* synthetic */ TJCorePlacement f226a;

        C00894(TJCorePlacement tJCorePlacement) {
            this.f226a = tJCorePlacement;
        }

        public final void onVideoStart() {
            TJPlacement a = this.f226a.m185a("SHOW");
            if (a != null && a.getVideoListener() != null) {
                a.getVideoListener().onVideoStart(a);
            }
        }

        public final void onVideoCompleted() {
            TJPlacement a = this.f226a.m185a("SHOW");
            if (a != null && a.getVideoListener() != null) {
                a.getVideoListener().onVideoComplete(a);
            }
        }

        public final void onVideoError(String errorMessage) {
            TJPlacement a = this.f226a.m185a("SHOW");
            if (a != null && a.getVideoListener() != null) {
                a.getVideoListener().onVideoError(a, errorMessage);
            }
        }
    }

    class C00905 implements Runnable {
        final /* synthetic */ TJCorePlacement f227a;

        C00905(TJCorePlacement tJCorePlacement) {
            this.f227a = tJCorePlacement;
        }

        public final void run() {
            try {
                TapjoyLog.m252i(TJCorePlacement.f240a, "Custom placement adapter request timed out");
                this.f227a.m176h();
            } catch (TapjoyException e) {
                this.f227a.m189a(ErrorType.SERVER_ERROR, new TJError(TJAdUnitConstants.DEFAULT_VOLUME_CHECK_INTERVAL, e.getMessage() + " for placement " + this.f227a.f245c.getPlacementName()));
            }
        }
    }

    class C00937 implements fw {
        final /* synthetic */ String f235a;
        final /* synthetic */ TJCorePlacement f236b;

        C00937(TJCorePlacement tJCorePlacement, String str) {
            this.f236b = tJCorePlacement;
            this.f235a = str;
        }

        public final void mo68a(Context context, String str, String str2) {
            if (str2 == null) {
                this.f236b.f245c.setRedirectURL(str);
            } else {
                this.f236b.f245c.setBaseURL(str);
                this.f236b.f245c.setHttpResponse(str2);
            }
            this.f236b.f245c.setHasProgressSpinner(true);
            this.f236b.f245c.setContentViewId(this.f235a);
            Intent intent = new Intent(this.f236b.f244b, TJAdUnitActivity.class);
            intent.putExtra(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA, this.f236b.f245c);
            intent.setFlags(268435456);
            context.startActivity(intent);
        }
    }

    class C00948 implements Runnable {
        final /* synthetic */ TJCorePlacement f237a;

        C00948(TJCorePlacement tJCorePlacement) {
            this.f237a = tJCorePlacement;
        }

        public final void run() {
            this.f237a.f251i.mo205a(gd.m956a().f1175p, this.f237a.f248f);
        }
    }

    class C00959 implements TJCacheListener {
        final /* synthetic */ TJCacheListener f238a;
        final /* synthetic */ TJCorePlacement f239b;

        C00959(TJCorePlacement tJCorePlacement, TJCacheListener tJCacheListener) {
            this.f239b = tJCorePlacement;
            this.f238a = tJCacheListener;
        }

        public final void onCachingComplete(int status) {
            this.f238a.onCachingComplete(status);
        }
    }

    TJCorePlacement(String placementName, String placementKey) {
        if (this.f244b == null) {
            TapjoyLog.m249d(f240a, "getVisibleActivity() is NULL. Activity can be explicitly set via `Tapjoy.setActivity(Activity)`");
        }
        this.f245c = new TJPlacementData(placementKey, getPlacementContentUrl());
        this.f245c.setPlacementName(placementName);
        this.f246d = UUID.randomUUID().toString();
        this.f249g = new TJAdUnit();
        this.f249g.setWebViewListener(this.f242B);
        this.f249g.setVideoListener(this.f243C);
        this.f241A = new C00905(this);
    }

    final synchronized void m186a() {
        String url = this.f245c.getUrl();
        if (ct.m463c(url)) {
            url = getPlacementContentUrl();
            if (ct.m463c(url)) {
                url = "TJPlacement is missing APP_ID";
                fj.m877b("TJPlacement.requestContent").m862a(url).m869c();
                m189a(ErrorType.SDK_ERROR, new TJError(0, url));
            } else {
                this.f245c.updateUrl(url);
            }
        }
        TapjoyLog.m249d(f240a, "sendContentRequest -- URL: " + url + " name: " + this.f245c.getPlacementName());
        m191a(url, null, true);
    }

    final synchronized void m191a(String str, Map map, boolean z) {
        String str2 = null;
        synchronized (this) {
            if (this.f266x) {
                TapjoyLog.m252i(f240a, "Placement " + this.f245c.getPlacementName() + " is already requesting content");
                fj.m877b("TJPlacement.requestContent").m867b("already doing").m869c();
            } else {
                el elVar;
                fm d;
                this.f245c.resetPlacementRequestData();
                ez ezVar = this.f248f;
                ezVar.f1021b = null;
                ezVar.f1023d = null;
                ezVar.f1020a = null;
                this.f249g.resetContentLoadState();
                this.f266x = false;
                this.f253k = false;
                this.f254l = false;
                this.f255m = false;
                this.f251i = null;
                this.f265w = null;
                this.f266x = true;
                final TJPlacement a = m185a("REQUEST");
                this.f262t = TapjoyConnectCore.getGenericURLParams();
                this.f262t.putAll(TapjoyConnectCore.getTimeStampAndVerifierParams());
                TapjoyUtil.safePut(this.f262t, TJAdUnitConstants.PARAM_PLACEMENT_NAME, this.f245c.getPlacementName(), true);
                TapjoyUtil.safePut(this.f262t, TJAdUnitConstants.PARAM_PLACEMENT_PRELOAD, "true", true);
                TapjoyUtil.safePut(this.f262t, TapjoyConstants.TJC_DEBUG, Boolean.toString(ga.f1141a), true);
                gd a2 = gd.m956a();
                Map map2 = this.f262t;
                String str3 = TJAdUnitConstants.PARAM_ACTION_ID_EXCLUSION;
                if (a2.f1161b != null) {
                    gm gmVar = a2.f1161b;
                    gmVar.m1089b();
                    str2 = gmVar.f1236b.m1338a();
                }
                TapjoyUtil.safePut(map2, str3, str2, true);
                TapjoyUtil.safePut(this.f262t, TJAdUnitConstants.PARAM_PLACEMENT_BY_SDK, String.valueOf(this.f252j), true);
                TapjoyUtil.safePut(this.f262t, TJAdUnitConstants.PARAM_PUSH_ID, a.pushId, true);
                TapjoyUtil.safePut(this.f262t, TapjoyConstants.TJC_MEDIATION_SOURCE, this.f257o, true);
                TapjoyUtil.safePut(this.f262t, TapjoyConstants.TJC_ADAPTER_VERSION, this.f258p, true);
                if (map != null) {
                    this.f262t.putAll(map);
                }
                if (z) {
                    elVar = new el(fd.m837b().m830c("placement_request_content_retry_timeout"));
                    d = fd.m837b().m831d("placement_request_content_retry_backoff");
                } else {
                    elVar = el.f975a;
                    d = fm.f1095a;
                }
                final C0215a d2 = fj.m880d("TJPlacement.requestContent");
                final String str4 = str;
                new Thread(this) {
                    final /* synthetic */ TJCorePlacement f234f;

                    class C00911 implements TJCacheListener {
                        final /* synthetic */ C00926 f228a;

                        C00911(C00926 c00926) {
                            this.f228a = c00926;
                        }

                        public final void onCachingComplete(int status) {
                            this.f228a.f234f.f264v = this.f228a.f234f.getAdUnit().preload(this.f228a.f234f.f245c, this.f228a.f234f.f244b);
                        }
                    }

                    public final void run() {
                        fj.m872a("TJPlacement.requestContent", d2);
                        int i = 0;
                        while (!m154a()) {
                            i++;
                            this.f234f.f262t.put(TapjoyConstants.TJC_RETRY, Integer.toString(i));
                            if (i == 1) {
                                d2.m864a("retry_timeout", Long.valueOf(elVar.f976b));
                            }
                            d2.m863a("retry_count", (long) i);
                        }
                    }

                    private boolean m154a() {
                        long b;
                        TapjoyLog.m252i(TJCorePlacement.f240a, "Sending content request for placement " + this.f234f.f245c.getPlacementName());
                        TJCorePlacement tJCorePlacement = this.f234f;
                        gd a = gd.m956a();
                        String f = this.f234f.f245c.getPlacementName();
                        Context h = this.f234f.f244b;
                        gl glVar = a.f1160a;
                        ee a2 = glVar.f1231a.m963a(false);
                        tJCorePlacement.f265w = new hn(glVar.f1231a, a2.f849d, a2.f850e, a2.f851f, f, h);
                        TapjoyHttpURLResponse responseFromURL = new TapjoyURLConnection().getResponseFromURL(str4, null, null, this.f234f.f262t);
                        this.f234f.f245c.setHttpStatusCode(responseFromURL.statusCode);
                        this.f234f.f245c.setHttpResponse(responseFromURL.response);
                        if (!responseFromURL.getHeaderFieldAsString(TapjoyConstants.TAPJOY_PRERENDER_HEADER).equals("0")) {
                            this.f234f.f245c.setPrerenderingRequested(true);
                        }
                        String headerFieldAsString = responseFromURL.getHeaderFieldAsString(TapjoyConstants.TAPJOY_DEBUG_HEADER);
                        if (headerFieldAsString != null) {
                            TapjoyLog.m253v(TJCorePlacement.f240a, "Tapjoy-Server-Debug: " + headerFieldAsString);
                        }
                        if (responseFromURL.expires > 0) {
                            b = responseFromURL.expires - (responseFromURL.date > 0 ? responseFromURL.date : C0289y.m1352b());
                            if (b > 0) {
                                this.f234f.f247e = b + SystemClock.elapsedRealtime();
                            }
                        } else {
                            this.f234f.f247e = 0;
                        }
                        if (ct.m463c(responseFromURL.getHeaderFieldAsString(TapjoyConstants.TAPJOY_MEDIATION_HEADER))) {
                            if (!(responseFromURL == null || a.getListener() == null)) {
                                switch (responseFromURL.statusCode) {
                                    case 0:
                                        if (elVar.m770a(d.f1099e)) {
                                            fj.m877b("TJPlacement.requestContent").m862a("network error").m864a("retry_timeout", Long.valueOf(elVar.f976b)).m869c();
                                            this.f234f.m188a(a, ErrorType.NETWORK_ERROR, new TJError(responseFromURL.statusCode, responseFromURL.response));
                                            break;
                                        }
                                        fm fmVar = d;
                                        long j = fmVar.f1099e;
                                        b = (long) (((double) fmVar.f1099e) * fmVar.f1098d);
                                        if (b < fmVar.f1096b) {
                                            b = fmVar.f1096b;
                                        } else if (b > fmVar.f1097c) {
                                            b = fmVar.f1097c;
                                        }
                                        fmVar.f1099e = b;
                                        if (j > 0) {
                                            synchronized (fmVar) {
                                                try {
                                                    fmVar.wait(j);
                                                } catch (InterruptedException e) {
                                                }
                                            }
                                        }
                                        return false;
                                    case 200:
                                        TJCorePlacement.m180k(this.f234f);
                                        headerFieldAsString = responseFromURL.getHeaderFieldAsString("Content-Type");
                                        if (!ct.m463c(headerFieldAsString) && headerFieldAsString.contains("json")) {
                                            if (!responseFromURL.getHeaderFieldAsString(TapjoyConstants.TAPJOY_DISABLE_PRELOAD_HEADER).equals("1")) {
                                                if (!this.f234f.m167b(responseFromURL.response)) {
                                                    fj.m877b("TJPlacement.requestContent").m862a("asset error").m869c();
                                                    this.f234f.m188a(a, ErrorType.SERVER_ERROR, new TJError(responseFromURL.statusCode, responseFromURL.response));
                                                    break;
                                                }
                                                fj.m877b("TJPlacement.requestContent").m864a("content_type", (Object) "mm").m869c();
                                                this.f234f.m178i();
                                                this.f234f.m193c();
                                                break;
                                            }
                                            try {
                                                TJCorePlacement.m163a(this.f234f, responseFromURL.response);
                                                fj.m877b("TJPlacement.requestContent").m864a("content_type", (Object) "ad").m869c();
                                                this.f234f.f248f.f1020a = this.f234f.f263u;
                                                this.f234f.m178i();
                                                this.f234f.m193c();
                                                break;
                                            } catch (TapjoyException e2) {
                                                headerFieldAsString = e2.getMessage() + " for placement " + this.f234f.f245c.getPlacementName();
                                                fj.m877b("TJPlacement.requestContent").m862a("server error").m869c();
                                                this.f234f.m188a(a, ErrorType.SERVER_ERROR, new TJError(responseFromURL.statusCode, headerFieldAsString));
                                                break;
                                            }
                                        }
                                        fj.m877b("TJPlacement.requestContent").m864a("content_type", (Object) "ad").m869c();
                                        this.f234f.f248f.f1020a = this.f234f.f263u;
                                        this.f234f.m178i();
                                        TJCorePlacement tJCorePlacement2 = this.f234f;
                                        TJCacheListener c00911 = new C00911(this);
                                        TapjoyLog.m252i(TJCorePlacement.f240a, "Checking if there is content to cache for placement " + tJCorePlacement2.f245c.getPlacementName());
                                        String headerFieldAsString2 = responseFromURL.getHeaderFieldAsString(TapjoyConstants.TAPJOY_CACHE_HEADER);
                                        try {
                                            if (!TJPlacementManager.canCachePlacement()) {
                                                TapjoyLog.m252i(TJCorePlacement.f240a, "Placement caching limit reached. No content will be cached for placement " + tJCorePlacement2.f245c.getPlacementName());
                                                c00911.onCachingComplete(2);
                                                break;
                                            }
                                            JSONArray jSONArray = new JSONArray(headerFieldAsString2);
                                            if (jSONArray.length() <= 0) {
                                                c00911.onCachingComplete(1);
                                                break;
                                            }
                                            TapjoyLog.m252i(TJCorePlacement.f240a, "Begin caching content for placement " + tJCorePlacement2.f245c.getPlacementName());
                                            TJPlacementManager.incrementPlacementCacheCount();
                                            tJCorePlacement2.f250h = true;
                                            TapjoyCache.getInstance().cacheAssetGroup(jSONArray, new C00959(tJCorePlacement2, c00911));
                                            break;
                                        } catch (JSONException e3) {
                                            c00911.onCachingComplete(2);
                                            break;
                                        }
                                        break;
                                    default:
                                        fj.m877b("TJPlacement.requestContent").m864a("content_type", (Object) "none").m864a("code", Integer.valueOf(responseFromURL.statusCode)).m869c();
                                        this.f234f.m187a(a);
                                        break;
                                }
                            }
                        }
                        try {
                            this.f234f.f267y = new TJMediatedPlacementData(this.f234f.f245c.getHttpResponse());
                            TJCorePlacement.m179j(this.f234f);
                        } catch (TapjoyException e22) {
                            headerFieldAsString = e22.getMessage() + " for placement " + this.f234f.f245c.getPlacementName();
                            fj.m877b("TJPlacement.requestContent").m862a("mediation error").m869c();
                            this.f234f.m188a(a, ErrorType.SDK_ERROR, new TJError(this.f234f.f245c.getHttpStatusCode(), headerFieldAsString));
                        }
                        this.f234f.f266x = false;
                        return true;
                    }
                }.start();
            }
        }
    }

    private void m174g() {
        this.f268z.removeCallbacks(this.f241A);
    }

    private void m176h() {
        TapjoyLog.m252i(f240a, "Custom placement call failed, retrying Tapjoy request");
        if (this.f267y == null) {
            throw new TapjoyException("Mediation data is null");
        }
        JSONObject nextCall = this.f267y.getNextCall();
        this.f256n = null;
        this.f267y = null;
        try {
            m191a(this.f245c.getUrl(), TapjoyUtil.jsonToStringMap(nextCall), false);
        } catch (JSONException e) {
            TapjoyLog.m252i(f240a, "Failed to load next call parameters for mediated placement " + this.f245c.getPlacementName());
            throw new TapjoyException("TJPlacement request failed due to custom placement fallback failure");
        }
    }

    private boolean m167b(String str) {
        try {
            C0268a c0268a = (C0268a) this.f265w.mo117a(URI.create(this.f245c.getUrl()), new ByteArrayInputStream(str.getBytes()));
            this.f251i = c0268a.f1441a;
            c0268a.f1441a.mo204a();
            if (c0268a.f1441a.mo206b()) {
                et etVar = null;
                if (this.f251i instanceof gi) {
                    etVar = new ex(this.f245c.getPlacementName(), this.f245c.getPlacementType(), this.f263u);
                } else if (this.f251i instanceof fz) {
                    etVar = new ey(this.f245c.getPlacementName(), this.f245c.getPlacementType(), this.f263u);
                }
                this.f248f.f1020a = etVar;
                return true;
            }
            TapjoyLog.m251e(f240a, "Failed to load fiverocks placement");
            return false;
        } catch (IOException e) {
            TapjoyLog.m251e(f240a, e.toString());
            e.printStackTrace();
            return false;
        } catch (cg e2) {
            TapjoyLog.m251e(f240a, e2.toString());
            e2.printStackTrace();
            return false;
        }
    }

    public Context getContext() {
        return this.f244b;
    }

    public void setContext(Context activityContext) {
        this.f244b = activityContext;
    }

    public TJAdUnit getAdUnit() {
        return this.f249g;
    }

    public TJPlacementData getPlacementData() {
        return this.f245c;
    }

    public boolean isContentReady() {
        return this.f255m;
    }

    public boolean isContentAvailable() {
        return this.f254l;
    }

    public String getPlacementContentUrl() {
        String appID = TapjoyConnectCore.getAppID();
        if (ct.m463c(appID)) {
            return "";
        }
        return TapjoyConnectCore.getPlacementURL() + "v1/apps/" + appID + "/content?";
    }

    final String m192b() {
        TJMediatedPlacementData tJMediatedPlacementData = this.f267y;
        if (this.f256n != null && tJMediatedPlacementData != null) {
            return tJMediatedPlacementData.getName();
        }
        if (this.f251i != null) {
            return "mm";
        }
        if (this.f254l) {
            return "ad";
        }
        return "none";
    }

    final void m190a(String str, TJPlacement tJPlacement) {
        synchronized (this.f261s) {
            this.f261s.put(str, tJPlacement);
            if (tJPlacement != null) {
                TapjoyLog.m249d(f240a, "Setting " + str + " placement: " + tJPlacement.getGUID());
            }
        }
    }

    final TJPlacement m185a(String str) {
        TJPlacement tJPlacement;
        synchronized (this.f261s) {
            tJPlacement = (TJPlacement) this.f261s.get(str);
            if (tJPlacement != null) {
                TapjoyLog.m249d(f240a, "Returning " + str + " placement: " + tJPlacement.getGUID());
            }
        }
        return tJPlacement;
    }

    private void m178i() {
        this.f254l = true;
        m187a(m185a("REQUEST"));
    }

    final void m187a(TJPlacement tJPlacement) {
        ez ezVar = this.f248f;
        Object placementName = this.f245c.getPlacementName();
        Object placementType = this.f245c.getPlacementType();
        Object b = m192b();
        ezVar.f1022c = 0;
        ezVar.f1021b = fj.m881e("PlacementContent.funnel").m861a().m864a("placement", placementName).m864a("placement_type", placementType).m864a("content_type", b).m864a("state", Integer.valueOf(ezVar.f1022c));
        ezVar.f1021b.m869c();
        if (!"none".equals(b)) {
            ezVar.f1024e = fj.m881e("PlacementContent.ready").m861a().m864a("placement", placementName).m864a("placement_type", placementType).m864a("content_type", b);
        }
        if (tJPlacement != null && tJPlacement.getListener() != null) {
            TapjoyLog.m252i(f240a, "Content request delivered successfully for placement " + this.f245c.getPlacementName() + ", contentAvailable: " + isContentAvailable() + ", mediationAgent: " + this.f259q);
            tJPlacement.getListener().onRequestSuccess(tJPlacement);
        }
    }

    final void m189a(ErrorType errorType, TJError tJError) {
        m188a(m185a("REQUEST"), errorType, tJError);
    }

    final void m188a(TJPlacement tJPlacement, ErrorType errorType, TJError tJError) {
        TapjoyLog.m250e(f240a, new TapjoyErrorMessage(errorType, "Content request failed for placement " + this.f245c.getPlacementName() + "; Reason= " + tJError.message));
        if (tJPlacement != null && tJPlacement.getListener() != null) {
            tJPlacement.getListener().onRequestFailure(tJPlacement, tJError);
        }
    }

    final void m193c() {
        if (!this.f253k) {
            ez ezVar;
            this.f255m = true;
            TapjoyLog.m252i(f240a, "Content is ready for placement " + this.f245c.getPlacementName());
            if (this.f249g.isPrerendered()) {
                ezVar = this.f248f;
                String str = "prerendered";
                Object valueOf = Boolean.valueOf(true);
                C0215a c0215a = ezVar.f1021b;
                if (c0215a != null) {
                    c0215a.m864a(str, valueOf);
                }
                C0215a c0215a2 = ezVar.f1024e;
                if (c0215a2 != null) {
                    c0215a2.m864a(str, valueOf);
                }
            }
            ezVar = this.f248f;
            C0215a c0215a3 = ezVar.f1024e;
            if (c0215a3 != null) {
                ezVar.f1024e = null;
                c0215a3.m866b().m869c();
            }
            TJPlacement a = m185a("REQUEST");
            if (a != null && a.getListener() != null) {
                a.getListener().onContentReady(a);
                this.f253k = true;
            }
        }
    }

    final void m194d() {
        TJPlacement a = m185a("SHOW");
        if (a != null && a.getListener() != null) {
            TapjoyLog.m252i(f240a, "Content dismissed for placement " + this.f245c.getPlacementName());
            et etVar = this.f248f.f1020a;
            if (etVar != null) {
                etVar.f989b.clear();
            }
            if (a != null && a.a != null) {
                a.a.onContentDismiss(a);
            }
        }
    }

    final void m195e() {
        TapjoyLog.m252i(f240a, "Content shown for placement " + this.f245c.getPlacementName());
        this.f248f.m809a();
        TJPlacement a = m185a("SHOW");
        if (a != null && a.getListener() != null) {
            a.getListener().onContentShow(a);
        }
    }

    public void onCustomPlacementLoad() {
        if (this.f256n != null) {
            m174g();
            this.f254l = true;
            if (!(this.f267y == null || this.f267y.getFillURL() == null)) {
                final String fillURL = this.f267y.getFillURL();
                new Thread(this) {
                    final /* synthetic */ TJCorePlacement f223b;

                    public final void run() {
                        TapjoyLog.m249d(TJCorePlacement.f240a, "onCustomPlacementLoad -- fillUrl=" + fillURL);
                        new TapjoyURLConnection().getResponseFromURL(fillURL);
                    }
                }.start();
            }
            fj.m877b("TJPlacement.requestContent").m864a("content_type", m192b()).m869c();
            m178i();
            m193c();
        }
    }

    public void onCustomPlacementFailure(Error error) {
        if (this.f256n != null) {
            m174g();
            try {
                if (!(this.f267y == null || this.f267y.getNoFillURL() == null)) {
                    final String noFillURL = this.f267y.getNoFillURL();
                    new Thread(this) {
                        final /* synthetic */ TJCorePlacement f225b;

                        public final void run() {
                            TapjoyLog.m249d(TJCorePlacement.f240a, "onCustomPlacementFailure -- noFillUrl=" + noFillURL);
                            new TapjoyURLConnection().getResponseFromURL(noFillURL);
                        }
                    }.start();
                }
                m176h();
            } catch (TapjoyException e) {
                m189a(ErrorType.SERVER_ERROR, new TJError(TJAdUnitConstants.DEFAULT_VOLUME_CHECK_INTERVAL, e.getMessage() + " for placement " + this.f245c.getPlacementName()));
            }
        }
    }

    public void onCustomPlacementContentShown() {
        m195e();
    }

    public void onCustomPlacementContentDismiss() {
        this.f256n = null;
        this.f267y = null;
        m194d();
    }

    public void onCustomPlacementReward(final String type, int amount) {
        TJPlacement a = m185a("SHOW");
        if (a != null && a.getListener() != null) {
            a.getListener().onRewardRequest(a, new TJActionRequest(this) {
                final /* synthetic */ TJCorePlacement f220b;

                public final String getRequestId() {
                    return type;
                }

                public final String getToken() {
                    return null;
                }

                public final void completed() {
                }

                public final void cancelled() {
                }
            }, type, amount);
        }
    }

    static /* synthetic */ void m179j(TJCorePlacement tJCorePlacement) {
        try {
            Class cls = Class.forName(tJCorePlacement.f267y.getClassname());
            if (TJCustomPlacement.class.isAssignableFrom(cls)) {
                tJCorePlacement.f256n = (TJCustomPlacement) cls.getConstructor(new Class[0]).newInstance(new Object[0]);
                if (tJCorePlacement.f268z == null) {
                    tJCorePlacement.f268z = new Handler(Looper.getMainLooper());
                }
                tJCorePlacement.f268z.postDelayed(tJCorePlacement.f241A, TJMediationSettings.getInstance().getTimeout());
                final C0215a d = fj.m880d("TJPlacement.requestContent");
                tJCorePlacement.f256n.requestContentWithCustomPlacementParams(tJCorePlacement.f244b, new TJCustomPlacementListener(tJCorePlacement) {
                    final /* synthetic */ TJCorePlacement f218b;

                    public final void onCustomPlacementLoad() {
                        fj.m872a("TJPlacement.requestContent", d);
                        this.f218b.onCustomPlacementLoad();
                    }

                    public final void onCustomPlacementFailure(Error error) {
                        fj.m872a("TJPlacement.requestContent", d);
                        this.f218b.onCustomPlacementFailure(error);
                    }

                    public final void onCustomPlacementContentShown() {
                        this.f218b.onCustomPlacementContentShown();
                    }

                    public final void onCustomPlacementContentDismiss() {
                        this.f218b.onCustomPlacementContentDismiss();
                    }

                    public final void onCustomPlacementReward(String type, int amount) {
                        this.f218b.onCustomPlacementReward(type, amount);
                    }
                }, tJCorePlacement.f267y.getExtras());
                return;
            }
            TapjoyLog.m251e(f240a, tJCorePlacement.f267y.getClassname() + " does not implement TJCustomPlacement.");
            tJCorePlacement.m176h();
        } catch (Exception e) {
            TapjoyLog.m250e(f240a, new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Failed to load custom class " + tJCorePlacement.f267y.getClassname() + " for placement " + tJCorePlacement.f245c.getPlacementName()));
            tJCorePlacement.m176h();
        }
    }

    static /* synthetic */ void m180k(TJCorePlacement tJCorePlacement) {
        tJCorePlacement.f263u = new ep(tJCorePlacement.f245c.getPlacementName(), tJCorePlacement.f245c.getPlacementType());
        tJCorePlacement.f249g.setAdContentTracker(tJCorePlacement.f263u);
    }

    static /* synthetic */ void m163a(TJCorePlacement tJCorePlacement, String str) {
        if (str != null) {
            try {
                TapjoyLog.m249d(f240a, "Disable preload flag is set for placement " + tJCorePlacement.f245c.getPlacementName());
                tJCorePlacement.f245c.setRedirectURL(new JSONObject(str).getString(TapjoyConstants.TJC_REDIRECT_URL));
                tJCorePlacement.f245c.setPreloadDisabled(true);
                tJCorePlacement.f245c.setHasProgressSpinner(true);
                TapjoyLog.m249d(f240a, "redirect_url:" + tJCorePlacement.f245c.getRedirectURL());
                return;
            } catch (JSONException e) {
                throw new TapjoyException("TJPlacement request failed, malformed server response");
            }
        }
        throw new TapjoyException("TJPlacement request failed due to null response");
    }
}
