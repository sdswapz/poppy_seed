package com.tapjoy;

import android.content.Context;
import android.content.Intent;
import com.tapjoy.internal.C0059l;
import com.tapjoy.internal.gd;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class InstallReferrerReceiver extends C0059l {
    public void onReceive(Context context, Intent intent) {
        String a = gd.m958a(context, intent);
        int a2 = m107a(context, intent);
        if (intent.getBooleanExtra("fiverocks:verify", false) && isOrderedBroadcast()) {
            setResultCode(a2 + 1);
            if (a != null) {
                try {
                    setResultData("http://play.google.com/store/apps/details?id=" + context.getPackageName() + "&referrer=" + URLEncoder.encode(a, "UTF-8"));
                } catch (UnsupportedEncodingException e) {
                }
            }
        }
    }
}
