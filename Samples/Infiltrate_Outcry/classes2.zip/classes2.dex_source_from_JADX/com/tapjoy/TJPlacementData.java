package com.tapjoy;

import com.tapjoy.internal.ct;
import java.io.Serializable;

public class TJPlacementData implements Serializable {
    private String f287a;
    private String f288b;
    private String f289c;
    private String f290d;
    private String f291e;
    private int f292f;
    private String f293g;
    private String f294h;
    private int f295i;
    private boolean f296j;
    private String f297k;
    private boolean f298l;
    private String f299m;
    private String f300n;
    private boolean f301o = true;
    private boolean f302p = false;

    public TJPlacementData(String key, String url) {
        setKey(key);
        updateUrl(url);
        setPlacementType(TapjoyConstants.TJC_APP_PLACEMENT);
    }

    public TJPlacementData(String baseUrl, String httpResponse, String callbackID) {
        setBaseURL(baseUrl);
        setHttpResponse(httpResponse);
        this.f299m = callbackID;
        this.f301o = false;
        setPlacementType(TapjoyConstants.TJC_APP_PLACEMENT);
    }

    public void resetPlacementRequestData() {
        setHttpResponse(null);
        setHttpStatusCode(0);
        setRedirectURL(null);
        setHasProgressSpinner(false);
        setPrerenderingRequested(false);
        setPreloadDisabled(false);
        setContentViewId(null);
    }

    public String getCallbackID() {
        return this.f299m;
    }

    public boolean isBaseActivity() {
        return this.f301o;
    }

    public void setKey(String key) {
        this.f287a = key;
    }

    public void setBaseURL(String baseURL) {
        this.f289c = baseURL;
    }

    public void setMediationURL(String mediationURL) {
        this.f290d = mediationURL;
    }

    public void setHttpResponse(String httpResponse) {
        this.f291e = httpResponse;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.f292f = httpStatusCode;
    }

    public void setPlacementName(String placementName) {
        this.f293g = placementName;
    }

    public void setPlacementType(String placementType) {
        this.f294h = placementType;
    }

    public void setViewType(int viewType) {
        this.f295i = viewType;
    }

    public void setRedirectURL(String redirectURL) {
        this.f297k = redirectURL;
    }

    public void setHasProgressSpinner(boolean hasProgressSpinner) {
        this.f296j = hasProgressSpinner;
    }

    public void setContentViewId(String contentViewId) {
        this.f300n = contentViewId;
    }

    public String getUrl() {
        return this.f288b;
    }

    public String getKey() {
        return this.f287a;
    }

    public String getBaseURL() {
        return this.f289c;
    }

    public String getMediationURL() {
        return this.f290d;
    }

    public String getHttpResponse() {
        return this.f291e;
    }

    public int getHttpStatusCode() {
        return this.f292f;
    }

    public String getPlacementName() {
        return this.f293g;
    }

    public String getPlacementType() {
        return this.f294h;
    }

    public int getViewType() {
        return this.f295i;
    }

    public String getRedirectURL() {
        return this.f297k;
    }

    public String getContentViewId() {
        return this.f300n;
    }

    public boolean hasProgressSpinner() {
        return this.f296j;
    }

    public void setPreloadDisabled(boolean value) {
        this.f302p = value;
    }

    public boolean isPreloadDisabled() {
        return this.f302p;
    }

    public boolean isPrerenderingRequested() {
        return this.f298l;
    }

    public void setPrerenderingRequested(boolean prerenderingRequested) {
        this.f298l = prerenderingRequested;
    }

    public void updateUrl(String url) {
        this.f288b = url;
        if (!ct.m463c(url)) {
            setBaseURL(url.substring(0, url.indexOf(47, url.indexOf("//") + 3)));
        }
    }
}
