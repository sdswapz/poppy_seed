package com.tapjoy;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build.VERSION;
import android.os.Handler;
import android.widget.ImageButton;
import android.widget.RelativeLayout.LayoutParams;

public class TJCloseButton extends ImageButton {
    private static final String f210a = TJCloseButton.class.getSimpleName();
    private ClosePosition f211b;
    private boolean f212c;
    private boolean f213d;

    class C00851 implements Runnable {
        final /* synthetic */ TJCloseButton f207a;

        class C00841 implements AnimatorListener {
            final /* synthetic */ C00851 f206a;

            C00841(C00851 c00851) {
                this.f206a = c00851;
            }

            public final void onAnimationCancel(Animator arg0) {
                this.f206a.f207a.setClickable(this.f206a.f207a.f212c);
                this.f206a.f207a.f213d = false;
            }

            public final void onAnimationRepeat(Animator arg0) {
            }

            public final void onAnimationStart(Animator arg0) {
            }

            public final void onAnimationEnd(Animator arg0) {
                this.f206a.f207a.setClickable(this.f206a.f207a.f212c);
                this.f206a.f207a.f213d = false;
            }
        }

        C00851(TJCloseButton tJCloseButton) {
            this.f207a = tJCloseButton;
        }

        @SuppressLint({"NewApi"})
        public final void run() {
            this.f207a.animate().alpha(TapjoyConnectCore.DEFAULT_CURRENCY_MULTIPLIER).setDuration(500).setListener(new C00841(this));
        }
    }

    public enum ClosePosition {
        TOP_LEFT(new int[]{10, 9}),
        TOP_CENTER(new int[]{10, 14}),
        TOP_RIGHT(new int[]{10, 11}),
        CENTER(new int[]{13}),
        BOTTOM_LEFT(new int[]{12, 9}),
        BOTTOM_CENTER(new int[]{12, 14}),
        BOTTOM_RIGHT(new int[]{12, 11});
        
        final LayoutParams f209a;

        private ClosePosition(int[] layoutParams) {
            this.f209a = new LayoutParams(-2, -2);
            for (int addRule : layoutParams) {
                this.f209a.addRule(addRule);
            }
            int deviceScreenDensityScale = (int) (-10.0f * TapjoyConnectCore.getDeviceScreenDensityScale());
            this.f209a.setMargins(0, deviceScreenDensityScale, deviceScreenDensityScale, 0);
        }
    }

    public TJCloseButton(Context context) {
        this(context, ClosePosition.TOP_RIGHT);
    }

    public TJCloseButton(Context context, ClosePosition closePosition) {
        super(context);
        this.f212c = true;
        this.f211b = closePosition;
        Bitmap loadBitmapFromJar = TapjoyUtil.loadBitmapFromJar("tj_close_button.png", context);
        if (loadBitmapFromJar == null) {
            try {
                loadBitmapFromJar = BitmapFactory.decodeResource(context.getResources(), context.getResources().getIdentifier("tj_close_button", "drawable", context.getPackageName()));
            } catch (Exception e) {
                TapjoyLog.m254w(f210a, "Could not find close button asset");
            }
        }
        setImageBitmap(loadBitmapFromJar);
        setBackgroundColor(16777215);
        setLayoutParams(this.f211b.f209a);
    }

    @TargetApi(11)
    protected void onAttachedToWindow() {
        if (VERSION.SDK_INT >= 12) {
            setAlpha(0.0f);
            setVisibility(0);
            this.f213d = true;
            setClickable(false);
            new Handler().postDelayed(new C00851(this), 2000);
        }
    }

    void setClickableRequested(boolean clickable) {
        this.f212c = clickable;
        if (!this.f213d) {
            setClickable(clickable);
        }
    }
}
