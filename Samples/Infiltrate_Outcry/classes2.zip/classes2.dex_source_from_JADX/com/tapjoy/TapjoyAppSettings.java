package com.tapjoy;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.tapjoy.internal.ct;

public class TapjoyAppSettings {
    public static final String TAG = TapjoyAppSettings.class.getSimpleName();
    private static TapjoyAppSettings f313b;
    String f314a = this.f316d.getString(TapjoyConstants.PREF_LOG_LEVEL, null);
    private Context f315c;
    private SharedPreferences f316d = this.f315c.getSharedPreferences(TapjoyConstants.TJC_PREFERENCE, 0);

    private TapjoyAppSettings(Context applicationContext) {
        this.f315c = applicationContext;
        if (!ct.m463c(this.f314a)) {
            TapjoyLog.m249d(TAG, "restoreLoggingLevel from sharedPref -- loggingLevel=" + this.f314a);
            TapjoyLog.m248a(this.f314a, true);
        }
    }

    public static TapjoyAppSettings getInstance() {
        return f313b;
    }

    public static void init(Context applicationContext) {
        TapjoyLog.m249d(TAG, "initializing app settings");
        f313b = new TapjoyAppSettings(applicationContext);
    }

    public void saveLoggingLevel(String level) {
        if (ct.m463c(level)) {
            TapjoyLog.m249d(TAG, "saveLoggingLevel -- server logging level is NULL or Empty string");
            return;
        }
        TapjoyLog.m249d(TAG, "saveLoggingLevel -- currentLevel=" + this.f314a + ";newLevel=" + level);
        if (ct.m463c(this.f314a) || !this.f314a.equals(level)) {
            Editor edit = this.f316d.edit();
            edit.putString(TapjoyConstants.PREF_LOG_LEVEL, level);
            edit.commit();
            this.f314a = level;
            TapjoyLog.m248a(this.f314a, true);
        }
        TapjoyLog.m252i(TAG, "Tapjoy remote device debugging set to '" + level + "'. The SDK Debug-setting is: " + (TapjoyLog.isLoggingEnabled() ? "'Enabled'" : "'Disabled'"));
    }

    public void clearLoggingLevel() {
        Editor edit = this.f316d.edit();
        edit.remove(TapjoyConstants.PREF_LOG_LEVEL);
        edit.commit();
        this.f314a = null;
        boolean isLoggingEnabled = TapjoyLog.isLoggingEnabled();
        TapjoyLog.m252i(TAG, "Tapjoy remote device debugging 'Disabled'. The SDK Debug-setting is: " + (isLoggingEnabled ? "'Enabled'" : "'Disabled'"));
        TapjoyLog.setDebugEnabled(isLoggingEnabled);
    }

    public void saveConnectResultAndParams(String result, String paramsHash, long expires) {
        if (!ct.m463c(result) && !ct.m463c(paramsHash)) {
            Editor edit = this.f316d.edit();
            edit.putString(TapjoyConstants.PREF_LAST_CONNECT_RESULT, result);
            edit.putString(TapjoyConstants.PREF_LAST_CONNECT_PARAMS_HASH, paramsHash);
            if (expires >= 0) {
                edit.putLong(TapjoyConstants.PREF_LAST_CONNECT_RESULT_EXPIRES, expires);
            } else {
                edit.remove(TapjoyConstants.PREF_LAST_CONNECT_RESULT_EXPIRES);
            }
            TapjoyLog.m252i(TAG, "Stored connect result");
            edit.commit();
        }
    }

    public void removeConnectResult() {
        if (this.f316d.getString(TapjoyConstants.PREF_LAST_CONNECT_PARAMS_HASH, null) != null) {
            Editor edit = this.f316d.edit();
            edit.remove(TapjoyConstants.PREF_LAST_CONNECT_RESULT);
            edit.remove(TapjoyConstants.PREF_LAST_CONNECT_PARAMS_HASH);
            edit.remove(TapjoyConstants.PREF_LAST_CONNECT_RESULT_EXPIRES);
            TapjoyLog.m252i(TAG, "Removed connect result");
            edit.commit();
        }
    }

    public String getConnectResult(String paramsHash, long currentTimeMillis) {
        String string = this.f316d.getString(TapjoyConstants.PREF_LAST_CONNECT_RESULT, null);
        if (ct.m463c(string) || ct.m463c(paramsHash) || !paramsHash.equals(this.f316d.getString(TapjoyConstants.PREF_LAST_CONNECT_PARAMS_HASH, null))) {
            return null;
        }
        long j = this.f316d.getLong(TapjoyConstants.PREF_LAST_CONNECT_RESULT_EXPIRES, -1);
        if (j < 0 || j >= currentTimeMillis) {
            return string;
        }
        return null;
    }
}
