package com.tapjoy;

public class TapjoyErrorMessage {
    private ErrorType f401a;
    private String f402b;

    public enum ErrorType {
        INTERNAL_ERROR,
        SDK_ERROR,
        SERVER_ERROR,
        INTEGRATION_ERROR,
        NETWORK_ERROR
    }

    public TapjoyErrorMessage(ErrorType type, String message) {
        this.f401a = type;
        this.f402b = message;
    }

    public ErrorType getType() {
        return this.f401a;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Type=" + this.f401a.toString());
        stringBuilder.append(";Message=" + this.f402b);
        return stringBuilder.toString();
    }
}
