package com.tapjoy;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Pair;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import com.moat.analytics.mobile.tjy.MoatAdEvent;
import com.moat.analytics.mobile.tjy.MoatAdEventType;
import com.moat.analytics.mobile.tjy.MoatFactory;
import com.moat.analytics.mobile.tjy.ReactiveVideoTracker;
import com.moat.analytics.mobile.tjy.ReactiveVideoTrackerPlugin;
import com.neurondigital.nudge.Instance;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.ct;
import com.tapjoy.mraid.view.MraidView;
import com.tapjoy.mraid.view.MraidView.PLACEMENT_TYPE;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"SetJavaScriptEnabled"})
public class TJAdUnitJSBridge implements TJWebViewJSInterfaceListener {
    final ConcurrentLinkedQueue f191a;
    public boolean allowRedirect;
    private TJWebViewJSInterface f192b;
    private TJAdUnitJSBridge f193c;
    public boolean closeRequested;
    public boolean customClose;
    private Context f194d;
    public boolean didLaunchOtherActivity;
    private TJAdUnitActivity f195e;
    private TJAdUnit f196f;
    private WebView f197g;
    private ProgressDialog f198h;
    private LocationManager f199i;
    private LocationListener f200j;
    private View f201k;
    private boolean f202l;
    private ReactiveVideoTracker f203m;
    private HashMap f204n;
    private Handler f205o;
    public String otherActivityCallbackID;

    public interface AdUnitAsyncTaskListner {
        void onComplete(boolean z);
    }

    @TargetApi(11)
    class C0083a extends AsyncTask {
        WebView f189a;
        final /* synthetic */ TJAdUnitJSBridge f190b;

        protected final /* bridge */ /* synthetic */ Object doInBackground(Object[] objArr) {
            return (Boolean[]) objArr;
        }

        protected final /* synthetic */ void onPostExecute(Object obj) {
            Boolean[] boolArr = (Boolean[]) obj;
            final boolean booleanValue = boolArr[0].booleanValue();
            final boolean booleanValue2 = boolArr[1].booleanValue();
            if (this.f190b.f194d instanceof Activity) {
                TapjoyUtil.runOnMainThread(new Runnable(this) {
                    final /* synthetic */ C0083a f188c;

                    public final void run() {
                        if (booleanValue) {
                            this.f188c.f189a.setVisibility(0);
                            if (booleanValue2) {
                                if (this.f188c.f189a.getParent() instanceof RelativeLayout) {
                                    ((RelativeLayout) this.f188c.f189a.getParent()).getBackground().setAlpha(0);
                                    ((RelativeLayout) this.f188c.f189a.getParent()).setBackgroundColor(0);
                                }
                                if (VERSION.SDK_INT >= 11) {
                                    this.f188c.f189a.setLayerType(1, null);
                                    return;
                                }
                                return;
                            }
                            if (this.f188c.f189a.getParent() instanceof RelativeLayout) {
                                ((RelativeLayout) this.f188c.f189a.getParent()).getBackground().setAlpha(255);
                                ((RelativeLayout) this.f188c.f189a.getParent()).setBackgroundColor(-1);
                            }
                            if (VERSION.SDK_INT >= 11) {
                                this.f188c.f189a.setLayerType(0, null);
                                return;
                            }
                            return;
                        }
                        this.f188c.f189a.setVisibility(4);
                        if (this.f188c.f189a.getParent() instanceof RelativeLayout) {
                            ((RelativeLayout) this.f188c.f189a.getParent()).getBackground().setAlpha(0);
                            ((RelativeLayout) this.f188c.f189a.getParent()).setBackgroundColor(0);
                        }
                    }
                });
            } else {
                TapjoyLog.m251e("TJAdUnitJSBridge", "Unable to present offerwall. No Activity context provided.");
            }
        }

        public C0083a(TJAdUnitJSBridge tJAdUnitJSBridge, WebView webView) {
            this.f190b = tJAdUnitJSBridge;
            this.f189a = webView;
        }
    }

    public TJAdUnitJSBridge(Context c, TJAdUnit tjAdUnit) {
        this(c, tjAdUnit.getWebView());
        this.f196f = tjAdUnit;
    }

    public TJAdUnitJSBridge(Context c, WebView w) {
        this.f201k = null;
        this.didLaunchOtherActivity = false;
        this.allowRedirect = true;
        this.otherActivityCallbackID = null;
        this.customClose = false;
        this.closeRequested = false;
        this.f191a = new ConcurrentLinkedQueue();
        TapjoyLog.m252i("TJAdUnitJSBridge", "creating AdUnit/JS Bridge");
        this.f194d = c;
        this.f197g = w;
        this.f193c = this;
        if (this.f197g == null) {
            TapjoyLog.m250e("TJAdUnitJSBridge", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Cannot create AdUnitJSBridge -- webview is NULL"));
            return;
        }
        this.f192b = new TJWebViewJSInterface(this.f197g, this);
        this.f197g.addJavascriptInterface(this.f192b, TJAdUnitConstants.JAVASCRIPT_INTERFACE_ID);
        setEnabled(true);
    }

    public void onDispatchMethod(String methodName, JSONObject json) {
        String str = null;
        if (this.f202l) {
            try {
                str = json.optString(String.CALLBACK_ID, null);
                JSONObject jSONObject = json.getJSONObject(String.DATA);
                Method method = TJAdUnitJSBridge.class.getMethod(methodName, new Class[]{JSONObject.class, String.class});
                TapjoyLog.m249d("TJAdUnitJSBridge", "Dispatching method: " + method + " with data=" + jSONObject + "; callbackID=" + str);
                method.invoke(this.f193c, new Object[]{jSONObject, str});
                return;
            } catch (Exception e) {
                e.printStackTrace();
                invokeJSCallback(str, Boolean.FALSE);
                return;
            }
        }
        TapjoyLog.m249d("TJAdUnitJSBridge", "Bridge currently disabled. Adding " + methodName + " to message queue");
        this.f191a.add(new Pair(methodName, json));
    }

    public void alert(JSONObject json, final String callbackID) {
        CharSequence charSequence;
        JSONArray jSONArray;
        Exception e;
        JSONArray jSONArray2;
        Object obj;
        Context context;
        AlertDialog create;
        TapjoyLog.m249d("TJAdUnitJSBridge", "alert_method: " + json);
        CharSequence charSequence2 = "";
        String str = "";
        JSONArray jSONArray3 = null;
        String string;
        try {
            charSequence2 = json.getString(String.TITLE);
            string = json.getString(String.MESSAGE);
            try {
                charSequence = string;
                jSONArray = json.getJSONArray(String.BUTTONS);
            } catch (Exception e2) {
                e = e2;
                invokeJSCallback(callbackID, Boolean.FALSE);
                e.printStackTrace();
                jSONArray2 = jSONArray3;
                obj = string;
                jSONArray = jSONArray2;
                context = this.f195e;
                if (context != null) {
                    TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot alert -- TJAdUnitActivity is null");
                }
                create = new Builder(context).setTitle(charSequence2).setMessage(charSequence).create();
                if (jSONArray != null) {
                }
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
        } catch (Exception e3) {
            Exception exception = e3;
            string = str;
            e = exception;
            invokeJSCallback(callbackID, Boolean.FALSE);
            e.printStackTrace();
            jSONArray2 = jSONArray3;
            obj = string;
            jSONArray = jSONArray2;
            context = this.f195e;
            if (context != null) {
                create = new Builder(context).setTitle(charSequence2).setMessage(charSequence).create();
                if (jSONArray != null) {
                }
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
            TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot alert -- TJAdUnitActivity is null");
        }
        context = this.f195e;
        if (context != null) {
            create = new Builder(context).setTitle(charSequence2).setMessage(charSequence).create();
            if (jSONArray != null || jSONArray.length() == 0) {
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                int i2;
                switch (i) {
                    case 0:
                        i2 = -2;
                        break;
                    case 1:
                        i2 = -3;
                        break;
                    default:
                        i2 = -1;
                        break;
                }
                try {
                    arrayList.add(jSONArray.getString(i));
                } catch (Exception e4) {
                    e4.printStackTrace();
                }
                create.setButton(i2, (CharSequence) arrayList.get(i), new OnClickListener(this) {
                    final /* synthetic */ TJAdUnitJSBridge f167b;

                    public final void onClick(DialogInterface dialog, int which) {
                        int i = 0;
                        switch (which) {
                            case -3:
                                i = 1;
                                break;
                            case TapjoyCache.CACHE_LIMIT /*-1*/:
                                i = 2;
                                break;
                        }
                        try {
                            this.f167b.invokeJSCallback(callbackID, Integer.valueOf(i));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
            create.setCancelable(false);
            create.setCanceledOnTouchOutside(false);
            create.show();
            return;
        }
        TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot alert -- TJAdUnitActivity is null");
    }

    public void checkAppInstalled(JSONObject json, String callbackID) {
        String str = "";
        try {
            str = json.getString(String.BUNDLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (str != null && str.length() > 0) {
            for (ApplicationInfo applicationInfo : this.f194d.getPackageManager().getInstalledApplications(0)) {
                if (applicationInfo.packageName.equals(str)) {
                    invokeJSCallback(callbackID, Boolean.TRUE);
                    return;
                }
            }
        }
        invokeJSCallback(callbackID, Boolean.FALSE);
    }

    public void getInstalledAppData(JSONObject json, String callbackID) {
        PackageManager packageManager = this.f194d.getPackageManager();
        List<ApplicationInfo> installedApplications = packageManager.getInstalledApplications(0);
        JSONArray jSONArray = new JSONArray();
        for (ApplicationInfo applicationInfo : installedApplications) {
            if ((applicationInfo.flags & 1) != 1) {
                Map hashMap = new HashMap();
                String str = applicationInfo.packageName;
                hashMap.put("packageName", str);
                hashMap.put("targetSdk", Integer.valueOf(applicationInfo.targetSdkVersion));
                try {
                    PackageInfo packageInfo = packageManager.getPackageInfo(str, 4096);
                    hashMap.put("installTime", new Date(packageInfo.firstInstallTime));
                    hashMap.put("updateTime", new Date(packageInfo.lastUpdateTime));
                    hashMap.put("versionName", packageInfo.versionName);
                    hashMap.put("versionCode", Integer.valueOf(packageInfo.versionCode));
                    jSONArray.put(new JSONObject(hashMap));
                } catch (Exception e) {
                }
            }
        }
        invokeJSCallback(callbackID, jSONArray);
    }

    public void closeRequested(Boolean shouldForceClose) {
        this.closeRequested = true;
        Map hashMap = new HashMap();
        hashMap.put(String.FORCE_CLOSE, shouldForceClose);
        invokeJSAdunitMethod(String.CLOSE_REQUESTED, hashMap);
    }

    public void getVolume(JSONObject json, String callbackID) {
        Map volumeArgs = getVolumeArgs();
        if (volumeArgs != null) {
            invokeJSCallback(callbackID, volumeArgs);
            return;
        }
        invokeJSCallback(callbackID, Boolean.valueOf(false));
    }

    public void onVolumeChanged() {
        invokeJSAdunitMethod(String.VOLUME_CHANGED, getVolumeArgs());
    }

    public HashMap getVolumeArgs() {
        if (this.f196f == null) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "No ad unit provided");
            return null;
        }
        String volume = this.f196f.getVolume();
        boolean isMuted = this.f196f.isMuted();
        TapjoyLog.m249d("TJAdUnitJSBridge", "getVolumeArgs: volume=" + volume + "; isMuted=" + isMuted);
        HashMap hashMap = new HashMap();
        hashMap.put(String.CURRENT_VOLUME, volume);
        hashMap.put(String.IS_MUTED, Boolean.valueOf(isMuted));
        return hashMap;
    }

    public void destroy() {
        if (this.f200j != null && this.f199i != null) {
            this.f199i.removeUpdates(this.f200j);
            this.f199i = null;
            this.f200j = null;
        }
    }

    public void dismiss(JSONObject json, String callbackID) {
        TJAdUnitActivity tJAdUnitActivity = this.f195e;
        if (tJAdUnitActivity != null) {
            invokeJSCallback(callbackID, Boolean.valueOf(true));
            tJAdUnitActivity.finish();
            return;
        }
        TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot dismiss -- TJAdUnitActivity is null");
        invokeJSCallback(callbackID, Boolean.valueOf(false));
    }

    public void display() {
        invokeJSAdunitMethod(String.DISPLAY, new Object[0]);
    }

    public void displayRichMedia(final JSONObject json, String callbackID) {
        boolean z;
        String string;
        try {
            z = json.getBoolean(String.INLINE);
        } catch (Exception e) {
            z = false;
        }
        try {
            string = json.getString(String.HTML);
        } catch (Exception e2) {
            e2.printStackTrace();
            string = null;
        }
        if (string == null) {
            invokeJSCallback(callbackID, Boolean.FALSE);
        } else if (z) {
            ((Activity) this.f194d).runOnUiThread(new Runnable(this) {
                final /* synthetic */ TJAdUnitJSBridge f177b;

                public final void run() {
                    String string;
                    try {
                        string = json.getString(String.HTML);
                    } catch (Exception e) {
                        e.printStackTrace();
                        string = null;
                    }
                    if (!(this.f177b.f201k == null || this.f177b.f201k.getParent() == null)) {
                        ((ViewGroup) this.f177b.f201k.getParent()).removeView(this.f177b.f201k);
                    }
                    View mraidView = new MraidView(this.f177b.f194d);
                    this.f177b.f197g.getSettings().setJavaScriptEnabled(true);
                    mraidView.setPlacementType(PLACEMENT_TYPE.INLINE);
                    mraidView.setLayoutParams(new LayoutParams(640, 100));
                    mraidView.setInitialScale(100);
                    mraidView.setBackgroundColor(0);
                    mraidView.loadDataWithBaseURL(null, string, "text/html", "utf-8", null);
                    int width = ((WindowManager) ((Activity) this.f177b.f194d).getSystemService("window")).getDefaultDisplay().getWidth();
                    this.f177b.f201k = TapjoyUtil.scaleDisplayAd(mraidView, width);
                    ((Activity) this.f177b.f194d).addContentView(this.f177b.f201k, new LayoutParams(width, (int) (100.0d * (((double) width) / 640.0d))));
                }
            });
        } else {
            Serializable tJPlacementData = new TJPlacementData(TapjoyConnectCore.getHostURL(), string, callbackID);
            Context context = this.f195e;
            if (context != null) {
                Intent intent = new Intent(context, TJAdUnitActivity.class);
                intent.putExtra(TJAdUnitConstants.EXTRA_TJ_PLACEMENT_DATA, tJPlacementData);
                context.startActivityForResult(intent, TJAdUnitConstants.MRAID_REQUEST_CODE);
            }
        }
    }

    public void displayStoreURL(JSONObject json, String callbackID) {
        displayURL(json, callbackID);
    }

    public void displayURL(JSONObject json, String callbackID) {
        try {
            String string = json.getString(String.URL);
            this.didLaunchOtherActivity = true;
            this.otherActivityCallbackID = callbackID;
            ((Activity) this.f194d).startActivity(new Intent("android.intent.action.VIEW", Uri.parse(string)));
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.TRUE);
            e.printStackTrace();
        }
    }

    public void clearCache(JSONObject json, String callbackID) {
        if (TapjoyCache.getInstance() != null) {
            TapjoyCache.getInstance().clearTapjoyCache();
            invokeJSCallback(callbackID, Boolean.TRUE);
            return;
        }
        invokeJSCallback(callbackID, Boolean.FALSE);
    }

    public void setPrerenderLimit(JSONObject json, String callbackID) {
        try {
            TJPlacementManager.setPreRenderedPlacementLimit(json.getInt(String.TJC_PLACEMENT_PRE_RENDERED_LIMIT));
            invokeJSCallback(callbackID, Boolean.TRUE);
        } catch (Exception e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to set Tapjoy placement pre-render limit. Invalid parameters.");
            invokeJSCallback(callbackID, Boolean.FALSE);
        }
    }

    public void setEventPreloadLimit(JSONObject json, String callbackID) {
        if (TapjoyCache.getInstance() != null) {
            try {
                TJPlacementManager.setCachedPlacementLimit(json.getInt(String.TJC_PLACEMENT_CACHE_LIMIT));
                invokeJSCallback(callbackID, Boolean.TRUE);
                return;
            } catch (Exception e) {
                TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to set Tapjoy cache's event preload limit. Invalid parameters.");
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
        }
        invokeJSCallback(callbackID, Boolean.FALSE);
    }

    public void removeAssetFromCache(JSONObject json, String callbackID) {
        try {
            String assetURL = json.getString(String.URL);
            if (TapjoyCache.getInstance() != null) {
                invokeJSCallback(callbackID, Boolean.valueOf(TapjoyCache.getInstance().removeAssetFromCache(assetURL)));
                return;
            }
            invokeJSCallback(callbackID, Boolean.FALSE);
        } catch (Exception e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to cache video. Invalid parameters.");
            invokeJSCallback(callbackID, Boolean.FALSE);
        }
    }

    public void cacheAsset(JSONObject json, String callbackID) {
        String str = "";
        Long valueOf = Long.valueOf(0);
        try {
            String assetURL = json.getString(String.URL);
            try {
                str = json.getString(TapjoyConstants.TJC_PLACEMENT_OFFER_ID);
            } catch (Exception e) {
            }
            try {
                valueOf = Long.valueOf(json.getLong(TapjoyConstants.TJC_TIME_TO_LIVE));
            } catch (Exception e2) {
            }
            if (TapjoyCache.getInstance() != null) {
                invokeJSCallback(callbackID, TapjoyCache.getInstance().cacheAssetFromURL(assetURL, str, valueOf.longValue()));
                return;
            }
            invokeJSCallback(callbackID, Boolean.FALSE);
        } catch (Exception e3) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to cache video. Invalid parameters.");
            invokeJSCallback(callbackID, Boolean.FALSE);
        }
    }

    public void cachePathForURL(JSONObject json, String callbackID) {
        try {
            String url = json.getString(String.URL);
            if (TapjoyCache.getInstance() != null) {
                invokeJSCallback(callbackID, TapjoyCache.getInstance().getPathOfCachedURL(url));
                return;
            }
            invokeJSCallback(callbackID, "");
        } catch (Exception e) {
            invokeJSCallback(callbackID, "");
        }
    }

    public void getCachedAssets(JSONObject json, String callbackID) {
        if (TapjoyCache.getInstance() != null) {
            invokeJSCallback(callbackID, TapjoyCache.getInstance().cachedAssetsToJSON());
            return;
        }
        invokeJSCallback(callbackID, "");
    }

    public void contentReady(JSONObject json, String callbackID) {
        if (this.f196f != null) {
            this.f196f.fireContentReady();
            invokeJSCallback(callbackID, Boolean.valueOf(true));
            return;
        }
        invokeJSCallback(callbackID, Boolean.valueOf(false));
    }

    public void setOrientation(JSONObject json, String callbackID) {
        if (this.f196f == null) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "No ad unit provided");
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            return;
        }
        try {
            String string = json.getString(String.ORIENTATION);
            int i = (string.equals(String.LANDSCAPE) || string.equals(String.LANDSCAPE_LEFT)) ? 0 : string.equals(String.LANDSCAPE_RIGHT) ? 8 : 1;
            this.f196f.setOrientation(i);
            invokeJSCallback(callbackID, Boolean.valueOf(true));
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void setBackgroundColor(JSONObject json, final String callbackID) {
        try {
            String backgroundHexColor = json.getString(String.BACKGROUND_COLOR);
            if (this.f196f != null) {
                this.f196f.setBackgroundColor(backgroundHexColor, new AdUnitAsyncTaskListner(this) {
                    final /* synthetic */ TJAdUnitJSBridge f179b;

                    public final void onComplete(boolean result) {
                        this.f179b.invokeJSCallback(callbackID, Boolean.valueOf(result));
                    }
                });
                return;
            }
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (Exception e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to set background color. Invalid parameters.");
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void setBackgroundWebViewContent(JSONObject json, final String callbackID) {
        TapjoyLog.m249d("TJAdUnitJSBridge", "setBackgroundWebViewContent");
        try {
            String string = json.getString(String.BACKGROUND_CONTENT);
            if (this.f196f != null) {
                this.f196f.setBackgroundContent(string, new AdUnitAsyncTaskListner(this) {
                    final /* synthetic */ TJAdUnitJSBridge f181b;

                    public final void onComplete(boolean result) {
                        this.f181b.invokeJSCallback(callbackID, Boolean.valueOf(result));
                    }
                });
                return;
            }
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (Exception e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to set background content. Invalid parameters.");
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void displayVideo(JSONObject json, final String callbackID) {
        try {
            String url = json.getString(String.URL);
            if (url.length() <= 0 || url == "") {
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
            this.f196f.loadVideoUrl(url, new AdUnitAsyncTaskListner(this) {
                final /* synthetic */ TJAdUnitJSBridge f183b;

                public final void onComplete(boolean result) {
                    this.f183b.invokeJSCallback(callbackID, Boolean.valueOf(result));
                }
            });
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            e.printStackTrace();
        }
    }

    public void playVideo(JSONObject json, String callbackID) {
        if (this.f196f != null) {
            invokeJSCallback(callbackID, Boolean.valueOf(this.f196f.playVideo()));
        }
    }

    public void pauseVideo(JSONObject json, String callbackID) {
        if (this.f196f != null) {
            invokeJSCallback(callbackID, Boolean.valueOf(this.f196f.pauseVideo()));
        }
    }

    public void clearVideo(JSONObject json, final String callbackID) {
        if (this.f196f != null) {
            this.f196f.clearVideo(new AdUnitAsyncTaskListner(this) {
                final /* synthetic */ TJAdUnitJSBridge f185b;

                public final void onComplete(boolean result) {
                    this.f185b.invokeJSCallback(callbackID, Boolean.valueOf(result));
                }
            });
        }
    }

    public void getLocation(JSONObject json, String callbackID) {
        boolean booleanValue;
        float f = Instance.NORMAL_SCALE;
        try {
            f = Float.valueOf(json.getString(String.GPS_ACCURACY)).floatValue();
        } catch (Exception e) {
        }
        try {
            booleanValue = Boolean.valueOf(json.getString(String.ENABLED)).booleanValue();
        } catch (Exception e2) {
            e2.printStackTrace();
            booleanValue = false;
        }
        this.f199i = (LocationManager) this.f194d.getSystemService("location");
        String bestProvider = this.f199i.getBestProvider(new Criteria(), false);
        if (this.f200j == null) {
            this.f200j = new LocationListener(this) {
                final /* synthetic */ TJAdUnitJSBridge f160a;

                {
                    this.f160a = r1;
                }

                public final void onLocationChanged(Location location) {
                    if (this.f160a.f194d == null || this.f160a.f197g == null) {
                        if (this.f160a.f199i != null && this.f160a.f200j != null) {
                            TapjoyLog.m249d("TJAdUnitJSBridge", "stopping updates");
                            this.f160a.f199i.removeUpdates(this.f160a.f200j);
                        }
                    } else if (location != null) {
                        Map hashMap = new HashMap();
                        hashMap.put(String.LAT, Double.valueOf(location.getLatitude()));
                        hashMap.put(String.LONG, Double.valueOf(location.getLongitude()));
                        hashMap.put(String.ALTITUDE, Double.valueOf(location.getAltitude()));
                        hashMap.put("timestamp", Long.valueOf(location.getTime()));
                        hashMap.put(String.SPEED, Float.valueOf(location.getSpeed()));
                        hashMap.put(String.COURSE, Float.valueOf(location.getBearing()));
                        this.f160a.invokeJSAdunitMethod(String.LOCATION_UPDATED, hashMap);
                    }
                }

                public final void onProviderEnabled(String p) {
                }

                public final void onProviderDisabled(String p) {
                }

                public final void onStatusChanged(String p, int status, Bundle extras) {
                }
            };
        }
        if (booleanValue) {
            if (bestProvider != null) {
                this.f199i.requestLocationUpdates(bestProvider, 0, f, this.f200j);
            } else {
                invokeJSCallback(callbackID, Boolean.FALSE);
                return;
            }
        } else if (!(this.f199i == null || this.f200j == null)) {
            this.f199i.removeUpdates(this.f200j);
        }
        invokeJSCallback(callbackID, Boolean.TRUE);
    }

    public void log(JSONObject json, String callbackID) {
        try {
            TapjoyLog.m249d("TJAdUnitJSBridge", "Logging message=" + json.getString(String.MESSAGE));
            invokeJSCallback(callbackID, Boolean.TRUE);
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            e.printStackTrace();
        }
    }

    public void openApp(JSONObject json, String callbackID) {
        try {
            this.f194d.startActivity(this.f194d.getPackageManager().getLaunchIntentForPackage(json.getString(String.BUNDLE)));
            invokeJSCallback(callbackID, Boolean.TRUE);
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            e.printStackTrace();
        }
    }

    @TargetApi(19)
    public void nativeEval(final JSONObject json, final String callbackID) {
        TapjoyUtil.runOnMainThread(new Runnable(this) {
            final /* synthetic */ TJAdUnitJSBridge f163c;

            public final void run() {
                try {
                    if (VERSION.SDK_INT >= 19) {
                        this.f163c.f197g.evaluateJavascript(json.getString(String.COMMAND), null);
                    } else {
                        this.f163c.f197g.loadUrl("javascript:" + json.getString(String.COMMAND));
                    }
                    this.f163c.invokeJSCallback(callbackID, Boolean.TRUE);
                } catch (Exception e) {
                    this.f163c.invokeJSCallback(callbackID, Boolean.FALSE);
                }
            }
        });
    }

    public void present(JSONObject json, String callbackID) {
        try {
            Boolean.valueOf(false);
            Boolean valueOf = Boolean.valueOf(false);
            Boolean valueOf2 = Boolean.valueOf(json.getString(String.VISIBLE));
            try {
                valueOf = Boolean.valueOf(json.getString(String.TRANSPARENT));
            } catch (Exception e) {
            }
            try {
                this.customClose = Boolean.valueOf(json.getString(String.CUSTOM_CLOSE)).booleanValue();
            } catch (Exception e2) {
            }
            new C0083a(this, this.f197g).execute(new Boolean[]{valueOf2, valueOf});
            invokeJSCallback(callbackID, Boolean.TRUE);
        } catch (Exception e3) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            e3.printStackTrace();
        }
    }

    public void triggerEvent(JSONObject json, String callbackID) {
        if (this.f196f != null) {
            try {
                String string = json.getString("eventName");
                if (string.equals(String.VIDEO_START)) {
                    this.f196f.fireOnVideoStart();
                } else if (string.equals(String.VIDEO_COMPLETE)) {
                    this.f196f.fireOnVideoComplete();
                } else if (string.equals(String.VIDEO_ERROR)) {
                    this.f196f.fireOnVideoError("Error while trying to play video.");
                }
            } catch (Exception e) {
                TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to triggerEvent. No event name.");
            }
        }
    }

    public void invokeJSAdunitMethod(String methodName, Object... args) {
        this.f192b.callback(new ArrayList(Arrays.asList(args)), methodName, null);
    }

    public void invokeJSAdunitMethod(String methodName, Map arguments) {
        this.f192b.callback(arguments, methodName, null);
    }

    public void invokeJSCallback(String callbackID, Object... argArray) {
        if (ct.m463c(callbackID)) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "invokeJSCallback -- no callbackID provided");
            return;
        }
        this.f192b.callback(new ArrayList(Arrays.asList(argArray)), "", callbackID);
    }

    public void invokeJSCallback(String callbackID, Map arguments) {
        this.f192b.callback(arguments, "", callbackID);
    }

    public void flushBacklogMessageQueue() {
        while (true) {
            Pair pair = (Pair) this.f191a.poll();
            if (pair != null) {
                onDispatchMethod((String) pair.first, (JSONObject) pair.second);
            } else {
                return;
            }
        }
    }

    public void flushMessageQueue() {
        this.f192b.flushMessageQueue();
    }

    public void setAllowRedirect(JSONObject json, String callbackID) {
        boolean z;
        try {
            z = json.getBoolean(String.ENABLED);
        } catch (Exception e) {
            z = true;
        }
        this.allowRedirect = z;
        invokeJSCallback(callbackID, Boolean.TRUE);
    }

    public void setAdUnitActivity(TJAdUnitActivity activity) {
        this.f195e = activity;
    }

    public void setSpinnerVisible(JSONObject json, String callbackID) {
        try {
            boolean visible = json.getBoolean(String.VISIBLE);
            String title = json.optString(String.TITLE);
            String message = json.optString(String.MESSAGE);
            Context context = this.f195e;
            if (context != null) {
                if (visible) {
                    this.f198h = ProgressDialog.show(context, title, message);
                } else if (this.f198h != null) {
                    this.f198h.dismiss();
                }
                invokeJSCallback(callbackID, Boolean.TRUE);
                return;
            }
            TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot setSpinnerVisible -- TJAdUnitActivity is null");
            invokeJSCallback(callbackID, Boolean.FALSE);
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            e.printStackTrace();
        }
    }

    public void setCloseButtonVisible(JSONObject json, String callbackID) {
        try {
            final boolean z = json.getBoolean(String.VISIBLE);
            TapjoyUtil.runOnMainThread(new Runnable(this) {
                final /* synthetic */ TJAdUnitJSBridge f165b;

                public final void run() {
                    TJAdUnitActivity f = this.f165b.f195e;
                    if (f != null) {
                        f.setCloseButtonVisibility(z);
                    } else {
                        TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot setCloseButtonVisible -- TJAdUnitActivity is null");
                    }
                }
            });
            invokeJSCallback(callbackID, Boolean.valueOf(true));
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            e.printStackTrace();
        }
    }

    public void setCloseButtonClickable(JSONObject json, String callbackID) {
        try {
            final boolean optBoolean = json.optBoolean(String.CLICKABLE);
            TapjoyUtil.runOnMainThread(new Runnable(this) {
                final /* synthetic */ TJAdUnitJSBridge f169b;

                public final void run() {
                    TJAdUnitActivity f = this.f169b.f195e;
                    if (f != null) {
                        f.setCloseButtonClickable(optBoolean);
                    } else {
                        TapjoyLog.m249d("TJAdUnitJSBridge", "Cannot setCloseButtonClickable -- TJAdUnitActivity is null");
                    }
                }
            });
            invokeJSCallback(callbackID, Boolean.valueOf(true));
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            e.printStackTrace();
        }
    }

    public void shouldClose(JSONObject json, String callbackID) {
        TJAdUnitActivity tJAdUnitActivity = this.f195e;
        try {
            Boolean.valueOf(false);
            if (Boolean.valueOf(json.getString(String.CLOSE)).booleanValue() && tJAdUnitActivity != null) {
                tJAdUnitActivity.finish();
            }
            invokeJSCallback(callbackID, Boolean.TRUE);
        } catch (Exception e) {
            invokeJSCallback(callbackID, Boolean.FALSE);
            if (tJAdUnitActivity != null) {
                tJAdUnitActivity.finish();
            }
            e.printStackTrace();
        }
        this.closeRequested = false;
    }

    public void setLoggingLevel(JSONObject json, String callbackID) {
        try {
            TapjoyAppSettings.getInstance().saveLoggingLevel(String.valueOf(json.getString(String.LOGGING_LEVEL)));
        } catch (Exception e) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "setLoggingLevel exception " + e.getLocalizedMessage());
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            e.printStackTrace();
        }
    }

    public void clearLoggingLevel(JSONObject json, String callbackID) {
        TapjoyAppSettings.getInstance().clearLoggingLevel();
    }

    public void attachVolumeListener(JSONObject json, String callbackID) {
        try {
            boolean z = json.getBoolean(String.ATTACH);
            int optInt = json.optInt(String.INTERVAL, TJAdUnitConstants.DEFAULT_VOLUME_CHECK_INTERVAL);
            if (optInt > 0) {
                this.f196f.attachVolumeListener(z, optInt);
                invokeJSCallback(callbackID, Boolean.valueOf(true));
                return;
            }
            TapjoyLog.m249d("TJAdUnitJSBridge", "Invalid `interval` value passed to attachVolumeListener(): interval=" + optInt);
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (Exception e) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "attachVolumeListener exception " + e.toString());
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            e.printStackTrace();
        }
    }

    public void initMoatVideoTracker(JSONObject json, String callbackID) {
        Activity activity = this.f195e;
        if (activity == null) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "Error from initMoatVideoTracker -- TJAdUnitActivity is null");
            invokeJSCallback(callbackID, Boolean.valueOf(false));
            return;
        }
        try {
            this.f203m = (ReactiveVideoTracker) MoatFactory.create(activity).createCustomTracker(new ReactiveVideoTrackerPlugin(json.getString(String.PARTNER_CODE)));
            if (this.f204n == null) {
                TapjoyLog.m249d("TJAdUnitJSBridge", "Initializing MOAT tracking events map");
                this.f204n = new HashMap();
                this.f204n.put(String.VIDEO_FIRST_QUARTILE, MoatAdEventType.AD_EVT_FIRST_QUARTILE);
                this.f204n.put(String.VIDEO_MIDPOINT, MoatAdEventType.AD_EVT_MID_POINT);
                this.f204n.put(String.VIDEO_THIRD_QUARTILE, MoatAdEventType.AD_EVT_THIRD_QUARTILE);
                this.f204n.put(String.VIDEO_COMPLETE, MoatAdEventType.AD_EVT_COMPLETE);
                this.f204n.put(String.VIDEO_PAUSED, MoatAdEventType.AD_EVT_PAUSED);
                this.f204n.put(String.VIDEO_PLAYING, MoatAdEventType.AD_EVT_PLAYING);
                this.f204n.put(String.VIDEO_START, MoatAdEventType.AD_EVT_START);
                this.f204n.put(String.VIDEO_STOPPED, MoatAdEventType.AD_EVT_STOPPED);
                this.f204n.put(String.VIDEO_SKIPPED, MoatAdEventType.AD_EVT_SKIPPED);
                this.f204n.put(String.VOLUME_CHANGED, MoatAdEventType.AD_EVT_VOLUME_CHANGE);
                this.f204n.put(String.ENTER_FULL_SCREEN, MoatAdEventType.AD_EVT_ENTER_FULLSCREEN);
                this.f204n.put(String.EXIT_FULL_SCREEN, MoatAdEventType.AD_EVT_EXIT_FULLSCREEN);
            }
            this.f205o = new Handler(Looper.getMainLooper());
            invokeJSCallback(callbackID, Boolean.valueOf(true));
        } catch (Exception e) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "initMoatVideoTracker exception " + e.toString());
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void startMoatVideoTracker(JSONObject json, final String callbackID) {
        try {
            final Integer valueOf = Integer.valueOf(json.getInt(String.VIDEO_LENGTH));
            final Map hashMap = new HashMap();
            JSONObject jSONObject = json.getJSONObject(String.AD_IDS);
            if (jSONObject != null) {
                Iterator keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String str = (String) keys.next();
                    hashMap.put(str, jSONObject.getString(str));
                }
            }
            this.f205o.post(new Runnable(this) {
                final /* synthetic */ TJAdUnitJSBridge f173d;

                public final void run() {
                    boolean trackVideoAd;
                    if (this.f173d.f203m != null) {
                        trackVideoAd = this.f173d.f203m.trackVideoAd(hashMap, valueOf, this.f173d.f197g);
                    } else {
                        trackVideoAd = false;
                    }
                    this.f173d.invokeJSCallback(callbackID, Boolean.valueOf(trackVideoAd));
                }
            });
        } catch (Exception e) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "startMoatVideoTracker exception " + e.toString());
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void triggerMoatVideoEvent(JSONObject json, String callbackID) {
        try {
            Integer valueOf = Integer.valueOf(json.getInt(String.CURRENT_VIDEO_TIME));
            String string = json.getString("eventName");
            MoatAdEventType moatAdEventType = null;
            if (this.f204n != null) {
                moatAdEventType = (MoatAdEventType) this.f204n.get(string);
            }
            if (moatAdEventType == null) {
                TapjoyLog.m249d("TJAdUnitJSBridge", "eventName:" + string + " has no matching MOAT event");
                invokeJSCallback(callbackID, Boolean.valueOf(false));
                return;
            }
            TapjoyLog.m249d("TJAdUnitJSBridge", "Sending MOAT event: " + moatAdEventType);
            final MoatAdEvent moatAdEvent = new MoatAdEvent(moatAdEventType, valueOf);
            this.f205o.post(new Runnable(this) {
                final /* synthetic */ TJAdUnitJSBridge f175b;

                public final void run() {
                    if (this.f175b.f203m != null) {
                        this.f175b.f203m.dispatchEvent(moatAdEvent);
                    }
                }
            });
            invokeJSCallback(callbackID, Boolean.valueOf(true));
        } catch (Exception e) {
            TapjoyLog.m249d("TJAdUnitJSBridge", "triggerMoatVideoEvent exception " + e.toString());
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        }
    }

    public void startUsageTrackingEvent(JSONObject json, String callbackID) {
        try {
            String string = json.getString(String.USAGE_TRACKER_NAME);
            if (string.isEmpty()) {
                TapjoyLog.m249d("TJAdUnitJSBridge", "Empty name for startUsageTrackingEvent");
                invokeJSCallback(callbackID, Boolean.valueOf(false));
                return;
            }
            if (this.f196f != null) {
                this.f196f.startAdContentTracking(string, json);
                invokeJSCallback(callbackID, Boolean.valueOf(true));
                return;
            }
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (JSONException e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to startUsageTrackingEvent. Invalid parameters: " + e);
        }
    }

    public void endUsageTrackingEvent(JSONObject json, String callbackID) {
        try {
            String string = json.getString(String.USAGE_TRACKER_NAME);
            if (string.isEmpty()) {
                TapjoyLog.m249d("TJAdUnitJSBridge", "Empty name for endUsageTrackingEvent");
                invokeJSCallback(callbackID, Boolean.valueOf(false));
                return;
            }
            if (this.f196f != null) {
                this.f196f.endAdContentTracking(string, json);
                invokeJSCallback(callbackID, Boolean.valueOf(true));
                return;
            }
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (JSONException e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to endUsageTrackingEvent. Invalid parameters: " + e);
        }
    }

    public void sendUsageTrackingEvent(JSONObject json, String callbackID) {
        try {
            String string = json.getString(String.USAGE_TRACKER_NAME);
            if (string.isEmpty()) {
                TapjoyLog.m249d("TJAdUnitJSBridge", "Empty name for sendUsageTrackingEvent");
                invokeJSCallback(callbackID, Boolean.valueOf(false));
                return;
            }
            if (this.f196f != null) {
                this.f196f.sendAdContentTracking(string, json);
                invokeJSCallback(callbackID, Boolean.valueOf(true));
                return;
            }
            invokeJSCallback(callbackID, Boolean.valueOf(false));
        } catch (JSONException e) {
            TapjoyLog.m254w("TJAdUnitJSBridge", "Unable to sendUsageTrackingEvent. Invalid parameters: " + e);
        }
    }

    public void setEnabled(boolean toggle) {
        this.f202l = toggle;
        if (this.f202l) {
            flushBacklogMessageQueue();
        }
    }

    public void onVideoReady(int videoDuration, int videoWidth, int videoHeight) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_READY_EVENT);
        hashMap.put(String.VIDEO_DURATION, Integer.valueOf(videoDuration));
        hashMap.put(String.VIDEO_WIDTH, Integer.valueOf(videoWidth));
        hashMap.put(String.VIDEO_HEIGHT, Integer.valueOf(videoHeight));
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoStarted(int currentTime) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_START_EVENT);
        hashMap.put(String.VIDEO_CURRENT_TIME, Integer.valueOf(currentTime));
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoProgress(int currentTime) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_PROGRESS_EVENT);
        hashMap.put(String.VIDEO_CURRENT_TIME, Integer.valueOf(currentTime));
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoPaused(int currentTime) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_PAUSE_EVENT);
        hashMap.put(String.VIDEO_CURRENT_TIME, Integer.valueOf(currentTime));
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoCompletion() {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_COMPLETE_EVENT);
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoInfo(String infoMessage) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_INFO_EVENT);
        hashMap.put(String.VIDEO_INFO, infoMessage);
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }

    public void onVideoError(String errorMessage) {
        Map hashMap = new HashMap();
        hashMap.put(String.VIDEO_EVENT_NAME, String.VIDEO_ERROR_EVENT);
        invokeJSAdunitMethod(String.VIDEO_EVENT, hashMap);
    }
}
