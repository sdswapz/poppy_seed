package com.tapjoy;

import android.content.Context;
import android.content.res.Configuration;
import android.util.DisplayMetrics;
import android.view.WindowManager;

public class TapjoyDisplayMetricsUtil {
    private Context f397a;
    private Configuration f398b;
    private DisplayMetrics f399c = new DisplayMetrics();

    public TapjoyDisplayMetricsUtil(Context theContext) {
        this.f397a = theContext;
        ((WindowManager) this.f397a.getSystemService("window")).getDefaultDisplay().getMetrics(this.f399c);
        this.f398b = this.f397a.getResources().getConfiguration();
    }

    public int getScreenDensityDPI() {
        return this.f399c.densityDpi;
    }

    public float getScreenDensityScale() {
        return this.f399c.density;
    }

    public int getScreenLayoutSize() {
        return this.f398b.screenLayout & 15;
    }
}
