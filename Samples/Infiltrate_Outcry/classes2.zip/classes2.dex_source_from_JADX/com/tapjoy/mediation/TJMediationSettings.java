package com.tapjoy.mediation;

import com.tapjoy.TapjoyErrorMessage;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.TapjoyLog;

public class TJMediationSettings {
    private static final String f1570a = TJMediationSettings.class.getSimpleName();
    private static TJMediationSettings f1571b;
    private long f1572c;

    private TJMediationSettings() {
        m1356a(20);
        TapjoyLog.m249d(f1570a, "Default mediation timeout set to 20s");
    }

    public static TJMediationSettings getInstance() {
        if (f1571b == null) {
            f1571b = new TJMediationSettings();
        }
        return f1571b;
    }

    public void setTimeout(String timeoutInSeconds) {
        try {
            m1356a(Integer.parseInt(timeoutInSeconds));
        } catch (NumberFormatException e) {
            TapjoyLog.m250e(f1570a, new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Invalid type! Make sure to pass in an `int` type for the `TapjoyConnectFlag.MEDIATION_TIMEOUT` value"));
        }
    }

    private void m1356a(int i) {
        if (i < 0) {
            TapjoyLog.m250e(f1570a, new TapjoyErrorMessage(ErrorType.INTEGRATION_ERROR, "Invalid type! Make sure to pass in a positive value for the `TapjoyConnectFlag.MEDIATION_TIMEOUT`"));
        } else {
            this.f1572c = ((long) i) * 1000;
        }
    }

    public long getTimeout() {
        TapjoyLog.m249d(f1570a, "Mediation timeout set to: " + this.f1572c + "ms");
        return this.f1572c;
    }
}
