package com.tapjoy.mediation;

public interface TJMediationNetwork {
    void init();
}
