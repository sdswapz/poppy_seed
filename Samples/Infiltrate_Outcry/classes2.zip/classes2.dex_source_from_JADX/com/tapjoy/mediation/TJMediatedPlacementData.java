package com.tapjoy.mediation;

import android.os.Bundle;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyException;
import com.tapjoy.TapjoyUtil;
import java.util.Map;
import java.util.Map.Entry;
import org.json.JSONException;
import org.json.JSONObject;

public class TJMediatedPlacementData {
    private String f1562a;
    private String f1563b;
    private String f1564c;
    private Bundle f1565d;
    private JSONObject f1566e;
    private String f1567f;
    private String f1568g;
    private int f1569h;

    public TJMediatedPlacementData(String mediatedData) {
        try {
            JSONObject jSONObject = new JSONObject(mediatedData);
            this.f1562a = jSONObject.getString(String.USAGE_TRACKER_NAME);
            this.f1563b = jSONObject.optString("description", "No description provided");
            this.f1564c = jSONObject.getString("class_name");
            this.f1565d = m1355a(TapjoyUtil.jsonToStringMap(jSONObject.getJSONObject("params")));
            this.f1566e = jSONObject.getJSONObject("next_call");
            this.f1567f = jSONObject.getString("fill_url");
            this.f1568g = jSONObject.getString("no_fill_url");
            this.f1569h = jSONObject.optInt("current_card_index", 0);
        } catch (JSONException e) {
            throw new TapjoyException("Could not create MediatedPlacementData. Malformed or missing data.");
        }
    }

    private static Bundle m1355a(Map map) {
        Bundle bundle = new Bundle();
        for (Entry entry : map.entrySet()) {
            bundle.putString((String) entry.getKey(), (String) entry.getValue());
        }
        return bundle;
    }

    public String getName() {
        return this.f1562a;
    }

    public String getClassname() {
        return this.f1564c;
    }

    public Bundle getExtras() {
        return this.f1565d;
    }

    public JSONObject getNextCall() {
        return this.f1566e;
    }

    public String getFillURL() {
        return this.f1567f;
    }

    public String getNoFillURL() {
        return this.f1568g;
    }
}
