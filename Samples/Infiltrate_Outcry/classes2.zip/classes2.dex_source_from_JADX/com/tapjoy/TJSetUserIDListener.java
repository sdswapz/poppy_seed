package com.tapjoy;

public interface TJSetUserIDListener {
    void onSetUserIDFailure(String str);

    void onSetUserIDSuccess();
}
