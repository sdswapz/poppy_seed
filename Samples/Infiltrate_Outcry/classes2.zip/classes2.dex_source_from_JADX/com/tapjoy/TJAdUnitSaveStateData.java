package com.tapjoy;

import java.io.Serializable;

public class TJAdUnitSaveStateData implements Serializable {
    public boolean isVideoComplete;
    public int seekTime;
}
