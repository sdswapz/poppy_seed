package com.tapjoy;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import java.util.concurrent.CountDownLatch;

@SuppressLint({"SetJavaScriptEnabled"})
public class TJEventOptimizer extends WebView {
    private static String f282a = "TJEventOptimizer";
    private static TJEventOptimizer f283b;
    private static CountDownLatch f284c;
    private Context f285d;
    private TJAdUnitJSBridge f286e;

    class C0100a extends WebChromeClient {
        final /* synthetic */ TJEventOptimizer f280a;

        private C0100a(TJEventOptimizer tJEventOptimizer) {
            this.f280a = tJEventOptimizer;
        }

        @TargetApi(8)
        public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            TapjoyLog.m249d(TJEventOptimizer.f282a, "JS CONSOLE: " + consoleMessage.message() + " -- From line " + consoleMessage.lineNumber() + " of " + consoleMessage.sourceId());
            return true;
        }
    }

    class C0101b extends WebViewClient {
        final /* synthetic */ TJEventOptimizer f281a;

        private C0101b(TJEventOptimizer tJEventOptimizer) {
            this.f281a = tJEventOptimizer;
        }

        public final void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            TapjoyLog.m250e(TJEventOptimizer.f282a, new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error encountered when instantiating a WebViewClient"));
        }

        public final void onPageFinished(WebView view, String url) {
            TapjoyLog.m249d(TJEventOptimizer.f282a, "boostrap html loaded successfully");
        }
    }

    private TJEventOptimizer(Context context) {
        super(context);
        this.f285d = context;
        this.f286e = new TJAdUnitJSBridge(this.f285d, (WebView) this);
        getSettings().setJavaScriptEnabled(true);
        setWebViewClient(new C0101b());
        setWebChromeClient(new C0100a());
        loadUrl(TapjoyConnectCore.getHostURL() + TJAdUnitConstants.EVENTS_PROXY_PATH + TapjoyUtil.convertURLParams(TapjoyConnectCore.getGenericURLParams(), true));
    }

    public static void init(final Context context) {
        TapjoyLog.m249d(f282a, "Initializing event optimizer");
        f284c = new CountDownLatch(1);
        TapjoyUtil.runOnMainThread(new Runnable() {
            public final void run() {
                try {
                    TJEventOptimizer.f283b = new TJEventOptimizer(context);
                } catch (Exception e) {
                    TapjoyLog.m254w(TJEventOptimizer.f282a, e.getMessage());
                }
                TJEventOptimizer.f284c.countDown();
            }
        });
        f284c.await();
        if (f283b == null) {
            throw new RuntimeException("Failed to init TJEventOptimizer");
        }
    }

    public static TJEventOptimizer getInstance() {
        return f283b;
    }
}
