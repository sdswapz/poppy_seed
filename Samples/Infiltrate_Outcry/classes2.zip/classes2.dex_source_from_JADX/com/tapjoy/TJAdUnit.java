package com.tapjoy;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnInfoListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnSeekCompleteListener;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.webkit.ConsoleMessage;
import android.webkit.WebView;
import android.widget.VideoView;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TJAdUnitJSBridge.AdUnitAsyncTaskListner;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.ct;
import com.tapjoy.internal.ep;
import com.tapjoy.internal.et;
import com.tapjoy.internal.fj;
import com.tapjoy.internal.gr;
import com.tapjoy.mraid.listener.MraidViewListener;
import com.tapjoy.mraid.view.BasicWebView;
import com.tapjoy.mraid.view.MraidView;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

public class TJAdUnit implements OnCompletionListener, OnErrorListener, OnInfoListener, OnPreparedListener {
    public static TJVideoListener publisherVideoListener;
    private final Runnable f117A = new C00601(this);
    private final Runnable f118B = new C00656(this);
    private final Runnable f119C = new C00667(this);
    TJAdUnitJSBridge f120a;
    BasicWebView f121b;
    MraidView f122c;
    VideoView f123d;
    volatile boolean f124e;
    private final Handler f125f = new Handler(Looper.getMainLooper());
    private TJAdUnitWebViewListener f126g;
    private TJAdUnitVideoListener f127h;
    private TJAdUnitActivity f128i;
    private int f129j;
    private boolean f130k;
    private boolean f131l;
    private boolean f132m;
    private ScheduledFuture f133n;
    private AudioManager f134o;
    private int f135p = 0;
    private int f136q;
    private boolean f137r;
    private boolean f138s;
    private boolean f139t;
    private boolean f140u;
    private boolean f141v;
    private int f142w = -1;
    private boolean f143x;
    private boolean f144y;
    private ep f145z;

    class C00601 implements Runnable {
        final /* synthetic */ TJAdUnit f94a;

        C00601(TJAdUnit tJAdUnit) {
            this.f94a = tJAdUnit;
        }

        public final void run() {
            int streamVolume = this.f94a.f134o.getStreamVolume(3);
            if (this.f94a.f135p != streamVolume) {
                this.f94a.f135p = streamVolume;
                this.f94a.f120a.onVolumeChanged();
            }
        }
    }

    class C00656 implements Runnable {
        final /* synthetic */ TJAdUnit f108a;

        C00656(TJAdUnit tJAdUnit) {
            this.f108a = tJAdUnit;
        }

        public final void run() {
            if (this.f108a.f123d.getCurrentPosition() != 0) {
                if (!this.f108a.f131l) {
                    this.f108a.f131l = true;
                }
                this.f108a.f120a.onVideoStarted(this.f108a.f129j);
                this.f108a.f119C.run();
            } else if (this.f108a.f143x) {
                this.f108a.f144y = true;
            } else {
                this.f108a.f125f.postDelayed(this.f108a.f118B, 200);
            }
        }
    }

    class C00667 implements Runnable {
        final /* synthetic */ TJAdUnit f109a;

        C00667(TJAdUnit tJAdUnit) {
            this.f109a = tJAdUnit;
        }

        public final void run() {
            this.f109a.f120a.onVideoProgress(this.f109a.f123d.getCurrentPosition());
            this.f109a.f125f.postDelayed(this.f109a.f119C, 500);
        }
    }

    public interface TJAdUnitVideoListener {
        void onVideoCompleted();

        void onVideoError(String str);

        void onVideoStart();
    }

    public interface TJAdUnitWebViewListener {
        void onClosed();

        void onContentReady();
    }

    class C0069a implements MraidViewListener {
        final /* synthetic */ TJAdUnit f116a;

        private C0069a(TJAdUnit tJAdUnit) {
            this.f116a = tJAdUnit;
        }

        public final boolean onResizeClose() {
            return false;
        }

        public final boolean onResize() {
            return false;
        }

        public final boolean onReady() {
            return false;
        }

        public final boolean onEventFired() {
            return false;
        }

        public final boolean onClose() {
            TJAdUnitActivity r = this.f116a.f128i;
            if (r != null) {
                r.handleClose();
            }
            return false;
        }

        @TargetApi(8)
        public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            int i = 0;
            if (this.f116a.f120a.closeRequested) {
                String[] strArr = new String[]{"Uncaught", "uncaught", "Error", String.VIDEO_ERROR, "not defined"};
                TapjoyLog.m249d("TJAdUnit", "shouldClose...");
                TJAdUnitActivity r = this.f116a.f128i;
                if (r != null) {
                    while (i < 5) {
                        if (consoleMessage.message().contains(strArr[i])) {
                            r.handleClose();
                            break;
                        }
                        i++;
                    }
                }
            }
            return true;
        }

        public final void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            TJAdUnitActivity r = this.f116a.f128i;
            if (r != null) {
                r.showErrorDialog();
            }
        }

        public final void onPageStarted(WebView view, String url, Bitmap favicon) {
            TapjoyLog.m249d("TJAdUnit", "onPageStarted: " + url);
            if (this.f116a.f120a != null) {
                this.f116a.f120a.allowRedirect = true;
                this.f116a.f120a.customClose = false;
                this.f116a.f120a.closeRequested = false;
                this.f116a.m112a();
            }
        }

        public final void onPageFinished(WebView view, String url) {
            TapjoyLog.m249d("TJAdUnit", "onPageFinished: " + url);
            if (!(this.f116a == null || this.f116a.f122c == null || !this.f116a.f122c.isMraid())) {
                this.f116a.f120a.allowRedirect = false;
            }
            TJAdUnitActivity r = this.f116a.f128i;
            if (r != null) {
                r.setProgressSpinnerVisibility(false);
            }
            this.f116a.f141v = true;
            if (this.f116a.f138s) {
                this.f116a.f120a.display();
            }
            this.f116a.f120a.flushMessageQueue();
        }

        @TargetApi(9)
        public final boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (m108a()) {
                boolean z;
                TapjoyLog.m249d("TJAdUnit", "interceptURL: " + url);
                if (this.f116a == null || this.f116a.f122c == null || !this.f116a.f122c.isMraid() || !url.contains("mraid")) {
                    z = false;
                } else {
                    z = true;
                }
                if (z) {
                    return false;
                }
                if (C0069a.m109a(url)) {
                    TapjoyLog.m249d("TJAdUnit", "Open redirecting URL:" + url);
                    ((MraidView) view).loadUrlStandard(url);
                    return true;
                } else if (this.f116a.f120a.allowRedirect) {
                    return false;
                } else {
                    view.loadUrl(url);
                    return true;
                }
            }
            TJAdUnitActivity r = this.f116a.f128i;
            if (r == null) {
                return true;
            }
            r.showErrorDialog();
            return true;
        }

        private static boolean m109a(String str) {
            try {
                CharSequence host = new URL(TapjoyConfig.TJC_SERVICE_URL).getHost();
                if ((host != null && str.contains(host)) || str.contains(TapjoyConnectCore.getRedirectDomain()) || str.contains(TapjoyUtil.getRedirectDomain(TapjoyConnectCore.getPlacementURL()))) {
                    return true;
                }
                return false;
            } catch (MalformedURLException e) {
                return false;
            }
        }

        private boolean m108a() {
            try {
                NetworkInfo activeNetworkInfo = this.f116a.f122c.getConnectivityManager().getActiveNetworkInfo();
                if (activeNetworkInfo != null && activeNetworkInfo.isAvailable() && activeNetworkInfo.isConnected()) {
                    return true;
                }
                return false;
            } catch (Exception e) {
                return false;
            }
        }
    }

    public boolean preload(TJPlacementData placementData, Context context) {
        if (this.f139t || !placementData.isPrerenderingRequested() || !TJPlacementManager.canPreRenderPlacement() || TapjoyConnectCore.isViewOpen()) {
            fireContentReady();
            return false;
        }
        TapjoyLog.m252i("TJAdUnit", "Pre-rendering ad unit for placement: " + placementData.getPlacementName());
        TJPlacementManager.incrementPlacementPreRenderCount();
        load(placementData, true, context);
        return true;
    }

    public void load(final TJPlacementData placementData, final boolean shouldPrerenderContent, final Context context) {
        this.f139t = false;
        TapjoyUtil.runOnMainThread(new Runnable(this) {
            final /* synthetic */ TJAdUnit f98d;

            public final void run() {
                TJAdUnit tJAdUnit = this.f98d;
                Context context = context;
                if (!(Looper.myLooper() != Looper.getMainLooper() || tJAdUnit.f124e || context == null)) {
                    TapjoyLog.m249d("TJAdUnit", "Constructing ad unit");
                    tJAdUnit.f124e = true;
                    tJAdUnit.f121b = new BasicWebView(context);
                    tJAdUnit.f121b.loadDataWithBaseURL(null, "<!DOCTYPE html><html><head><title>Tapjoy Background Webview</title></head></html>", "text/html", "utf-8", null);
                    tJAdUnit.f122c = new MraidView(context);
                    tJAdUnit.f122c.setListener(new C0069a());
                    tJAdUnit.f123d = new VideoView(context);
                    tJAdUnit.f123d.setOnCompletionListener(tJAdUnit);
                    tJAdUnit.f123d.setOnErrorListener(tJAdUnit);
                    tJAdUnit.f123d.setOnPreparedListener(tJAdUnit);
                    tJAdUnit.f123d.setVisibility(4);
                    tJAdUnit.f120a = new TJAdUnitJSBridge(context, tJAdUnit);
                    if (context instanceof TJAdUnitActivity) {
                        tJAdUnit.setAdUnitActivity((TJAdUnitActivity) context);
                    }
                }
                if (tJAdUnit.f124e) {
                    boolean z;
                    TapjoyLog.m252i("TJAdUnit", "Loading ad unit content");
                    this.f98d.f139t = true;
                    if (ct.m463c(placementData.getRedirectURL())) {
                        if (placementData.getBaseURL() == null || placementData.getHttpResponse() == null) {
                            TapjoyLog.m250e("TJAdUnit", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error loading ad unit content"));
                            this.f98d.f139t = false;
                        } else {
                            this.f98d.f122c.loadDataWithBaseURL(placementData.getBaseURL(), placementData.getHttpResponse(), "text/html", "utf-8", null);
                        }
                    } else if (placementData.isPreloadDisabled()) {
                        this.f98d.f122c.postUrl(placementData.getRedirectURL(), null);
                    } else {
                        this.f98d.f122c.loadUrl(placementData.getRedirectURL());
                    }
                    TJAdUnit tJAdUnit2 = this.f98d;
                    if (this.f98d.f139t && shouldPrerenderContent) {
                        z = true;
                    } else {
                        z = false;
                    }
                    tJAdUnit2.f140u = z;
                }
            }
        });
    }

    public void resume(TJAdUnitSaveStateData saveStateData) {
        if (this.f120a.didLaunchOtherActivity) {
            TapjoyLog.m249d("TJAdUnit", "onResume bridge.didLaunchOtherActivity callbackID: " + this.f120a.otherActivityCallbackID);
            this.f120a.invokeJSCallback(this.f120a.otherActivityCallbackID, Boolean.TRUE);
            this.f120a.didLaunchOtherActivity = false;
        }
        this.f143x = false;
        this.f120a.setEnabled(true);
        if (saveStateData != null) {
            this.f129j = saveStateData.seekTime;
            this.f123d.seekTo(this.f129j);
        }
        if (this.f144y) {
            this.f144y = false;
            this.f125f.postDelayed(this.f118B, 200);
        }
    }

    public void pause() {
        this.f143x = true;
        this.f120a.setEnabled(false);
        pauseVideo();
    }

    public void invokeBridgeCallback(String callbackID, Object... argArray) {
        if (this.f120a != null && callbackID != null) {
            this.f120a.invokeJSCallback(callbackID, argArray);
        }
    }

    public void destroy() {
        this.f120a.destroy();
        if (this.f121b != null) {
            this.f121b.removeAllViews();
            this.f121b = null;
        }
        if (this.f122c != null) {
            this.f122c.removeAllViews();
            this.f122c = null;
        }
        m116b();
        this.f124e = false;
        this.f138s = false;
        setAdUnitActivity(null);
        m112a();
        if (this.f126g != null) {
            this.f126g.onClosed();
        }
        resetContentLoadState();
    }

    public void resetContentLoadState() {
        this.f139t = false;
        this.f141v = false;
        this.f140u = false;
    }

    public void setVisible(boolean visible) {
        this.f138s = visible;
        if (this.f138s && this.f141v) {
            this.f120a.display();
        }
    }

    public void fireContentReady() {
        if (this.f126g != null) {
            this.f126g.onContentReady();
        }
    }

    public void closeRequested(boolean shouldForceClose) {
        if (this.f122c == null || !this.f122c.videoPlaying()) {
            this.f120a.closeRequested(Boolean.valueOf(shouldForceClose));
        } else {
            this.f122c.videoViewCleanup();
        }
    }

    public void setOrientation(int requestedOrientation) {
        int i = 0;
        TJAdUnitActivity tJAdUnitActivity = this.f128i;
        if (tJAdUnitActivity != null) {
            TJAdUnitActivity tJAdUnitActivity2 = this.f128i;
            if (tJAdUnitActivity2 != null) {
                int rotation = tJAdUnitActivity2.getWindowManager().getDefaultDisplay().getRotation();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                tJAdUnitActivity2.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int i2 = displayMetrics.widthPixels;
                int i3 = displayMetrics.heightPixels;
                if (((rotation != 0 && rotation != 2) || i3 <= i2) && ((rotation != 1 && rotation != 3) || i2 <= i3)) {
                    switch (rotation) {
                        case 0:
                            break;
                        case 1:
                            i = 1;
                            break;
                        case 2:
                            i = 8;
                            break;
                        case 3:
                            i = 9;
                            break;
                        default:
                            TapjoyLog.m254w("TJAdUnit", "Unknown screen orientation. Defaulting to landscape.");
                            break;
                    }
                }
                switch (rotation) {
                    case 0:
                        i = 1;
                        break;
                    case 1:
                        break;
                    case 2:
                        i = 9;
                        break;
                    case 3:
                        i = 8;
                        break;
                    default:
                        i = 1;
                        break;
                }
            }
            i = -1;
            if (this.f142w != -1) {
                i = this.f142w;
            }
            if ((m113a(i) && m113a(requestedOrientation)) || (m117b(i) && m117b(requestedOrientation))) {
                requestedOrientation = this.f142w;
            }
            tJAdUnitActivity.setRequestedOrientation(requestedOrientation);
            this.f142w = requestedOrientation;
            this.f137r = true;
        }
    }

    private void m112a() {
        TapjoyLog.m249d("TJAdUnit", "detachVolumeListener");
        if (this.f133n != null) {
            this.f133n.cancel(false);
            this.f133n = null;
        }
        this.f134o = null;
    }

    private static boolean m113a(int i) {
        return i == 0 || i == 8 || i == 6 || i == 11;
    }

    private static boolean m117b(int i) {
        return i == 1 || i == 9 || i == 7 || i == 12;
    }

    public void setAdUnitActivity(TJAdUnitActivity activity) {
        this.f128i = activity;
        if (this.f122c != null) {
            this.f122c.setContext(this.f128i);
        }
        if (this.f120a != null) {
            this.f120a.setAdUnitActivity(this.f128i);
        }
    }

    public void setAdContentTracker(ep adContentTracker) {
        this.f145z = adContentTracker;
    }

    public void setBackgroundColor(final String hexColor, final AdUnitAsyncTaskListner adUnitAsyncTaskListner) {
        TapjoyUtil.runOnMainThread(new Runnable(this) {
            final /* synthetic */ TJAdUnit f101c;

            public final void run() {
                try {
                    TapjoyLog.m249d("TJAdUnit", "setBackgroundColor: " + hexColor);
                    this.f101c.f121b.setBackgroundColor(Color.parseColor(hexColor));
                    adUnitAsyncTaskListner.onComplete(true);
                } catch (Exception e) {
                    TapjoyLog.m249d("TJAdUnit", "Error setting background color. backgroundWebView: " + this.f101c.f121b + ", hexColor: " + hexColor);
                    adUnitAsyncTaskListner.onComplete(false);
                }
            }
        });
    }

    public void setBackgroundContent(final String backgroundHTML, final AdUnitAsyncTaskListner adUnitAsyncTaskListner) {
        TapjoyUtil.runOnMainThread(new Runnable(this) {
            final /* synthetic */ TJAdUnit f104c;

            public final void run() {
                try {
                    TapjoyLog.m249d("TJAdUnit", "setBackgroundContent: " + backgroundHTML);
                    this.f104c.f121b.loadDataWithBaseURL(null, backgroundHTML, "text/html", "utf-8", null);
                    adUnitAsyncTaskListner.onComplete(true);
                } catch (Exception e) {
                    TapjoyLog.m249d("TJAdUnit", "Error setting background content. backgroundWebView: " + this.f104c.f121b + ", content: " + backgroundHTML);
                    adUnitAsyncTaskListner.onComplete(false);
                }
            }
        });
    }

    public void setWebViewListener(TJAdUnitWebViewListener adUnitWebViewListener) {
        this.f126g = adUnitWebViewListener;
    }

    public void setVideoListener(TJAdUnitVideoListener adUnitVideoListener) {
        this.f127h = adUnitVideoListener;
    }

    public int getOrientation() {
        return this.f142w;
    }

    public boolean hasCalledLoad() {
        return this.f139t;
    }

    public boolean isPrerendered() {
        return this.f140u;
    }

    public boolean isLockedOrientation() {
        return this.f137r;
    }

    public BasicWebView getBackgroundWebView() {
        return this.f121b;
    }

    public MraidView getWebView() {
        return this.f122c;
    }

    public boolean getCloseRequested() {
        return this.f120a.closeRequested;
    }

    public void loadVideoUrl(final String videoURL, final AdUnitAsyncTaskListner adUnitAsyncTaskListner) {
        TapjoyUtil.runOnMainThread(new Runnable(this) {
            final /* synthetic */ TJAdUnit f107c;

            public final void run() {
                if (this.f107c.f123d != null) {
                    TapjoyLog.m252i("TJAdUnit", "loadVideoUrl: " + videoURL);
                    this.f107c.f123d.setVideoPath(videoURL);
                    this.f107c.f123d.setVisibility(0);
                    this.f107c.f123d.seekTo(0);
                    adUnitAsyncTaskListner.onComplete(true);
                    return;
                }
                adUnitAsyncTaskListner.onComplete(false);
            }
        });
    }

    public boolean playVideo() {
        TapjoyLog.m252i("TJAdUnit", "playVideo");
        if (this.f123d == null) {
            return false;
        }
        this.f123d.start();
        this.f132m = false;
        this.f125f.postDelayed(this.f118B, 200);
        return true;
    }

    public boolean pauseVideo() {
        m116b();
        if (this.f123d == null || !this.f123d.isPlaying()) {
            return false;
        }
        this.f123d.pause();
        this.f129j = this.f123d.getCurrentPosition();
        TapjoyLog.m252i("TJAdUnit", "Video paused at: " + this.f129j);
        this.f120a.onVideoPaused(this.f129j);
        return true;
    }

    public void clearVideo(final AdUnitAsyncTaskListner adUnitAsyncTaskListner) {
        if (this.f123d != null) {
            m116b();
            TapjoyUtil.runOnMainThread(new Runnable(this) {
                final /* synthetic */ TJAdUnit f111b;

                public final void run() {
                    this.f111b.f123d.setVisibility(4);
                    this.f111b.f123d.stopPlayback();
                    this.f111b.f131l = false;
                    this.f111b.f130k = false;
                    this.f111b.f129j = 0;
                    adUnitAsyncTaskListner.onComplete(true);
                }
            });
            return;
        }
        adUnitAsyncTaskListner.onComplete(false);
    }

    public void attachVolumeListener(boolean isAttached, int interval) {
        TapjoyLog.m249d("TJAdUnit", "attachVolumeListener: isAttached=" + isAttached + "; interval=" + interval);
        m112a();
        if (isAttached) {
            TJAdUnitActivity tJAdUnitActivity = this.f128i;
            if (tJAdUnitActivity != null) {
                this.f134o = (AudioManager) tJAdUnitActivity.getSystemService("audio");
                this.f135p = this.f134o.getStreamVolume(3);
                this.f136q = this.f134o.getStreamMaxVolume(3);
                this.f133n = gr.f1283a.scheduleWithFixedDelay(this.f117A, (long) interval, (long) interval, TimeUnit.MILLISECONDS);
            }
        }
    }

    public VideoView getVideoView() {
        return this.f123d;
    }

    public int getVideoSeekTime() {
        return this.f129j;
    }

    public boolean isVideoComplete() {
        return this.f132m;
    }

    public void onPrepared(MediaPlayer mp) {
        TapjoyLog.m252i("TJAdUnit", "video -- onPrepared");
        final int duration = this.f123d.getDuration();
        final int measuredWidth = this.f123d.getMeasuredWidth();
        final int measuredHeight = this.f123d.getMeasuredHeight();
        if (this.f129j <= 0 || this.f123d.getCurrentPosition() == this.f129j) {
            this.f120a.onVideoReady(duration, measuredWidth, measuredHeight);
        } else {
            mp.setOnSeekCompleteListener(new OnSeekCompleteListener(this) {
                final /* synthetic */ TJAdUnit f115d;

                public final void onSeekComplete(MediaPlayer mp) {
                    this.f115d.f120a.onVideoReady(duration, measuredWidth, measuredHeight);
                }
            });
        }
        mp.setOnInfoListener(this);
    }

    public boolean onError(MediaPlayer mp, int what, int extra) {
        String str;
        TapjoyLog.m250e("TJAdUnit", new TapjoyErrorMessage(ErrorType.SDK_ERROR, "Error encountered when instantiating the VideoView: " + what + " - " + extra));
        this.f130k = true;
        m116b();
        switch (what) {
            case 100:
                str = "MEDIA_ERROR_SERVER_DIED";
                break;
            default:
                str = "MEDIA_ERROR_UNKNOWN";
                break;
        }
        str = str + " -- ";
        switch (extra) {
            case -1010:
                str = str + "MEDIA_ERROR_UNSUPPORTED";
                break;
            case -1007:
                str = str + "MEDIA_ERROR_MALFORMED";
                break;
            case -1004:
                str = str + "MEDIA_ERROR_IO";
                break;
            case -110:
                str = str + "MEDIA_ERROR_TIMED_OUT";
                break;
            default:
                str = str + "MEDIA_ERROR_EXTRA_UNKNOWN";
                break;
        }
        this.f120a.onVideoError(str);
        if (what == 1 || extra == -1004) {
            return true;
        }
        return false;
    }

    private void m116b() {
        this.f125f.removeCallbacks(this.f118B);
        this.f125f.removeCallbacks(this.f119C);
    }

    public void onCompletion(MediaPlayer mp) {
        TapjoyLog.m252i("TJAdUnit", "video -- onCompletion");
        m116b();
        this.f132m = true;
        if (!this.f130k) {
            this.f120a.onVideoCompletion();
        }
        this.f130k = false;
    }

    public void fireOnVideoStart() {
        TapjoyLog.m253v("TJAdUnit", "Firing onVideoStart");
        if (getPublisherVideoListener() != null) {
            getPublisherVideoListener().onVideoStart();
        }
        if (this.f127h != null) {
            this.f127h.onVideoStart();
        }
    }

    public void fireOnVideoError(String errorMessage) {
        TapjoyLog.m251e("TJAdUnit", "Firing onVideoError with error: " + errorMessage);
        if (getPublisherVideoListener() != null) {
            getPublisherVideoListener().onVideoError(3);
        }
        if (this.f127h != null) {
            this.f127h.onVideoError(errorMessage);
        }
    }

    public void fireOnVideoComplete() {
        TapjoyLog.m253v("TJAdUnit", "Firing onVideoComplete");
        if (getPublisherVideoListener() != null) {
            getPublisherVideoListener().onVideoComplete();
        }
        if (this.f127h != null) {
            this.f127h.onVideoCompleted();
        }
    }

    public String getVolume() {
        double d = ((double) this.f135p) / ((double) this.f136q);
        return String.format("%.2f", new Object[]{Double.valueOf(d)});
    }

    public boolean isMuted() {
        return this.f135p == 0;
    }

    public void startAdContentTracking(String name, JSONObject adUnitParams) {
        if (this.f145z != null) {
            this.f145z.m788a(name, adUnitParams);
        }
    }

    public void endAdContentTracking(String name, JSONObject adUnitParams) {
        if (this.f145z != null) {
            m119c();
            this.f145z.m789b(name, adUnitParams);
        }
    }

    public void sendAdContentTracking(String name, JSONObject adUnitParams) {
        if (this.f145z != null) {
            m119c();
            et etVar = this.f145z;
            Map a = ep.m786a(adUnitParams);
            fj.m881e(name).m865a(etVar.f988a).m865a(a).m868b(ep.m787b(adUnitParams)).m869c();
        }
    }

    private void m119c() {
        if (this.f145z != null) {
            this.f145z.m783a("prerendered", Boolean.valueOf(this.f140u));
        }
    }

    public boolean onInfo(MediaPlayer mp, int what, int extra) {
        String str = "";
        switch (what) {
            case 3:
                str = "MEDIA_INFO_VIDEO_RENDERING_START";
                break;
            case 700:
                str = "MEDIA_INFO_VIDEO_TRACK_LAGGING";
                break;
            case 701:
                str = "MEDIA_INFO_BUFFERING_START";
                break;
            case 702:
                str = "MEDIA_INFO_BUFFERING_END";
                break;
            case 801:
                str = "MEDIA_INFO_NOT_SEEKABLE";
                break;
        }
        this.f120a.onVideoInfo(str);
        return false;
    }

    public TJVideoListener getPublisherVideoListener() {
        return publisherVideoListener;
    }
}
