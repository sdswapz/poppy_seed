package com.tapjoy;

public class TapjoyException extends Exception {
    public TapjoyException(String message) {
        super(message);
    }
}
