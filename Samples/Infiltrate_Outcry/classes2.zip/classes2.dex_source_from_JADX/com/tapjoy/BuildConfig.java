package com.tapjoy;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.tapjoy.android";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 11110;
    public static final String VERSION_NAME = "11.11.0";
}
