package com.tapjoy;

import java.io.Serializable;
import org.json.JSONException;
import org.json.JSONObject;

public class TapjoyCachedAssetData implements Serializable {
    private long f332a;
    private long f333b;
    private String f334c;
    private String f335d;
    private String f336e;
    private long f337f;
    private String f338g;
    private String f339h;

    public TapjoyCachedAssetData(String assetURL, String localFilePath, long timeToLiveInSeconds) {
        this(assetURL, localFilePath, timeToLiveInSeconds, System.currentTimeMillis() / 1000);
    }

    public TapjoyCachedAssetData(String assetURL, String localFilePath, long timeToLiveInSeconds, long timestampInSeconds) {
        setAssetURL(assetURL);
        setLocalFilePath(localFilePath);
        this.f333b = timeToLiveInSeconds;
        this.f332a = timestampInSeconds;
        this.f337f = timestampInSeconds + timeToLiveInSeconds;
    }

    public void setAssetURL(String assetURL) {
        this.f334c = assetURL;
        this.f338g = TapjoyUtil.determineMimeType(assetURL);
    }

    public void setLocalFilePath(String localFilePath) {
        this.f335d = localFilePath;
        this.f336e = "file://" + localFilePath;
    }

    public void resetTimeToLive(long timeToLiveInSeconds) {
        this.f333b = timeToLiveInSeconds;
        this.f337f = (System.currentTimeMillis() / 1000) + timeToLiveInSeconds;
    }

    public void setOfferID(String offerID) {
        this.f339h = offerID;
    }

    public long getTimestampInSeconds() {
        return this.f332a;
    }

    public long getTimeToLiveInSeconds() {
        return this.f333b;
    }

    public long getTimeOfDeathInSeconds() {
        return this.f337f;
    }

    public String getAssetURL() {
        return this.f334c;
    }

    public String getLocalFilePath() {
        return this.f335d;
    }

    public String getLocalURL() {
        return this.f336e;
    }

    public String getMimeType() {
        return this.f338g;
    }

    public String getOfferId() {
        return this.f339h;
    }

    public JSONObject toJSON() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("timestamp", getTimestampInSeconds());
            jSONObject.put(TapjoyConstants.TJC_TIME_TO_LIVE, getTimeToLiveInSeconds());
            jSONObject.put("assetURL", getAssetURL());
            jSONObject.put("localFilePath", getLocalFilePath());
            jSONObject.put("offerID", getOfferId());
        } catch (JSONException e) {
        }
        return jSONObject;
    }

    public String toRawJSONString() {
        return toJSON().toString();
    }

    public static TapjoyCachedAssetData fromRawJSONString(String jsonRep) {
        try {
            return fromJSONObject(new JSONObject(jsonRep));
        } catch (JSONException e) {
            TapjoyLog.m252i("TapjoyCachedAssetData", "Can not build TapjoyVideoObject -- error reading json string");
            return null;
        }
    }

    public static TapjoyCachedAssetData fromJSONObject(JSONObject data) {
        TapjoyCachedAssetData tapjoyCachedAssetData;
        try {
            tapjoyCachedAssetData = new TapjoyCachedAssetData(data.getString("assetURL"), data.getString("localFilePath"), data.getLong(TapjoyConstants.TJC_TIME_TO_LIVE), data.getLong("timestamp"));
            try {
                tapjoyCachedAssetData.setOfferID(data.optString("offerID"));
            } catch (JSONException e) {
                TapjoyLog.m252i("TapjoyCachedAssetData", "Can not build TapjoyVideoObject -- not enough data.");
                return tapjoyCachedAssetData;
            }
        } catch (JSONException e2) {
            tapjoyCachedAssetData = null;
            TapjoyLog.m252i("TapjoyCachedAssetData", "Can not build TapjoyVideoObject -- not enough data.");
            return tapjoyCachedAssetData;
        }
        return tapjoyCachedAssetData;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nURL=").append(this.f336e).append("\n");
        stringBuilder.append("AssetURL=").append(this.f334c).append("\n");
        stringBuilder.append("MimeType=").append(this.f338g).append("\n");
        stringBuilder.append("Timestamp=").append(getTimestampInSeconds()).append("\n");
        stringBuilder.append("TimeOfDeath=").append(this.f337f).append("\n");
        stringBuilder.append("TimeToLive=").append(this.f333b).append("\n");
        return stringBuilder.toString();
    }
}
