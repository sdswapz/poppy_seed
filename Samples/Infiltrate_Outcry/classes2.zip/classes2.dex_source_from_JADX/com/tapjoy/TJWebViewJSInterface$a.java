package com.tapjoy;

import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.webkit.WebView;
import com.tapjoy.TapjoyErrorMessage.ErrorType;

@TargetApi(19)
class TJWebViewJSInterface$a extends AsyncTask {
    WebView f308a;
    final /* synthetic */ TJWebViewJSInterface f309b;

    protected final /* bridge */ /* synthetic */ Object doInBackground(Object[] objArr) {
        return ((String[]) objArr)[0];
    }

    protected final /* synthetic */ void onPostExecute(Object obj) {
        String str = (String) obj;
        if (this.f308a == null) {
            return;
        }
        if (!str.startsWith("javascript:") || VERSION.SDK_INT < 19) {
            try {
                this.f308a.loadUrl(str);
                return;
            } catch (Exception e) {
                TapjoyLog.m250e("TJWebViewJSInterface", new TapjoyErrorMessage(ErrorType.INTERNAL_ERROR, "Exception in loadUrl. Device not supported. " + e.toString()));
                return;
            }
        }
        try {
            this.f308a.evaluateJavascript(str.replaceFirst("javascript:", ""), null);
        } catch (Exception e2) {
            TapjoyLog.m250e("TJWebViewJSInterface", new TapjoyErrorMessage(ErrorType.INTERNAL_ERROR, "Exception in evaluateJavascript. Device not supported. " + e2.toString()));
        }
    }

    public TJWebViewJSInterface$a(TJWebViewJSInterface tJWebViewJSInterface, WebView webView) {
        this.f309b = tJWebViewJSInterface;
        this.f308a = webView;
    }
}
