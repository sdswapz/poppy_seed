package com.tapjoy;

public interface TJEarnedCurrencyListener {
    void onEarnedCurrency(String str, int i);
}
