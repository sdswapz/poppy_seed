package com.tapjoy;

public class TapjoyRevision {
    public static final String GIT_REVISION = "30ef4dc";
}
