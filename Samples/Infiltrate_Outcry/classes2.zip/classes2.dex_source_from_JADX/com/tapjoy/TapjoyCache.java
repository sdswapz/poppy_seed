package com.tapjoy;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Environment;
import android.text.TextUtils;
import com.tapjoy.TJAdUnitConstants.String;
import com.tapjoy.TapjoyErrorMessage.ErrorType;
import com.tapjoy.internal.em;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TapjoyCache {
    public static final String CACHE_DIRECTORY_NAME = "Tapjoy/Cache/";
    public static final int CACHE_LIMIT = -1;
    private static TapjoyCache f324a = null;
    public static boolean unit_test_mode = false;
    private Context f325b;
    private TapjoyCacheMap f326c;
    private Vector f327d;
    private ExecutorService f328e;
    private File f329f;

    public class CacheAssetThread implements Callable {
        final /* synthetic */ TapjoyCache f320a;
        private URL f321b;
        private String f322c;
        private long f323d;

        public CacheAssetThread(TapjoyCache this$0, URL assetURL, String offerId, long timeToLive) {
            this.f320a = this$0;
            this.f321b = assetURL;
            this.f322c = offerId;
            this.f323d = timeToLive;
            if (this.f323d <= 0) {
                this.f323d = 86400;
            }
            this$0.f327d.add(TapjoyCache.m212b(this.f321b.toString()));
        }

        public Boolean call() {
            BufferedInputStream bufferedInputStream;
            BufferedOutputStream bufferedOutputStream;
            SocketTimeoutException e;
            BufferedInputStream bufferedInputStream2;
            Boolean valueOf;
            Throwable th;
            Exception e2;
            BufferedOutputStream bufferedOutputStream2 = null;
            String a = TapjoyCache.m212b(this.f321b.toString());
            if (this.f320a.f326c.containsKey(a)) {
                if (new File(((TapjoyCachedAssetData) this.f320a.f326c.get(a)).getLocalFilePath()).exists()) {
                    if (this.f323d != 0) {
                        ((TapjoyCachedAssetData) this.f320a.f326c.get(a)).resetTimeToLive(this.f323d);
                    } else {
                        ((TapjoyCachedAssetData) this.f320a.f326c.get(a)).resetTimeToLive(86400);
                    }
                    TapjoyLog.m249d("TapjoyCache", "Reseting time to live for " + this.f321b.toString());
                    this.f320a.f327d.remove(a);
                    return Boolean.valueOf(true);
                }
                TapjoyCache.getInstance().removeAssetFromCache(a);
            }
            System.currentTimeMillis();
            try {
                File file = new File(this.f320a.f329f + "/" + TapjoyUtil.SHA256(a));
                TapjoyLog.m249d("TapjoyCache", "Downloading and caching asset from: " + this.f321b + " to " + file);
                try {
                    URLConnection a2 = em.m772a(this.f321b);
                    a2.setConnectTimeout(15000);
                    a2.setReadTimeout(30000);
                    a2.connect();
                    bufferedInputStream = new BufferedInputStream(a2.getInputStream());
                    try {
                        bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(file));
                        try {
                            TapjoyUtil.writeFileToDevice(bufferedInputStream, bufferedOutputStream);
                            try {
                                bufferedInputStream.close();
                            } catch (IOException e3) {
                            }
                            try {
                                bufferedOutputStream.close();
                            } catch (IOException e4) {
                            }
                            TapjoyCachedAssetData tapjoyCachedAssetData = new TapjoyCachedAssetData(this.f321b.toString(), file.getAbsolutePath(), this.f323d);
                            if (this.f322c != null) {
                                tapjoyCachedAssetData.setOfferID(this.f322c);
                            }
                            this.f320a.f326c.put(a, tapjoyCachedAssetData);
                            this.f320a.f327d.remove(a);
                            TapjoyLog.m249d("TapjoyCache", "----- Download complete -----" + tapjoyCachedAssetData.toString());
                            return Boolean.valueOf(true);
                        } catch (SocketTimeoutException e5) {
                            e = e5;
                            bufferedInputStream2 = bufferedInputStream;
                            try {
                                TapjoyLog.m250e("TapjoyCache", new TapjoyErrorMessage(ErrorType.NETWORK_ERROR, "Network timeout during caching: " + e.toString()));
                                this.f320a.f327d.remove(a);
                                TapjoyUtil.deleteFileOrDirectory(file);
                                valueOf = Boolean.valueOf(false);
                                if (bufferedInputStream2 != null) {
                                    try {
                                        bufferedInputStream2.close();
                                    } catch (IOException e6) {
                                    }
                                }
                                if (bufferedOutputStream != null) {
                                    return valueOf;
                                }
                                try {
                                    bufferedOutputStream.close();
                                    return valueOf;
                                } catch (IOException e7) {
                                    return valueOf;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                bufferedInputStream = bufferedInputStream2;
                                bufferedOutputStream2 = bufferedOutputStream;
                                if (bufferedInputStream != null) {
                                    try {
                                        bufferedInputStream.close();
                                    } catch (IOException e8) {
                                    }
                                }
                                if (bufferedOutputStream2 != null) {
                                    try {
                                        bufferedOutputStream2.close();
                                    } catch (IOException e9) {
                                    }
                                }
                                throw th;
                            }
                        } catch (Exception e10) {
                            e2 = e10;
                            bufferedOutputStream2 = bufferedOutputStream;
                            try {
                                TapjoyLog.m251e("TapjoyCache", "Error caching asset: " + e2.toString());
                                this.f320a.f327d.remove(a);
                                TapjoyUtil.deleteFileOrDirectory(file);
                                valueOf = Boolean.valueOf(false);
                                if (bufferedInputStream != null) {
                                    try {
                                        bufferedInputStream.close();
                                    } catch (IOException e11) {
                                    }
                                }
                                if (bufferedOutputStream2 != null) {
                                    return valueOf;
                                }
                                try {
                                    bufferedOutputStream2.close();
                                    return valueOf;
                                } catch (IOException e12) {
                                    return valueOf;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                if (bufferedInputStream != null) {
                                    bufferedInputStream.close();
                                }
                                if (bufferedOutputStream2 != null) {
                                    bufferedOutputStream2.close();
                                }
                                throw th;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                            bufferedOutputStream2 = bufferedOutputStream;
                            if (bufferedInputStream != null) {
                                bufferedInputStream.close();
                            }
                            if (bufferedOutputStream2 != null) {
                                bufferedOutputStream2.close();
                            }
                            throw th;
                        }
                    } catch (SocketTimeoutException e13) {
                        e = e13;
                        bufferedOutputStream = null;
                        bufferedInputStream2 = bufferedInputStream;
                        TapjoyLog.m250e("TapjoyCache", new TapjoyErrorMessage(ErrorType.NETWORK_ERROR, "Network timeout during caching: " + e.toString()));
                        this.f320a.f327d.remove(a);
                        TapjoyUtil.deleteFileOrDirectory(file);
                        valueOf = Boolean.valueOf(false);
                        if (bufferedInputStream2 != null) {
                            bufferedInputStream2.close();
                        }
                        if (bufferedOutputStream != null) {
                            return valueOf;
                        }
                        bufferedOutputStream.close();
                        return valueOf;
                    } catch (Exception e14) {
                        e2 = e14;
                        TapjoyLog.m251e("TapjoyCache", "Error caching asset: " + e2.toString());
                        this.f320a.f327d.remove(a);
                        TapjoyUtil.deleteFileOrDirectory(file);
                        valueOf = Boolean.valueOf(false);
                        if (bufferedInputStream != null) {
                            bufferedInputStream.close();
                        }
                        if (bufferedOutputStream2 != null) {
                            return valueOf;
                        }
                        bufferedOutputStream2.close();
                        return valueOf;
                    }
                } catch (SocketTimeoutException e15) {
                    e = e15;
                    bufferedOutputStream = null;
                    TapjoyLog.m250e("TapjoyCache", new TapjoyErrorMessage(ErrorType.NETWORK_ERROR, "Network timeout during caching: " + e.toString()));
                    this.f320a.f327d.remove(a);
                    TapjoyUtil.deleteFileOrDirectory(file);
                    valueOf = Boolean.valueOf(false);
                    if (bufferedInputStream2 != null) {
                        bufferedInputStream2.close();
                    }
                    if (bufferedOutputStream != null) {
                        return valueOf;
                    }
                    bufferedOutputStream.close();
                    return valueOf;
                } catch (Exception e16) {
                    e2 = e16;
                    bufferedInputStream = null;
                    TapjoyLog.m251e("TapjoyCache", "Error caching asset: " + e2.toString());
                    this.f320a.f327d.remove(a);
                    TapjoyUtil.deleteFileOrDirectory(file);
                    valueOf = Boolean.valueOf(false);
                    if (bufferedInputStream != null) {
                        bufferedInputStream.close();
                    }
                    if (bufferedOutputStream2 != null) {
                        return valueOf;
                    }
                    bufferedOutputStream2.close();
                    return valueOf;
                } catch (Throwable th5) {
                    th = th5;
                    bufferedInputStream = null;
                    if (bufferedInputStream != null) {
                        bufferedInputStream.close();
                    }
                    if (bufferedOutputStream2 != null) {
                        bufferedOutputStream2.close();
                    }
                    throw th;
                }
            } catch (Exception e17) {
                this.f320a.f327d.remove(a);
                return Boolean.valueOf(false);
            }
        }
    }

    public TapjoyCache(Context applicationContext) {
        if (f324a == null || unit_test_mode) {
            f324a = this;
            this.f325b = applicationContext;
            this.f326c = new TapjoyCacheMap(applicationContext, -1);
            this.f327d = new Vector();
            this.f328e = Executors.newFixedThreadPool(5);
            if (Environment.getExternalStorageDirectory() != null) {
                TapjoyUtil.deleteFileOrDirectory(new File(Environment.getExternalStorageDirectory(), "tapjoy"));
                TapjoyUtil.deleteFileOrDirectory(new File(Environment.getExternalStorageDirectory(), "tjcache/tmp/"));
            }
            this.f329f = new File(this.f325b.getFilesDir() + "/Tapjoy/Cache/");
            if (!this.f329f.exists()) {
                if (this.f329f.mkdirs()) {
                    TapjoyLog.m249d("TapjoyCache", "Created directory at: " + this.f329f.getPath());
                } else {
                    TapjoyLog.m251e("TapjoyCache", "Error initalizing cache");
                    f324a = null;
                }
            }
            m210a();
        }
    }

    private void m210a() {
        SharedPreferences sharedPreferences = this.f325b.getSharedPreferences(TapjoyConstants.PREF_TAPJOY_CACHE, 0);
        Editor edit = sharedPreferences.edit();
        for (Entry entry : sharedPreferences.getAll().entrySet()) {
            File file = new File((String) entry.getKey());
            if (file.exists() && file.isFile()) {
                TapjoyCachedAssetData fromRawJSONString = TapjoyCachedAssetData.fromRawJSONString(entry.getValue().toString());
                if (fromRawJSONString != null) {
                    TapjoyLog.m249d("TapjoyCache", "Loaded Asset: " + fromRawJSONString.getAssetURL());
                    String b = m212b(fromRawJSONString.getAssetURL());
                    if (b == null || "".equals(b) || b.length() <= 0) {
                        TapjoyLog.m251e("TapjoyCache", "Removing asset because deserialization failed.");
                        edit.remove((String) entry.getKey()).commit();
                    } else if (fromRawJSONString.getTimeOfDeathInSeconds() < System.currentTimeMillis() / 1000) {
                        TapjoyLog.m249d("TapjoyCache", "Asset expired, removing from cache: " + fromRawJSONString.getAssetURL());
                        if (fromRawJSONString.getLocalFilePath() != null && fromRawJSONString.getLocalFilePath().length() > 0) {
                            TapjoyUtil.deleteFileOrDirectory(new File(fromRawJSONString.getLocalFilePath()));
                        }
                    } else {
                        this.f326c.put(b, fromRawJSONString);
                    }
                } else {
                    TapjoyLog.m251e("TapjoyCache", "Removing asset because deserialization failed.");
                    edit.remove((String) entry.getKey()).commit();
                }
            } else {
                TapjoyLog.m249d("TapjoyCache", "Removing reference to missing asset: " + ((String) entry.getKey()));
                edit.remove((String) entry.getKey()).commit();
            }
        }
    }

    public void cacheAssetGroup(final JSONArray assetGroup, final TJCacheListener tapjoyCacheListener) {
        if (assetGroup != null && assetGroup.length() > 0) {
            new Thread(this) {
                final /* synthetic */ TapjoyCache f319c;

                public final void run() {
                    int i;
                    TapjoyLog.m249d("TapjoyCache", "Starting to cache asset group size of " + assetGroup.length());
                    List<Future> arrayList = new ArrayList();
                    int i2 = 1;
                    for (i = 0; i < assetGroup.length(); i++) {
                        try {
                            Future cacheAssetFromJSONObject = this.f319c.cacheAssetFromJSONObject(assetGroup.getJSONObject(i));
                            if (cacheAssetFromJSONObject != null) {
                                arrayList.add(cacheAssetFromJSONObject);
                            }
                        } catch (JSONException e) {
                            TapjoyLog.m251e("TapjoyCache", "Failed to load JSON object from JSONArray");
                        }
                    }
                    for (Future future : arrayList) {
                        try {
                            if (((Boolean) future.get()).booleanValue()) {
                                i = i2;
                            } else {
                                i = 2;
                            }
                            i2 = i;
                        } catch (InterruptedException e2) {
                            TapjoyLog.m251e("TapjoyCache", "Caching thread failed: " + e2.toString());
                            i2 = 2;
                        } catch (ExecutionException e3) {
                            TapjoyLog.m251e("TapjoyCache", "Caching thread failed: " + e3.toString());
                            i2 = 2;
                        }
                    }
                    TapjoyLog.m249d("TapjoyCache", "Finished caching group");
                    if (tapjoyCacheListener != null) {
                        tapjoyCacheListener.onCachingComplete(i2);
                    }
                }
            }.start();
        } else if (tapjoyCacheListener != null) {
            tapjoyCacheListener.onCachingComplete(1);
        }
    }

    public Future cacheAssetFromJSONObject(JSONObject assetData) {
        try {
            String string = assetData.getString(String.URL);
            Long.valueOf(86400);
            return cacheAssetFromURL(string, assetData.optString(TapjoyConstants.TJC_PLACEMENT_OFFER_ID), Long.valueOf(assetData.optLong(TapjoyConstants.TJC_TIME_TO_LIVE)).longValue());
        } catch (JSONException e) {
            TapjoyLog.m251e("TapjoyCache", "Required parameters to cache an asset from JSON is not present");
            return null;
        }
    }

    public Future cacheAssetFromURL(String assetURLString, String offerId, long timeToLive) {
        try {
            URL url = new URL(assetURLString);
            if (!this.f327d.contains(m212b(assetURLString))) {
                return startCachingThread(url, offerId, timeToLive);
            }
            TapjoyLog.m249d("TapjoyCache", "URL is already in the process of being cached: " + assetURLString);
            return null;
        } catch (MalformedURLException e) {
            TapjoyLog.m249d("TapjoyCache", "Invalid cache assetURL");
            return null;
        }
    }

    private static String m212b(String str) {
        if (str.startsWith("//")) {
            str = "http:" + str;
        }
        try {
            return new URL(str).getFile();
        } catch (MalformedURLException e) {
            TapjoyLog.m251e("TapjoyCache", "Invalid URL " + str);
            return "";
        }
    }

    public Future startCachingThread(URL assetURL, String offerId, long timeToLive) {
        if (assetURL != null) {
            return this.f328e.submit(new CacheAssetThread(this, assetURL, offerId, timeToLive));
        }
        return null;
    }

    public void clearTapjoyCache() {
        TapjoyLog.m249d("TapjoyCache", "Cleaning Tapjoy cache!");
        TapjoyUtil.deleteFileOrDirectory(this.f329f);
        if (this.f329f.mkdirs()) {
            TapjoyLog.m249d("TapjoyCache", "Created new cache directory at: " + this.f329f.getPath());
        }
        this.f326c = new TapjoyCacheMap(this.f325b, -1);
    }

    public boolean removeAssetFromCache(String url) {
        Object b = m212b(url);
        return (b == "" || this.f326c.remove(b) == null) ? false : true;
    }

    public boolean isURLDownloading(String url) {
        if (this.f327d == null) {
            return false;
        }
        String b = m212b(url);
        if (b == "" || !this.f327d.contains(b)) {
            return false;
        }
        return true;
    }

    public boolean isURLCached(String url) {
        return this.f326c.get(m212b(url)) != null;
    }

    public TapjoyCachedAssetData getCachedDataForURL(String url) {
        String b = m212b(url);
        if (b != "") {
            return (TapjoyCachedAssetData) this.f326c.get(b);
        }
        return null;
    }

    public TapjoyCacheMap getCachedData() {
        return this.f326c;
    }

    public String getPathOfCachedURL(String url) {
        String b = m212b(url);
        if (b == "" || !this.f326c.containsKey(b)) {
            return url;
        }
        TapjoyCachedAssetData tapjoyCachedAssetData = (TapjoyCachedAssetData) this.f326c.get(b);
        if (new File(tapjoyCachedAssetData.getLocalFilePath()).exists()) {
            return tapjoyCachedAssetData.getLocalURL();
        }
        getInstance().removeAssetFromCache(url);
        return url;
    }

    public String cachedAssetsToJSON() {
        JSONObject jSONObject = new JSONObject();
        for (Entry entry : this.f326c.entrySet()) {
            try {
                jSONObject.put(((String) entry.getKey()).toString(), ((TapjoyCachedAssetData) entry.getValue()).toRawJSONString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return jSONObject.toString();
    }

    public String getCachedOfferIDs() {
        String str = "";
        Iterable arrayList = new ArrayList();
        if (this.f326c == null) {
            return str;
        }
        for (Entry value : this.f326c.entrySet()) {
            str = ((TapjoyCachedAssetData) value.getValue()).getOfferId();
            if (!(str == null || str.length() == 0 || arrayList.contains(str))) {
                arrayList.add(str);
            }
        }
        return TextUtils.join(",", arrayList);
    }

    public void printCacheInformation() {
        TapjoyLog.m249d("TapjoyCache", "------------- Cache Data -------------");
        TapjoyLog.m249d("TapjoyCache", "Number of files in cache: " + this.f326c.size());
        TapjoyLog.m249d("TapjoyCache", "Cache Size: " + TapjoyUtil.fileOrDirectorySize(this.f329f));
        TapjoyLog.m249d("TapjoyCache", "--------------------------------------");
    }

    public static TapjoyCache getInstance() {
        return f324a;
    }

    public static void setInstance(TapjoyCache cache) {
        f324a = cache;
    }
}
