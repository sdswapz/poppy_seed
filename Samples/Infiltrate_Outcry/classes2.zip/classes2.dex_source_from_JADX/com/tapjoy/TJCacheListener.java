package com.tapjoy;

public interface TJCacheListener {
    void onCachingComplete(int i);
}
