package com.tapjoy;

import android.content.Context;

public class TapjoyGpsHelper {
    private Context f403a;
    private String f404b;
    private boolean f405c;
    private int f406d = 0;
    private int f407e = 0;
    private boolean f408f;
    private Boolean f409g;
    private Boolean f410h;

    public TapjoyGpsHelper(Context context) {
        this.f403a = context;
    }

    public void loadAdvertisingId() {
        TapjoyLog.m252i("TapjoyGpsHelper", "Looking for Google Play Services...");
        if (isGooglePlayServicesAvailable() && isGooglePlayManifestConfigured()) {
            TapjoyLog.m252i("TapjoyGpsHelper", "Packaged Google Play Services found, fetching advertisingID...");
            TapjoyLog.m252i("TapjoyGpsHelper", "Packaged Google Play Services version: " + this.f407e);
            TapjoyAdIdClient tapjoyAdIdClient = new TapjoyAdIdClient(this.f403a);
            this.f408f = tapjoyAdIdClient.setupAdIdInfo();
            try {
                this.f406d = this.f403a.getPackageManager().getPackageInfo("com.google.android.gms", 0).versionCode;
                TapjoyLog.m252i("TapjoyGpsHelper", "Device's Google Play Services version: " + this.f406d);
            } catch (Exception e) {
                TapjoyLog.m252i("TapjoyGpsHelper", "Error getting device's Google Play Services version");
            }
            if (this.f408f) {
                this.f405c = tapjoyAdIdClient.isAdTrackingEnabled();
                this.f404b = tapjoyAdIdClient.getAdvertisingId();
                TapjoyLog.m252i("TapjoyGpsHelper", "Found advertising ID: " + this.f404b);
                TapjoyLog.m252i("TapjoyGpsHelper", "Is ad tracking enabled: " + Boolean.toString(this.f405c));
                return;
            }
            TapjoyLog.m252i("TapjoyGpsHelper", "Error getting advertisingID from Google Play Services");
            return;
        }
        TapjoyLog.m252i("TapjoyGpsHelper", "Google Play Services not found");
    }

    public void checkGooglePlayIntegration() {
        if (!isGooglePlayServicesAvailable()) {
            throw new TapjoyIntegrationException("Tapjoy SDK is disabled because Google Play Services was not found. For more information about including the Google Play services client library visit http://developer.android.com/google/play-services/setup.html or http://tech.tapjoy.com/product-overview/sdk-change-log/tapjoy-and-identifiers");
        } else if (!isGooglePlayManifestConfigured()) {
            throw new TapjoyIntegrationException("Failed to load manifest.xml meta-data, 'com.google.android.gms.version' not found. For more information about including the Google Play services client library visit http://developer.android.com/google/play-services/setup.html or http://tech.tapjoy.com/product-overview/sdk-change-log/tapjoy-and-identifiers");
        }
    }

    public boolean isGooglePlayServicesAvailable() {
        if (this.f409g == null) {
            try {
                this.f403a.getClassLoader().loadClass("com.google.android.gms.ads.identifier.AdvertisingIdClient");
                this.f409g = Boolean.valueOf(true);
            } catch (Exception e) {
                this.f409g = Boolean.valueOf(false);
            } catch (Error e2) {
                this.f409g = Boolean.valueOf(false);
            }
        }
        return this.f409g.booleanValue();
    }

    public boolean isGooglePlayManifestConfigured() {
        if (this.f410h == null) {
            try {
                this.f407e = this.f403a.getPackageManager().getApplicationInfo(this.f403a.getPackageName(), 128).metaData.getInt("com.google.android.gms.version");
                this.f410h = Boolean.valueOf(true);
            } catch (Exception e) {
                this.f410h = Boolean.valueOf(false);
            }
        }
        return this.f410h.booleanValue();
    }

    public String getAdvertisingId() {
        return this.f404b;
    }

    public boolean isAdTrackingEnabled() {
        return this.f405c;
    }

    public boolean isAdIdAvailable() {
        return this.f408f;
    }

    public int getDeviceGooglePlayServicesVersion() {
        return this.f406d;
    }

    public int getPackagedGooglePlayServicesVersion() {
        return this.f407e;
    }
}
