package com.google.android.gms.drive.events;

public interface CompletionListener extends zzf {
    void onCompletion(CompletionEvent completionEvent);
}
