package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.zzou;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.NodeApi;
import com.google.android.gms.wearable.NodeApi.GetConnectedNodesResult;
import com.google.android.gms.wearable.NodeApi.GetLocalNodeResult;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import java.util.ArrayList;
import java.util.List;

public final class zzbb implements NodeApi {

    class C15933 implements zza<NodeListener> {
        final /* synthetic */ IntentFilter[] zzbCw;

        C15933(IntentFilter[] intentFilterArr) {
            this.zzbCw = intentFilterArr;
        }

        public void zza(zzbp com_google_android_gms_wearable_internal_zzbp, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, NodeListener nodeListener, zzou<NodeListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_NodeApi_NodeListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzbp.zza((com.google.android.gms.internal.zznt.zzb) com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, nodeListener, (zzou) com_google_android_gms_internal_zzou_com_google_android_gms_wearable_NodeApi_NodeListener, this.zzbCw);
        }
    }

    public static class zza implements GetConnectedNodesResult {
        private final Status zzaaO;
        private final List<Node> zzbDC;

        public zza(Status status, List<Node> list) {
            this.zzaaO = status;
            this.zzbDC = list;
        }

        public List<Node> getNodes() {
            return this.zzbDC;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    public static class zzb implements GetLocalNodeResult {
        private final Status zzaaO;
        private final Node zzbDD;

        public zzb(Status status, Node node) {
            this.zzaaO = status;
            this.zzbDD = node;
        }

        public Node getNode() {
            return this.zzbDD;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    private static zza<NodeListener> zza(IntentFilter[] intentFilterArr) {
        return new C15933(intentFilterArr);
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, NodeListener nodeListener) {
        return zzb.zza(googleApiClient, zza(new IntentFilter[]{zzbn.zzhE("com.google.android.gms.wearable.NODE_CHANGED")}), nodeListener);
    }

    public PendingResult<GetConnectedNodesResult> getConnectedNodes(GoogleApiClient googleApiClient) {
        return googleApiClient.zzc(new zzi<GetConnectedNodesResult>(this, googleApiClient) {
            final /* synthetic */ zzbb zzbDA;

            protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
                com_google_android_gms_wearable_internal_zzbp.zzx(this);
            }

            protected GetConnectedNodesResult zzbM(Status status) {
                return new zza(status, new ArrayList());
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbM(status);
            }
        });
    }

    public PendingResult<GetLocalNodeResult> getLocalNode(GoogleApiClient googleApiClient) {
        return googleApiClient.zzc(new zzi<GetLocalNodeResult>(this, googleApiClient) {
            final /* synthetic */ zzbb zzbDA;

            protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
                com_google_android_gms_wearable_internal_zzbp.zzw(this);
            }

            protected GetLocalNodeResult zzbL(Status status) {
                return new zzb(status, null);
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzbL(status);
            }
        });
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, final NodeListener nodeListener) {
        return googleApiClient.zzc(new zzi<Status>(this, googleApiClient) {
            final /* synthetic */ zzbb zzbDA;

            protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
                com_google_android_gms_wearable_internal_zzbp.zza((com.google.android.gms.internal.zznt.zzb) this, nodeListener);
            }

            public Status zzb(Status status) {
                return status;
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzb(status);
            }
        });
    }
}
