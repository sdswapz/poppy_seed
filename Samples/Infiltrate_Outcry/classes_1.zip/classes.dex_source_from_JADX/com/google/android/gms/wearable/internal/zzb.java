package com.google.android.gms.wearable.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzou;

final class zzb<T> extends zzi<Status> {
    private T mListener;
    private zza<T> zzbCh;
    private zzou<T> zzbin;

    interface zza<T> {
        void zza(zzbp com_google_android_gms_wearable_internal_zzbp, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, T t, zzou<T> com_google_android_gms_internal_zzou_T) throws RemoteException;
    }

    private zzb(GoogleApiClient googleApiClient, T t, zzou<T> com_google_android_gms_internal_zzou_T, zza<T> com_google_android_gms_wearable_internal_zzb_zza_T) {
        super(googleApiClient);
        this.mListener = zzaa.zzz(t);
        this.zzbin = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_T);
        this.zzbCh = (zza) zzaa.zzz(com_google_android_gms_wearable_internal_zzb_zza_T);
    }

    static <T> PendingResult<Status> zza(GoogleApiClient googleApiClient, zza<T> com_google_android_gms_wearable_internal_zzb_zza_T, T t) {
        return googleApiClient.zzc(new zzb(googleApiClient, t, googleApiClient.zzs(t), com_google_android_gms_wearable_internal_zzb_zza_T));
    }

    protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
        this.zzbCh.zza(com_google_android_gms_wearable_internal_zzbp, this, this.mListener, this.zzbin);
        this.mListener = null;
        this.zzbin = null;
    }

    protected Status zzb(Status status) {
        this.mListener = null;
        this.zzbin = null;
        return status;
    }

    protected /* synthetic */ Result zzc(Status status) {
        return zzb(status);
    }
}
