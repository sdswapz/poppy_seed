package com.google.android.gms.wearable;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.zze;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.AmsEntityUpdateParcelable;
import com.google.android.gms.wearable.internal.AncsNotificationParcelable;
import com.google.android.gms.wearable.internal.CapabilityInfoParcelable;
import com.google.android.gms.wearable.internal.ChannelEventParcelable;
import com.google.android.gms.wearable.internal.MessageEventParcelable;
import com.google.android.gms.wearable.internal.NodeParcelable;
import java.util.List;

public abstract class WearableListenerService extends Service implements CapabilityListener, ChannelListener, DataListener, MessageListener, NodeListener {
    public static final String BIND_LISTENER_INTENT_ACTION = "com.google.android.gms.wearable.BIND_LISTENER";
    private String zzZC;
    private IBinder zzaqQ;
    private Handler zzbBU;
    private final Object zzbBV = new Object();
    private boolean zzbBW;

    private final class zza extends com.google.android.gms.wearable.internal.zzaw.zza {
        private volatile int zzaqn;
        final /* synthetic */ WearableListenerService zzbBX;

        private zza(WearableListenerService wearableListenerService) {
            this.zzbBX = wearableListenerService;
            this.zzaqn = -1;
        }

        private void zzNs() throws SecurityException {
            int callingUid = Binder.getCallingUid();
            if (callingUid != this.zzaqn) {
                if (zze.zze(this.zzbBX, callingUid)) {
                    this.zzaqn = callingUid;
                    return;
                }
                throw new SecurityException("Caller is not GooglePlayServices");
            }
        }

        private boolean zza(Runnable runnable, String str, Object obj) {
            if (Log.isLoggable("WearableLS", 3)) {
                Log.d("WearableLS", String.format("%s: %s %s", new Object[]{str, this.zzbBX.zzZC, obj}));
            }
            zzNs();
            synchronized (this.zzbBX.zzbBV) {
                if (this.zzbBX.zzbBW) {
                    return false;
                }
                this.zzbBX.zzbBU.post(runnable);
                return true;
            }
        }

        public void onConnectedNodes(final List<NodeParcelable> list) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onConnectedNodes(list);
                }
            }, "onConnectedNodes", list);
        }

        public void zza(final AmsEntityUpdateParcelable amsEntityUpdateParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onEntityUpdate(amsEntityUpdateParcelable);
                }
            }, "onEntityUpdate", amsEntityUpdateParcelable);
        }

        public void zza(final AncsNotificationParcelable ancsNotificationParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onNotificationReceived(ancsNotificationParcelable);
                }
            }, "onNotificationReceived", ancsNotificationParcelable);
        }

        public void zza(final CapabilityInfoParcelable capabilityInfoParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onCapabilityChanged(capabilityInfoParcelable);
                }
            }, "onConnectedCapabilityChanged", capabilityInfoParcelable);
        }

        public void zza(final ChannelEventParcelable channelEventParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    channelEventParcelable.zza(this.zzbBZ.zzbBX);
                }
            }, "onChannelEvent", channelEventParcelable);
        }

        public void zza(final MessageEventParcelable messageEventParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onMessageReceived(messageEventParcelable);
                }
            }, "onMessageReceived", messageEventParcelable);
        }

        public void zza(final NodeParcelable nodeParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onPeerConnected(nodeParcelable);
                }
            }, "onPeerConnected", nodeParcelable);
        }

        public void zzaq(final DataHolder dataHolder) {
            try {
                if (!zza(new Runnable(this) {
                    final /* synthetic */ zza zzbBZ;

                    public void run() {
                        DataEventBuffer dataEventBuffer = new DataEventBuffer(dataHolder);
                        try {
                            this.zzbBZ.zzbBX.onDataChanged(dataEventBuffer);
                        } finally {
                            dataEventBuffer.release();
                        }
                    }
                }, "onDataItemChanged", dataHolder)) {
                }
            } finally {
                dataHolder.close();
            }
        }

        public void zzb(final NodeParcelable nodeParcelable) {
            zza(new Runnable(this) {
                final /* synthetic */ zza zzbBZ;

                public void run() {
                    this.zzbBZ.zzbBX.onPeerDisconnected(nodeParcelable);
                }
            }, "onPeerDisconnected", nodeParcelable);
        }
    }

    public final IBinder onBind(Intent intent) {
        return BIND_LISTENER_INTENT_ACTION.equals(intent.getAction()) ? this.zzaqQ : null;
    }

    public void onCapabilityChanged(CapabilityInfo capabilityInfo) {
    }

    public void onChannelClosed(Channel channel, int i, int i2) {
    }

    public void onChannelOpened(Channel channel) {
    }

    public void onConnectedNodes(List<Node> list) {
    }

    public void onCreate() {
        super.onCreate();
        if (Log.isLoggable("WearableLS", 3)) {
            String str = "WearableLS";
            String str2 = "onCreate: ";
            String valueOf = String.valueOf(new ComponentName(getPackageName(), getClass().getName()).flattenToShortString());
            Log.d(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
        this.zzZC = getPackageName();
        HandlerThread handlerThread = new HandlerThread("WearableListenerService");
        handlerThread.start();
        this.zzbBU = new Handler(handlerThread.getLooper());
        this.zzaqQ = new zza();
    }

    public void onDataChanged(DataEventBuffer dataEventBuffer) {
    }

    public void onDestroy() {
        if (Log.isLoggable("WearableLS", 3)) {
            String str = "WearableLS";
            String str2 = "onDestroy: ";
            String valueOf = String.valueOf(new ComponentName(getPackageName(), getClass().getName()).flattenToShortString());
            Log.d(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
        synchronized (this.zzbBV) {
            this.zzbBW = true;
            if (this.zzbBU == null) {
                throw new IllegalStateException("onDestroy: mServiceHandler not set, did you override onCreate() but forget to call super.onCreate()?");
            }
            this.zzbBU.getLooper().quit();
        }
        super.onDestroy();
    }

    public void onEntityUpdate(zzb com_google_android_gms_wearable_zzb) {
    }

    public void onInputClosed(Channel channel, int i, int i2) {
    }

    public void onMessageReceived(MessageEvent messageEvent) {
    }

    public void onNotificationReceived(zzd com_google_android_gms_wearable_zzd) {
    }

    public void onOutputClosed(Channel channel, int i, int i2) {
    }

    public void onPeerConnected(Node node) {
    }

    public void onPeerDisconnected(Node node) {
    }
}
