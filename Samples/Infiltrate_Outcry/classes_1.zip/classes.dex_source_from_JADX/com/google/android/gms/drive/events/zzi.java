package com.google.android.gms.drive.events;

public interface zzi extends zzf {
    void zza(zzh com_google_android_gms_drive_events_zzh);
}
