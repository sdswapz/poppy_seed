package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzou;
import com.google.android.gms.internal.zzou.zzb;
import com.google.android.gms.wearable.CapabilityApi.CapabilityListener;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.DataApi.DataListener;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.MessageApi.MessageListener;
import com.google.android.gms.wearable.NodeApi.NodeListener;
import com.google.android.gms.wearable.internal.zzaw.zza;
import java.util.List;

public class zzbq<T> extends zza {
    private zzou<Object> zzbDV;
    private zzou<Object> zzbDW;
    private zzou<DataListener> zzbDX;
    private zzou<NodeListener> zzbDY;
    private zzou<Object> zzbDZ;
    private final IntentFilter[] zzbDz;
    private zzou<ChannelListener> zzbEa;
    private zzou<CapabilityListener> zzbEb;
    private final String zzbEc;
    private zzou<MessageListener> zzbif;

    class C15981 implements zzb<DataListener> {
        final /* synthetic */ DataHolder zzbBY;

        C15981(DataHolder dataHolder) {
            this.zzbBY = dataHolder;
        }

        public void zza(DataListener dataListener) {
            try {
                dataListener.onDataChanged(new DataEventBuffer(this.zzbBY));
            } finally {
                this.zzbBY.close();
            }
        }

        public void zzrV() {
            this.zzbBY.close();
        }

        public /* synthetic */ void zzt(Object obj) {
            zza((DataListener) obj);
        }
    }

    class C15992 implements zzb<MessageListener> {
        final /* synthetic */ MessageEventParcelable zzbCa;

        C15992(MessageEventParcelable messageEventParcelable) {
            this.zzbCa = messageEventParcelable;
        }

        public void zza(MessageListener messageListener) {
            messageListener.onMessageReceived(this.zzbCa);
        }

        public void zzrV() {
        }

        public /* synthetic */ void zzt(Object obj) {
            zza((MessageListener) obj);
        }
    }

    class C16003 implements zzb<NodeListener> {
        final /* synthetic */ NodeParcelable zzbCb;

        C16003(NodeParcelable nodeParcelable) {
            this.zzbCb = nodeParcelable;
        }

        public void zza(NodeListener nodeListener) {
            nodeListener.onPeerConnected(this.zzbCb);
        }

        public void zzrV() {
        }

        public /* synthetic */ void zzt(Object obj) {
            zza((NodeListener) obj);
        }
    }

    class C16014 implements zzb<NodeListener> {
        final /* synthetic */ NodeParcelable zzbCb;

        C16014(NodeParcelable nodeParcelable) {
            this.zzbCb = nodeParcelable;
        }

        public void zza(NodeListener nodeListener) {
            nodeListener.onPeerDisconnected(this.zzbCb);
        }

        public void zzrV() {
        }

        public /* synthetic */ void zzt(Object obj) {
            zza((NodeListener) obj);
        }
    }

    class C16025 implements zzb<ChannelListener> {
        final /* synthetic */ ChannelEventParcelable zzbCg;

        C16025(ChannelEventParcelable channelEventParcelable) {
            this.zzbCg = channelEventParcelable;
        }

        public void zzb(ChannelListener channelListener) {
            this.zzbCg.zza(channelListener);
        }

        public void zzrV() {
        }

        public /* synthetic */ void zzt(Object obj) {
            zzb((ChannelListener) obj);
        }
    }

    class C16036 implements zzb<CapabilityListener> {
        final /* synthetic */ CapabilityInfoParcelable zzbEd;

        C16036(CapabilityInfoParcelable capabilityInfoParcelable) {
            this.zzbEd = capabilityInfoParcelable;
        }

        public void zza(CapabilityListener capabilityListener) {
            capabilityListener.onCapabilityChanged(this.zzbEd);
        }

        public void zzrV() {
        }

        public /* synthetic */ void zzt(Object obj) {
            zza((CapabilityListener) obj);
        }
    }

    private zzbq(IntentFilter[] intentFilterArr, String str) {
        this.zzbDz = (IntentFilter[]) zzaa.zzz(intentFilterArr);
        this.zzbEc = str;
    }

    public static zzbq<ChannelListener> zza(zzou<ChannelListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener, String str, IntentFilter[] intentFilterArr) {
        zzbq<ChannelListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, (String) zzaa.zzz(str));
        com_google_android_gms_wearable_internal_zzbq.zzbEa = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    public static zzbq<DataListener> zza(zzou<DataListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_DataApi_DataListener, IntentFilter[] intentFilterArr) {
        zzbq<DataListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzbq.zzbDX = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_DataApi_DataListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    private static zzb<DataListener> zzas(DataHolder dataHolder) {
        return new C15981(dataHolder);
    }

    private static zzb<CapabilityListener> zzb(CapabilityInfoParcelable capabilityInfoParcelable) {
        return new C16036(capabilityInfoParcelable);
    }

    private static zzb<ChannelListener> zzb(ChannelEventParcelable channelEventParcelable) {
        return new C16025(channelEventParcelable);
    }

    private static zzb<MessageListener> zzb(MessageEventParcelable messageEventParcelable) {
        return new C15992(messageEventParcelable);
    }

    public static zzbq<MessageListener> zzb(zzou<MessageListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_MessageApi_MessageListener, IntentFilter[] intentFilterArr) {
        zzbq<MessageListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzbq.zzbif = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_MessageApi_MessageListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    private static zzb<NodeListener> zzc(NodeParcelable nodeParcelable) {
        return new C16003(nodeParcelable);
    }

    public static zzbq<NodeListener> zzc(zzou<NodeListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_NodeApi_NodeListener, IntentFilter[] intentFilterArr) {
        zzbq<NodeListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzbq.zzbDY = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_NodeApi_NodeListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    private static zzb<NodeListener> zzd(NodeParcelable nodeParcelable) {
        return new C16014(nodeParcelable);
    }

    public static zzbq<ChannelListener> zzd(zzou<ChannelListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener, IntentFilter[] intentFilterArr) {
        zzbq<ChannelListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzbq.zzbEa = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    public static zzbq<CapabilityListener> zze(zzou<CapabilityListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_CapabilityApi_CapabilityListener, IntentFilter[] intentFilterArr) {
        zzbq<CapabilityListener> com_google_android_gms_wearable_internal_zzbq = new zzbq(intentFilterArr, null);
        com_google_android_gms_wearable_internal_zzbq.zzbEb = (zzou) zzaa.zzz(com_google_android_gms_internal_zzou_com_google_android_gms_wearable_CapabilityApi_CapabilityListener);
        return com_google_android_gms_wearable_internal_zzbq;
    }

    private static void zzi(zzou<?> com_google_android_gms_internal_zzou_) {
        if (com_google_android_gms_internal_zzou_ != null) {
            com_google_android_gms_internal_zzou_.clear();
        }
    }

    public void clear() {
        zzi(null);
        this.zzbDV = null;
        zzi(null);
        this.zzbDW = null;
        zzi(this.zzbDX);
        this.zzbDX = null;
        zzi(this.zzbif);
        this.zzbif = null;
        zzi(this.zzbDY);
        this.zzbDY = null;
        zzi(null);
        this.zzbDZ = null;
        zzi(this.zzbEa);
        this.zzbEa = null;
        zzi(this.zzbEb);
        this.zzbEb = null;
    }

    public void onConnectedNodes(List<NodeParcelable> list) {
    }

    public IntentFilter[] zzNJ() {
        return this.zzbDz;
    }

    public String zzNK() {
        return this.zzbEc;
    }

    public void zza(AmsEntityUpdateParcelable amsEntityUpdateParcelable) {
    }

    public void zza(AncsNotificationParcelable ancsNotificationParcelable) {
    }

    public void zza(CapabilityInfoParcelable capabilityInfoParcelable) {
        if (this.zzbEb != null) {
            this.zzbEb.zza(zzb(capabilityInfoParcelable));
        }
    }

    public void zza(ChannelEventParcelable channelEventParcelable) {
        if (this.zzbEa != null) {
            this.zzbEa.zza(zzb(channelEventParcelable));
        }
    }

    public void zza(MessageEventParcelable messageEventParcelable) {
        if (this.zzbif != null) {
            this.zzbif.zza(zzb(messageEventParcelable));
        }
    }

    public void zza(NodeParcelable nodeParcelable) {
        if (this.zzbDY != null) {
            this.zzbDY.zza(zzc(nodeParcelable));
        }
    }

    public void zzaq(DataHolder dataHolder) {
        if (this.zzbDX != null) {
            this.zzbDX.zza(zzas(dataHolder));
        } else {
            dataHolder.close();
        }
    }

    public void zzb(NodeParcelable nodeParcelable) {
        if (this.zzbDY != null) {
            this.zzbDY.zza(zzd(nodeParcelable));
        }
    }
}
