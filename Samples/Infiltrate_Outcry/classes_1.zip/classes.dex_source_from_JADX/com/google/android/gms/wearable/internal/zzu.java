package com.google.android.gms.wearable.internal;

interface zzu {
    void zzb(zzm com_google_android_gms_wearable_internal_zzm);
}
