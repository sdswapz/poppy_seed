package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResource;
import com.google.android.gms.drive.DriveResource.MetadataResult;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.events.ChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class zzab implements DriveResource {
    protected final DriveId zzauZ;

    private abstract class zzd extends zzt<MetadataResult> {
        final /* synthetic */ zzab zzaxZ;

        private zzd(zzab com_google_android_gms_drive_internal_zzab, GoogleApiClient googleApiClient) {
            this.zzaxZ = com_google_android_gms_drive_internal_zzab;
            super(googleApiClient);
        }

        public MetadataResult zzL(Status status) {
            return new zzc(status, null);
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzL(status);
        }
    }

    private static class zza extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<MetadataBufferResult> zzasz;

        public zza(com.google.android.gms.internal.zznt.zzb<MetadataBufferResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_MetadataBufferResult) {
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_MetadataBufferResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zzg(status, null, false));
        }

        public void zza(OnListParentsResponse onListParentsResponse) throws RemoteException {
            this.zzasz.setResult(new zzg(Status.zzalw, new MetadataBuffer(onListParentsResponse.zzwB()), false));
        }
    }

    private static class zzb extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<MetadataResult> zzasz;

        public zzb(com.google.android.gms.internal.zznt.zzb<MetadataResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveResource_MetadataResult) {
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveResource_MetadataResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zzc(status, null));
        }

        public void zza(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.zzasz.setResult(new zzc(Status.zzalw, new zzp(onMetadataResponse.zzwC())));
        }
    }

    private static class zzc implements MetadataResult {
        private final Status zzaaO;
        private final Metadata zzayb;

        public zzc(Status status, Metadata metadata) {
            this.zzaaO = status;
            this.zzayb = metadata;
        }

        public Metadata getMetadata() {
            return this.zzayb;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    public zzab(DriveId driveId) {
        this.zzauZ = driveId;
    }

    private PendingResult<MetadataResult> zza(GoogleApiClient googleApiClient, final boolean z) {
        return googleApiClient.zzc(new zzd(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new GetMetadataRequest(this.zzaxZ.zzauZ, z), new zzb(this));
            }
        });
    }

    public PendingResult<Status> addChangeListener(GoogleApiClient googleApiClient, ChangeListener changeListener) {
        return ((zzu) googleApiClient.zza(Drive.zzaaz)).zza(googleApiClient, this.zzauZ, changeListener);
    }

    public PendingResult<Status> addChangeSubscription(GoogleApiClient googleApiClient) {
        return ((zzu) googleApiClient.zza(Drive.zzaaz)).zza(googleApiClient, this.zzauZ);
    }

    public PendingResult<Status> delete(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new DeleteResourceRequest(this.zzaxZ.zzauZ), new zzbr(this));
            }
        });
    }

    public DriveId getDriveId() {
        return this.zzauZ;
    }

    public PendingResult<MetadataResult> getMetadata(GoogleApiClient googleApiClient) {
        return zza(googleApiClient, false);
    }

    public PendingResult<MetadataBufferResult> listParents(GoogleApiClient googleApiClient) {
        return googleApiClient.zzc(new zzh(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new ListParentsRequest(this.zzaxZ.zzauZ), new zza(this));
            }
        });
    }

    public PendingResult<Status> removeChangeListener(GoogleApiClient googleApiClient, ChangeListener changeListener) {
        return ((zzu) googleApiClient.zza(Drive.zzaaz)).zzb(googleApiClient, this.zzauZ, changeListener);
    }

    public PendingResult<Status> removeChangeSubscription(GoogleApiClient googleApiClient) {
        return ((zzu) googleApiClient.zza(Drive.zzaaz)).zzb(googleApiClient, this.zzauZ);
    }

    public PendingResult<Status> setParents(GoogleApiClient googleApiClient, Set<DriveId> set) {
        if (set == null) {
            throw new IllegalArgumentException("ParentIds must be provided.");
        }
        final List arrayList = new ArrayList(set);
        return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new SetResourceParentsRequest(this.zzaxZ.zzauZ, arrayList), new zzbr(this));
            }
        });
    }

    public PendingResult<Status> trash(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new TrashResourceRequest(this.zzaxZ.zzauZ), new zzbr(this));
            }
        });
    }

    public PendingResult<Status> untrash(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
            final /* synthetic */ zzab zzaxZ;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new UntrashResourceRequest(this.zzaxZ.zzauZ), new zzbr(this));
            }
        });
    }

    public PendingResult<MetadataResult> updateMetadata(GoogleApiClient googleApiClient, final MetadataChangeSet metadataChangeSet) {
        if (metadataChangeSet != null) {
            return googleApiClient.zzd(new zzd(this, googleApiClient) {
                final /* synthetic */ zzab zzaxZ;

                protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                    metadataChangeSet.zzvU().setContext(com_google_android_gms_drive_internal_zzu.getContext());
                    com_google_android_gms_drive_internal_zzu.zzwn().zza(new UpdateMetadataRequest(this.zzaxZ.zzauZ, metadataChangeSet.zzvU()), new zzb(this));
                }
            });
        }
        throw new IllegalArgumentException("ChangeSet must be provided.");
    }
}
