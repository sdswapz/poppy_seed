package com.google.android.gms.wearable.internal;

import android.content.IntentFilter;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.internal.zzou;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.ChannelApi;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;
import com.google.android.gms.wearable.ChannelApi.OpenChannelResult;

public final class zzl implements ChannelApi {

    class C16102 implements zza<ChannelListener> {
        final /* synthetic */ IntentFilter[] zzbCw;

        C16102(IntentFilter[] intentFilterArr) {
            this.zzbCw = intentFilterArr;
        }

        public void zza(zzbp com_google_android_gms_wearable_internal_zzbp, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, ChannelListener channelListener, zzou<ChannelListener> com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener) throws RemoteException {
            com_google_android_gms_wearable_internal_zzbp.zza((com.google.android.gms.internal.zznt.zzb) com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, channelListener, (zzou) com_google_android_gms_internal_zzou_com_google_android_gms_wearable_ChannelApi_ChannelListener, null, this.zzbCw);
        }
    }

    static final class zza implements OpenChannelResult {
        private final Status zzaaO;
        private final Channel zzbCF;

        zza(Status status, Channel channel) {
            this.zzaaO = (Status) zzaa.zzz(status);
            this.zzbCF = channel;
        }

        public Channel getChannel() {
            return this.zzbCF;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    static final class zzb extends zzi<Status> {
        private final String zzabf;
        private ChannelListener zzbCG;

        zzb(GoogleApiClient googleApiClient, ChannelListener channelListener, String str) {
            super(googleApiClient);
            this.zzbCG = (ChannelListener) zzaa.zzz(channelListener);
            this.zzabf = str;
        }

        protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
            com_google_android_gms_wearable_internal_zzbp.zza((com.google.android.gms.internal.zznt.zzb) this, this.zzbCG, this.zzabf);
            this.zzbCG = null;
        }

        public Status zzb(Status status) {
            this.zzbCG = null;
            return status;
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzb(status);
        }
    }

    private static zza<ChannelListener> zza(IntentFilter[] intentFilterArr) {
        return new C16102(intentFilterArr);
    }

    public PendingResult<Status> addListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzaa.zzb((Object) googleApiClient, (Object) "client is null");
        zzaa.zzb((Object) channelListener, (Object) "listener is null");
        return zzb.zza(googleApiClient, zza(new IntentFilter[]{zzbn.zzhE(ChannelApi.ACTION_CHANNEL_EVENT)}), channelListener);
    }

    public PendingResult<OpenChannelResult> openChannel(GoogleApiClient googleApiClient, final String str, final String str2) {
        zzaa.zzb((Object) googleApiClient, (Object) "client is null");
        zzaa.zzb((Object) str, (Object) "nodeId is null");
        zzaa.zzb((Object) str2, (Object) "path is null");
        return googleApiClient.zzc(new zzi<OpenChannelResult>(this, googleApiClient) {
            final /* synthetic */ zzl zzbCE;

            protected void zza(zzbp com_google_android_gms_wearable_internal_zzbp) throws RemoteException {
                com_google_android_gms_wearable_internal_zzbp.zze(this, str, str2);
            }

            public OpenChannelResult zzbD(Status status) {
                return new zza(status, null);
            }

            public /* synthetic */ Result zzc(Status status) {
                return zzbD(status);
            }
        });
    }

    public PendingResult<Status> removeListener(GoogleApiClient googleApiClient, ChannelListener channelListener) {
        zzaa.zzb((Object) googleApiClient, (Object) "client is null");
        zzaa.zzb((Object) channelListener, (Object) "listener is null");
        return googleApiClient.zzc(new zzb(googleApiClient, channelListener, null));
    }
}
