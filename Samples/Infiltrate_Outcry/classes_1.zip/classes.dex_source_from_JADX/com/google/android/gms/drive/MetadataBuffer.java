package com.google.android.gms.drive;

import com.google.android.gms.common.data.AbstractDataBuffer;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.internal.zzp;
import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.drive.metadata.internal.zze;
import com.google.android.gms.internal.zzqd;

public final class MetadataBuffer extends AbstractDataBuffer<Metadata> {
    private zza zzavB;

    private static class zza extends Metadata {
        private final DataHolder zzamz;
        private final int zzapb;
        private final int zzavC;

        public zza(DataHolder dataHolder, int i) {
            this.zzamz = dataHolder;
            this.zzavC = i;
            this.zzapb = dataHolder.zzbP(i);
        }

        public /* synthetic */ Object freeze() {
            return zzvT();
        }

        public boolean isDataValid() {
            return !this.zzamz.isClosed();
        }

        public <T> T zza(MetadataField<T> metadataField) {
            return metadataField.zza(this.zzamz, this.zzavC, this.zzapb);
        }

        public Metadata zzvT() {
            MetadataBundle zzwN = MetadataBundle.zzwN();
            for (MetadataField metadataField : zze.zzwL()) {
                if (metadataField != zzqd.zzaAa) {
                    metadataField.zza(this.zzamz, zzwN, this.zzavC, this.zzapb);
                }
            }
            return new zzp(zzwN);
        }
    }

    public MetadataBuffer(DataHolder dataHolder) {
        super(dataHolder);
        dataHolder.zzsO().setClassLoader(MetadataBuffer.class.getClassLoader());
    }

    public Metadata get(int i) {
        zza com_google_android_gms_drive_MetadataBuffer_zza = this.zzavB;
        if (com_google_android_gms_drive_MetadataBuffer_zza != null && com_google_android_gms_drive_MetadataBuffer_zza.zzavC == i) {
            return com_google_android_gms_drive_MetadataBuffer_zza;
        }
        Metadata com_google_android_gms_drive_MetadataBuffer_zza2 = new zza(this.zzamz, i);
        this.zzavB = com_google_android_gms_drive_MetadataBuffer_zza2;
        return com_google_android_gms_drive_MetadataBuffer_zza2;
    }

    @Deprecated
    public String getNextPageToken() {
        return null;
    }

    public void release() {
        if (this.zzamz != null) {
            zze.zza(this.zzamz);
        }
        super.release();
    }
}
