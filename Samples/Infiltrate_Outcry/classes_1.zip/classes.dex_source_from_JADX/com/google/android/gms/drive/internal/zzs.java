package com.google.android.gms.drive.internal;

import android.annotation.SuppressLint;
import android.os.RemoteException;
import com.google.android.gms.common.api.BooleanResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.CreateFileActivityBuilder;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveApi.DriveIdResult;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.query.Query;
import java.util.List;

public class zzs implements DriveApi {

    static abstract class zzh extends zzt<MetadataBufferResult> {
        zzh(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        public MetadataBufferResult zzH(Status status) {
            return new zzg(status, null, false);
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzH(status);
        }
    }

    static abstract class zzc extends zzt<DriveContentsResult> {
        zzc(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        public DriveContentsResult zzF(Status status) {
            return new zzb(status, null);
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzF(status);
        }
    }

    static abstract class zzf extends zzt<DriveIdResult> {
        zzf(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        public DriveIdResult zzG(Status status) {
            return new zze(status, null);
        }

        public /* synthetic */ Result zzc(Status status) {
            return zzG(status);
        }
    }

    private static class zza extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<DriveContentsResult> zzasz;

        public zza(com.google.android.gms.internal.zznt.zzb<DriveContentsResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveContentsResult) {
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveContentsResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zzb(status, null));
        }

        public void zza(OnContentsResponse onContentsResponse) throws RemoteException {
            this.zzasz.setResult(new zzb(Status.zzalw, new zzv(onContentsResponse.zzwt())));
        }
    }

    static class zzb implements Releasable, DriveContentsResult {
        private final Status zzaaO;
        private final DriveContents zzavc;

        public zzb(Status status, DriveContents driveContents) {
            this.zzaaO = status;
            this.zzavc = driveContents;
        }

        public DriveContents getDriveContents() {
            return this.zzavc;
        }

        public Status getStatus() {
            return this.zzaaO;
        }

        public void release() {
            if (this.zzavc != null) {
                this.zzavc.zzvH();
            }
        }
    }

    static class zzd extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<DriveIdResult> zzasz;

        public zzd(com.google.android.gms.internal.zznt.zzb<DriveIdResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveIdResult) {
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveIdResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zze(status, null));
        }

        public void zza(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.zzasz.setResult(new zze(Status.zzalw, onDriveIdResponse.getDriveId()));
        }

        public void zza(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.zzasz.setResult(new zze(Status.zzalw, new zzp(onMetadataResponse.zzwC()).getDriveId()));
        }
    }

    private static class zze implements DriveIdResult {
        private final Status zzaaO;
        private final DriveId zzauZ;

        public zze(Status status, DriveId driveId) {
            this.zzaaO = status;
            this.zzauZ = driveId;
        }

        public DriveId getDriveId() {
            return this.zzauZ;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    static class zzg implements MetadataBufferResult {
        private final Status zzaaO;
        private final MetadataBuffer zzaxi;
        private final boolean zzaxj;

        public zzg(Status status, MetadataBuffer metadataBuffer, boolean z) {
            this.zzaaO = status;
            this.zzaxi = metadataBuffer;
            this.zzaxj = z;
        }

        public MetadataBuffer getMetadataBuffer() {
            return this.zzaxi;
        }

        public Status getStatus() {
            return this.zzaaO;
        }

        public void release() {
            if (this.zzaxi != null) {
                this.zzaxi.release();
            }
        }
    }

    private static class zzi extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<MetadataBufferResult> zzasz;

        public zzi(com.google.android.gms.internal.zznt.zzb<MetadataBufferResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_MetadataBufferResult) {
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_MetadataBufferResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zzg(status, null, false));
        }

        public void zza(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
            this.zzasz.setResult(new zzg(Status.zzalw, new MetadataBuffer(onListEntriesResponse.zzwz()), onListEntriesResponse.zzwA()));
        }
    }

    @SuppressLint({"MissingRemoteException"})
    static class zzj extends com.google.android.gms.drive.internal.zzt.zza {
        zzj(GoogleApiClient googleApiClient, Status status) {
            super(googleApiClient);
            zzb(status);
        }

        protected void zza(zzu com_google_android_gms_drive_internal_zzu) {
        }
    }

    public PendingResult<Status> cancelPendingActions(GoogleApiClient googleApiClient, List<String> list) {
        return ((zzu) googleApiClient.zza(Drive.zzaaz)).cancelPendingActions(googleApiClient, list);
    }

    public PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient googleApiClient, final String str) {
        return googleApiClient.zzc(new zzf(this, googleApiClient) {
            final /* synthetic */ zzs zzaxd;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new GetMetadataRequest(DriveId.zzdw(str), false), new zzd(this));
            }
        });
    }

    public DriveFolder getAppFolder(GoogleApiClient googleApiClient) {
        zzu com_google_android_gms_drive_internal_zzu = (zzu) googleApiClient.zza(Drive.zzaaz);
        if (com_google_android_gms_drive_internal_zzu.zzwq()) {
            DriveId zzwp = com_google_android_gms_drive_internal_zzu.zzwp();
            return zzwp != null ? new zzy(zzwp) : null;
        } else {
            throw new IllegalStateException("Client is not yet connected");
        }
    }

    public DriveFile getFile(GoogleApiClient googleApiClient, DriveId driveId) {
        if (driveId == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (googleApiClient.isConnected()) {
            return new zzw(driveId);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getFolder(GoogleApiClient googleApiClient, DriveId driveId) {
        if (driveId == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (googleApiClient.isConnected()) {
            return new zzy(driveId);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getRootFolder(GoogleApiClient googleApiClient) {
        zzu com_google_android_gms_drive_internal_zzu = (zzu) googleApiClient.zza(Drive.zzaaz);
        if (com_google_android_gms_drive_internal_zzu.zzwq()) {
            DriveId zzwo = com_google_android_gms_drive_internal_zzu.zzwo();
            return zzwo != null ? new zzy(zzwo) : null;
        } else {
            throw new IllegalStateException("Client is not yet connected");
        }
    }

    public PendingResult<BooleanResult> isAutobackupEnabled(GoogleApiClient googleApiClient) {
        return googleApiClient.zzc(new zzt<BooleanResult>(this, googleApiClient) {
            final /* synthetic */ zzs zzaxd;

            protected BooleanResult zzE(Status status) {
                return new BooleanResult(status, false);
            }

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zze(new zzd(this) {
                    final /* synthetic */ C06065 zzaxh;

                    public void zzam(boolean z) {
                        this.zzb(new BooleanResult(Status.zzalw, z));
                    }
                });
            }

            protected /* synthetic */ Result zzc(Status status) {
                return zzE(status);
            }
        });
    }

    public CreateFileActivityBuilder newCreateFileActivityBuilder() {
        return new CreateFileActivityBuilder();
    }

    public PendingResult<DriveContentsResult> newDriveContents(GoogleApiClient googleApiClient) {
        return zza(googleApiClient, DriveFile.MODE_WRITE_ONLY);
    }

    public OpenFileActivityBuilder newOpenFileActivityBuilder() {
        return new OpenFileActivityBuilder();
    }

    public PendingResult<MetadataBufferResult> query(GoogleApiClient googleApiClient, final Query query) {
        if (query != null) {
            return googleApiClient.zzc(new zzh(this, googleApiClient) {
                final /* synthetic */ zzs zzaxd;

                protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                    com_google_android_gms_drive_internal_zzu.zzwn().zza(new QueryRequest(query), new zzi(this));
                }
            });
        }
        throw new IllegalArgumentException("Query must be provided.");
    }

    public PendingResult<Status> requestSync(GoogleApiClient googleApiClient) {
        return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
            final /* synthetic */ zzs zzaxd;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new zzbr(this));
            }
        });
    }

    public PendingResult<DriveContentsResult> zza(GoogleApiClient googleApiClient, final int i) {
        return googleApiClient.zzc(new zzc(this, googleApiClient) {
            final /* synthetic */ zzs zzaxd;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zza(new CreateContentsRequest(i), new zza(this));
            }
        });
    }
}
