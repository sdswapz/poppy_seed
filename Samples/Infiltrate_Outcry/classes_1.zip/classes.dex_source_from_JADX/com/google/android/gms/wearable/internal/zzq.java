package com.google.android.gms.wearable.internal;

import android.util.Log;
import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.wearable.ChannelIOException;
import java.io.IOException;
import java.io.OutputStream;

public final class zzq extends OutputStream {
    private volatile zzm zzbCR;
    private final OutputStream zzbCT;

    class C16121 implements zzu {
        final /* synthetic */ zzq zzbCU;

        C16121(zzq com_google_android_gms_wearable_internal_zzq) {
            this.zzbCU = com_google_android_gms_wearable_internal_zzq;
        }

        public void zzb(zzm com_google_android_gms_wearable_internal_zzm) {
            this.zzbCU.zzc(com_google_android_gms_wearable_internal_zzm);
        }
    }

    public zzq(OutputStream outputStream) {
        this.zzbCT = (OutputStream) zzaa.zzz(outputStream);
    }

    private IOException zza(IOException iOException) {
        zzm com_google_android_gms_wearable_internal_zzm = this.zzbCR;
        if (com_google_android_gms_wearable_internal_zzm == null) {
            return iOException;
        }
        if (Log.isLoggable("ChannelOutputStream", 2)) {
            Log.v("ChannelOutputStream", "Caught IOException, but channel has been closed. Translating to ChannelIOException.", iOException);
        }
        return new ChannelIOException("Channel closed unexpectedly before stream was finished", com_google_android_gms_wearable_internal_zzm.zzbCH, com_google_android_gms_wearable_internal_zzm.zzbCI);
    }

    public void close() throws IOException {
        try {
            this.zzbCT.close();
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void flush() throws IOException {
        try {
            this.zzbCT.flush();
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(int i) throws IOException {
        try {
            this.zzbCT.write(i);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(byte[] bArr) throws IOException {
        try {
            this.zzbCT.write(bArr);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    public void write(byte[] bArr, int i, int i2) throws IOException {
        try {
            this.zzbCT.write(bArr, i, i2);
        } catch (IOException e) {
            throw zza(e);
        }
    }

    zzu zzNE() {
        return new C16121(this);
    }

    void zzc(zzm com_google_android_gms_wearable_internal_zzm) {
        this.zzbCR = com_google_android_gms_wearable_internal_zzm;
    }
}
