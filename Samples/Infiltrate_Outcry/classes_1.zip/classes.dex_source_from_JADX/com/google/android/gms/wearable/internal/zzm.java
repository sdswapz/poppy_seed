package com.google.android.gms.wearable.internal;

final class zzm {
    final int zzbCH;
    final int zzbCI;

    zzm(int i, int i2) {
        this.zzbCH = i;
        this.zzbCI = i2;
    }
}
