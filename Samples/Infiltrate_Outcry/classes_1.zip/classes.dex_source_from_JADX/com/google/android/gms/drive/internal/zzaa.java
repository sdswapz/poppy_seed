package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DrivePreferencesApi;
import com.google.android.gms.drive.DrivePreferencesApi.FileUploadPreferencesResult;
import com.google.android.gms.drive.FileUploadPreferences;

public class zzaa implements DrivePreferencesApi {

    private abstract class zzc extends zzt<FileUploadPreferencesResult> {
        final /* synthetic */ zzaa zzaxV;

        public zzc(zzaa com_google_android_gms_drive_internal_zzaa, GoogleApiClient googleApiClient) {
            this.zzaxV = com_google_android_gms_drive_internal_zzaa;
            super(googleApiClient);
        }

        protected FileUploadPreferencesResult zzK(Status status) {
            return new zzb(status, null);
        }

        protected /* synthetic */ Result zzc(Status status) {
            return zzK(status);
        }
    }

    private class zza extends zzd {
        private final com.google.android.gms.internal.zznt.zzb<FileUploadPreferencesResult> zzasz;
        final /* synthetic */ zzaa zzaxV;

        private zza(zzaa com_google_android_gms_drive_internal_zzaa, com.google.android.gms.internal.zznt.zzb<FileUploadPreferencesResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DrivePreferencesApi_FileUploadPreferencesResult) {
            this.zzaxV = com_google_android_gms_drive_internal_zzaa;
            this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DrivePreferencesApi_FileUploadPreferencesResult;
        }

        public void onError(Status status) throws RemoteException {
            this.zzasz.setResult(new zzb(status, null));
        }

        public void zza(OnDeviceUsagePreferenceResponse onDeviceUsagePreferenceResponse) throws RemoteException {
            this.zzasz.setResult(new zzb(Status.zzalw, onDeviceUsagePreferenceResponse.zzwv()));
        }
    }

    private class zzb implements FileUploadPreferencesResult {
        private final Status zzaaO;
        final /* synthetic */ zzaa zzaxV;
        private final FileUploadPreferences zzaxX;

        private zzb(zzaa com_google_android_gms_drive_internal_zzaa, Status status, FileUploadPreferences fileUploadPreferences) {
            this.zzaxV = com_google_android_gms_drive_internal_zzaa;
            this.zzaaO = status;
            this.zzaxX = fileUploadPreferences;
        }

        public FileUploadPreferences getFileUploadPreferences() {
            return this.zzaxX;
        }

        public Status getStatus() {
            return this.zzaaO;
        }
    }

    public PendingResult<FileUploadPreferencesResult> getFileUploadPreferences(GoogleApiClient googleApiClient) {
        return googleApiClient.zzc(new zzc(this, googleApiClient) {
            final /* synthetic */ zzaa zzaxV;

            protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                com_google_android_gms_drive_internal_zzu.zzwn().zzd(new zza(this));
            }
        });
    }

    public PendingResult<Status> setFileUploadPreferences(GoogleApiClient googleApiClient, FileUploadPreferences fileUploadPreferences) {
        if (fileUploadPreferences instanceof FileUploadPreferencesImpl) {
            final FileUploadPreferencesImpl fileUploadPreferencesImpl = (FileUploadPreferencesImpl) fileUploadPreferences;
            return googleApiClient.zzd(new com.google.android.gms.drive.internal.zzt.zza(this, googleApiClient) {
                final /* synthetic */ zzaa zzaxV;

                protected void zza(zzu com_google_android_gms_drive_internal_zzu) throws RemoteException {
                    com_google_android_gms_drive_internal_zzu.zzwn().zza(new SetFileUploadPreferencesRequest(fileUploadPreferencesImpl), new zzbr(this));
                }
            });
        }
        throw new IllegalArgumentException("Invalid preference value");
    }
}
