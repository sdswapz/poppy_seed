package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.android.gms.internal.zzsi;
import java.util.concurrent.Callable;

public class zzb {
    private static SharedPreferences zzaIQ = null;

    class C06541 implements Callable<SharedPreferences> {
        final /* synthetic */ Context zzqB;

        C06541(Context context) {
            this.zzqB = context;
        }

        public /* synthetic */ Object call() throws Exception {
            return zzyI();
        }

        public SharedPreferences zzyI() {
            return this.zzqB.getSharedPreferences("google_sdk_flags", 1);
        }
    }

    public static SharedPreferences zzn(Context context) {
        SharedPreferences sharedPreferences;
        synchronized (SharedPreferences.class) {
            if (zzaIQ == null) {
                zzaIQ = (SharedPreferences) zzsi.zzb(new C06541(context));
            }
            sharedPreferences = zzaIQ;
        }
        return sharedPreferences;
    }
}
