package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.zza;

public final class zze implements zza {
}
