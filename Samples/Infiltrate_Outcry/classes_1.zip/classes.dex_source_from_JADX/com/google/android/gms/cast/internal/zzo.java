package com.google.android.gms.cast.internal;

public interface zzo {
    void zzA(long j);

    void zza(long j, int i, Object obj);
}
