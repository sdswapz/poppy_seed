package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

final class zzay<T> {
    private final Map<T, zzbq<T>> zzaDR = new HashMap();

    private static class zza<T> extends zzb<Status> {
        private WeakReference<Map<T, zzbq<T>>> zzbDt;
        private WeakReference<T> zzbDu;

        zza(Map<T, zzbq<T>> map, T t, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status);
            this.zzbDt = new WeakReference(map);
            this.zzbDu = new WeakReference(t);
        }

        public void zza(Status status) {
            Map map = (Map) this.zzbDt.get();
            Object obj = this.zzbDu.get();
            if (!(status.getStatus().isSuccess() || map == null || obj == null)) {
                synchronized (map) {
                    zzbq com_google_android_gms_wearable_internal_zzbq = (zzbq) map.remove(obj);
                    if (com_google_android_gms_wearable_internal_zzbq != null) {
                        com_google_android_gms_wearable_internal_zzbq.clear();
                    }
                }
            }
            zzZ(status);
        }
    }

    private static class zzb<T> extends zzb<Status> {
        private WeakReference<Map<T, zzbq<T>>> zzbDt;
        private WeakReference<T> zzbDu;

        zzb(Map<T, zzbq<T>> map, T t, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status) {
            super(com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status);
            this.zzbDt = new WeakReference(map);
            this.zzbDu = new WeakReference(t);
        }

        public void zza(Status status) {
            Map map = (Map) this.zzbDt.get();
            Object obj = this.zzbDu.get();
            if (!(status.getStatus().getStatusCode() != 4002 || map == null || obj == null)) {
                synchronized (map) {
                    zzbq com_google_android_gms_wearable_internal_zzbq = (zzbq) map.remove(obj);
                    if (com_google_android_gms_wearable_internal_zzbq != null) {
                        com_google_android_gms_wearable_internal_zzbq.clear();
                    }
                }
            }
            zzZ(status);
        }
    }

    zzay() {
    }

    public void zza(zzbp com_google_android_gms_wearable_internal_zzbp, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, T t) throws RemoteException {
        synchronized (this.zzaDR) {
            zzbq com_google_android_gms_wearable_internal_zzbq = (zzbq) this.zzaDR.remove(t);
            if (com_google_android_gms_wearable_internal_zzbq == null) {
                com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status.setResult(new Status(4002));
                return;
            }
            com_google_android_gms_wearable_internal_zzbq.clear();
            ((zzax) com_google_android_gms_wearable_internal_zzbp.zztm()).zza(new zzb(this.zzaDR, t, com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status), new RemoveListenerRequest(com_google_android_gms_wearable_internal_zzbq));
        }
    }

    public void zza(zzbp com_google_android_gms_wearable_internal_zzbp, com.google.android.gms.internal.zznt.zzb<Status> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status, T t, zzbq<T> com_google_android_gms_wearable_internal_zzbq_T) throws RemoteException {
        synchronized (this.zzaDR) {
            if (this.zzaDR.get(t) != null) {
                com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status.setResult(new Status(4001));
                return;
            }
            this.zzaDR.put(t, com_google_android_gms_wearable_internal_zzbq_T);
            try {
                ((zzax) com_google_android_gms_wearable_internal_zzbp.zztm()).zza(new zza(this.zzaDR, t, com_google_android_gms_internal_zznt_zzb_com_google_android_gms_common_api_Status), new AddListenerRequest(com_google_android_gms_wearable_internal_zzbq_T));
            } catch (RemoteException e) {
                this.zzaDR.remove(t);
                throw e;
            }
        }
    }

    public void zzeE(IBinder iBinder) {
        synchronized (this.zzaDR) {
            zzax zzeD = com.google.android.gms.wearable.internal.zzax.zza.zzeD(iBinder);
            zzav com_google_android_gms_wearable_internal_zzbo_zzo = new zzo();
            for (Entry entry : this.zzaDR.entrySet()) {
                zzbq com_google_android_gms_wearable_internal_zzbq = (zzbq) entry.getValue();
                try {
                    zzeD.zza(com_google_android_gms_wearable_internal_zzbo_zzo, new AddListenerRequest(com_google_android_gms_wearable_internal_zzbq));
                    if (Log.isLoggable("WearableClient", 2)) {
                        String valueOf = String.valueOf(entry.getKey());
                        String valueOf2 = String.valueOf(com_google_android_gms_wearable_internal_zzbq);
                        Log.d("WearableClient", new StringBuilder((String.valueOf(valueOf).length() + 27) + String.valueOf(valueOf2).length()).append("onPostInitHandler: added: ").append(valueOf).append("/").append(valueOf2).toString());
                    }
                } catch (RemoteException e) {
                    String valueOf3 = String.valueOf(entry.getKey());
                    String valueOf4 = String.valueOf(com_google_android_gms_wearable_internal_zzbq);
                    Log.d("WearableClient", new StringBuilder((String.valueOf(valueOf3).length() + 32) + String.valueOf(valueOf4).length()).append("onPostInitHandler: Didn't add: ").append(valueOf3).append("/").append(valueOf4).toString());
                }
            }
        }
    }
}
