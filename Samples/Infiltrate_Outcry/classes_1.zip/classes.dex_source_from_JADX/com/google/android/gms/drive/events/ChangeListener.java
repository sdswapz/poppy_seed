package com.google.android.gms.drive.events;

public interface ChangeListener extends zzf {
    void onChange(ChangeEvent changeEvent);
}
