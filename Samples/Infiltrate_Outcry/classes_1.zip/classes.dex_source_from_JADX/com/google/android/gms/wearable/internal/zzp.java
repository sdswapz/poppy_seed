package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.wearable.ChannelIOException;
import java.io.IOException;
import java.io.InputStream;

public final class zzp extends InputStream {
    private final InputStream zzbCQ;
    private volatile zzm zzbCR;

    class C16111 implements zzu {
        final /* synthetic */ zzp zzbCS;

        C16111(zzp com_google_android_gms_wearable_internal_zzp) {
            this.zzbCS = com_google_android_gms_wearable_internal_zzp;
        }

        public void zzb(zzm com_google_android_gms_wearable_internal_zzm) {
            this.zzbCS.zza(com_google_android_gms_wearable_internal_zzm);
        }
    }

    public zzp(InputStream inputStream) {
        this.zzbCQ = (InputStream) zzaa.zzz(inputStream);
    }

    private int zzmF(int i) throws ChannelIOException {
        if (i == -1) {
            zzm com_google_android_gms_wearable_internal_zzm = this.zzbCR;
            if (com_google_android_gms_wearable_internal_zzm != null) {
                throw new ChannelIOException("Channel closed unexpectedly before stream was finished", com_google_android_gms_wearable_internal_zzm.zzbCH, com_google_android_gms_wearable_internal_zzm.zzbCI);
            }
        }
        return i;
    }

    public int available() throws IOException {
        return this.zzbCQ.available();
    }

    public void close() throws IOException {
        this.zzbCQ.close();
    }

    public void mark(int i) {
        this.zzbCQ.mark(i);
    }

    public boolean markSupported() {
        return this.zzbCQ.markSupported();
    }

    public int read() throws IOException {
        return zzmF(this.zzbCQ.read());
    }

    public int read(byte[] bArr) throws IOException {
        return zzmF(this.zzbCQ.read(bArr));
    }

    public int read(byte[] bArr, int i, int i2) throws IOException {
        return zzmF(this.zzbCQ.read(bArr, i, i2));
    }

    public void reset() throws IOException {
        this.zzbCQ.reset();
    }

    public long skip(long j) throws IOException {
        return this.zzbCQ.skip(j);
    }

    zzu zzNE() {
        return new C16111(this);
    }

    void zza(zzm com_google_android_gms_wearable_internal_zzm) {
        this.zzbCR = (zzm) zzaa.zzz(com_google_android_gms_wearable_internal_zzm);
    }
}
