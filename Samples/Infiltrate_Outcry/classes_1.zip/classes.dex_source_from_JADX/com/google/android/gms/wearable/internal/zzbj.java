package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.wearable.Channel;
import com.google.android.gms.wearable.ChannelApi.ChannelListener;

final class zzbj implements ChannelListener {
    private final String zzabf;
    private final ChannelListener zzbDH;

    zzbj(String str, ChannelListener channelListener) {
        this.zzabf = (String) zzaa.zzz(str);
        this.zzbDH = (ChannelListener) zzaa.zzz(channelListener);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof zzbj)) {
            return false;
        }
        zzbj com_google_android_gms_wearable_internal_zzbj = (zzbj) obj;
        return this.zzbDH.equals(com_google_android_gms_wearable_internal_zzbj.zzbDH) && this.zzabf.equals(com_google_android_gms_wearable_internal_zzbj.zzabf);
    }

    public int hashCode() {
        return (this.zzabf.hashCode() * 31) + this.zzbDH.hashCode();
    }

    public void onChannelClosed(Channel channel, int i, int i2) {
        this.zzbDH.onChannelClosed(channel, i, i2);
    }

    public void onChannelOpened(Channel channel) {
        this.zzbDH.onChannelOpened(channel);
    }

    public void onInputClosed(Channel channel, int i, int i2) {
        this.zzbDH.onInputClosed(channel, i, i2);
    }

    public void onOutputClosed(Channel channel, int i, int i2) {
        this.zzbDH.onOutputClosed(channel, i, i2);
    }
}
