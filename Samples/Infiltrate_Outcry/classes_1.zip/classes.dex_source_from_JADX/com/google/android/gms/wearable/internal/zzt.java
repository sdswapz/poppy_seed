package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.internal.zzaa;
import com.google.android.gms.wearable.internal.zzau.zza;

public final class zzt extends zza {
    private zzm zzbCR;
    private zzu zzbCV;
    private final Object zzpp = new Object();

    public void zza(zzu com_google_android_gms_wearable_internal_zzu) {
        synchronized (this.zzpp) {
            this.zzbCV = (zzu) zzaa.zzz(com_google_android_gms_wearable_internal_zzu);
            zzm com_google_android_gms_wearable_internal_zzm = this.zzbCR;
        }
        if (com_google_android_gms_wearable_internal_zzm != null) {
            com_google_android_gms_wearable_internal_zzu.zzb(com_google_android_gms_wearable_internal_zzm);
        }
    }

    public void zzz(int i, int i2) {
        synchronized (this.zzpp) {
            zzu com_google_android_gms_wearable_internal_zzu = this.zzbCV;
            zzm com_google_android_gms_wearable_internal_zzm = new zzm(i, i2);
            this.zzbCR = com_google_android_gms_wearable_internal_zzm;
        }
        if (com_google_android_gms_wearable_internal_zzu != null) {
            com_google_android_gms_wearable_internal_zzu.zzb(com_google_android_gms_wearable_internal_zzm);
        }
    }
}
