package com.google.android.gms.clearcut;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface zzc {
    PendingResult<Status> zza(GoogleApiClient googleApiClient, LogEventParcelable logEventParcelable);
}
