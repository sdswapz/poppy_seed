package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.zzc;

public final class zzg implements zzc {
}
