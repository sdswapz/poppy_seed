package com.google.android.gms.cast.internal;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

public abstract class zzc extends zzd {
    protected final Handler mHandler;
    protected final long zzahS;
    protected final Runnable zzahT;
    protected boolean zzahU;

    private class zza implements Runnable {
        final /* synthetic */ zzc zzahV;

        private zza(zzc com_google_android_gms_cast_internal_zzc) {
            this.zzahV = com_google_android_gms_cast_internal_zzc;
        }

        public void run() {
            this.zzahV.zzahU = false;
            this.zzahV.zzae(this.zzahV.zzB(SystemClock.elapsedRealtime()));
        }
    }

    public zzc(String str, String str2, String str3) {
        this(str, str2, str3, 1000);
    }

    public zzc(String str, String str2, String str3, long j) {
        super(str, str2, str3);
        this.mHandler = new Handler(Looper.getMainLooper());
        this.zzahT = new zza();
        this.zzahS = j;
        zzae(false);
    }

    protected abstract boolean zzB(long j);

    protected final void zzae(boolean z) {
        if (this.zzahU != z) {
            this.zzahU = z;
            if (z) {
                this.mHandler.postDelayed(this.zzahT, this.zzahS);
            } else {
                this.mHandler.removeCallbacks(this.zzahT);
            }
        }
    }

    public void zzqo() {
        zzae(false);
    }
}
