package com.google.android.gms.flags.impl;

import android.content.SharedPreferences;
import com.google.android.gms.internal.zzsi;
import java.util.concurrent.Callable;

public abstract class zza<T> {

    public static class zza extends zza<Boolean> {

        class C06501 implements Callable<Boolean> {
            final /* synthetic */ SharedPreferences zzaIK;
            final /* synthetic */ String zzaIL;
            final /* synthetic */ Boolean zzaIM;

            C06501(SharedPreferences sharedPreferences, String str, Boolean bool) {
                this.zzaIK = sharedPreferences;
                this.zzaIL = str;
                this.zzaIM = bool;
            }

            public /* synthetic */ Object call() throws Exception {
                return zzji();
            }

            public Boolean zzji() {
                return Boolean.valueOf(this.zzaIK.getBoolean(this.zzaIL, this.zzaIM.booleanValue()));
            }
        }

        public static Boolean zza(SharedPreferences sharedPreferences, String str, Boolean bool) {
            return (Boolean) zzsi.zzb(new C06501(sharedPreferences, str, bool));
        }
    }

    public static class zzb extends zza<Integer> {

        class C06511 implements Callable<Integer> {
            final /* synthetic */ SharedPreferences zzaIK;
            final /* synthetic */ String zzaIL;
            final /* synthetic */ Integer zzaIN;

            C06511(SharedPreferences sharedPreferences, String str, Integer num) {
                this.zzaIK = sharedPreferences;
                this.zzaIL = str;
                this.zzaIN = num;
            }

            public /* synthetic */ Object call() throws Exception {
                return zzyG();
            }

            public Integer zzyG() {
                return Integer.valueOf(this.zzaIK.getInt(this.zzaIL, this.zzaIN.intValue()));
            }
        }

        public static Integer zza(SharedPreferences sharedPreferences, String str, Integer num) {
            return (Integer) zzsi.zzb(new C06511(sharedPreferences, str, num));
        }
    }

    public static class zzc extends zza<Long> {

        class C06521 implements Callable<Long> {
            final /* synthetic */ SharedPreferences zzaIK;
            final /* synthetic */ String zzaIL;
            final /* synthetic */ Long zzaIO;

            C06521(SharedPreferences sharedPreferences, String str, Long l) {
                this.zzaIK = sharedPreferences;
                this.zzaIL = str;
                this.zzaIO = l;
            }

            public /* synthetic */ Object call() throws Exception {
                return zzyH();
            }

            public Long zzyH() {
                return Long.valueOf(this.zzaIK.getLong(this.zzaIL, this.zzaIO.longValue()));
            }
        }

        public static Long zza(SharedPreferences sharedPreferences, String str, Long l) {
            return (Long) zzsi.zzb(new C06521(sharedPreferences, str, l));
        }
    }

    public static class zzd extends zza<String> {

        class C06531 implements Callable<String> {
            final /* synthetic */ SharedPreferences zzaIK;
            final /* synthetic */ String zzaIL;
            final /* synthetic */ String zzaIP;

            C06531(SharedPreferences sharedPreferences, String str, String str2) {
                this.zzaIK = sharedPreferences;
                this.zzaIL = str;
                this.zzaIP = str2;
            }

            public /* synthetic */ Object call() throws Exception {
                return zzmU();
            }

            public String zzmU() {
                return this.zzaIK.getString(this.zzaIL, this.zzaIP);
            }
        }

        public static String zza(SharedPreferences sharedPreferences, String str, String str2) {
            return (String) zzsi.zzb(new C06531(sharedPreferences, str, str2));
        }
    }
}
