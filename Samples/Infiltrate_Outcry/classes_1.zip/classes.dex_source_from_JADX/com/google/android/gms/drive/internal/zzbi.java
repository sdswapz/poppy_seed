package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveApi.DriveContentsResult;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.internal.zznt.zzb;

class zzbi extends zzd {
    private final zzb<DriveContentsResult> zzasz;
    private final DownloadProgressListener zzayT;

    zzbi(zzb<DriveContentsResult> com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveContentsResult, DownloadProgressListener downloadProgressListener) {
        this.zzasz = com_google_android_gms_internal_zznt_zzb_com_google_android_gms_drive_DriveApi_DriveContentsResult;
        this.zzayT = downloadProgressListener;
    }

    public void onError(Status status) throws RemoteException {
        this.zzasz.setResult(new zzb(status, null));
    }

    public void zza(OnContentsResponse onContentsResponse) throws RemoteException {
        this.zzasz.setResult(new zzb(onContentsResponse.zzwu() ? new Status(-1) : Status.zzalw, new zzv(onContentsResponse.zzwt())));
    }

    public void zza(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
        if (this.zzayT != null) {
            this.zzayT.onProgress(onDownloadProgressResponse.zzww(), onDownloadProgressResponse.zzwx());
        }
    }
}
